/*    */ package net.highmc.medal;
/*    */ import java.util.List;
/*    */ import net.md_5.bungee.api.ChatColor;
/*    */ 
/*    */ public class Medal {
/*    */   private String medalName;
/*    */   private String symbol;
/*    */   
/*    */   public Medal(String medalName, String symbol, String chatColor, List<String> aliases) {
/* 10 */     this.medalName = medalName; this.symbol = symbol; this.chatColor = chatColor; this.aliases = aliases;
/*    */   } private String chatColor; private List<String> aliases;
/*    */   public String getMedalName() {
/* 13 */     return this.medalName; } public String getSymbol() {
/* 14 */     return this.symbol;
/*    */   }
/*    */   public List<String> getAliases() {
/* 17 */     return this.aliases;
/*    */   }
/*    */   
/*    */   public ChatColor getChatColor() {
/* 21 */     return ChatColor.valueOf(this.chatColor);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 26 */     if (obj == this) {
/* 27 */       return true;
/*    */     }
/* 29 */     if (obj instanceof Medal) {
/* 30 */       Medal medal = (Medal)obj;
/* 31 */       return medal.getMedalName().equals(getMedalName());
/*    */     } 
/*    */     
/* 34 */     return super.equals(obj);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/medal/Medal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */