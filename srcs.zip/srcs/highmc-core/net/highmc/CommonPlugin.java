/*     */ package net.highmc;
/*     */ 
/*     */ import com.google.common.base.Charsets;
/*     */ import com.google.gson.stream.JsonReader;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import java.util.logging.Logger;
/*     */ import net.highmc.backend.data.DiscordData;
/*     */ import net.highmc.backend.data.MemberData;
/*     */ import net.highmc.backend.data.PartyData;
/*     */ import net.highmc.backend.data.ServerData;
/*     */ import net.highmc.backend.data.SkinData;
/*     */ import net.highmc.backend.data.impl.DiscordDataImpl;
/*     */ import net.highmc.backend.data.impl.MemberDataImpl;
/*     */ import net.highmc.backend.data.impl.PartyDataImpl;
/*     */ import net.highmc.backend.data.impl.ServerDataImpl;
/*     */ import net.highmc.backend.data.impl.SkinDataImpl;
/*     */ import net.highmc.backend.mongodb.MongoConnection;
/*     */ import net.highmc.backend.redis.RedisConnection;
/*     */ import net.highmc.manager.ConfigurationManager;
/*     */ import net.highmc.manager.MemberManager;
/*     */ import net.highmc.manager.PartyManager;
/*     */ import net.highmc.manager.ReportManager;
/*     */ import net.highmc.manager.StatusManager;
/*     */ import net.highmc.member.party.Party;
/*     */ import net.highmc.packet.Packet;
/*     */ import net.highmc.packet.types.configuration.ConfigurationFieldUpdate;
/*     */ import net.highmc.packet.types.configuration.ConfigurationUpdate;
/*     */ import net.highmc.permission.Group;
/*     */ import net.highmc.server.ServerManager;
/*     */ import net.highmc.server.ServerType;
/*     */ import net.highmc.server.loadbalancer.BaseBalancer;
/*     */ import net.highmc.server.loadbalancer.server.MinigameServer;
/*     */ import net.highmc.server.loadbalancer.server.MinigameState;
/*     */ import net.highmc.server.loadbalancer.server.ProxiedServer;
/*     */ import net.highmc.utils.FileCreator;
/*     */ import net.highmc.utils.configuration.DefaultFileCreator;
/*     */ import net.highmc.utils.mojang.NameFetcher;
/*     */ import net.highmc.utils.mojang.UUIDFetcher;
/*     */ 
/*     */ public class CommonPlugin
/*     */ {
/*     */   private static CommonPlugin instance;
/*     */   private PluginPlatform pluginPlatform;
/*     */   private PluginInfo pluginInfo;
/*     */   private FileCreator fileCreator;
/*     */   
/*     */   public static CommonPlugin getInstance() {
/*  55 */     return instance;
/*     */   }
/*     */   
/*  58 */   public PluginPlatform getPluginPlatform() { return this.pluginPlatform; }
/*  59 */   public void setPluginInfo(PluginInfo pluginInfo) { this.pluginInfo = pluginInfo; }
/*  60 */   public PluginInfo getPluginInfo() { return this.pluginInfo; } public FileCreator getFileCreator() {
/*  61 */     return this.fileCreator;
/*     */   }
/*  63 */   private ConfigurationManager configurationManager = new ConfigurationManager(); public void setConfigurationManager(ConfigurationManager configurationManager) { this.configurationManager = configurationManager; } public ConfigurationManager getConfigurationManager() {
/*  64 */     return this.configurationManager;
/*     */   }
/*  66 */   private MemberManager memberManager = new MemberManager(); public void setMemberManager(MemberManager memberManager) { this.memberManager = memberManager; } public MemberManager getMemberManager() {
/*  67 */     return this.memberManager;
/*  68 */   } private PartyManager partyManager = new PartyManager(); public void setPartyManager(PartyManager partyManager) { this.partyManager = partyManager; } public PartyManager getPartyManager() {
/*  69 */     return this.partyManager;
/*  70 */   } private StatusManager statusManager = new StatusManager(); public void setStatusManager(StatusManager statusManager) { this.statusManager = statusManager; } public StatusManager getStatusManager() {
/*  71 */     return this.statusManager;
/*  72 */   } private DiscordData discordData; private MemberData memberData; private PartyData partyData; private ReportManager reportManager = new ReportManager(); private ServerData serverData; private SkinData skinData; public void setReportManager(ReportManager reportManager) { this.reportManager = reportManager; } public ReportManager getReportManager() {
/*  73 */     return this.reportManager;
/*     */   }
/*  75 */   public void setDiscordData(DiscordData discordData) { this.discordData = discordData; }
/*  76 */   public DiscordData getDiscordData() { return this.discordData; }
/*  77 */   public void setMemberData(MemberData memberData) { this.memberData = memberData; }
/*  78 */   public MemberData getMemberData() { return this.memberData; }
/*  79 */   public void setPartyData(PartyData partyData) { this.partyData = partyData; }
/*  80 */   public PartyData getPartyData() { return this.partyData; }
/*  81 */   public void setServerData(ServerData serverData) { this.serverData = serverData; }
/*  82 */   public ServerData getServerData() { return this.serverData; }
/*  83 */   public void setSkinData(SkinData skinData) { this.skinData = skinData; } public SkinData getSkinData() {
/*  84 */     return this.skinData;
/*     */   }
/*  86 */   private UUIDFetcher uuidFetcher = new UUIDFetcher(); public UUIDFetcher getUuidFetcher() { return this.uuidFetcher; }
/*  87 */    private NameFetcher nameFetcher = new NameFetcher(); public NameFetcher getNameFetcher() { return this.nameFetcher; }
/*     */   
/*  89 */   private String serverId = "highmc.net"; public void setServerId(String serverId) { this.serverId = serverId; } public String getServerId() {
/*  90 */     return this.serverId;
/*  91 */   } private String serverAddress = "0.0.0.0"; public void setServerAddress(String serverAddress) { this.serverAddress = serverAddress; } public String getServerAddress() {
/*  92 */     return this.serverAddress;
/*  93 */   } private ServerType serverType = ServerType.BUNGEECORD; public void setServerType(ServerType serverType) { this.serverType = serverType; }
/*  94 */   public ServerType getServerType() { return this.serverType; } private boolean joinEnabled = true;
/*  95 */   public void setJoinEnabled(boolean joinEnabled) { this.joinEnabled = joinEnabled; } public boolean isJoinEnabled() {
/*  96 */     return this.joinEnabled;
/*     */   }
/*  98 */   private String map = "Unknown"; public void setMap(String map) { this.map = map; } public String getMap() {
/*  99 */     return this.map;
/* 100 */   } private MinigameState minigameState = MinigameState.NONE; private int serverTime; private Class<? extends Party> partyClass; private MongoConnection mongoConnection; private RedisConnection redisConnection; public void setMinigameState(MinigameState minigameState) { this.minigameState = minigameState; }
/* 101 */   public MinigameState getMinigameState() { return this.minigameState; }
/* 102 */   public void setServerTime(int serverTime) { this.serverTime = serverTime; } public int getServerTime() {
/* 103 */     return this.serverTime;
/*     */   }
/* 105 */   public void setPartyClass(Class<? extends Party> partyClass) { this.partyClass = partyClass; } public Class<? extends Party> getPartyClass() {
/* 106 */     return this.partyClass;
/*     */   }
/* 108 */   public MongoConnection getMongoConnection() { return this.mongoConnection; } public RedisConnection getRedisConnection() {
/* 109 */     return this.redisConnection;
/*     */   }
/*     */   public static void set(Group group, int id) throws Exception {
/* 112 */     Field field = Group.class.getDeclaredField("id");
/* 113 */     field.setAccessible(true);
/* 114 */     field.set(group, Integer.valueOf(id));
/*     */   }
/*     */   
/*     */   public CommonPlugin(PluginPlatform pluginPlatform) {
/* 118 */     instance = this;
/*     */     
/* 120 */     this.pluginPlatform = pluginPlatform;
/* 121 */     this.fileCreator = (FileCreator)new DefaultFileCreator();
/*     */     
/* 123 */     loadConfig();
/*     */     
/*     */     try {
/* 126 */       this.mongoConnection = new MongoConnection(this.pluginInfo.getMongoCredentials());
/* 127 */       this.redisConnection = new RedisConnection(this.pluginInfo.getRedisCredentials());
/*     */       
/* 129 */       this.mongoConnection.connect();
/* 130 */       this.redisConnection.connect();
/*     */       
/* 132 */       setDiscordData((DiscordData)new DiscordDataImpl(this.redisConnection));
/* 133 */       setMemberData((MemberData)new MemberDataImpl(this.mongoConnection, this.redisConnection));
/* 134 */       setPartyData((PartyData)new PartyDataImpl(this.mongoConnection));
/* 135 */       setServerData((ServerData)new ServerDataImpl(this.redisConnection));
/* 136 */       setSkinData((SkinData)new SkinDataImpl(this.redisConnection));
/* 137 */     } catch (Exception ex) {
/* 138 */       pluginPlatform.shutdown("The database has not loaded!");
/* 139 */       ex.printStackTrace();
/*     */     } 
/*     */     
/* 142 */     this.reportManager.loadReports();
/*     */   }
/*     */ 
/*     */   
/*     */   public void loadConfig() {
/*     */     try {
/* 148 */       FileInputStream fileInputStream = new FileInputStream(this.fileCreator.createFile("server.json", CommonConst.PRINCIPAL_DIRECTORY));
/* 149 */       InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream, "UTF-8");
/*     */       
/* 151 */       JsonReader jsonReader = new JsonReader(inputStreamReader);
/* 152 */       this.pluginInfo = (PluginInfo)CommonConst.GSON_PRETTY.fromJson(jsonReader, PluginInfo.class);
/*     */       
/* 154 */       jsonReader.close();
/* 155 */       inputStreamReader.close();
/* 156 */       fileInputStream.close();
/* 157 */     } catch (Exception ex) {
/* 158 */       ex.printStackTrace();
/* 159 */       this.pluginPlatform.shutdown("The configuration server.json not found!");
/*     */     } 
/*     */   }
/*     */   
/*     */   public void saveConfig(String fieldName) {
/*     */     try {
/* 165 */       this.pluginInfo.sort();
/*     */       
/* 167 */       String json = CommonConst.GSON_PRETTY.toJson(this.pluginInfo);
/*     */ 
/*     */       
/* 170 */       FileOutputStream fileOutputStream = new FileOutputStream(this.fileCreator.createFile("server.json", CommonConst.PRINCIPAL_DIRECTORY));
/* 171 */       OutputStreamWriter outputStreamReader = new OutputStreamWriter(fileOutputStream, "UTF-8");
/*     */       
/* 173 */       BufferedWriter bufferedWriter = new BufferedWriter(outputStreamReader);
/*     */       
/* 175 */       bufferedWriter.write(json);
/*     */       
/* 177 */       bufferedWriter.flush();
/* 178 */       bufferedWriter.close();
/* 179 */       fileOutputStream.close();
/* 180 */       outputStreamReader.close();
/* 181 */     } catch (Exception ex) {
/* 182 */       ex.printStackTrace();
/* 183 */       this.pluginPlatform.shutdown("The configuration server.json not found!");
/*     */     } 
/*     */     
/* 186 */     getInstance().getServerData().sendPacket((Packet)new ConfigurationFieldUpdate(fieldName));
/*     */   }
/*     */   
/*     */   public void saveConfig() {
/*     */     try {
/* 191 */       this.pluginInfo.sort();
/*     */       
/* 193 */       String json = CommonConst.GSON_PRETTY.toJson(this.pluginInfo);
/*     */ 
/*     */       
/* 196 */       FileOutputStream fileOutputStream = new FileOutputStream(this.fileCreator.createFile("server.json", CommonConst.PRINCIPAL_DIRECTORY));
/* 197 */       OutputStreamWriter outputStreamReader = new OutputStreamWriter(fileOutputStream, "UTF-8");
/*     */       
/* 199 */       BufferedWriter bufferedWriter = new BufferedWriter(outputStreamReader);
/*     */       
/* 201 */       bufferedWriter.write(json);
/*     */       
/* 203 */       bufferedWriter.flush();
/* 204 */       bufferedWriter.close();
/* 205 */       fileOutputStream.close();
/* 206 */       outputStreamReader.close();
/* 207 */     } catch (Exception ex) {
/* 208 */       ex.printStackTrace();
/* 209 */       this.pluginPlatform.shutdown("The configuration server.json not found!");
/*     */     } 
/*     */     
/* 212 */     getInstance().getServerData().sendPacket((Packet)new ConfigurationUpdate());
/*     */   }
/*     */   
/*     */   public Logger getLogger() {
/* 216 */     return this.pluginPlatform.getLogger();
/*     */   }
/*     */   
/*     */   public void debug(String message) {
/* 220 */     if (this.pluginInfo.isDebug()) {
/* 221 */       System.out.println("[DEBUG] " + message);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadServers(ServerManager serverManager) {
/* 226 */     for (Map.Entry<String, Map<String, String>> entry : (Iterable<Map.Entry<String, Map<String, String>>>)getServerData().loadServers().entrySet()) {
/*     */       try {
/* 228 */         if (!((Map)entry.getValue()).containsKey("type")) {
/*     */           continue;
/*     */         }
/*     */         
/* 232 */         if (!((Map)entry.getValue()).containsKey("address")) {
/*     */           continue;
/*     */         }
/*     */         
/* 236 */         if (!((Map)entry.getValue()).containsKey("maxplayers")) {
/*     */           continue;
/*     */         }
/*     */         
/* 240 */         if (ServerType.valueOf(((String)((Map)entry.getValue()).get("type")).toUpperCase()) == ServerType.BUNGEECORD) {
/*     */           continue;
/*     */         }
/*     */         
/* 244 */         ProxiedServer server = serverManager.addActiveServer((String)((Map)entry.getValue()).get("address"), entry.getKey(), 
/* 245 */             ServerType.valueOf(((String)((Map)entry.getValue()).get("type")).toUpperCase()), 
/* 246 */             Integer.valueOf((String)((Map)entry.getValue()).get("maxplayers")).intValue(), 
/* 247 */             Long.valueOf((String)((Map)entry.getValue()).get("starttime")).longValue());
/*     */         
/* 249 */         server.setOnlinePlayers(getServerData().getPlayers(entry.getKey()));
/* 250 */         server.setJoinEnabled(Boolean.valueOf((String)((Map)entry.getValue()).get("joinenabled")).booleanValue());
/*     */         
/* 252 */         if (server instanceof MinigameServer) {
/* 253 */           MinigameServer minigameServer = (MinigameServer)server;
/*     */           
/* 255 */           minigameServer.setTime(getServerData().getTime(entry.getKey()));
/* 256 */           minigameServer.setMap(getServerData().getMap(entry.getKey()));
/* 257 */           minigameServer.setState(getServerData().getState(entry.getKey()));
/*     */         } 
/*     */         
/* 260 */         debug("The server " + server.getServerId() + " (" + server.getServerType() + " - " + server
/* 261 */             .getOnlinePlayers() + "/" + server.getMaxPlayers() + ") has been loaded!");
/* 262 */       } catch (Exception exception) {}
/*     */     } 
/*     */ 
/*     */     
/* 266 */     int players = 0;
/*     */     
/* 268 */     for (BaseBalancer<?> server : (Iterable<BaseBalancer<?>>)serverManager.getBalancers().values()) {
/* 269 */       players += server.getTotalNumber();
/*     */     }
/* 271 */     serverManager.setTotalMembers(players);
/*     */   }
/*     */   
/*     */   public UUID getUniqueId(String name) {
/* 275 */     return getUniqueId(name, true);
/*     */   }
/*     */   
/*     */   public UUID getUniqueId(String name, boolean cracked) {
/* 279 */     UUID uniqueId = getMemberData().getUniqueId(name);
/*     */     
/* 281 */     if (uniqueId != null) {
/* 282 */       return uniqueId;
/*     */     }
/* 284 */     uniqueId = this.uuidFetcher.getUUID(name);
/* 285 */     return (uniqueId == null && cracked) ? UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(Charsets.UTF_8)) : uniqueId;
/*     */   }
/*     */ 
/*     */   
/*     */   public String formatTime(long time) {
/* 290 */     String[] all = CommonConst.FULL_DATE_FORMAT.format(Long.valueOf(time)).split(" ");
/* 291 */     String month = all[2];
/* 292 */     String[] dates = all[0].split("/");
/* 293 */     return dates[0] + " de " + month.toLowerCase() + " de " + dates[2] + " às " + all[1];
/*     */   }
/*     */   
/*     */   public static CommonPlugin createVoid() {
/* 297 */     return new CommonPlugin(new PluginPlatform()
/*     */         {
/*     */           public void shutdown(String message) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void runAsync(Runnable runnable, long delay, long repeat) {
/* 307 */             runnable.run();
/*     */           }
/*     */ 
/*     */           
/*     */           public void runAsync(Runnable runnable, long delay) {
/* 312 */             runnable.run();
/*     */           }
/*     */ 
/*     */           
/*     */           public void runAsync(Runnable runnable) {
/* 317 */             runnable.run();
/*     */           }
/*     */ 
/*     */           
/*     */           public void run(Runnable runnable, long delay, long repeat) {
/* 322 */             runnable.run();
/*     */           }
/*     */ 
/*     */           
/*     */           public void run(Runnable runnable, long delay) {
/* 327 */             runnable.run();
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           public UUID getUniqueId(String playerName) {
/* 333 */             return null;
/*     */           }
/*     */ 
/*     */           
/*     */           public Logger getLogger() {
/* 338 */             return Logger.getLogger("premium");
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void dispatchCommand(String command) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void broadcast(String string) {}
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void broadcast(String string, String permission) {}
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public String getName(UUID uuid) {
/* 362 */             return null;
/*     */           }
/*     */         });
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/CommonPlugin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */