/*    */ package net.highmc.manager;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.report.Report;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReportManager
/*    */ {
/* 16 */   private Map<UUID, Report> reportMap = new HashMap<>();
/*    */ 
/*    */   
/*    */   public Collection<Report> getReports() {
/* 20 */     return this.reportMap.values();
/*    */   }
/*    */   
/*    */   public void loadReport(Report report) {
/* 24 */     this.reportMap.put(report.getReportId(), report);
/*    */   }
/*    */   
/*    */   public void createReport(Report report) {
/* 28 */     loadReport(report);
/* 29 */     CommonPlugin.getInstance().getMemberData().createReport(report);
/*    */   }
/*    */   
/*    */   public void loadReports() {
/* 33 */     Collection<Report> loadReports = CommonPlugin.getInstance().getMemberData().loadReports();
/*    */     
/* 35 */     for (Report report : loadReports)
/* 36 */       loadReport(report); 
/*    */   }
/*    */   
/*    */   public Report getReportById(UUID uniqueId) {
/* 40 */     return this.reportMap.get(uniqueId);
/*    */   }
/*    */   
/*    */   public Report getReportByName(String playerName) {
/* 44 */     return this.reportMap.values().stream().filter(report -> report.getPlayerName().equals(playerName)).findFirst()
/* 45 */       .orElse(null);
/*    */   }
/*    */   
/*    */   public void deleteReport(UUID reportId) {
/* 49 */     this.reportMap.remove(reportId);
/*    */   }
/*    */   
/*    */   public void notify(UUID uniqueId) {
/* 53 */     Report report = getReportById(uniqueId);
/*    */     
/* 55 */     if (report != null)
/* 56 */       report.notifyPunish(); 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/manager/ReportManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */