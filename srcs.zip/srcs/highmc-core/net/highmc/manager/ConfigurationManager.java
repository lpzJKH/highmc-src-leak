/*    */ package net.highmc.manager;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import net.highmc.utils.configuration.Configuration;
/*    */ import net.highmc.utils.configuration.impl.JsonConfiguration;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigurationManager
/*    */ {
/*    */   private Map<String, Configuration> configurationMap;
/*    */   
/*    */   public static void main(String[] args) {
/* 17 */     ConfigurationManager configurationManager = new ConfigurationManager();
/*    */     try {
/* 19 */       System.out.println(((JsonConfiguration)configurationManager
/* 20 */           .<JsonConfiguration>loadConfig("bedwars.json", "C:\\Users\\ALLAN\\Desktop\\Servidores\\Bedwars", false, JsonConfiguration.class))
/* 21 */           .loadConfig().get("islands"));
/* 22 */     } catch (Exception e) {
/*    */       
/* 24 */       e.printStackTrace();
/*    */     } 
/*    */     
/* 27 */     System.out.println(configurationManager.getConfigByName("bedwars").get("islands"));
/*    */   }
/*    */   
/*    */   public ConfigurationManager() {
/* 31 */     this.configurationMap = new HashMap<>();
/*    */   }
/*    */   
/*    */   public Collection<String> getConfigs() {
/* 35 */     return this.configurationMap.keySet();
/*    */   }
/*    */   
/*    */   public Configuration getConfigByName(String configName) {
/* 39 */     if (configName.contains("\\.")) {
/* 40 */       configName = configName.split("\\.")[0];
/*    */     }
/* 42 */     return this.configurationMap.get(configName.toLowerCase());
/*    */   }
/*    */ 
/*    */   
/*    */   public <T extends Configuration> T loadConfig(String fileName, String pathName, boolean saveAsDefault, Class<T> clazz) {
/* 47 */     return loadConfig(fileName, new File(pathName), saveAsDefault, clazz);
/*    */   }
/*    */   
/*    */   public <T extends Configuration> T loadConfig(File file, boolean saveAsDefault, Class<T> clazz) {
/* 51 */     return loadConfig(file.getName(), file.getParentFile(), saveAsDefault, clazz);
/*    */   }
/*    */   
/*    */   public <T extends Configuration> T loadConfig(String fileName, File file, boolean saveAsDefault, Class<T> clazz) {
/*    */     try {
/* 56 */       Configuration configuration = clazz.getConstructor(new Class[] { String.class, String.class, boolean.class }).newInstance(new Object[] { fileName, file
/* 57 */             .getAbsolutePath(), Boolean.valueOf(saveAsDefault) });
/*    */       
/* 59 */       String configName = fileName.toLowerCase();
/*    */       
/* 61 */       if (configName.contains(".")) {
/* 62 */         configName = configName.split("\\.")[0];
/*    */       }
/* 64 */       this.configurationMap.put(configName, configuration);
/* 65 */       return (T)configuration;
/* 66 */     } catch (InstantiationException|IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException|NoSuchMethodException|SecurityException e) {
/*    */       
/* 68 */       e.printStackTrace();
/*    */ 
/*    */       
/* 71 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/manager/ConfigurationManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */