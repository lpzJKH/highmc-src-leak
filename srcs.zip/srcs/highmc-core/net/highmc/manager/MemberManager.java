/*     */ package net.highmc.manager;
/*     */ 
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import java.util.stream.Collectors;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.member.Member;
/*     */ import net.md_5.bungee.api.chat.BaseComponent;
/*     */ import net.md_5.bungee.api.chat.TextComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MemberManager
/*     */ {
/*  21 */   private Map<UUID, Member> memberMap = new HashMap<>();
/*     */ 
/*     */   
/*     */   public void loadMember(Member member) {
/*  25 */     this.memberMap.put(member.getUniqueId(), member);
/*  26 */     CommonPlugin.getInstance()
/*  27 */       .debug("The member " + member.getPlayerName() + "(" + member.getUniqueId() + ") has been loaded.");
/*     */   }
/*     */   
/*     */   public <T extends Member> T getMember(UUID uniqueId, Class<T> clazz) {
/*  31 */     if (this.memberMap.containsKey(uniqueId)) {
/*  32 */       return clazz.cast(this.memberMap.get(uniqueId));
/*     */     }
/*  34 */     return null;
/*     */   }
/*     */   
/*     */   public Member getMember(UUID uniqueId) {
/*  38 */     return this.memberMap.get(uniqueId);
/*     */   }
/*     */   
/*     */   public Member getMemberByName(String playerName) {
/*  42 */     return getMembers().stream().filter(member -> member.getName().equalsIgnoreCase(playerName)).findFirst()
/*  43 */       .orElse(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends Member> T getMemberByName(String playerName, Class<T> clazz) {
/*  48 */     Member orElse = getMembers().stream().filter(member -> member.getName().equalsIgnoreCase(playerName)).findFirst().orElse(null);
/*  49 */     return (orElse == null) ? null : clazz.cast(orElse);
/*     */   }
/*     */   
/*     */   public void unloadMember(UUID uniqueId) {
/*  53 */     unloadMember(getMember(uniqueId));
/*     */   }
/*     */   
/*     */   public void unloadMember(Member member) {
/*  57 */     if (member != null) {
/*  58 */       this.memberMap.remove(member.getUniqueId());
/*  59 */       CommonPlugin.getInstance().debug("The member " + member
/*  60 */           .getPlayerName() + "(" + member.getUniqueId() + ") has been unloaded.");
/*     */     } 
/*     */   }
/*     */   
/*     */   public Collection<Member> getMembers() {
/*  65 */     return (Collection<Member>)ImmutableList.copyOf(this.memberMap.values());
/*     */   }
/*     */   
/*     */   public <T extends Member> Collection<T> getMembers(Class<T> clazz) {
/*  69 */     return (Collection<T>)getMembers().stream().filter(member -> clazz.isAssignableFrom(member.getClass()))
/*  70 */       .map(member -> (Member)clazz.cast(member)).collect(Collectors.toList());
/*     */   }
/*     */   
/*     */   public void broadcast(String message, String permission) {
/*  74 */     getMembers().stream().filter(member -> member.hasPermission(permission))
/*  75 */       .forEach(member -> member.sendMessage(message));
/*  76 */     System.out.println(message);
/*     */   }
/*     */   
/*     */   public void staffLog(String message, boolean format) {
/*  80 */     getMembers().stream()
/*  81 */       .filter(member -> (member.hasPermission("staff.log") && member.getMemberConfiguration().isSeeingLogs()))
/*     */       
/*  83 */       .forEach(member -> member.sendMessage(format ? ("§7[" + message + "§7]") : message));
/*  84 */     System.out.println(message);
/*     */   }
/*     */ 
/*     */   
/*     */   public void staffLog(TextComponent textComponent) {
/*  89 */     getMembers().stream()
/*  90 */       .filter(member -> (member.hasPermission("staff.log") && member.getMemberConfiguration().isSeeingLogs()))
/*     */       
/*  92 */       .forEach(member -> member.sendMessage((BaseComponent)textComponent));
/*  93 */     System.out.println(textComponent.toPlainText());
/*     */   }
/*     */ 
/*     */   
/*     */   public void staffLog(String message) {
/*  98 */     staffLog(message, true);
/*     */   }
/*     */   
/*     */   public void actionbar(String message, String permission) {
/* 102 */     getMembers().stream().filter(member -> member.hasPermission(permission))
/* 103 */       .forEach(member -> member.sendActionBar(message));
/*     */   }
/*     */   
/*     */   public void title(String title, String subTitle, String permission) {
/* 107 */     getMembers().stream().filter(member -> member.hasPermission(permission))
/* 108 */       .forEach(member -> member.sendTitle(title, subTitle));
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/manager/MemberManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */