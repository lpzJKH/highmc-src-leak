/*    */ package net.highmc.manager;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.member.status.Status;
/*    */ import net.highmc.member.status.StatusType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StatusManager
/*    */ {
/* 16 */   private Map<UUID, Map<StatusType, Status>> statusMap = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Status loadStatus(UUID uniqueId, StatusType statusType) {
/* 29 */     if (this.statusMap.containsKey(uniqueId) && ((Map)this.statusMap.get(uniqueId)).containsKey(statusType)) {
/* 30 */       return (Status)((Map)this.statusMap.get(uniqueId)).get(statusType);
/*    */     }
/*    */     
/* 33 */     Status status = CommonPlugin.getInstance().getMemberData().loadStatus(uniqueId, statusType);
/* 34 */     ((Map<StatusType, Status>)this.statusMap.computeIfAbsent(uniqueId, v -> new HashMap<>())).put(statusType, status);
/* 35 */     return status;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void preloadStatus(UUID uniqueId, StatusType statusType) {
/* 48 */     if (this.statusMap.containsKey(uniqueId) && ((Map)this.statusMap.get(uniqueId)).containsKey(statusType)) {
/*    */       return;
/*    */     }
/*    */     
/* 52 */     Status status = CommonPlugin.getInstance().getMemberData().loadStatus(uniqueId, statusType);
/* 53 */     ((Map<StatusType, Status>)this.statusMap.computeIfAbsent(uniqueId, v -> new HashMap<>())).put(statusType, status);
/*    */   }
/*    */ 
/*    */   
/*    */   public void unloadStatus(UUID uniqueId) {
/* 58 */     this.statusMap.remove(uniqueId);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/manager/StatusManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */