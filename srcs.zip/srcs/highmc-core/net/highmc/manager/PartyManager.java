/*    */ package net.highmc.manager;
/*    */ 
/*    */ import com.google.common.collect.ImmutableList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.member.party.Party;
/*    */ import net.highmc.member.party.PartyRole;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PartyManager
/*    */ {
/*    */   public Map<UUID, Map<UUID, InviteInfo>> getPartyInvitesMap() {
/* 19 */     return this.partyInvitesMap;
/*    */   }
/*    */ 
/*    */   
/* 23 */   private Map<UUID, Party> partyMap = new HashMap<>();
/* 24 */   private Map<UUID, Map<UUID, InviteInfo>> partyInvitesMap = new HashMap<>();
/*    */ 
/*    */   
/*    */   public void loadParty(Party party) {
/* 28 */     this.partyMap.put(party.getPartyId(), party);
/* 29 */     CommonPlugin.getInstance().debug("The party " + party.getPartyId() + " has been loaded.");
/*    */   }
/*    */   
/*    */   public Party getPartyById(UUID uniqueId) {
/* 33 */     return this.partyMap.get(uniqueId);
/*    */   }
/*    */   
/*    */   public Party getPartyByOwner(UUID uniqueId) {
/* 37 */     return this.partyMap.values().stream().filter(party -> (party.getMembersMap().containsKey(uniqueId) && party.getMembersMap().get(uniqueId) == PartyRole.OWNER))
/* 38 */       .findFirst().orElse(null);
/*    */   }
/*    */   
/*    */   public Party getPlayerParty(UUID uniqueId) {
/* 42 */     return this.partyMap.values().stream().filter(party -> party.getMembersMap().containsKey(uniqueId)).findFirst()
/* 43 */       .orElse(null);
/*    */   }
/*    */   
/*    */   public void unloadParty(UUID partyId) {
/* 47 */     this.partyMap.remove(partyId);
/* 48 */     CommonPlugin.getInstance().debug("The party " + partyId + " has been unloaded.");
/*    */   }
/*    */   
/*    */   public void invite(UUID sender, UUID member, Party party) {
/* 52 */     ((Map<UUID, InviteInfo>)this.partyInvitesMap.computeIfAbsent(member, v -> new HashMap<>())).put(sender, new InviteInfo(party.getPartyId()));
/*    */   }
/*    */   
/*    */   public List<Party> loadParties() {
/* 56 */     return (List<Party>)ImmutableList.copyOf(this.partyMap.values());
/*    */   }
/*    */   
/*    */   public class InviteInfo {
/*    */     private final UUID partyId;
/*    */     private long createdAt;
/*    */     
/*    */     public InviteInfo(UUID partyId) {
/* 64 */       this.createdAt = System.currentTimeMillis(); this.partyId = partyId; } public long getCreatedAt() { return this.createdAt; }
/*    */ 
/*    */     
/*    */     public UUID getPartyId() {
/*    */       return this.partyId;
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/manager/PartyManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */