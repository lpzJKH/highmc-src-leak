package net.highmc.utils;

import java.io.File;

public interface FileCreator {
  File createFile(String paramString1, String paramString2) throws Exception;
}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/utils/FileCreator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */