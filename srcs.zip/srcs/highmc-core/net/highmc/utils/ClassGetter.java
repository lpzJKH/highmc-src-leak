/*     */ package net.highmc.utils;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.security.CodeSource;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ 
/*     */ public class ClassGetter
/*     */ {
/*     */   public static ArrayList<Class<?>> getClassesForPackage(Class<?> clas, String pkgname) {
/*  17 */     ArrayList<Class<?>> classes = new ArrayList<>();
/*  18 */     CodeSource src = clas.getProtectionDomain().getCodeSource();
/*  19 */     if (src != null) {
/*  20 */       URL resource = src.getLocation();
/*  21 */       resource.getPath();
/*  22 */       processJarfile(resource, pkgname, classes);
/*     */     } 
/*  24 */     return classes;
/*     */   }
/*     */   
/*     */   private static Class<?> loadClass(String className) {
/*     */     try {
/*  29 */       return Class.forName(className);
/*  30 */     } catch (ClassNotFoundException e) {
/*  31 */       throw new RuntimeException("Unexpected ClassNotFoundException loading class '" + className + "'");
/*  32 */     } catch (NoClassDefFoundError e) {
/*  33 */       return null;
/*     */     } 
/*     */   }
/*     */   private static void processJarfile(URL resource, String pkgname, ArrayList<Class<?>> classes) {
/*     */     JarFile jarFile;
/*  38 */     String relPath = pkgname.replace('.', '/');
/*  39 */     String resPath = resource.getPath().replace("%20", " ");
/*  40 */     String jarPath = resPath.replaceFirst("[.]jar[!].*", ".jar").replaceFirst("file:", "");
/*     */ 
/*     */     
/*     */     try {
/*  44 */       jarFile = new JarFile(jarPath);
/*  45 */     } catch (IOException e) {
/*  46 */       throw new RuntimeException("Unexpected IOException reading JAR File '" + jarPath + "'", e);
/*     */     } 
/*  48 */     Enumeration<JarEntry> entries = jarFile.entries();
/*  49 */     while (entries.hasMoreElements()) {
/*  50 */       JarEntry entry = entries.nextElement();
/*  51 */       String entryName = entry.getName();
/*  52 */       String className = null;
/*  53 */       if (entryName.endsWith(".class") && entryName.startsWith(relPath) && entryName
/*  54 */         .length() > relPath.length() + "/".length()) {
/*  55 */         className = entryName.replace('/', '.').replace('\\', '.').replace(".class", "");
/*     */       }
/*  57 */       if (className != null) {
/*  58 */         Class<?> c = loadClass(className);
/*  59 */         if (c != null)
/*  60 */           classes.add(c); 
/*     */       } 
/*     */     } 
/*     */     try {
/*  64 */       jarFile.close();
/*  65 */     } catch (IOException e) {
/*  66 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<Class<?>> getClassesForPackageByFile(File file, String pkgname) {
/*  72 */     List<Class<?>> classes = new ArrayList<>();
/*     */     
/*     */     try {
/*  75 */       String relPath = pkgname.replace('.', '/');
/*  76 */       try (JarFile jarFile = new JarFile(file)) {
/*  77 */         Enumeration<JarEntry> entries = jarFile.entries();
/*  78 */         while (entries.hasMoreElements()) {
/*  79 */           JarEntry entry = entries.nextElement();
/*  80 */           String entryName = entry.getName();
/*  81 */           if (entryName.endsWith(".class") && entryName
/*  82 */             .startsWith(relPath) && entryName
/*  83 */             .length() > relPath.length() + "/".length()) {
/*  84 */             String className = entryName.replace('/', '.').replace('\\', '.');
/*  85 */             if (className.endsWith(".class"))
/*  86 */               className = className.substring(0, className.length() - 6); 
/*  87 */             Class<?> c = loadClass(className);
/*  88 */             if (c != null)
/*  89 */               classes.add(c); 
/*     */           } 
/*     */         } 
/*     */       } 
/*  93 */     } catch (IOException e) {
/*  94 */       throw new RuntimeException("Unexpected IOException reading JAR File '" + file.getAbsolutePath() + "'", e);
/*     */     } 
/*     */     
/*  97 */     return classes;
/*     */   }
/*     */   
/*     */   public static List<Class<?>> getClassesForPackageByPlugin(Object plugin, String pkgname) {
/*     */     try {
/* 102 */       Method method = plugin.getClass().getMethod("getFile", new Class[0]);
/* 103 */       method.setAccessible(true);
/* 104 */       File file = (File)method.invoke(plugin, new Object[0]);
/* 105 */       return getClassesForPackageByFile(file, pkgname);
/* 106 */     } catch (Exception e) {
/* 107 */       e.printStackTrace();
/* 108 */       return new ArrayList<>();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/utils/ClassGetter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */