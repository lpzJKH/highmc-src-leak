/*    */ package net.highmc.utils.json;
/*    */ 
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import java.util.UUID;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JsonBuilder
/*    */ {
/* 21 */   private JsonObject jsonObject = new JsonObject();
/*    */ 
/*    */   
/*    */   public JsonBuilder add(String key, JsonElement value) {
/* 25 */     this.jsonObject.add(key, value);
/* 26 */     return this;
/*    */   }
/*    */   
/*    */   public JsonBuilder addProperty(String key, String value) {
/* 30 */     this.jsonObject.addProperty(key, value);
/* 31 */     return this;
/*    */   }
/*    */   
/*    */   public JsonBuilder addProperty(String key, Boolean value) {
/* 35 */     this.jsonObject.addProperty(key, value);
/* 36 */     return this;
/*    */   }
/*    */   
/*    */   public JsonBuilder addProperty(String key, Number value) {
/* 40 */     this.jsonObject.addProperty(key, value);
/* 41 */     return this;
/*    */   }
/*    */   
/*    */   public JsonBuilder addProperty(String key, Character value) {
/* 45 */     this.jsonObject.addProperty(key, value);
/* 46 */     return this;
/*    */   }
/*    */   
/*    */   public JsonObject build() {
/* 50 */     return this.jsonObject;
/*    */   }
/*    */   
/*    */   public static JsonBuilder createObjectBuilder() {
/* 54 */     return new JsonBuilder();
/*    */   }
/*    */   
/*    */   public static JsonBuilder createPlayer(String playerName, UUID uniqueId) {
/* 58 */     return createObjectBuilder().addProperty("playerName", playerName).addProperty("uniqueId", uniqueId.toString());
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/utils/json/JsonBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */