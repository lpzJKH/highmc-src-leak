/*    */ package net.highmc.utils.json;
/*    */ 
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import com.google.gson.JsonParser;
/*    */ import com.google.gson.JsonPrimitive;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import net.highmc.CommonConst;
/*    */ import org.bson.BsonInvalidOperationException;
/*    */ import org.bson.Document;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JsonUtils
/*    */ {
/*    */   public static JsonObject jsonTree(Object src) {
/* 21 */     return CommonConst.GSON.toJsonTree(src).getAsJsonObject();
/*    */   }
/*    */   
/*    */   public static Object elementToBson(JsonElement element) {
/* 25 */     if (element.isJsonPrimitive()) {
/* 26 */       JsonPrimitive primitive = element.getAsJsonPrimitive();
/* 27 */       if (primitive.isString())
/* 28 */         return primitive.getAsString(); 
/* 29 */       if (primitive.isNumber())
/* 30 */         return primitive.getAsNumber(); 
/* 31 */       if (primitive.isBoolean()) {
/* 32 */         return Boolean.valueOf(primitive.getAsBoolean());
/*    */       }
/* 34 */     } else if (element.isJsonArray()) {
/* 35 */       return CommonConst.GSON.fromJson(element, List.class);
/*    */     } 
/*    */     
/*    */     try {
/* 39 */       return Document.parse(CommonConst.GSON.toJson(element));
/* 40 */     } catch (BsonInvalidOperationException ex) {
/* 41 */       return JsonParser.parseString(CommonConst.GSON.toJson(element));
/*    */     } 
/*    */   }
/*    */   
/*    */   public static String elementToString(JsonElement element) {
/* 46 */     if (element.isJsonPrimitive()) {
/* 47 */       JsonPrimitive primitive = element.getAsJsonPrimitive();
/* 48 */       if (primitive.isString()) {
/* 49 */         return primitive.getAsString();
/*    */       }
/*    */     } 
/* 52 */     return CommonConst.GSON.toJson(element);
/*    */   }
/*    */   
/*    */   public static <T> T mapToObject(Map<String, String> map, Class<T> clazz) {
/* 56 */     JsonObject obj = new JsonObject();
/*    */     
/* 58 */     for (Map.Entry<String, String> entry : map.entrySet()) {
/*    */       try {
/* 60 */         obj.add(entry.getKey(), JsonParser.parseString(entry.getValue()));
/* 61 */       } catch (Exception e) {
/* 62 */         obj.addProperty(entry.getKey(), entry.getValue());
/*    */       } 
/*    */     } 
/*    */     
/* 66 */     return (T)CommonConst.GSON.fromJson((JsonElement)obj, clazz);
/*    */   }
/*    */   
/*    */   public static Map<String, String> objectToMap(Object src) {
/* 70 */     Map<String, String> map = new HashMap<>();
/* 71 */     JsonObject obj = (JsonObject)CommonConst.GSON.toJsonTree(src);
/*    */     
/* 73 */     for (Map.Entry<String, JsonElement> entry : (Iterable<Map.Entry<String, JsonElement>>)obj.entrySet()) {
/* 74 */       map.put(entry.getKey(), CommonConst.GSON.toJson(entry.getValue()));
/*    */     }
/*    */     
/* 77 */     return map;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/utils/json/JsonUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */