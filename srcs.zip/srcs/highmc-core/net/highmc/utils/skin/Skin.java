/*    */ package net.highmc.utils.skin;
/*    */ import java.util.UUID;
/*    */ 
/*    */ public class Skin {
/*    */   private String playerName;
/*    */   private UUID uniqueId;
/*    */   
/*    */   public Skin(String playerName, UUID uniqueId, String value, String signature, long createdAt) {
/*  9 */     this.playerName = playerName; this.uniqueId = uniqueId; this.value = value; this.signature = signature; this.createdAt = createdAt;
/*    */   } private String value; private String signature; private long createdAt;
/*    */   public String getPlayerName() {
/* 12 */     return this.playerName; } public UUID getUniqueId() {
/* 13 */     return this.uniqueId;
/*    */   }
/* 15 */   public String getValue() { return this.value; } public String getSignature() {
/* 16 */     return this.signature;
/*    */   } public long getCreatedAt() {
/* 18 */     return this.createdAt;
/*    */   }
/*    */   public Skin(String playerName, UUID uniqueId, String value, String signature) {
/* 21 */     this(playerName, uniqueId, value, signature, System.currentTimeMillis());
/*    */   }
/*    */   
/*    */   public Skin(String playerName, String value, String signature) {
/* 25 */     this(playerName, null, value, signature, System.currentTimeMillis());
/*    */   }
/*    */   
/*    */   public Skin(String playerName, UUID uniqueId, String value) {
/* 29 */     this(playerName, uniqueId, value, "", System.currentTimeMillis());
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/utils/skin/Skin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */