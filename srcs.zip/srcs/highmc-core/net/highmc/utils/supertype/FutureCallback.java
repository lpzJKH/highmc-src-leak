package net.highmc.utils.supertype;

public interface FutureCallback<T> {
  void result(T paramT, Throwable paramThrowable);
}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/utils/supertype/FutureCallback.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */