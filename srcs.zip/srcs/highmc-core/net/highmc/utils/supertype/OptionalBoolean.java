/*     */ package net.highmc.utils.supertype;
/*     */ 
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OptionalBoolean
/*     */ {
/*  33 */   private static final OptionalBoolean EMPTY = new OptionalBoolean();
/*     */   
/*     */   private final boolean isPresent;
/*     */   private final boolean value;
/*     */   
/*     */   private OptionalBoolean() {
/*  39 */     this.isPresent = false;
/*  40 */     this.value = false;
/*     */   }
/*     */   
/*     */   public static OptionalBoolean empty() {
/*  44 */     return EMPTY;
/*     */   }
/*     */   
/*     */   private OptionalBoolean(boolean value) {
/*  48 */     this.isPresent = true;
/*  49 */     this.value = value;
/*     */   }
/*     */   
/*     */   public static OptionalBoolean of(boolean value) {
/*  53 */     return new OptionalBoolean(value);
/*     */   }
/*     */   
/*     */   public boolean getAsBoolean() {
/*  57 */     if (!this.isPresent) {
/*  58 */       throw new NoSuchElementException("No value present");
/*     */     }
/*  60 */     return this.value;
/*     */   }
/*     */   
/*     */   public boolean isPresent() {
/*  64 */     return this.isPresent;
/*     */   }
/*     */   
/*     */   public void ifPresent(Consumer<Boolean> consumer) {
/*  68 */     if (this.isPresent)
/*  69 */       consumer.accept(Boolean.valueOf(this.value)); 
/*     */   }
/*     */   
/*     */   public boolean orElse(boolean other) {
/*  73 */     return this.isPresent ? this.value : other;
/*     */   }
/*     */   
/*     */   public boolean orElseGet(Supplier<Boolean> other) {
/*  77 */     return this.isPresent ? this.value : ((Boolean)other.get()).booleanValue();
/*     */   }
/*     */   
/*     */   public <X extends Throwable> boolean orElseThrow(Supplier<X> exceptionSupplier) throws X {
/*  81 */     if (this.isPresent) {
/*  82 */       return this.value;
/*     */     }
/*  84 */     throw (X)exceptionSupplier.get();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  90 */     if (this == obj) {
/*  91 */       return true;
/*     */     }
/*     */     
/*  94 */     if (!(obj instanceof OptionalBoolean)) {
/*  95 */       return false;
/*     */     }
/*     */     
/*  98 */     OptionalBoolean other = (OptionalBoolean)obj;
/*  99 */     return (this.isPresent && other.isPresent) ? ((this.value == other.value)) : ((this.isPresent == other.isPresent));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 104 */     return this.isPresent ? Boolean.hashCode(this.value) : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 109 */     return this.isPresent ? String.format("OptionalBoolean[%s]", new Object[] { Boolean.valueOf(this.value) }) : "OptionalBoolean.empty";
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/utils/supertype/OptionalBoolean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */