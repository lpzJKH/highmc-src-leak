/*    */ package net.highmc.utils.mojang;
/*    */ 
/*    */ import com.google.common.cache.CacheBuilder;
/*    */ import com.google.common.cache.CacheLoader;
/*    */ import com.google.common.cache.LoadingCache;
/*    */ import com.google.gson.JsonArray;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import com.google.gson.JsonParser;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.InputStreamReader;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.UUID;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import net.highmc.CommonPlugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NameFetcher
/*    */ {
/* 30 */   private List<String> apis = new ArrayList<>();
/*    */   
/* 32 */   private LoadingCache<UUID, String> cache = CacheBuilder.newBuilder().expireAfterWrite(1L, TimeUnit.DAYS)
/* 33 */     .build(new CacheLoader<UUID, String>()
/*    */       {
/*    */         public String load(UUID uuid) throws Exception {
/* 36 */           String name = CommonPlugin.getInstance().getPluginPlatform().getName(uuid);
/* 37 */           return (name == null) ? NameFetcher.this.request(uuid) : name;
/*    */         }
/*    */       });
/*    */   
/*    */   public NameFetcher() {
/* 42 */     this.apis.add("https://api.mojang.com/user/profiles/%s/names");
/* 43 */     this.apis.add("https://sessionserver.mojang.com/session/minecraft/profile/%s");
/* 44 */     this.apis.add("https://api.mcuuid.com/json/name/%s");
/* 45 */     this.apis.add("https://api.minetools.eu/uuid/%s");
/*    */   }
/*    */   
/*    */   private String request(UUID uuid) {
/* 49 */     return request(0, this.apis.get(0), uuid);
/*    */   }
/*    */   
/*    */   private String request(int idx, String api, UUID uuid) {
/*    */     try {
/* 54 */       URLConnection con = (new URL(String.format(api, new Object[] { uuid.toString().replace("-", "") }))).openConnection();
/* 55 */       JsonElement element = JsonParser.parseReader(new BufferedReader(new InputStreamReader(con
/* 56 */               .getInputStream(), StandardCharsets.UTF_8)));
/* 57 */       if (element instanceof JsonArray) {
/* 58 */         JsonArray names = (JsonArray)element;
/* 59 */         JsonObject name = (JsonObject)names.get(names.size() - 1);
/* 60 */         if (name.has("name")) {
/* 61 */           return name.get("name").getAsString();
/*    */         }
/* 63 */       } else if (element instanceof JsonObject) {
/* 64 */         JsonObject object = (JsonObject)element;
/* 65 */         if (object.has("error") && object.has("errorMessage"))
/* 66 */           throw new Exception(object.get("errorMessage").getAsString()); 
/* 67 */         if (object.has("name")) {
/* 68 */           return object.get("name").getAsString();
/*    */         }
/*    */       } 
/* 71 */     } catch (Exception e) {
/* 72 */       idx++;
/* 73 */       if (idx < this.apis.size()) {
/* 74 */         api = this.apis.get(idx);
/* 75 */         return request(idx, api, uuid);
/*    */       } 
/*    */     } 
/*    */     
/* 79 */     return null;
/*    */   }
/*    */   
/*    */   public String getName(UUID uuid) {
/*    */     try {
/* 84 */       return (String)this.cache.get(uuid);
/* 85 */     } catch (Exception e) {
/* 86 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/utils/mojang/NameFetcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */