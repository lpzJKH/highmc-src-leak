/*    */ package net.highmc.utils.mojang;
/*    */ 
/*    */ import com.google.common.cache.CacheBuilder;
/*    */ import com.google.common.cache.CacheLoader;
/*    */ import com.google.common.cache.LoadingCache;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import com.google.gson.JsonParser;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.InputStreamReader;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.UUID;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import net.highmc.CommonPlugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UUIDFetcher
/*    */ {
/* 24 */   private List<String> apis = new ArrayList<>();
/*    */   
/* 26 */   private LoadingCache<String, UUID> cache = CacheBuilder.newBuilder().expireAfterWrite(1L, TimeUnit.DAYS)
/* 27 */     .build(new CacheLoader<String, UUID>()
/*    */       {
/*    */         public UUID load(String name) throws Exception {
/* 30 */           UUID uuid = CommonPlugin.getInstance().getPluginPlatform().getUniqueId(name);
/* 31 */           return (uuid == null) ? UUIDFetcher.this.request(name) : uuid;
/*    */         }
/*    */       });
/*    */   
/*    */   public UUIDFetcher() {
/* 36 */     this.apis.add("https://api.mojang.com/users/profiles/minecraft/%s");
/* 37 */     this.apis.add("https://api.mcuuid.com/json/uuid/%s");
/* 38 */     this.apis.add("https://api.minetools.eu/uuid/%s");
/*    */   }
/*    */   
/*    */   public UUID request(String name) {
/* 42 */     return request(0, this.apis.get(0), name);
/*    */   }
/*    */   
/*    */   public UUID request(int idx, String api, String name) {
/*    */     try {
/* 47 */       URLConnection con = (new URL(String.format(api, new Object[] { name }))).openConnection();
/* 48 */       JsonElement element = JsonParser.parseReader(new BufferedReader(new InputStreamReader(con
/* 49 */               .getInputStream(), StandardCharsets.UTF_8)));
/* 50 */       if (element instanceof JsonObject) {
/* 51 */         JsonObject object = (JsonObject)element;
/* 52 */         if (object.has("error") && object.has("errorMessage"))
/* 53 */           throw new Exception(object.get("errorMessage").getAsString()); 
/* 54 */         if (object.has("id"))
/* 55 */           return UUIDParser.parse(object.get("id")); 
/* 56 */         if (object.has("uuid")) {
/* 57 */           JsonObject uuid = object.getAsJsonObject("uuid");
/* 58 */           if (uuid.has("formatted")) {
/* 59 */             return UUIDParser.parse(object.get("formatted"));
/*    */           }
/*    */         } 
/*    */       } 
/* 63 */     } catch (Exception e) {
/* 64 */       idx++;
/* 65 */       if (idx < this.apis.size()) {
/* 66 */         api = this.apis.get(idx);
/* 67 */         return request(idx, api, name);
/*    */       } 
/*    */     } 
/*    */     
/* 71 */     return null;
/*    */   }
/*    */   
/*    */   public UUID getUUID(String name) {
/* 75 */     if (name != null && !name.isEmpty()) {
/* 76 */       if (name.matches("[a-zA-Z0-9_]{3,16}")) {
/*    */         try {
/* 78 */           return (UUID)this.cache.get(name);
/* 79 */         } catch (Exception exception) {}
/*    */       } else {
/*    */         
/* 82 */         return UUIDParser.parse(name);
/*    */       } 
/*    */     }
/* 85 */     return null;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/utils/mojang/UUIDFetcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */