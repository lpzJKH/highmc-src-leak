/*     */ package net.highmc.utils.reflection;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Reflection
/*     */ {
/*     */   public static <T> FieldAccessor<T> getField(Class<?> target, String name, Class<T> fieldType) {
/*  54 */     return getField(target, name, fieldType, 0);
/*     */   }
/*     */   
/*     */   public static <T> FieldAccessor<T> getField(Class<?> target, Class<T> fieldType, int index) {
/*  58 */     return getField(target, null, fieldType, index);
/*     */   }
/*     */ 
/*     */   
/*     */   private static <T> FieldAccessor<T> getField(Class<?> target, String name, Class<T> fieldType, int index) {
/*  63 */     for (Field field : target.getDeclaredFields()) {
/*  64 */       if ((name == null || field.getName().equals(name)) && fieldType.isAssignableFrom(field.getType()) && index-- <= 0) {
/*     */         
/*  66 */         field.setAccessible(true);
/*     */ 
/*     */         
/*  69 */         return new FieldAccessor<T>()
/*     */           {
/*     */             
/*     */             public T get(Object target)
/*     */             {
/*     */               try {
/*  75 */                 return (T)field.get(target);
/*  76 */               } catch (IllegalAccessException e) {
/*  77 */                 throw new RuntimeException("Cannot access reflection.", e);
/*     */               } 
/*     */             }
/*     */ 
/*     */             
/*     */             public void set(Object target, Object value) {
/*     */               try {
/*  84 */                 field.set(target, value);
/*  85 */               } catch (IllegalAccessException e) {
/*  86 */                 throw new RuntimeException("Cannot access reflection.", e);
/*     */               } 
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             public boolean hasField(Object target) {
/*  93 */               return field.getDeclaringClass().isAssignableFrom(target.getClass());
/*     */             }
/*     */           };
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 100 */     if (target.getSuperclass() != null) {
/* 101 */       return getField(target.getSuperclass(), name, fieldType, index);
/*     */     }
/* 103 */     throw new IllegalArgumentException("Cannot contains field with type " + fieldType);
/*     */   }
/*     */   
/*     */   public static MethodInvoker getMethod(Class<?> clazz, String methodName, Class<?>... params) {
/* 107 */     return getTypedMethod(clazz, methodName, null, params);
/*     */   }
/*     */ 
/*     */   
/*     */   public static MethodInvoker getTypedMethod(Class<?> clazz, String methodName, Class<?> returnType, Class<?>... params) {
/* 112 */     for (Method method : clazz.getDeclaredMethods()) {
/* 113 */       if (((methodName == null || method.getName().equals(methodName)) && returnType == null) || (method
/* 114 */         .getReturnType().equals(returnType) && Arrays.equals((Object[])method.getParameterTypes(), (Object[])params))) {
/* 115 */         method.setAccessible(true);
/*     */         
/* 117 */         return new MethodInvoker()
/*     */           {
/*     */             public Object invoke(Object target, Object... arguments)
/*     */             {
/*     */               try {
/* 122 */                 return method.invoke(target, arguments);
/* 123 */               } catch (Exception e) {
/* 124 */                 throw new RuntimeException("Cannot invoke method " + method, e);
/*     */               } 
/*     */             }
/*     */           };
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 133 */     if (clazz.getSuperclass() != null) {
/* 134 */       return getMethod(clazz.getSuperclass(), methodName, params);
/*     */     }
/* 136 */     throw new IllegalStateException(
/* 137 */         String.format("Unable to contains method %s (%s).", new Object[] { methodName, Arrays.asList(params) }));
/*     */   }
/*     */   
/*     */   public static ConstructorInvoker getConstructor(Class<?> clazz, Class<?>... params) {
/* 141 */     for (Constructor<?> constructor : clazz.getDeclaredConstructors()) {
/* 142 */       if (Arrays.equals((Object[])constructor.getParameterTypes(), (Object[])params)) {
/* 143 */         constructor.setAccessible(true);
/*     */         
/* 145 */         return new ConstructorInvoker()
/*     */           {
/*     */             public Object invoke(Object... arguments)
/*     */             {
/*     */               try {
/* 150 */                 return constructor.newInstance(arguments);
/* 151 */               } catch (Exception e) {
/* 152 */                 throw new RuntimeException("Cannot invoke constructor " + constructor, e);
/*     */               } 
/*     */             }
/*     */           };
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 160 */     throw new IllegalStateException(
/* 161 */         String.format("Unable to contains constructor for %s (%s).", new Object[] { clazz, Arrays.asList(params) }));
/*     */   }
/*     */   
/*     */   public static Object getHandle(Object obj) {
/*     */     try {
/* 166 */       return getMethod(obj.getClass(), "getHandle", new Class[0]).invoke(obj, new Object[0]);
/* 167 */     } catch (Exception e) {
/* 168 */       e.printStackTrace();
/*     */       
/* 170 */       return null;
/*     */     } 
/*     */   }
/*     */   public static void setField(Object object, String fieldName, Object finalObject) {
/*     */     try {
/* 175 */       Field field = object.getClass().getDeclaredField(fieldName);
/* 176 */       field.setAccessible(true);
/* 177 */       field.set(fieldName, finalObject);
/* 178 */     } catch (NoSuchFieldException|IllegalArgumentException|IllegalAccessException e) {
/* 179 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Field getField(Class<?> clazz, String fieldName) {
/* 184 */     if (clazz != null && clazz != Object.class) {
/*     */       try {
/* 186 */         Field field = clazz.getDeclaredField(fieldName);
/* 187 */         field.setAccessible(true);
/* 188 */         return field;
/* 189 */       } catch (NoSuchFieldException e) {
/* 190 */         clazz = clazz.getSuperclass();
/*     */       } 
/*     */     }
/* 193 */     return null;
/*     */   }
/*     */   
/*     */   public static Field getFieldWithException(Class<?> clazz, String name) throws Exception {
/* 197 */     Field field = clazz.getDeclaredField(name);
/* 198 */     field.setAccessible(true);
/* 199 */     return field;
/*     */   }
/*     */   
/*     */   public static boolean ClassListEqual(Class<?>[] l1, Class<?>[] l2) {
/* 203 */     boolean equal = true;
/* 204 */     if (l1.length != l2.length) {
/* 205 */       return false;
/*     */     }
/* 207 */     for (int i = 0; i < l1.length; i++) {
/* 208 */       if (l1[i] != l2[i]) {
/* 209 */         equal = false;
/*     */         break;
/*     */       } 
/*     */     } 
/* 213 */     return equal;
/*     */   }
/*     */   
/*     */   public static interface ConstructorInvoker {
/*     */     Object invoke(Object... param1VarArgs);
/*     */   }
/*     */   
/*     */   public static interface MethodInvoker {
/*     */     Object invoke(Object param1Object, Object... param1VarArgs);
/*     */   }
/*     */   
/*     */   public static interface FieldAccessor<T> {
/*     */     T get(Object param1Object);
/*     */     
/*     */     void set(Object param1Object1, Object param1Object2);
/*     */     
/*     */     boolean hasField(Object param1Object);
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/utils/reflection/Reflection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */