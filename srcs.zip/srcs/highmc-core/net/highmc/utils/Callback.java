/*   */ package net.highmc.utils;
/*   */ 
/*   */ public abstract class Callback<T>
/*   */ {
/*   */   private T callback;
/*   */   
/*   */   public T getCallback() {
/* 8 */     return this.callback;
/*   */   }
/*   */   
/*   */   public abstract void callback(T paramT);
/*   */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/utils/Callback.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */