/*     */ package net.highmc.utils;
/*     */ 
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import net.highmc.language.Language;
/*     */ 
/*     */ 
/*     */ public class DateUtils
/*     */ {
/*     */   public static String getTime(Language language, long expire) {
/*  15 */     String string = formatDifference(language, (expire - System.currentTimeMillis()) / 1000L);
/*  16 */     if (string == null || string.isEmpty()) {
/*  17 */       string = "0 " + language.t("second", new String[0]);
/*     */     }
/*  19 */     return string.trim();
/*     */   }
/*     */   
/*     */   public static String formatTime(long time, DecimalFormat decimalFormat) {
/*  23 */     double seconds = (time - System.currentTimeMillis()) / 1000.0D;
/*  24 */     return decimalFormat.format(seconds);
/*     */   }
/*     */   
/*     */   public static long getMidNight() {
/*  28 */     Calendar date = new GregorianCalendar();
/*  29 */     date.set(11, 0);
/*  30 */     date.set(12, 0);
/*  31 */     date.set(13, 0);
/*  32 */     date.set(14, 0);
/*     */     
/*  34 */     date.add(5, 1);
/*     */     
/*  36 */     return date.getTimeInMillis();
/*     */   }
/*     */   
/*     */   public static String formatDifference(Language language, long time) {
/*  40 */     if (time == 0L) {
/*  41 */       return "";
/*     */     }
/*     */     
/*  44 */     long day = TimeUnit.SECONDS.toDays(time);
/*  45 */     long hours = TimeUnit.SECONDS.toHours(time) - day * 24L;
/*  46 */     long minutes = TimeUnit.SECONDS.toMinutes(time) - TimeUnit.SECONDS.toHours(time) * 60L;
/*  47 */     long seconds = TimeUnit.SECONDS.toSeconds(time) - TimeUnit.SECONDS.toMinutes(time) * 60L;
/*     */     
/*  49 */     StringBuilder sb = new StringBuilder();
/*  50 */     if (day > 0L) {
/*  51 */       sb.append(day).append(" ").append(language.t("day", new String[0]) + ((day == 1L) ? "" : "s")).append(" ");
/*     */     }
/*  53 */     if (hours > 0L) {
/*  54 */       sb.append(hours).append(" ").append(language.t("hour", new String[0]) + ((hours == 1L) ? "" : "s")).append(" ");
/*     */     }
/*  56 */     if (minutes > 0L) {
/*  57 */       sb.append(minutes).append(" ").append(language.t("minute", new String[0]) + ((minutes == 1L) ? "" : "s")).append(" ");
/*     */     }
/*  59 */     if (seconds > 0L) {
/*  60 */       sb.append(seconds).append(" ").append(language.t("second", new String[0]) + ((seconds == 1L) ? "" : "s"));
/*     */     }
/*  62 */     String diff = sb.toString();
/*     */     
/*  64 */     return diff.isEmpty() ? ("0 " + language.t("second", new String[0])) : diff;
/*     */   }
/*     */   
/*     */   public static Long getTime(String string) {
/*     */     try {
/*  69 */       return Long.valueOf(parseDateDiff(string, true) + 500L);
/*  70 */     } catch (Exception exception) {
/*     */       
/*  72 */       return null;
/*     */     } 
/*     */   }
/*     */   public static String getDifferenceFormat(Language language, long timestamp) {
/*  76 */     return formatDifference(language, timestamp - System.currentTimeMillis() / 1000L);
/*     */   }
/*     */   
/*     */   public static long parseDateDiff(String time, boolean future) throws Exception {
/*  80 */     Pattern timePattern = Pattern.compile("(?:([0-9]+)\\s*y[a-z]*[,\\s]*)?(?:([0-9]+)\\s*mo[a-z]*[,\\s]*)?(?:([0-9]+)\\s*w[a-z]*[,\\s]*)?(?:([0-9]+)\\s*d[a-z]*[,\\s]*)?(?:([0-9]+)\\s*h[a-z]*[,\\s]*)?(?:([0-9]+)\\s*m[a-z]*[,\\s]*)?(?:([0-9]+)\\s*(?:s[a-z]*)?)?", 2);
/*     */ 
/*     */ 
/*     */     
/*  84 */     Matcher m = timePattern.matcher(time);
/*  85 */     int years = 0;
/*  86 */     int months = 0;
/*  87 */     int weeks = 0;
/*  88 */     int days = 0;
/*  89 */     int hours = 0;
/*  90 */     int minutes = 0;
/*  91 */     int seconds = 0;
/*  92 */     boolean found = false;
/*  93 */     while (m.find()) {
/*  94 */       if (m.group() == null || m.group().isEmpty()) {
/*     */         continue;
/*     */       }
/*     */       
/*  98 */       for (int i = 0; i < m.groupCount(); i++) {
/*  99 */         if (m.group(i) != null && !m.group(i).isEmpty()) {
/* 100 */           found = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 105 */       if (found) {
/* 106 */         if (m.group(1) != null && !m.group(1).isEmpty()) {
/* 107 */           years = Integer.parseInt(m.group(1));
/*     */         }
/*     */         
/* 110 */         if (m.group(2) != null && !m.group(2).isEmpty()) {
/* 111 */           months = Integer.parseInt(m.group(2));
/*     */         }
/*     */         
/* 114 */         if (m.group(3) != null && !m.group(3).isEmpty()) {
/* 115 */           weeks = Integer.parseInt(m.group(3));
/*     */         }
/*     */         
/* 118 */         if (m.group(4) != null && !m.group(4).isEmpty()) {
/* 119 */           days = Integer.parseInt(m.group(4));
/*     */         }
/*     */         
/* 122 */         if (m.group(5) != null && !m.group(5).isEmpty()) {
/* 123 */           hours = Integer.parseInt(m.group(5));
/*     */         }
/*     */         
/* 126 */         if (m.group(6) != null && !m.group(6).isEmpty()) {
/* 127 */           minutes = Integer.parseInt(m.group(6));
/*     */         }
/*     */         
/* 130 */         if (m.group(7) != null && !m.group(7).isEmpty()) {
/* 131 */           seconds = Integer.parseInt(m.group(7));
/*     */         }
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 137 */     if (!found) {
/* 138 */       throw new Exception("Illegal Date");
/*     */     }
/*     */     
/* 141 */     if (years > 100) {
/* 142 */       throw new Exception("Illegal Date");
/*     */     }
/*     */     
/* 145 */     Calendar c = new GregorianCalendar();
/* 146 */     if (years > 0) {
/* 147 */       c.add(1, years * (future ? 1 : -1));
/*     */     }
/* 149 */     if (months > 0) {
/* 150 */       c.add(2, months * (future ? 1 : -1));
/*     */     }
/* 152 */     if (weeks > 0) {
/* 153 */       c.add(3, weeks * (future ? 1 : -1));
/*     */     }
/* 155 */     if (days > 0) {
/* 156 */       c.add(5, days * (future ? 1 : -1));
/*     */     }
/* 158 */     if (hours > 0) {
/* 159 */       c.add(11, hours * (future ? 1 : -1));
/*     */     }
/* 161 */     if (minutes > 0) {
/* 162 */       c.add(12, minutes * (future ? 1 : -1));
/*     */     }
/* 164 */     if (seconds > 0) {
/* 165 */       c.add(13, seconds * (future ? 1 : -1));
/*     */     }
/* 167 */     return c.getTimeInMillis();
/*     */   }
/*     */   
/*     */   public static boolean isForever(long time) {
/* 171 */     return (time - System.currentTimeMillis() >= 62208000000L);
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/utils/DateUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */