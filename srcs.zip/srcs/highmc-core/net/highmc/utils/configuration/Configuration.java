/*     */ package net.highmc.utils.configuration;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.OptionalDouble;
/*     */ import java.util.OptionalInt;
/*     */ import java.util.OptionalLong;
/*     */ import lombok.NonNull;
/*     */ import net.highmc.utils.FileCreator;
/*     */ import net.highmc.utils.NumberConversions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Configuration
/*     */ {
/*  25 */   public static final FileCreator FILE_CREATOR = new DefaultFileCreator();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Configuration loadConfig() throws FileNotFoundException, Exception;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean saveConfig() throws FileNotFoundException, Exception;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getFileName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getFilePath();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Configuration defaultSave(boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Map<String, Object> getValues();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   <T extends Configuration> T watch() throws Exception;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   <T> boolean set(@NonNull String paramString, T paramT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getAsObject(@NonNull String paramString, Object paramObject, boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   <T> T get(@NonNull String paramString, T paramT, boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <T> T get(@NonNull String fieldName, T defaultValue) {
/* 101 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 102 */     return get(fieldName, defaultValue, false);
/*     */   }
/*     */   default Object get(@NonNull String fieldName) {
/* 105 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 106 */     return get(fieldName, null, false);
/*     */   }
/*     */   default String getString(@NonNull String fieldName, String defaultValue, boolean saveDefaultValue) {
/* 109 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 110 */     return String.class.cast(get(fieldName, defaultValue, saveDefaultValue));
/*     */   }
/*     */   default String getString(@NonNull String fieldName) {
/* 113 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 114 */     return getString(fieldName, null, false);
/*     */   }
/*     */   default String getString(@NonNull String fieldName, String defaultValue) {
/* 117 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 118 */     return getString(fieldName, defaultValue, false);
/*     */   }
/*     */   default <T> T getAs(@NonNull String fieldName, T defaultValue, boolean saveDefaultValue, Class<T> clazz) {
/* 121 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 122 */     return clazz.cast(get(fieldName, defaultValue, saveDefaultValue));
/*     */   }
/*     */   default <T> T getAs(@NonNull String fieldName, T defaultValue, Class<T> clazz) {
/* 125 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 126 */     return getAs(fieldName, defaultValue, false, clazz);
/*     */   }
/*     */   default <T> T getAs(@NonNull String fieldName, Class<T> clazz) {
/* 129 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 130 */     return getAs(fieldName, null, false, clazz);
/*     */   }
/*     */   default OptionalInt getInt(@NonNull String fieldName, int defaultValue, boolean saveDefaultValue) {
/* 133 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 134 */     Object object = getAsObject(fieldName, Integer.valueOf(defaultValue), saveDefaultValue);
/* 135 */     return OptionalInt.of((object instanceof Number) ? NumberConversions.toInt(object) : 0);
/*     */   }
/*     */   default OptionalInt getInt(@NonNull String fieldName) {
/* 138 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 139 */     return getInt(fieldName, 0, false);
/*     */   }
/*     */   default OptionalInt getInt(@NonNull String fieldName, int defaultValue) {
/* 142 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 143 */     return getInt(fieldName, defaultValue, false);
/*     */   }
/*     */   default OptionalDouble getDouble(@NonNull String fieldName, double defaultValue, boolean saveDefaultValue) {
/* 146 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 147 */     Object object = getAsObject(fieldName, Double.valueOf(defaultValue), saveDefaultValue);
/* 148 */     return OptionalDouble.of((object instanceof Number) ? NumberConversions.toDouble(object) : 0.0D);
/*     */   }
/*     */   default OptionalDouble getDouble(@NonNull String fieldName, Double defaultValue) {
/* 151 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 152 */     return getDouble(fieldName, defaultValue.doubleValue(), false);
/*     */   }
/*     */   default OptionalDouble getDouble(@NonNull String fieldName) {
/* 155 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 156 */     return getDouble(fieldName, 0.0D, false);
/*     */   }
/*     */   default OptionalLong getLong(@NonNull String fieldName, long defaultValue, boolean saveDefaultValue) {
/* 159 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 160 */     Object object = getAsObject(fieldName, Long.valueOf(defaultValue), saveDefaultValue);
/* 161 */     return OptionalLong.of((object instanceof Number) ? NumberConversions.toLong(object) : 0L);
/*     */   }
/*     */   default OptionalLong getLong(@NonNull String fieldName, Long defaultValue) {
/* 164 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 165 */     return getLong(fieldName, defaultValue.longValue(), false);
/*     */   }
/*     */   default OptionalLong getLong(@NonNull String fieldName) {
/* 168 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 169 */     return getLong(fieldName, 0L, false);
/*     */   }
/*     */   default float getFloat(@NonNull String fieldName, float defaultValue, boolean saveDefaultValue) {
/* 172 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 173 */     Object object = getAsObject(fieldName, Float.valueOf(defaultValue), saveDefaultValue);
/* 174 */     return (object instanceof Number) ? NumberConversions.toFloat(object) : 0.0F;
/*     */   }
/*     */   default float getFloat(@NonNull String fieldName, float defaultValue) {
/* 177 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 178 */     return getFloat(fieldName, defaultValue, false);
/*     */   }
/*     */   default float getFloat(@NonNull String fieldName) {
/* 181 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 182 */     return getFloat(fieldName, 0.0F, false);
/*     */   }
/*     */   default boolean getBoolean(@NonNull String fieldName, Boolean defaultValue, boolean saveDefaultValue) {
/* 185 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 186 */     return ((Boolean)Boolean.class.cast(getAs(fieldName, defaultValue, saveDefaultValue, Boolean.class))).booleanValue();
/*     */   }
/*     */   default boolean getBoolean(@NonNull String fieldName, boolean defaultValue) {
/* 189 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 190 */     return getBoolean(fieldName, Boolean.valueOf(defaultValue), false);
/*     */   }
/*     */   default boolean getBoolean(@NonNull String fieldName) {
/* 193 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 194 */     return getBoolean(fieldName, Boolean.valueOf(false), false);
/*     */   }
/*     */   
/*     */   <T> List<T> getList(String paramString, List<T> paramList, boolean paramBoolean, Class<T> paramClass);
/*     */   
/*     */   default <T> List<T> getList(String fieldName, Class<T> clazz) {
/* 200 */     return getList(fieldName, new ArrayList<>(), false, clazz);
/*     */   }
/*     */   
/*     */   <T> boolean addElementToList(String paramString, T paramT);
/*     */   
/*     */   <T> boolean setElementToList(String paramString, int paramInt, T paramT);
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/utils/configuration/Configuration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */