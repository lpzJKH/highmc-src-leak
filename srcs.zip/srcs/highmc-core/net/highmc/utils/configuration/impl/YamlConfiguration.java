package net.highmc.utils.configuration.impl;

public class YamlConfiguration {}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/utils/configuration/impl/YamlConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */