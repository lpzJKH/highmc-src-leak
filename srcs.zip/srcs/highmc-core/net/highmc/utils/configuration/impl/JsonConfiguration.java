/*     */ package net.highmc.utils.configuration.impl;
/*     */ 
/*     */ import com.google.common.collect.ImmutableMap;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.stream.JsonReader;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import lombok.NonNull;
/*     */ import net.highmc.CommonConst;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.utils.FileWatcher;
/*     */ import net.highmc.utils.configuration.Configuration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonConfiguration
/*     */   implements Configuration
/*     */ {
/*     */   private final String fileName;
/*     */   private final String filePath;
/*     */   private boolean defaultSave;
/*     */   private Runnable watchChanges;
/*     */   private Map<String, Object> map;
/*     */   private Set<String> verifySet;
/*     */   
/*     */   public JsonConfiguration(String fileName, String filePath) {
/*  54 */     this.verifySet = new HashSet<>(); this.fileName = fileName; this.filePath = filePath; } public static void main(String[] args) { Configuration jsonConfiguration = (new JsonConfiguration("bedwars.json", "C:\\Users\\ALLAN\\Desktop\\high\\Server\\Bedwars 2\\plugins\\GameAPI")).defaultSave(true); try { jsonConfiguration.loadConfig(); } catch (Exception e) { e.printStackTrace(); }  System.out.println(jsonConfiguration.getInt("maxPlayers", 8)); jsonConfiguration.set("maxPlayers", Integer.valueOf(8)); } public String getFileName() { return this.fileName; } public String getFilePath() { return this.filePath; } public Set<String> getVerifySet() { return this.verifySet; }
/*     */   public boolean isDefaultSave() { return this.defaultSave; }
/*     */   public Runnable getWatchChanges() { return this.watchChanges; }
/*  57 */   public Map<String, Object> getMap() { return this.map; } public JsonConfiguration(String fileName, String filePath, boolean defaultSave) { this(fileName, filePath);
/*  58 */     this.defaultSave = defaultSave; }
/*     */ 
/*     */ 
/*     */   
/*     */   public Configuration loadConfig() throws FileNotFoundException, Exception {
/*  63 */     FileInputStream fileInputStream = new FileInputStream(FILE_CREATOR.createFile(this.fileName, this.filePath));
/*  64 */     InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream, "UTF-8");
/*     */     
/*  66 */     JsonReader jsonReader = new JsonReader(inputStreamReader);
/*  67 */     this.map = (Map<String, Object>)CommonConst.GSON_PRETTY.fromJson(jsonReader, Map.class);
/*     */     
/*  69 */     for (Map.Entry<String, Object> entry : this.map.entrySet()) {
/*  70 */       Object object = entry.getValue();
/*     */       
/*  72 */       if (object instanceof com.google.gson.internal.LinkedTreeMap) {
/*  73 */         JsonElement jsonElement = CommonConst.GSON.toJsonTree(object);
/*  74 */         entry.setValue(jsonElement);
/*     */       } 
/*     */     } 
/*     */     
/*  78 */     jsonReader.close();
/*  79 */     inputStreamReader.close();
/*  80 */     fileInputStream.close();
/*  81 */     this.verifySet.clear();
/*  82 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean saveConfig() throws FileNotFoundException, Exception {
/*  87 */     String json = CommonConst.GSON_PRETTY.toJson(this.map);
/*     */     
/*  89 */     FileOutputStream fileOutputStream = new FileOutputStream(FILE_CREATOR.createFile(this.fileName, this.filePath));
/*  90 */     OutputStreamWriter outputStreamReader = new OutputStreamWriter(fileOutputStream, "UTF-8");
/*     */     
/*  92 */     BufferedWriter bufferedWriter = new BufferedWriter(outputStreamReader);
/*     */     
/*  94 */     bufferedWriter.write(json);
/*     */     
/*  96 */     bufferedWriter.flush();
/*  97 */     bufferedWriter.close();
/*  98 */     fileOutputStream.close();
/*  99 */     outputStreamReader.close();
/* 100 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Configuration defaultSave(boolean defaultSave) {
/* 105 */     this.defaultSave = defaultSave;
/* 106 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Object> getValues() {
/* 111 */     return (Map<String, Object>)ImmutableMap.copyOf(this.map);
/*     */   }
/*     */   
/*     */   public <T> boolean set(@NonNull String fieldName, T value) {
/* 115 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 116 */     this.map.put(fieldName, value);
/*     */     
/* 118 */     if (this.defaultSave) {
/*     */       try {
/* 120 */         return saveConfig();
/* 121 */       } catch (Exception ex) {
/* 122 */         ex.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/* 126 */     return true;
/*     */   }
/*     */   
/*     */   public Object getAsObject(@NonNull String fieldName, Object defaultValue, boolean saveDefaultValue) {
/* 130 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 131 */     if (this.map.containsKey(fieldName)) {
/* 132 */       return this.map.get(fieldName);
/*     */     }
/* 134 */     if (saveDefaultValue && defaultValue != null) {
/* 135 */       set(fieldName, defaultValue);
/*     */     }
/* 137 */     return defaultValue;
/*     */   }
/*     */   
/*     */   public <T> T get(@NonNull String fieldName, T defaultValue, boolean saveDefaultValue) {
/* 141 */     if (fieldName == null) throw new NullPointerException("fieldName is marked non-null but is null"); 
/* 142 */     if (this.map.containsKey(fieldName)) {
/* 143 */       return (T)this.map.get(fieldName);
/*     */     }
/*     */     
/* 146 */     if (saveDefaultValue && defaultValue != null) {
/* 147 */       set(fieldName, defaultValue);
/*     */     }
/* 149 */     return defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> List<T> getList(String fieldName, List<T> defaultValue, boolean saveDefaultValue, Class<T> clazz) {
/* 154 */     if (this.map.containsKey(fieldName)) {
/* 155 */       Object object = this.map.get(fieldName);
/*     */       
/* 157 */       if (object instanceof List) {
/* 158 */         if (!this.verifySet.contains(fieldName)) {
/* 159 */           List<T> list = (List<T>)object;
/*     */           
/* 161 */           int index = 0;
/* 162 */           for (T t : list) {
/* 163 */             if (t instanceof com.google.gson.internal.LinkedTreeMap) {
/* 164 */               JsonElement jsonElement = CommonConst.GSON_PRETTY.toJsonTree(t);
/* 165 */               list.set(index, (T)CommonConst.GSON_PRETTY.fromJson(jsonElement, clazz));
/*     */             } 
/*     */             
/* 168 */             index++;
/*     */           } 
/*     */           
/* 171 */           this.verifySet.add(fieldName);
/*     */         } 
/*     */         
/* 174 */         return List.class.cast(object);
/*     */       } 
/*     */     } 
/*     */     
/* 178 */     if (saveDefaultValue && defaultValue != null) {
/* 179 */       set(fieldName, defaultValue);
/*     */     }
/* 181 */     return defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> boolean addElementToList(String fieldName, T value) {
/* 186 */     ((List<T>)this.map.computeIfAbsent(fieldName, v -> new ArrayList())).add(value);
/*     */     
/* 188 */     if (this.defaultSave) {
/*     */       try {
/* 190 */         return saveConfig();
/* 191 */       } catch (Exception ex) {
/* 192 */         ex.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/* 196 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> boolean setElementToList(String fieldName, int index, T value) {
/* 201 */     ((List<T>)this.map.computeIfAbsent(fieldName, v -> new ArrayList())).set(index, value);
/*     */     
/* 203 */     if (this.defaultSave) {
/*     */       try {
/* 205 */         return saveConfig();
/* 206 */       } catch (Exception ex) {
/* 207 */         ex.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/* 211 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonConfiguration watch() throws Exception {
/* 216 */     if (this.watchChanges == null) {
/* 217 */       CommonPlugin.getInstance().getPluginPlatform()
/* 218 */         .run(this.watchChanges = (Runnable)new FileWatcher(FILE_CREATOR.createFile(this.fileName, this.filePath))
/*     */           {
/*     */             public void onChange()
/*     */             {
/*     */               try {
/* 223 */                 JsonConfiguration.this.loadConfig();
/* 224 */               } catch (Exception e) {
/* 225 */                 e.printStackTrace();
/*     */               } 
/*     */             }
/*     */           }100L, 100L);
/*     */     } else {
/*     */       
/* 231 */       throw new Exception("Cannot disable watch file");
/*     */     } 
/* 233 */     return this;
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/utils/configuration/impl/JsonConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */