package net.highmc.utils.configuration.impl;

public class MongoConfiguration {}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/utils/configuration/impl/MongoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */