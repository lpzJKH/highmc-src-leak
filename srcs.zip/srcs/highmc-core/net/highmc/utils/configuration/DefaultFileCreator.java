/*    */ package net.highmc.utils.configuration;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.net.URI;
/*    */ import java.net.URL;
/*    */ import java.nio.file.CopyOption;
/*    */ import java.nio.file.FileSystem;
/*    */ import java.nio.file.FileSystems;
/*    */ import java.nio.file.Files;
/*    */ import java.nio.file.Path;
/*    */ import java.nio.file.Paths;
/*    */ import java.nio.file.StandardCopyOption;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import net.highmc.utils.FileCreator;
/*    */ 
/*    */ public class DefaultFileCreator implements FileCreator {
/*    */   public File createFile(String fileName, String path) throws Exception {
/* 19 */     File file = new File(path + File.separatorChar + fileName);
/*    */     
/* 21 */     if (!file.exists()) {
/* 22 */       URL url = getClass().getClassLoader().getResource(fileName);
/*    */       
/* 24 */       if (url == null) {
/* 25 */         return null;
/*    */       }
/*    */       
/* 28 */       file.createNewFile();
/* 29 */       URI uri = url.toURI();
/* 30 */       Map<String, String> env = new HashMap<>();
/* 31 */       env.put("create", "true");
/* 32 */       FileSystem zipfs = FileSystems.newFileSystem(uri, env);
/* 33 */       Path resourceFile = Paths.get(uri);
/* 34 */       Files.copy(resourceFile, file.toPath(), new CopyOption[] { StandardCopyOption.REPLACE_EXISTING });
/* 35 */       zipfs.close();
/*    */     } 
/*    */     
/* 38 */     return file;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/utils/configuration/DefaultFileCreator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */