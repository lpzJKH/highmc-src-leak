/*    */ package net.highmc.utils.string;
/*    */ 
/*    */ import net.highmc.CommonConst;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CodeCreator
/*    */ {
/*    */   public CodeCreator(int characters) {
/* 24 */     this.upperCase = true;
/* 25 */     this.numbers = true;
/* 26 */     this.specialCharacters = true; this.characters = characters; } public CodeCreator(int characters, boolean upperCase, boolean numbers, boolean specialCharacters) { this.upperCase = true; this.numbers = true; this.specialCharacters = true; this.characters = characters; this.upperCase = upperCase; this.numbers = numbers; this.specialCharacters = specialCharacters; } public static final CodeCreator DEFAULT_CREATOR = (new CodeCreator(12)).setSpecialCharacters(false); public static final CodeCreator DEFAULT_CREATOR_LETTERS_ONLY = (new CodeCreator(12)).setNumbers(false).setSpecialCharacters(false).setUpperCase(false); public static final CodeCreator DEFAULT_CREATOR_SPECIAL = new CodeCreator(12); private static final String LETTERS = "abcdefghijklmnopqrstuvwxyz"; private static final String NUMBERS = "123456789"; private static final String SPECIAL_CHARACTERS = "@_-()*&%$#!"; public boolean isSpecialCharacters() { return this.specialCharacters; }
/*    */   private final int characters;
/*    */   private boolean upperCase;
/* 29 */   private boolean numbers; private boolean specialCharacters; public int getCharacters() { return this.characters; } public boolean isUpperCase() { return this.upperCase; } public boolean isNumbers() { return this.numbers; } public CodeCreator setUpperCase(boolean upperCase) { this.upperCase = upperCase;
/* 30 */     return this; }
/*    */ 
/*    */   
/*    */   public CodeCreator setNumbers(boolean numbers) {
/* 34 */     this.numbers = numbers;
/* 35 */     return this;
/*    */   }
/*    */   
/*    */   public CodeCreator setSpecialCharacters(boolean specialCharacters) {
/* 39 */     this.specialCharacters = specialCharacters;
/* 40 */     return this;
/*    */   }
/*    */   
/*    */   public String random() {
/* 44 */     return random(this.characters);
/*    */   }
/*    */   
/*    */   public String random(int characters) {
/* 48 */     String avaiableCharacters = "abcdefghijklmnopqrstuvwxyz";
/*    */     
/* 50 */     if (this.upperCase) {
/* 51 */       avaiableCharacters = avaiableCharacters + "abcdefghijklmnopqrstuvwxyz".toUpperCase();
/*    */     }
/* 53 */     if (this.numbers) {
/* 54 */       avaiableCharacters = avaiableCharacters + "123456789";
/*    */     }
/* 56 */     if (this.specialCharacters) {
/* 57 */       avaiableCharacters = avaiableCharacters + "@_-()*&%$#!";
/*    */     }
/* 59 */     char[] chars = avaiableCharacters.toCharArray();
/* 60 */     StringBuilder code = new StringBuilder();
/*    */     
/* 62 */     for (int x = 1; x <= characters; x++) {
/* 63 */       code.append(chars[CommonConst.RANDOM.nextInt(chars.length)]);
/*    */     }
/*    */     
/* 66 */     return code.toString();
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/utils/string/CodeCreator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */