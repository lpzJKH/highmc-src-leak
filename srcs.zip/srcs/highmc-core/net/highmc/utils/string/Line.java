/*    */ package net.highmc.utils.string;
/*    */ 
/*    */ import com.google.common.base.Joiner;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ public class Line
/*    */ {
/* 10 */   private List<String> lines = new ArrayList<>();
/*    */   
/*    */   public Line line(String line) {
/* 13 */     this.lines.add(line.isEmpty() ? "§f" : line);
/* 14 */     return this;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 18 */     return Joiner.on('\n').join(this.lines);
/*    */   }
/*    */   
/*    */   public static Line create() {
/* 22 */     return new Line();
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/utils/string/Line.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */