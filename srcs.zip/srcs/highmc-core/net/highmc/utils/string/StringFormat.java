/*     */ package net.highmc.utils.string;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.OptionalDouble;
/*     */ import java.util.OptionalInt;
/*     */ import java.util.OptionalLong;
/*     */ import net.highmc.CommonConst;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.utils.supertype.OptionalBoolean;
/*     */ 
/*     */ 
/*     */ public class StringFormat
/*     */ {
/*     */   public static String formatString(String separator, Number... numbers) {
/*  16 */     StringBuilder stringBuilder = new StringBuilder();
/*     */     
/*  18 */     for (int i = 0; i < numbers.length; i++) {
/*  19 */       stringBuilder.append(CommonConst.DECIMAL_FORMAT.format(numbers[i].doubleValue()));
/*     */       
/*  21 */       if (i != numbers.length - 1) {
/*  22 */         stringBuilder.append(separator);
/*     */       }
/*     */     } 
/*  25 */     return stringBuilder.toString().trim();
/*     */   }
/*     */   
/*     */   public static String formatString(Enum<?> toFormat) {
/*  29 */     return formatString(toFormat.name().replace("_", " "));
/*     */   }
/*     */   
/*     */   public static String centerString(String string) {
/*  33 */     return centerString(string, 154);
/*     */   }
/*     */   
/*     */   public static String centerString(String string, int center) {
/*  37 */     if (string == null || string.equals("")) {
/*  38 */       return "";
/*     */     }
/*  40 */     string = string.replace("&", "§");
/*     */     
/*  42 */     int messagePxSize = 0;
/*  43 */     boolean previousCode = false;
/*  44 */     boolean isBold = false;
/*     */     
/*  46 */     for (char c : string.toCharArray()) {
/*  47 */       if (c == '§')
/*  48 */       { previousCode = true; }
/*     */       
/*  50 */       else if (previousCode == true)
/*  51 */       { previousCode = false;
/*  52 */         if (c == 'l' || c == 'L') {
/*  53 */           isBold = true;
/*     */         } else {
/*     */           
/*  56 */           isBold = false;
/*     */         }  }
/*  58 */       else { DefaultFontInfo dFI = DefaultFontInfo.getDefaultFontInfo(c);
/*  59 */         messagePxSize += isBold ? dFI.getBoldLength() : dFI.getLength();
/*  60 */         messagePxSize++; }
/*     */     
/*     */     } 
/*     */     
/*  64 */     int halvedMessageSize = messagePxSize / 2;
/*  65 */     int toCompensate = center - halvedMessageSize;
/*  66 */     int spaceLength = DefaultFontInfo.SPACE.getLength() + 1;
/*  67 */     int compensated = 0;
/*  68 */     StringBuilder stringBuilder = new StringBuilder();
/*  69 */     while (compensated < toCompensate) {
/*  70 */       stringBuilder.append(" ");
/*  71 */       compensated += spaceLength;
/*     */     } 
/*  73 */     return stringBuilder.toString() + string;
/*     */   }
/*     */   
/*     */   public static String join(List<String> input, String separator) {
/*  77 */     if (input == null || input.size() <= 0) {
/*  78 */       return "";
/*     */     }
/*  80 */     StringBuilder sb = new StringBuilder();
/*     */     
/*  82 */     for (int i = 0; i < input.size(); i++) {
/*     */       
/*  84 */       sb.append(input.get(i));
/*     */       
/*  86 */       if (i != input.size() - 1) {
/*  87 */         sb.append(separator);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  92 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String join(String[] input, String separator) {
/*  97 */     if (input == null || input.length <= 0) {
/*  98 */       return "";
/*     */     }
/* 100 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 102 */     for (int i = 0; i < input.length; i++) {
/*     */       
/* 104 */       sb.append(input[i]);
/*     */       
/* 106 */       if (i != input.length - 1) {
/* 107 */         sb.append(separator);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 112 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public static String format(int time) {
/* 116 */     if (time >= 3600) {
/* 117 */       int hours = time / 3600, i = time % 3600 / 60, j = time % 3600 % 60;
/* 118 */       return ((hours < 10) ? "0" : "") + hours + ":" + ((i < 10) ? "0" : "") + i + ":" + ((j < 10) ? "0" : "") + j;
/*     */     } 
/*     */     
/* 121 */     int minutes = time / 60, seconds = time % 60;
/* 122 */     return minutes + ":" + ((seconds < 10) ? "0" : "") + seconds;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String formatTime(int time) {
/* 127 */     return formatTime(time, TimeFormat.SHORT);
/*     */   }
/*     */   
/*     */   public static String formatTime(Language language, int time) {
/* 131 */     return formatTime(language, time, TimeFormat.SHORT);
/*     */   }
/*     */   
/*     */   public static String formatTime(Language language, int time, TimeFormat timeFormat) {
/* 135 */     int days = time / 3600 / 24, hours = time / 3600 % 24, minutes = time % 3600 / 60;
/* 136 */     int seconds = time % 3600 % 60;
/*     */     
/* 138 */     switch (timeFormat) {
/*     */       case SIMPLIFIED:
/* 140 */         if (days > 0)
/* 141 */           return days + " " + language.t("day", new String[0]) + ((days == 1) ? "" : "s"); 
/* 142 */         if (hours > 0)
/* 143 */           return hours + " " + language.t("hour", new String[0]) + ((hours == 1) ? "" : "s"); 
/* 144 */         if (minutes > 0) {
/* 145 */           return minutes + " " + language.t("minute", new String[0]) + ((minutes == 1) ? "" : "s");
/*     */         }
/* 147 */         return seconds + " " + language.t("second", new String[0]) + ((seconds == 1) ? " " : "s");
/*     */       case SHORT_SIMPLIFIED:
/* 149 */         if (days > 0)
/* 150 */           return days + "d"; 
/* 151 */         if (hours > 0)
/* 152 */           return hours + "h"; 
/* 153 */         if (minutes > 0) {
/* 154 */           return minutes + "m";
/*     */         }
/* 156 */         return seconds + "s";
/*     */       case SHORT:
/* 158 */         return ((days > 0) ? (days + "d" + ((hours > 0 || minutes > 0 || seconds > 0) ? " " : "")) : "") + ((hours > 0) ? (hours + "h" + ((seconds > 0 || minutes > 0) ? " " : "")) : "") + ((minutes > 0) ? (minutes + "m" + ((seconds > 0) ? " " : "")) : "") + ((seconds == 0 && (days > 0 || hours > 0 || minutes > 0)) ? "" : (seconds + "s"));
/*     */ 
/*     */ 
/*     */       
/*     */       case NORMAL:
/* 163 */         return ((days > 0) ? (days + " " + language
/* 164 */           .t("day", new String[0]) + ((days == 1) ? "" : "s") + ((hours > 0 || minutes > 0 || seconds > 0) ? " " : "")) : "") + ((hours > 0) ? (hours + " " + language
/*     */ 
/*     */ 
/*     */           
/* 168 */           .t("hour", new String[0]) + ((days == 1) ? "" : "s") + ((seconds > 0 || minutes > 0) ? " " : "")) : "") + ((minutes > 0) ? (minutes + " " + language
/*     */ 
/*     */ 
/*     */           
/* 172 */           .t("minute", new String[0]) + ((minutes == 1) ? "" : "s") + ((seconds > 0) ? " " : "")) : "") + ((seconds == 0 && (days > 0 || hours > 0 || minutes > 0)) ? "" : (seconds + " " + language
/*     */ 
/*     */ 
/*     */           
/* 176 */           .t("second", new String[0]) + ((seconds == 1) ? "" : "s")));
/*     */       case DOUBLE_DOT:
/* 178 */         return "" + ((hours > 0) ? (((hours >= 10) ? (String)Integer.valueOf(hours) : ("0" + hours)) + ":") : "") + ((minutes >= 10) ? 
/* 179 */           (String)Integer.valueOf(minutes) : ("0" + minutes)) + ":" + ((seconds >= 10) ? (String)Integer.valueOf(seconds) : ("0" + seconds));
/*     */     } 
/* 181 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   public static String formatTime(int time, TimeFormat timeFormat) {
/* 186 */     return formatTime(CommonPlugin.getInstance().getPluginInfo().getDefaultLanguage(), time, timeFormat);
/*     */   }
/*     */   
/*     */   public static String formatString(String string) {
/* 190 */     if (string.isEmpty()) {
/* 191 */       return string;
/*     */     }
/* 193 */     char[] stringArray = string.toLowerCase().toCharArray();
/* 194 */     stringArray[0] = Character.toUpperCase(stringArray[0]);
/* 195 */     return new String(stringArray);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {}
/*     */   
/*     */   public static String formatToCamelCase(String string) {
/* 202 */     if (string.isEmpty()) {
/* 203 */       return string;
/*     */     }
/* 205 */     boolean camelCase = true;
/* 206 */     StringBuilder stringBuilder = new StringBuilder();
/*     */     
/* 208 */     for (char test : string.toCharArray()) {
/* 209 */       if (camelCase) {
/* 210 */         stringBuilder.append(Character.toUpperCase(test));
/* 211 */         camelCase = false;
/*     */       }
/*     */       else {
/*     */         
/* 215 */         if (test == ' ') {
/* 216 */           camelCase = true;
/*     */         }
/* 218 */         stringBuilder.append(Character.toLowerCase(test));
/*     */       } 
/*     */     } 
/* 221 */     return stringBuilder.toString().trim();
/*     */   }
/*     */   
/*     */   public static String getName(Enum<?> e) {
/* 225 */     String name = e.name();
/* 226 */     String[] names = name.split("_");
/*     */     
/* 228 */     for (int i = 0; i < names.length; i++) {
/* 229 */       names[i] = (i == 0) ? formatString(names[i]) : names[i].toUpperCase();
/*     */     }
/* 231 */     return join(names, " ");
/*     */   }
/*     */   
/*     */   public static String getName(String string) {
/* 235 */     return toReadable(string);
/*     */   }
/*     */   
/*     */   public static String toReadable(String string) {
/* 239 */     String[] names = string.split("_");
/*     */     
/* 241 */     for (int i = 0; i < names.length; i++) {
/* 242 */       names[i] = names[i].substring(0, 1) + names[i].substring(1).toLowerCase();
/*     */     }
/* 244 */     return join(names, " ");
/*     */   }
/*     */   
/*     */   public enum TimeFormat
/*     */   {
/* 249 */     NORMAL, SIMPLIFIED, SHORT, SHORT_SIMPLIFIED, DOUBLE_DOT;
/*     */   }
/*     */ 
/*     */   
/*     */   public enum DefaultFontInfo
/*     */   {
/* 255 */     A('A', 5), a('a', 5), B('B', 5), b('b', 5), C('C', 5), c('c', 5), D('D', 5), d('d', 5), E('E', 5), e('e', 5),
/* 256 */     F('F', 5), f('f', 4), G('G', 5), g('g', 5), H('H', 5), h('h', 5), I('I', 3), i('i', 1), J('J', 5), j('j', 5),
/* 257 */     K('K', 5), k('k', 4), L('L', 5), l('l', 1), M('M', 5), m('m', 5), N('N', 5), n('n', 5), O('O', 5), o('o', 5),
/* 258 */     P('P', 5), p('p', 5), Q('Q', 5), q('q', 5), R('R', 5), r('r', 5), S('S', 5), s('s', 5), T('T', 5), t('t', 4),
/* 259 */     U('U', 5), u('u', 5), V('V', 5), v('v', 5), W('W', 5), w('w', 5), X('X', 5), x('x', 5), Y('Y', 5), y('y', 5),
/* 260 */     Z('Z', 5), z('z', 5), NUM_1('1', 5), NUM_2('2', 5), NUM_3('3', 5), NUM_4('4', 5), NUM_5('5', 5), NUM_6('6', 5),
/* 261 */     NUM_7('7', 5), NUM_8('8', 5), NUM_9('9', 5), NUM_0('0', 5), EXCLAMATION_POINT('!', 1), AT_SYMBOL('@', 6),
/* 262 */     NUM_SIGN('#', 5), DOLLAR_SIGN('$', 5), PERCENT('%', 5), UP_ARROW('^', 5), AMPERSAND('&', 5), ASTERISK('*', 5),
/* 263 */     LEFT_PARENTHESIS('(', 4), RIGHT_PERENTHESIS(')', 4), MINUS('-', 5), UNDERSCORE('_', 5), PLUS_SIGN('+', 5),
/* 264 */     EQUALS_SIGN('=', 5), LEFT_CURL_BRACE('{', 4), RIGHT_CURL_BRACE('}', 4), LEFT_BRACKET('[', 3),
/* 265 */     RIGHT_BRACKET(']', 3), COLON(':', 1), SEMI_COLON(';', 1), DOUBLE_QUOTE('"', 3), SINGLE_QUOTE('\'', 1),
/* 266 */     LEFT_ARROW('<', 4), RIGHT_ARROW('>', 4), QUESTION_MARK('?', 5), SLASH('/', 5), BACK_SLASH('\\', 5),
/* 267 */     LINE('|', 1), TILDE('~', 5), TICK('`', 2), PERIOD('.', 1), COMMA(',', 1), SPACE(' ', 3), DEFAULT('a', 4);
/*     */     
/*     */     private char character;
/*     */     private int length;
/*     */     
/*     */     DefaultFontInfo(char character, int length) {
/* 273 */       this.character = character;
/* 274 */       this.length = length;
/*     */     }
/*     */     
/*     */     public char getCharacter() {
/* 278 */       return this.character;
/*     */     }
/*     */     
/*     */     public int getLength() {
/* 282 */       return this.length;
/*     */     }
/*     */     
/*     */     public int getBoldLength() {
/* 286 */       if (this == SPACE)
/* 287 */         return getLength(); 
/* 288 */       return this.length + 1;
/*     */     }
/*     */     
/*     */     public static DefaultFontInfo getDefaultFontInfo(char c) {
/* 292 */       for (DefaultFontInfo dFI : values()) {
/* 293 */         if (dFI.getCharacter() == c)
/* 294 */           return dFI; 
/*     */       } 
/* 296 */       return DEFAULT;
/*     */     }
/*     */   }
/*     */   
/*     */   public static OptionalLong parseLong(String string) {
/*     */     try {
/* 302 */       Long integer = Long.valueOf(Long.parseLong(string));
/* 303 */       return OptionalLong.of(integer.longValue());
/* 304 */     } catch (NumberFormatException ex) {
/* 305 */       return OptionalLong.empty();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static OptionalLong parseLong(Object object) {
/* 310 */     return parseLong(String.valueOf(object));
/*     */   }
/*     */   
/*     */   public static OptionalInt parseInt(String string) {
/*     */     try {
/* 315 */       Integer integer = Integer.valueOf(Integer.parseInt(string));
/* 316 */       return OptionalInt.of(integer.intValue());
/* 317 */     } catch (NumberFormatException ex) {
/* 318 */       return OptionalInt.empty();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static OptionalInt parseInt(Object object) {
/* 323 */     return parseInt(String.valueOf(object));
/*     */   }
/*     */   
/*     */   public static OptionalDouble parseDouble(String string) {
/*     */     try {
/* 328 */       Double integer = Double.valueOf(Double.parseDouble(string));
/* 329 */       return OptionalDouble.of(integer.doubleValue());
/* 330 */     } catch (NumberFormatException ex) {
/* 331 */       return OptionalDouble.empty();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static OptionalDouble parseDouble(Object object) {
/* 336 */     return parseDouble(String.valueOf(object));
/*     */   }
/*     */   
/*     */   public static OptionalBoolean parseBoolean(String string) {
/* 340 */     if (string.equalsIgnoreCase("true") || string.equalsIgnoreCase("false")) {
/* 341 */       return OptionalBoolean.of(string.equalsIgnoreCase("true"));
/*     */     }
/* 343 */     return OptionalBoolean.empty();
/*     */   }
/*     */   
/*     */   public static OptionalBoolean parseBoolean(Language language, String string) {
/* 347 */     String trueString = language.t("true", new String[0]);
/*     */     
/* 349 */     if (string.equalsIgnoreCase("true") || string.equalsIgnoreCase("false") || string.equalsIgnoreCase(trueString)) {
/* 350 */       return OptionalBoolean.of((string.equalsIgnoreCase("true") || string.equalsIgnoreCase(trueString)));
/*     */     }
/* 352 */     return OptionalBoolean.empty();
/*     */   }
/*     */   
/*     */   public static String getPositionFormat(int position) {
/* 356 */     return ((position == 1) ? "§a" : ((position == 2) ? "§e" : ((position == 3) ? "§c" : "§7"))) + position + "° ";
/*     */   }
/*     */   
/*     */   public static String formatRomane(int level) {
/* 360 */     switch (level) {
/*     */       case 1:
/* 362 */         return "I";
/*     */       case 2:
/* 364 */         return "II";
/*     */       case 3:
/* 366 */         return "III";
/*     */       case 4:
/* 368 */         return "IV";
/*     */       case 5:
/* 370 */         return "V";
/*     */     } 
/* 372 */     return String.valueOf(level);
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/utils/string/StringFormat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */