/*     */ package net.highmc.utils.string;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.md_5.bungee.api.chat.BaseComponent;
/*     */ import net.md_5.bungee.api.chat.ClickEvent;
/*     */ import net.md_5.bungee.api.chat.HoverEvent;
/*     */ import net.md_5.bungee.api.chat.TextComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageBuilder
/*     */ {
/*     */   private String message;
/*     */   private boolean hoverable;
/*     */   private HoverEvent hoverEvent;
/*     */   private boolean clickable;
/*     */   private ClickEvent clickEvent;
/*     */   private List<TextComponent> componentList;
/*     */   
/*     */   public String getMessage() {
/*  22 */     return this.message;
/*     */   }
/*  24 */   public boolean isHoverable() { return this.hoverable; } public HoverEvent getHoverEvent() {
/*  25 */     return this.hoverEvent;
/*     */   }
/*  27 */   public boolean isClickable() { return this.clickable; } public ClickEvent getClickEvent() {
/*  28 */     return this.clickEvent;
/*     */   } public List<TextComponent> getComponentList() {
/*  30 */     return this.componentList;
/*     */   }
/*     */   public MessageBuilder(String message) {
/*  33 */     this.message = message;
/*  34 */     this.componentList = new ArrayList<>();
/*     */   }
/*     */   
/*     */   public MessageBuilder setMessage(String message) {
/*  38 */     this.message = message;
/*  39 */     return this;
/*     */   }
/*     */   
/*     */   public MessageBuilder setHoverable(boolean hoverable) {
/*  43 */     this.hoverable = hoverable;
/*  44 */     return this;
/*     */   }
/*     */   
/*     */   public MessageBuilder setHoverEvent(HoverEvent hoverEvent) {
/*  48 */     this.hoverEvent = hoverEvent;
/*  49 */     this.hoverable = true;
/*  50 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageBuilder setHoverEvent(HoverEvent.Action action, String text) {
/*  55 */     this.hoverEvent = new HoverEvent(action, TextComponent.fromLegacyText(text));
/*  56 */     this.hoverable = true;
/*  57 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageBuilder setHoverEvent(String text) {
/*  62 */     this.hoverEvent = new HoverEvent(HoverEvent.Action.SHOW_TEXT, TextComponent.fromLegacyText(text));
/*  63 */     this.hoverable = true;
/*  64 */     return this;
/*     */   }
/*     */   
/*     */   public MessageBuilder setClickable(boolean clickable) {
/*  68 */     this.clickable = clickable;
/*  69 */     return this;
/*     */   }
/*     */   
/*     */   public MessageBuilder setClickEvent(ClickEvent clickEvent) {
/*  73 */     this.clickEvent = clickEvent;
/*  74 */     this.clickable = true;
/*  75 */     return this;
/*     */   }
/*     */   
/*     */   public MessageBuilder setClickEvent(ClickEvent.Action action, String text) {
/*  79 */     this.clickEvent = new ClickEvent(action, text);
/*  80 */     this.clickable = true;
/*  81 */     return this;
/*     */   }
/*     */   
/*     */   public MessageBuilder setClickEvent(String text) {
/*  85 */     this.clickEvent = new ClickEvent(ClickEvent.Action.RUN_COMMAND, text);
/*  86 */     this.clickable = true;
/*  87 */     return this;
/*     */   }
/*     */   
/*     */   public MessageBuilder extra(String message) {
/*  91 */     this.componentList.add(new TextComponent(message));
/*  92 */     return this;
/*     */   }
/*     */   
/*     */   public MessageBuilder extra(TextComponent textComponent) {
/*  96 */     this.componentList.add(textComponent);
/*  97 */     return this;
/*     */   }
/*     */   
/*     */   public MessageBuilder extra(List<TextComponent> extra) {
/* 101 */     this.componentList.addAll(extra);
/* 102 */     return this;
/*     */   }
/*     */   
/*     */   public TextComponent create() {
/* 106 */     TextComponent textComponent = new TextComponent(this.message);
/*     */     
/* 108 */     if (this.hoverable) {
/* 109 */       textComponent.setHoverEvent(this.hoverEvent);
/*     */     }
/* 111 */     if (this.clickable) {
/* 112 */       textComponent.setClickEvent(this.clickEvent);
/*     */     }
/* 114 */     for (TextComponent text : this.componentList) {
/* 115 */       textComponent.addExtra((BaseComponent)text);
/*     */     }
/* 117 */     return textComponent;
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/utils/string/MessageBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */