/*    */ package net.highmc.utils;
/*    */ 
/*    */ import java.io.File;
/*    */ 
/*    */ public abstract class FileWatcher
/*    */   implements Runnable {
/*    */   private File file;
/*    */   private long lastModified;
/*    */   
/*    */   public FileWatcher(File file) {
/* 11 */     this.file = file;
/* 12 */     this.lastModified = file.lastModified();
/*    */   }
/*    */ 
/*    */   
/*    */   public void run() {
/* 17 */     if (this.lastModified != this.file.lastModified()) {
/* 18 */       onChange();
/* 19 */       this.lastModified = this.file.lastModified();
/*    */     } 
/*    */   }
/*    */   
/*    */   public abstract void onChange();
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/utils/FileWatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */