/*    */ package net.highmc.utils;
/*    */ 
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ public enum ProtocolVersion
/*    */ {
/*  7 */   MINECRAFT_1_16_3(753),
/*  8 */   MINECRAFT_1_16_2(751),
/*  9 */   MINECRAFT_1_16_1(736),
/* 10 */   MINECRAFT_1_16(735),
/* 11 */   MINECRAFT_1_15_2(578),
/* 12 */   MINECRAFT_1_15_1(575),
/* 13 */   MINECRAFT_1_15(573),
/* 14 */   MINECRAFT_1_14_4(498),
/* 15 */   MINECRAFT_1_14_3(490),
/* 16 */   MINECRAFT_1_14_2(485),
/* 17 */   MINECRAFT_1_14_1(480),
/* 18 */   MINECRAFT_1_14(477),
/* 19 */   MINECRAFT_1_13_2(404),
/* 20 */   MINECRAFT_1_13_1(401),
/* 21 */   MINECRAFT_1_13(393),
/* 22 */   MINECRAFT_1_12_2(340),
/* 23 */   MINECRAFT_1_12_1(338),
/* 24 */   MINECRAFT_1_12(335),
/* 25 */   MINECRAFT_1_11_1(316),
/* 26 */   MINECRAFT_1_11(315),
/* 27 */   MINECRAFT_1_10(210),
/* 28 */   MINECRAFT_1_9_3(110),
/* 29 */   MINECRAFT_1_9_2(109),
/* 30 */   MINECRAFT_1_9_1(108),
/* 31 */   MINECRAFT_1_9(107),
/* 32 */   MINECRAFT_1_8(47),
/* 33 */   MINECRAFT_1_7_10(5),
/* 34 */   MINECRAFT_1_7_2(4),
/* 35 */   UNKNOWN(-1);
/*    */   
/*    */   private int id;
/*    */   
/*    */   ProtocolVersion(int id) {
/* 40 */     this.id = id;
/*    */   }
/*    */   
/*    */   public int getId() {
/* 44 */     return this.id;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 49 */     return super.toString().replace("MINECRAFT_", "").replace("_", ".");
/*    */   }
/*    */   
/*    */   public static ProtocolVersion getById(int id) {
/* 53 */     return Stream.<ProtocolVersion>of(values()).filter(version -> (version.getId() == id)).findFirst().orElse(UNKNOWN);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/utils/ProtocolVersion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */