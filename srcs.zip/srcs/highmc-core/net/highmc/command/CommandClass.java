/*    */ package net.highmc.command;
/*    */ 
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.packet.Packet;
/*    */ import net.highmc.packet.types.staff.Stafflog;
/*    */ import net.highmc.server.ServerType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface CommandClass
/*    */ {
/*    */   default void staffLog(String message) {
/* 15 */     CommonPlugin.getInstance().getMemberManager().staffLog(message);
/*    */   }
/*    */   
/*    */   default void staffLog(String message, boolean bungeecord) {
/* 19 */     if (bungeecord && CommonPlugin.getInstance().getServerType() != ServerType.BUNGEECORD) {
/* 20 */       CommonPlugin.getInstance().getServerData().sendPacket((Packet)new Stafflog("§7[" + message + "§7]"));
/*    */     } else {
/* 22 */       CommonPlugin.getInstance().getMemberManager().staffLog(message);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/command/CommandClass.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */