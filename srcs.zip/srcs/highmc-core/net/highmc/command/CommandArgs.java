/*    */ package net.highmc.command;
/*    */ 
/*    */ import net.highmc.member.Member;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CommandArgs
/*    */ {
/*    */   private final CommandSender sender;
/*    */   private final String label;
/*    */   private final String[] args;
/*    */   
/*    */   protected CommandArgs(CommandSender sender, String label, String[] args, int subCommand) {
/* 17 */     String[] modArgs = new String[args.length - subCommand];
/* 18 */     System.arraycopy(args, subCommand, modArgs, 0, args.length - subCommand);
/*    */     
/* 20 */     StringBuilder buffer = new StringBuilder();
/* 21 */     buffer.append(label);
/*    */     
/* 23 */     for (int x = 0; x < subCommand; x++) {
/* 24 */       buffer.append(".").append(args[x]);
/*    */     }
/*    */     
/* 27 */     String cmdLabel = buffer.toString();
/* 28 */     this.sender = sender;
/* 29 */     this.label = cmdLabel;
/* 30 */     this.args = modArgs;
/*    */   }
/*    */   
/*    */   public Member getSenderAsMember() {
/* 34 */     return Member.class.cast(this.sender);
/*    */   }
/*    */   
/*    */   public <T extends Member> T getSenderAsMember(Class<T> t) {
/* 38 */     return t.cast(this.sender);
/*    */   }
/*    */   
/*    */   public CommandSender getSender() {
/* 42 */     return this.sender;
/*    */   }
/*    */   
/*    */   public String getLabel() {
/* 46 */     return this.label;
/*    */   }
/*    */   
/*    */   public String[] getArgs() {
/* 50 */     return this.args;
/*    */   }
/*    */   
/*    */   public abstract boolean isPlayer();
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/command/CommandArgs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */