/*     */ package net.highmc.command;
/*     */ 
/*     */ import java.util.UUID;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.member.Profile;
/*     */ import net.highmc.permission.Group;
/*     */ import net.md_5.bungee.api.chat.BaseComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface CommandSender
/*     */ {
/*     */   UUID getUniqueId();
/*     */   
/*     */   String getSenderName();
/*     */   
/*     */   void sendMessage(String paramString);
/*     */   
/*     */   void sendMessage(BaseComponent paramBaseComponent);
/*     */   
/*     */   void sendMessage(BaseComponent... paramVarArgs);
/*     */   
/*     */   boolean hasPermission(String paramString);
/*     */   
/*     */   void setTellEnabled(boolean paramBoolean);
/*     */   
/*     */   boolean isTellEnabled();
/*     */   
/*     */   void setReplyId(UUID paramUUID);
/*     */   
/*     */   UUID getReplyId();
/*     */   
/*     */   boolean isPlayer();
/*     */   
/*     */   boolean isStaff();
/*     */   
/*     */   boolean isUserBlocked(Profile paramProfile);
/*     */   
/*     */   default Group getServerGroup() {
/* 132 */     if (isPlayer()) {
/* 133 */       return null;
/*     */     }
/* 135 */     return CommonPlugin.getInstance().getPluginInfo().getHighGroup();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default String getName() {
/* 146 */     return getSenderName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean hasReply() {
/* 157 */     return (getReplyId() != null);
/*     */   }
/*     */   
/*     */   Language getLanguage();
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/command/CommandSender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */