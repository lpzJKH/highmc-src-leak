/*    */ package net.highmc.command;
/*    */ 
/*    */ import java.lang.annotation.ElementType;
/*    */ import java.lang.annotation.Retention;
/*    */ import java.lang.annotation.RetentionPolicy;
/*    */ import java.lang.annotation.Target;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.utils.ClassGetter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface CommandFramework
/*    */ {
/*    */   Class<?> getJarClass();
/*    */   
/*    */   void registerCommands(CommandClass paramCommandClass);
/*    */   
/*    */   default CommandFramework loadCommands(String packageName) {
/* 53 */     for (Class<?> commandClass : (Iterable<Class<?>>)ClassGetter.getClassesForPackage(getJarClass(), packageName)) {
/* 54 */       if (CommandClass.class != commandClass && 
/* 55 */         CommandClass.class.isAssignableFrom(commandClass)) {
/*    */         try {
/* 57 */           registerCommands((CommandClass)commandClass.newInstance());
/* 58 */         } catch (Exception ex) {
/* 59 */           CommonPlugin.getInstance().getLogger()
/* 60 */             .warning("Error when loading command from " + commandClass.getSimpleName() + "!");
/* 61 */           ex.printStackTrace();
/*    */         } 
/*    */       }
/*    */     } 
/* 65 */     return this;
/*    */   }
/*    */   
/*    */   default CommandFramework loadCommands(Class<?> jarClass, String packageName) {
/* 69 */     for (Class<?> commandClass : (Iterable<Class<?>>)ClassGetter.getClassesForPackage(jarClass, packageName)) {
/* 70 */       if (CommandClass.class.isAssignableFrom(commandClass)) {
/*    */         try {
/* 72 */           registerCommands((CommandClass)commandClass.newInstance());
/* 73 */         } catch (Exception e) {
/* 74 */           CommonPlugin.getInstance().getLogger()
/* 75 */             .warning("Error when loading command from " + commandClass.getSimpleName() + "!");
/* 76 */           e.printStackTrace();
/*    */         } 
/*    */       }
/*    */     } 
/* 80 */     return this;
/*    */   }
/*    */   
/*    */   @Target({ElementType.METHOD})
/*    */   @Retention(RetentionPolicy.RUNTIME)
/*    */   public static @interface Completer {
/*    */     String name();
/*    */     
/*    */     String[] aliases() default {};
/*    */   }
/*    */   
/*    */   @Target({ElementType.METHOD})
/*    */   @Retention(RetentionPolicy.RUNTIME)
/*    */   public static @interface Command {
/*    */     String name();
/*    */     
/*    */     String permission() default "";
/*    */     
/*    */     String[] aliases() default {};
/*    */     
/*    */     String description() default "";
/*    */     
/*    */     String usage() default "";
/*    */     
/*    */     boolean runAsync() default false;
/*    */     
/*    */     boolean console() default true;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/command/CommandFramework.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */