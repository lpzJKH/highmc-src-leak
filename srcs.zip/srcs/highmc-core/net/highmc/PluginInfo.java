/*     */ package net.highmc;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import net.highmc.backend.Credentials;
/*     */ import net.highmc.command.CommandSender;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.medal.Medal;
/*     */ import net.highmc.permission.Group;
/*     */ import net.highmc.permission.Tag;
/*     */ 
/*     */ public class PluginInfo {
/*     */   private String website;
/*     */   private String discord;
/*     */   private String store;
/*     */   private String ip;
/*     */   private Language defaultLanguage;
/*     */   private boolean piratePlayersEnabled;
/*     */   private boolean redisDebugEnabled;
/*     */   private boolean debug;
/*     */   
/*  30 */   public String getWebsite() { return this.website; } private Credentials mongoCredentials; private Credentials redisCredentials; private LinkedHashMap<String, Group> groupMap; private LinkedHashMap<String, Tag> tagMap; private Map<Language, Map<String, String>> languageMap; private Map<String, Medal> medalMap; private transient Tag defaultTag; private transient Group defaultGroup; public String getDiscord() {
/*  31 */     return this.discord; }
/*  32 */   public String getStore() { return this.store; }
/*  33 */   public String getIp() { return this.ip; }
/*  34 */   public void setDefaultLanguage(Language defaultLanguage) { this.defaultLanguage = defaultLanguage; } public Language getDefaultLanguage() {
/*  35 */     return this.defaultLanguage;
/*     */   }
/*  37 */   public boolean isPiratePlayersEnabled() { return this.piratePlayersEnabled; }
/*  38 */   public boolean isRedisDebugEnabled() { return this.redisDebugEnabled; } public boolean isDebug() {
/*  39 */     return this.debug;
/*     */   }
/*  41 */   public Credentials getMongoCredentials() { return this.mongoCredentials; } public Credentials getRedisCredentials() {
/*  42 */     return this.redisCredentials;
/*     */   }
/*  44 */   public LinkedHashMap<String, Group> getGroupMap() { return this.groupMap; } public LinkedHashMap<String, Tag> getTagMap() {
/*  45 */     return this.tagMap;
/*     */   }
/*  47 */   public Map<Language, Map<String, String>> getLanguageMap() { return this.languageMap; } public Map<String, Medal> getMedalMap() {
/*  48 */     return this.medalMap;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getWebsiteUrl() {
/*  54 */     return "https://" + getWebsite() + "/";
/*     */   }
/*     */   
/*     */   public void loadMedal(Medal medal) {
/*  58 */     this.medalMap.put(medal.getMedalName().toLowerCase(), medal);
/*  59 */     CommonPlugin.getInstance().saveConfig("medalMap");
/*     */   }
/*     */   
/*     */   public void loadGroup(Group group) {
/*  63 */     this.groupMap.put(group.getGroupName().toLowerCase(), group);
/*  64 */     CommonPlugin.getInstance().saveConfig("groupMap");
/*     */   }
/*     */   
/*     */   public void loadTag(Tag tag) {
/*  68 */     this.tagMap.put(tag.getTagName().toLowerCase(), tag);
/*  69 */     CommonPlugin.getInstance().saveConfig("tagMap");
/*     */   }
/*     */   
/*     */   public Tag getTagById(int id) {
/*  73 */     return this.tagMap.values().stream().filter(tag -> (tag.getTagId() == id)).findFirst().orElse(null);
/*     */   }
/*     */   
/*     */   public Group filterGroup(Predicate<? super Group> filter) {
/*  77 */     return this.groupMap.values().stream().filter(filter).findFirst().orElse(null);
/*     */   }
/*     */   
/*     */   public Group filterGroup(Predicate<? super Group> filter, Group orElse) {
/*  81 */     return this.groupMap.values().stream().filter(filter).findFirst().orElse(orElse);
/*     */   }
/*     */   
/*     */   public Group getFirstLowerGroup(int id) {
/*  85 */     return this.groupMap.values().stream().filter(group -> (group.getId() < id)).findFirst().orElse(null);
/*     */   }
/*     */   
/*     */   public Group getGroupById(int id) {
/*  89 */     return this.groupMap.values().stream().filter(group -> (group.getId() == id)).findFirst().orElse(null);
/*     */   }
/*     */   
/*     */   public Group getGroupByName(String string) {
/*  93 */     Group group = this.groupMap.get(string.toLowerCase());
/*     */     
/*  95 */     if (group == null)
/*     */     {
/*  97 */       group = this.groupMap.values().stream().filter(g -> g.getGroupName().equalsIgnoreCase(string)).findFirst().orElse(null);
/*     */     }
/*  99 */     return group;
/*     */   }
/*     */   
/*     */   public String translate(Language language, String key, String... replaces) {
/* 103 */     Map<String, String> map = this.languageMap.computeIfAbsent(language, v -> new HashMap<>());
/* 104 */     String translate = "[NOT FOUND: " + key + "]";
/*     */     
/* 106 */     if (map.containsKey(key)) {
/* 107 */       translate = (String)((Map)this.languageMap.get(language)).get(key);
/*     */       
/* 109 */       if (replaces.length > 0 && replaces.length % 2 == 0) {
/* 110 */         for (int i = 0; i < replaces.length; i += 2) {
/* 111 */           translate = translate.replace(replaces[i], replaces[i + 1]);
/*     */         }
/*     */       }
/*     */     } else {
/* 115 */       if (this.defaultLanguage == language) {
/* 116 */         map.put(key, translate);
/*     */       } else {
/* 118 */         translate = translate(this.defaultLanguage, key, replaces) + " §0§l*";
/* 119 */         map.put(key, translate);
/*     */       } 
/*     */       
/* 122 */       CommonPlugin.getInstance().saveConfig("languageMap");
/*     */     } 
/*     */     
/* 125 */     return ChatColor.translateAlternateColorCodes('&', translate);
/*     */   }
/*     */   
/*     */   public String findAndTranslate(Language lang, String string) {
/* 129 */     if (string != null && !string.isEmpty()) {
/* 130 */       Matcher matcher = CommonConst.TRANSLATE_PATTERN.matcher(string);
/*     */       
/* 132 */       while (matcher.find()) {
/* 133 */         String replace = matcher.group(), id = matcher.group(2).toLowerCase();
/* 134 */         string = string.replace(replace, translate(lang, id, new String[0]));
/*     */       } 
/*     */     } 
/*     */     
/* 138 */     return string;
/*     */   }
/*     */   
/*     */   public String translate(String key) {
/* 142 */     return translate(getDefaultLanguage(), key, new String[0]);
/*     */   }
/*     */   
/*     */   public void addTranslate(Language language, String translateKey, String translate) {
/* 146 */     ((Map<String, String>)this.languageMap.computeIfAbsent(language, v -> new HashMap<>())).put(translateKey, translate);
/* 147 */     CommonPlugin.getInstance().saveConfig("languageMap");
/*     */   }
/*     */   
/*     */   public static String t(CommandSender sender, String translate) {
/* 151 */     return sender.getLanguage().t(translate, new String[0]);
/*     */   }
/*     */   
/*     */   public static String t(CommandSender sender, String translate, String... replaces) {
/* 155 */     return sender.getLanguage().t(translate, replaces);
/*     */   }
/*     */ 
/*     */   
/*     */   public void sort() {
/* 160 */     for (Iterator<Language> iterator = this.languageMap.keySet().iterator(); iterator.hasNext(); ) { Language language = iterator.next();
/* 161 */       Map<String, String> map = this.languageMap.get(language);
/*     */       
/* 163 */       List<Map.Entry<String, String>> list = (List<Map.Entry<String, String>>)map.entrySet().stream().sorted((o1, o2) -> ((String)o1.getKey()).compareTo((String)o2.getKey())).collect(Collectors.toList());
/*     */       
/* 165 */       map.clear();
/*     */       
/* 167 */       for (Map.Entry<String, String> entry : list) {
/* 168 */         map.put(entry.getKey(), entry.getValue());
/*     */       } }
/*     */ 
/*     */ 
/*     */     
/* 173 */     sortGroup();
/* 174 */     sortTag();
/*     */   }
/*     */   
/*     */   public Group getHighGroup() {
/* 178 */     return getSortGroup().findFirst().orElse(null);
/*     */   }
/*     */   
/*     */   public Stream<Group> getSortGroup() {
/* 182 */     return this.groupMap.values().stream().sorted((o1, o2) -> o2.getId() - o1.getId());
/*     */   }
/*     */   
/*     */   public Collection<Tag> getTags() {
/* 186 */     return this.tagMap.values();
/*     */   }
/*     */   
/*     */   public Tag getTagByGroup(Group serverGroup) {
/* 190 */     Tag tag = this.tagMap.get(serverGroup.getGroupName().toLowerCase());
/* 191 */     return (tag == null) ? getDefaultTag() : tag;
/*     */   }
/*     */   
/*     */   public Tag getTagByName(String string) {
/* 195 */     return this.tagMap.containsKey(string.toLowerCase()) ? this.tagMap.get(string.toLowerCase()) : this.tagMap
/* 196 */       .values().stream().filter(t -> 
/* 197 */         (t.getTagName().equalsIgnoreCase(string) || t.getAliases().contains(string.toLowerCase())))
/* 198 */       .findFirst().orElse(null);
/*     */   }
/*     */   
/*     */   public Tag getDefaultTag() {
/* 202 */     return (this.defaultTag == null) ? (this
/*     */       
/* 204 */       .defaultTag = this.tagMap.values().stream().filter(tag -> tag.isDefaultTag()).findFirst().orElse(new Tag(20, "membro", "§7", new ArrayList(), false, true))) : this.defaultTag;
/*     */   }
/*     */ 
/*     */   
/*     */   public Group getDefaultGroup() {
/* 209 */     return (this.defaultGroup == null) ? (this
/* 210 */       .defaultGroup = this.groupMap.values().stream().filter(tag -> tag.isDefaultGroup()).findFirst().orElse(null)) : this.defaultGroup;
/*     */   }
/*     */ 
/*     */   
/*     */   public Medal getMedalByName(String medalName) {
/* 215 */     return 
/* 216 */       this.medalMap.containsKey(medalName.toLowerCase()) ? this.medalMap
/* 217 */       .get(medalName.toLowerCase()) : this.medalMap
/* 218 */       .values().stream()
/* 219 */       .filter(medal -> (medal.getMedalName().equalsIgnoreCase(medalName) || medal.getAliases().contains(medalName.toLowerCase())))
/*     */       
/* 221 */       .findFirst().orElse(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void sortGroup() {
/* 226 */     List<Map.Entry<String, Group>> list = (List<Map.Entry<String, Group>>)this.groupMap.entrySet().stream().sorted((o1, o2) -> ((Group)o2.getValue()).getId() - ((Group)o1.getValue()).getId()).collect(Collectors.toList());
/*     */     
/* 228 */     this.groupMap.clear();
/*     */     
/* 230 */     for (Map.Entry<String, Group> entry : list) {
/* 231 */       this.groupMap.put(entry.getKey(), entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void sortTag() {
/* 237 */     List<Map.Entry<String, Tag>> list = (List<Map.Entry<String, Tag>>)this.tagMap.entrySet().stream().sorted((o1, o2) -> ((Tag)o1.getValue()).getTagId() - ((Tag)o2.getValue()).getTagId()).collect(Collectors.toList());
/*     */     
/* 239 */     this.tagMap.clear();
/*     */     
/* 241 */     for (Map.Entry<String, Tag> entry : list)
/* 242 */       this.tagMap.put(entry.getKey(), entry.getValue()); 
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/PluginInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */