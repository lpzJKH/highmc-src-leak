package net.highmc.backend;

public interface Database {
  void connect() throws Exception;
  
  boolean isConnected();
  
  void close();
}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/backend/Database.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */