/*     */ package net.highmc.backend.mongodb;
/*     */ 
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParser;
/*     */ import com.mongodb.client.MongoCollection;
/*     */ import com.mongodb.client.MongoCursor;
/*     */ import com.mongodb.client.MongoDatabase;
/*     */ import com.mongodb.client.model.Filters;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import net.highmc.backend.Query;
/*     */ import net.highmc.utils.json.JsonUtils;
/*     */ import org.bson.Document;
/*     */ import org.bson.conversions.Bson;
/*     */ import org.bson.json.JsonWriterSettings;
/*     */ import org.bson.json.StrictJsonWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MongoQuery
/*     */   implements Query<JsonElement>
/*     */ {
/*     */   private static final JsonWriterSettings SETTINGS;
/*     */   private MongoDatabase database;
/*     */   private MongoCollection<Document> collection;
/*     */   
/*     */   static {
/*  30 */     SETTINGS = JsonWriterSettings.builder().int64Converter((value, writer) -> writer.writeNumber(value.toString())).build();
/*     */   }
/*  32 */   public MongoDatabase getDatabase() { return this.database; } public MongoCollection<Document> getCollection() {
/*  33 */     return this.collection;
/*     */   }
/*     */   public MongoQuery(MongoConnection mongoConnection, String collectionName) {
/*  36 */     this.database = mongoConnection.getDb();
/*  37 */     this.collection = this.database.getCollection(collectionName);
/*     */   }
/*     */   
/*     */   public MongoQuery(MongoConnection mongoConnection, String databaseName, String collectionName) {
/*  41 */     this.database = mongoConnection.getDatabase(databaseName);
/*  42 */     this.collection = this.database.getCollection(collectionName);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<JsonElement> find() {
/*  47 */     MongoCursor<Document> mongoCursor = this.collection.find().iterator();
/*  48 */     List<JsonElement> documentList = new ArrayList<>();
/*     */     
/*  50 */     while (mongoCursor.hasNext()) {
/*  51 */       documentList.add(JsonParser.parseString(((Document)mongoCursor.next()).toJson(SETTINGS)));
/*     */     }
/*  53 */     return documentList;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<JsonElement> find(String collection) {
/*  58 */     MongoCursor<Document> mongoCursor = this.database.getCollection(collection).find().iterator();
/*  59 */     List<JsonElement> documentList = new ArrayList<>();
/*     */     
/*  61 */     while (mongoCursor.hasNext()) {
/*  62 */       documentList.add(JsonParser.parseString(((Document)mongoCursor.next()).toJson(SETTINGS)));
/*     */     }
/*  64 */     return documentList;
/*     */   }
/*     */ 
/*     */   
/*     */   public <GenericType> Collection<JsonElement> find(String key, GenericType value) {
/*  69 */     MongoCursor<Document> mongoCursor = this.collection.find(Filters.eq(key, value)).iterator();
/*  70 */     List<JsonElement> documentList = new ArrayList<>();
/*     */     
/*  72 */     while (mongoCursor.hasNext()) {
/*  73 */       documentList.add(JsonParser.parseString(((Document)mongoCursor.next()).toJson(SETTINGS)));
/*     */     }
/*  75 */     return documentList;
/*     */   }
/*     */ 
/*     */   
/*     */   public <GenericType> Collection<JsonElement> find(String collection, String key, GenericType value) {
/*  80 */     MongoCursor<Document> mongoCursor = this.database.getCollection(collection).find(Filters.eq(key, value)).iterator();
/*  81 */     List<JsonElement> documentList = new ArrayList<>();
/*     */     
/*  83 */     while (mongoCursor.hasNext()) {
/*  84 */       documentList.add(JsonParser.parseString(((Document)mongoCursor.next()).toJson(SETTINGS)));
/*     */     }
/*  86 */     return documentList;
/*     */   }
/*     */ 
/*     */   
/*     */   public <GenericType> JsonElement findOne(String key, GenericType value) {
/*  91 */     JsonElement json = null;
/*  92 */     Document document = (Document)this.collection.find(Filters.eq(key, value)).first();
/*     */     
/*  94 */     if (document != null) {
/*  95 */       json = JsonParser.parseString(document.toJson(SETTINGS));
/*     */     }
/*  97 */     return json;
/*     */   }
/*     */ 
/*     */   
/*     */   public <GenericType> JsonElement findOne(String collection, String key, GenericType value) {
/* 102 */     JsonElement json = null;
/* 103 */     Document document = (Document)this.database.getCollection(collection).find(Filters.eq(key, value)).first();
/*     */     
/* 105 */     if (document != null) {
/* 106 */       json = JsonParser.parseString(document.toJson(SETTINGS));
/*     */     }
/* 108 */     return json;
/*     */   }
/*     */ 
/*     */   
/*     */   public void create(String[] jsons) {
/* 113 */     for (String json : jsons) {
/* 114 */       this.collection.insertOne(Document.parse(json));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void create(String collection, String[] jsons) {
/* 120 */     for (String json : jsons) {
/* 121 */       this.database.getCollection(collection).insertOne(Document.parse(json));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public <GenericType> void deleteOne(String key, GenericType value) {
/* 127 */     this.collection.deleteOne(Filters.eq(key, value));
/*     */   }
/*     */ 
/*     */   
/*     */   public <GenericType> void deleteOne(String collection, String key, GenericType value) {
/* 132 */     this.database.getCollection(collection).deleteOne(Filters.eq(key, value));
/*     */   }
/*     */ 
/*     */   
/*     */   public <GenericType> void updateOne(String key, GenericType value, JsonElement t) {
/* 137 */     JsonObject jsonObject = (JsonObject)t;
/*     */     
/* 139 */     if (jsonObject.has("fieldName") && jsonObject.has("value")) {
/* 140 */       Object object = JsonUtils.elementToBson(jsonObject.get("value"));
/*     */       
/* 142 */       if (object == null || jsonObject.get("value").isJsonNull()) {
/* 143 */         this.collection.updateOne(Filters.eq(key, value), (Bson)new Document("$unset", new Document(jsonObject
/* 144 */                 .get("fieldName").getAsString(), "")));
/*     */       } else {
/* 146 */         this.collection.updateOne(Filters.eq(key, value), (Bson)new Document("$set", new Document(jsonObject
/* 147 */                 .get("fieldName").getAsString(), object)));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public <GenericType> void updateOne(String collection, String key, GenericType value, JsonElement t) {
/* 154 */     JsonObject jsonObject = (JsonObject)t;
/*     */     
/* 156 */     if (jsonObject.has("fieldName") && jsonObject.has("value")) {
/* 157 */       Object object = JsonUtils.elementToBson(jsonObject.get("value"));
/*     */       
/* 159 */       this.database.getCollection(collection).updateOne(Filters.eq(key, value), (Bson)new Document("$set", new Document(jsonObject
/* 160 */               .get("fieldName").getAsString(), object)));
/*     */       
/*     */       return;
/*     */     } 
/* 164 */     this.database.getCollection(collection).updateOne(Filters.eq(key, value), (Bson)Document.parse(t.toString()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <GenericType> Collection<JsonElement> ranking(String key, GenericType value, int limit) {
/* 170 */     MongoCursor<Document> mongoCursor = this.collection.find().sort(Filters.eq(key, value)).limit(limit).iterator();
/* 171 */     List<JsonElement> documentList = new ArrayList<>();
/*     */     
/* 173 */     while (mongoCursor.hasNext()) {
/* 174 */       documentList.add(JsonParser.parseString(((Document)mongoCursor.next()).toJson(SETTINGS)));
/*     */     }
/* 176 */     return documentList;
/*     */   }
/*     */ 
/*     */   
/*     */   public static MongoQuery createDefault(MongoConnection mongoConnection, String databaseName, String collectionName) {
/* 181 */     return new MongoQuery(mongoConnection, databaseName, collectionName);
/*     */   }
/*     */   
/*     */   public static MongoQuery createDefault(MongoConnection mongoConnection, String collectionName) {
/* 185 */     return new MongoQuery(mongoConnection, mongoConnection.getDataBase(), collectionName);
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/backend/mongodb/MongoQuery.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */