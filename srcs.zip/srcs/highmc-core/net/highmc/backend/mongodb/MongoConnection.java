/*    */ package net.highmc.backend.mongodb;
/*    */ 
/*    */ import com.mongodb.MongoClient;
/*    */ import com.mongodb.MongoClientURI;
/*    */ import com.mongodb.client.MongoDatabase;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ import java.util.regex.Pattern;
/*    */ import net.highmc.backend.Credentials;
/*    */ import net.highmc.backend.Database;
/*    */ 
/*    */ public class MongoConnection
/*    */   implements Database {
/*    */   private static final String PATTERN = "([01]?[0-9]{1,2}|2[0-4][0-9]|25[0-5])";
/*    */   private MongoClient client;
/*    */   private MongoDatabase db;
/*    */   private String url;
/*    */   private String dataBase;
/* 19 */   private static final Pattern IP_PATTERN = Pattern.compile("([01]?[0-9]{1,2}|2[0-4][0-9]|25[0-5])\\.([01]?[0-9]{1,2}|2[0-4][0-9]|25[0-5])\\.([01]?[0-9]{1,2}|2[0-4][0-9]|25[0-5])\\.([01]?[0-9]{1,2}|2[0-4][0-9]|25[0-5])"); private int port;
/*    */   public MongoClient getClient() {
/* 21 */     return this.client;
/*    */   } public MongoDatabase getDb() {
/* 23 */     return this.db;
/*    */   }
/*    */   public String getUrl() {
/* 26 */     return this.url;
/*    */   }
/* 28 */   public String getDataBase() { return this.dataBase; } public int getPort() {
/* 29 */     return this.port;
/*    */   }
/*    */   public MongoConnection(String url) {
/* 32 */     this.url = url;
/*    */   }
/*    */   
/*    */   public MongoConnection(String hostName, String userName, String passWord, String dataBase, int port) {
/* 36 */     this(IP_PATTERN.matcher(hostName).matches() ? ("mongodb://" + (
/* 37 */         userName.isEmpty() ? "" : (userName + ":" + passWord + "@")) + hostName + "/" + dataBase + "?retryWrites=true&w=majority") : ("mongodb+srv://" + (
/*    */         
/* 39 */         userName.isEmpty() ? "" : (userName + ":" + passWord + "@")) + hostName + "/" + dataBase + "?retryWrites=true&w=majority"));
/*    */   }
/*    */ 
/*    */   
/*    */   public MongoConnection(Credentials credentials) {
/* 44 */     this(credentials.getHostName(), credentials.getUserName(), credentials.getPassWord(), credentials.getDatabase(), credentials
/* 45 */         .getPort());
/*    */   }
/*    */   
/*    */   public MongoConnection(String hostName, String userName, String passWord, String dataBase) {
/* 49 */     this(hostName, userName, passWord, dataBase, 27017);
/*    */   }
/*    */ 
/*    */   
/*    */   public void connect() {
/* 54 */     MongoClientURI uri = new MongoClientURI(getUrl());
/* 55 */     this.dataBase = uri.getDatabase();
/*    */     
/* 57 */     this.client = new MongoClient(new MongoClientURI(getUrl()));
/*    */     
/* 59 */     Logger.getLogger("uri").setLevel(Level.SEVERE);
/*    */     
/* 61 */     this.db = this.client.getDatabase(this.dataBase);
/*    */   }
/*    */   
/*    */   public MongoDatabase getDefaultDatabase() {
/* 65 */     return this.client.getDatabase(getDataBase());
/*    */   }
/*    */   
/*    */   public MongoDatabase getDatabase(String database) {
/* 69 */     return this.client.getDatabase(database);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isConnected() {
/* 74 */     return (this.client != null);
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() {
/* 79 */     this.client.close();
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/backend/mongodb/MongoConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */