/*    */ package net.highmc.backend.data;
/*    */ import java.util.UUID;
/*    */ import net.highmc.server.ServerType;
/*    */ 
/*    */ public class DataServerMessage<T> {
/*    */   private final String source;
/*    */   private final ServerType serverType;
/*    */   private final Action action;
/*    */   private final T payload;
/*    */   
/*    */   public DataServerMessage(String source, ServerType serverType, Action action, T payload) {
/* 12 */     this.source = source; this.serverType = serverType; this.action = action; this.payload = payload;
/*    */   }
/*    */   
/* 15 */   public String getSource() { return this.source; }
/* 16 */   public ServerType getServerType() { return this.serverType; }
/* 17 */   public Action getAction() { return this.action; } public T getPayload() {
/* 18 */     return this.payload;
/*    */   } public static class StartPayload { private final String serverAddress;
/*    */     public StartPayload(String serverAddress, ProxiedServer server, long startTime) {
/* 21 */       this.serverAddress = serverAddress; this.server = server; this.startTime = startTime;
/*    */     } private final ProxiedServer server; private final long startTime; public String getServerAddress() {
/* 23 */       return this.serverAddress; }
/* 24 */     public ProxiedServer getServer() { return this.server; } public long getStartTime() {
/* 25 */       return this.startTime;
/*    */     } }
/*    */   public static class StopPayload { private final String serverId;
/*    */     public StopPayload(String serverId) {
/* 29 */       this.serverId = serverId;
/*    */     } public String getServerId() {
/* 31 */       return this.serverId;
/*    */     } }
/*    */   public static class UpdatePayload { private final int time; private final String map; private final MinigameState state;
/*    */     public UpdatePayload(int time, String map, MinigameState state) {
/* 35 */       this.time = time; this.map = map; this.state = state;
/*    */     }
/* 37 */     public int getTime() { return this.time; }
/* 38 */     public String getMap() { return this.map; } public MinigameState getState() {
/* 39 */       return this.state;
/*    */     } }
/*    */   public static class JoinEnablePayload { private final boolean enable;
/*    */     public JoinEnablePayload(boolean enable) {
/* 43 */       this.enable = enable;
/*    */     } public boolean isEnable() {
/* 45 */       return this.enable;
/*    */     } }
/*    */   public static class JoinPayload { private final UUID uniqueId; private final int maxPlayers;
/*    */     public JoinPayload(UUID uniqueId, int maxPlayers) {
/* 49 */       this.uniqueId = uniqueId; this.maxPlayers = maxPlayers;
/*    */     }
/* 51 */     public UUID getUniqueId() { return this.uniqueId; } public int getMaxPlayers() {
/* 52 */       return this.maxPlayers;
/*    */     } }
/*    */   public static class LeavePayload { private final UUID uniqueId; private final int maxPlayers;
/*    */     public LeavePayload(UUID uniqueId, int maxPlayers) {
/* 56 */       this.uniqueId = uniqueId; this.maxPlayers = maxPlayers;
/*    */     }
/* 58 */     public UUID getUniqueId() { return this.uniqueId; } public int getMaxPlayers() {
/* 59 */       return this.maxPlayers;
/*    */     } }
/*    */   
/*    */   public enum Action {
/* 63 */     START, STOP, UPDATE, JOIN_ENABLE, JOIN, LEAVE;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/backend/data/DataServerMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */