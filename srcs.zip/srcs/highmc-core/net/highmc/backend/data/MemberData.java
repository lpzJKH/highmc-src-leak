package net.highmc.backend.data;

import java.util.Collection;
import java.util.List;
import java.util.UUID;
import net.highmc.backend.mongodb.MongoQuery;
import net.highmc.member.Member;
import net.highmc.member.status.Status;
import net.highmc.member.status.StatusType;
import net.highmc.permission.Group;
import net.highmc.report.Report;

public interface MemberData extends Data<MongoQuery> {
  Member loadMember(UUID paramUUID);
  
  <T extends Member> T loadMember(UUID paramUUID, Class<T> paramClass);
  
  Member loadMember(String paramString, boolean paramBoolean);
  
  <T extends Member> T loadMember(String paramString, boolean paramBoolean, Class<T> paramClass);
  
  <T extends Member> Collection<T> loadMembersByAddress(String paramString, Class<T> paramClass);
  
  <T extends Member> T loadMember(String paramString1, String paramString2, boolean paramBoolean, Class<T> paramClass);
  
  List<Member> getMembersByGroup(Group paramGroup);
  
  boolean createMember(Member paramMember);
  
  boolean deleteMember(UUID paramUUID);
  
  void updateMember(Member paramMember, String paramString);
  
  void reloadPlugins();
  
  void cacheMember(UUID paramUUID);
  
  void saveRedisMember(Member paramMember);
  
  boolean checkCache(UUID paramUUID);
  
  boolean isRedisCached(String paramString);
  
  boolean isConnectionPremium(String paramString);
  
  void setConnectionStatus(String paramString, UUID paramUUID, boolean paramBoolean);
  
  void cacheConnection(String paramString, boolean paramBoolean);
  
  UUID getUniqueId(String paramString);
  
  boolean isDiscordCached(String paramString);
  
  UUID getUniqueIdFromDiscord(String paramString);
  
  void setDiscordCache(String paramString, UUID paramUUID);
  
  void deleteDiscordCache(String paramString);
  
  Status loadStatus(UUID paramUUID, StatusType paramStatusType);
  
  boolean createStatus(Status paramStatus);
  
  void saveStatus(Status paramStatus, String paramString);
  
  Collection<Report> loadReports();
  
  void createReport(Report paramReport);
  
  void deleteReport(UUID paramUUID);
  
  void updateReport(Report paramReport, String paramString);
  
  void closeConnection();
}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/backend/data/MemberData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */