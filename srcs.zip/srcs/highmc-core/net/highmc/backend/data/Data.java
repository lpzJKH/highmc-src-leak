package net.highmc.backend.data;

public interface Data<T extends net.highmc.backend.Query<com.google.gson.JsonElement>> {
  T getQuery();
}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/backend/data/Data.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */