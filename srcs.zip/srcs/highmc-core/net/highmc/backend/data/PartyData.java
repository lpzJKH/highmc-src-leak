package net.highmc.backend.data;

import java.util.UUID;
import net.highmc.backend.mongodb.MongoQuery;
import net.highmc.member.party.Party;

public interface PartyData extends Data<MongoQuery> {
  <T extends Party> T loadParty(UUID paramUUID, Class<T> paramClass);
  
  void createParty(Party paramParty);
  
  void deleteParty(Party paramParty);
  
  void updateParty(Party paramParty, String paramString);
  
  UUID getPartyId();
}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/backend/data/PartyData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */