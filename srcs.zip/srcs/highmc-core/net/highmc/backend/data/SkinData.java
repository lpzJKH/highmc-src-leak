package net.highmc.backend.data;

import java.util.Optional;
import java.util.UUID;
import net.highmc.utils.skin.Skin;

public interface SkinData {
  Optional<Skin> loadData(String paramString);
  
  void save(Skin paramSkin, int paramInt);
  
  String[] loadSkinById(UUID paramUUID);
}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/backend/data/SkinData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */