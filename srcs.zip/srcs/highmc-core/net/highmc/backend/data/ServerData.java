package net.highmc.backend.data;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.highmc.backend.mongodb.MongoQuery;
import net.highmc.packet.Packet;
import net.highmc.server.loadbalancer.server.MinigameState;

public interface ServerData extends Data<MongoQuery> {
  int getTime(String paramString);
  
  long getStartTime(String paramString);
  
  MinigameState getState(String paramString);
  
  String getMap(String paramString);
  
  Map<String, Map<String, String>> loadServers();
  
  Set<UUID> getPlayers(String paramString);
  
  void startServer(int paramInt);
  
  void updateStatus(String paramString1, MinigameState paramMinigameState, String paramString2, int paramInt);
  
  void updateStatus(MinigameState paramMinigameState, String paramString, int paramInt);
  
  void updateStatus(MinigameState paramMinigameState, int paramInt);
  
  void updateStatus();
  
  void setJoinEnabled(String paramString, boolean paramBoolean);
  
  void setJoinEnabled(boolean paramBoolean);
  
  void stopServer();
  
  void setTotalMembers(int paramInt);
  
  void joinPlayer(UUID paramUUID, int paramInt);
  
  void leavePlayer(UUID paramUUID, int paramInt);
  
  void sendPacket(Packet paramPacket);
  
  void closeConnection();
}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/backend/data/ServerData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */