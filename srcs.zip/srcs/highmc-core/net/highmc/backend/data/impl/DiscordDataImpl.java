/*    */ package net.highmc.backend.data.impl;
/*    */ 
/*    */ import java.util.Set;
/*    */ import net.highmc.backend.data.DiscordData;
/*    */ import net.highmc.backend.redis.RedisConnection;
/*    */ import net.highmc.utils.string.CodeCreator;
/*    */ import redis.clients.jedis.Jedis;
/*    */ 
/*    */ public class DiscordDataImpl implements DiscordData {
/*    */   public DiscordDataImpl(RedisConnection redisConnection) {
/* 11 */     this.redisConnection = redisConnection;
/*    */   }
/*    */ 
/*    */   
/*    */   private RedisConnection redisConnection;
/*    */   
/*    */   public String getNameByCode(String code, boolean delete) {
/* 18 */     try (Jedis jedis = this.redisConnection.getPool().getResource()) {
/* 19 */       Set<String> list = jedis.keys("discord-sync:*");
/*    */       
/* 21 */       for (String possible : list) {
/* 22 */         if (jedis.get(possible).equals(code)) {
/* 23 */           String name = possible.replace("discord-sync:", "");
/*    */           
/* 25 */           if (delete) {
/* 26 */             jedis.del(possible);
/*    */           }
/* 28 */           return name;
/*    */         } 
/*    */       } 
/*    */     } 
/*    */     
/* 33 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getCodeOrCreate(String playerName, String code) {
/* 38 */     try (Jedis jedis = this.redisConnection.getPool().getResource()) {
/* 39 */       boolean exists = (jedis.ttl("discord-sync:" + playerName.toLowerCase()).longValue() >= 0L);
/*    */       
/* 41 */       if (exists) {
/* 42 */         return jedis.get("discord-sync:" + playerName.toLowerCase());
/*    */       }
/* 44 */       code = CodeCreator.DEFAULT_CREATOR_LETTERS_ONLY.random(6);
/* 45 */       jedis.setex("discord-sync:" + playerName.toLowerCase(), 120, code);
/* 46 */       return code;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/backend/data/impl/DiscordDataImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */