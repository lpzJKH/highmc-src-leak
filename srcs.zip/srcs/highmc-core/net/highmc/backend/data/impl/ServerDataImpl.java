/*     */ package net.highmc.backend.data.impl;
/*     */ 
/*     */ import com.google.gson.JsonElement;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import net.highmc.CommonConst;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.backend.Query;
/*     */ import net.highmc.backend.data.DataServerMessage;
/*     */ import net.highmc.backend.data.ServerData;
/*     */ import net.highmc.backend.mongodb.MongoQuery;
/*     */ import net.highmc.backend.redis.RedisConnection;
/*     */ import net.highmc.packet.Packet;
/*     */ import net.highmc.server.ServerType;
/*     */ import net.highmc.server.loadbalancer.server.MinigameState;
/*     */ import net.highmc.server.loadbalancer.server.ProxiedServer;
/*     */ import net.highmc.utils.json.JsonBuilder;
/*     */ import redis.clients.jedis.Jedis;
/*     */ import redis.clients.jedis.Pipeline;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerDataImpl
/*     */   implements ServerData
/*     */ {
/*     */   private RedisConnection redisDatabase;
/*     */   
/*     */   public ServerDataImpl(RedisConnection redisConnection) {
/*  35 */     this.redisDatabase = redisConnection;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTime(String serverId) {
/*  40 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/*  41 */       Map<String, String> m = jedis.hgetAll("server:" + serverId);
/*     */       
/*  43 */       if (m.containsKey("time"))
/*  44 */         return Integer.valueOf(m.get("time")).intValue(); 
/*  45 */     } catch (Exception e) {
/*  46 */       e.printStackTrace();
/*     */     } 
/*     */     
/*  49 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getStartTime(String serverId) {
/*  54 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/*  55 */       Map<String, String> m = jedis.hgetAll("server:" + serverId);
/*     */       
/*  57 */       if (m.containsKey("starttime"))
/*  58 */         return Integer.valueOf(m.get("starttime")).intValue(); 
/*  59 */     } catch (Exception e) {
/*  60 */       e.printStackTrace();
/*     */     } 
/*     */     
/*  63 */     return -1L;
/*     */   }
/*     */ 
/*     */   
/*     */   public MinigameState getState(String serverId) {
/*  68 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/*  69 */       Map<String, String> m = jedis.hgetAll("server:" + serverId);
/*     */       
/*  71 */       if (m.containsKey("state"))
/*  72 */         return MinigameState.valueOf(((String)m.get("state")).toUpperCase()); 
/*  73 */     } catch (Exception e) {
/*  74 */       e.printStackTrace();
/*     */     } 
/*     */     
/*  77 */     return MinigameState.NONE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMap(String serverId) {
/*  83 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/*  84 */       Map<String, String> m = jedis.hgetAll("server:" + serverId);
/*     */       
/*  86 */       if (m.containsKey("map"))
/*  87 */         return m.get("map"); 
/*  88 */     } catch (Exception e) {
/*  89 */       e.printStackTrace();
/*     */     } 
/*     */     
/*  92 */     return "Unknown";
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Map<String, String>> loadServers() {
/*  97 */     Map<String, Map<String, String>> map = new HashMap<>();
/*  98 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/*  99 */       String[] str = new String[(ServerType.values()).length];
/*     */       
/* 101 */       for (int i = 0; i < (ServerType.values()).length; i++) {
/* 102 */         str[i] = "server:type:" + ServerType.values()[i].toString().toLowerCase();
/*     */       }
/*     */       
/* 105 */       for (String server : jedis.sunion(str)) {
/* 106 */         Map<String, String> m = jedis.hgetAll("server:" + server);
/* 107 */         map.put(server, m);
/*     */       } 
/* 109 */     } catch (Exception e) {
/* 110 */       e.printStackTrace();
/* 111 */       return new HashMap<>();
/*     */     } 
/* 113 */     return map;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<UUID> getPlayers(String serverId) {
/* 118 */     Set<UUID> players = new HashSet<>();
/* 119 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/* 120 */       for (String uuid : jedis.smembers("server:" + serverId + ":players")) {
/* 121 */         UUID uniqueId = UUID.fromString(uuid);
/* 122 */         players.add(uniqueId);
/*     */       } 
/* 124 */     } catch (Exception e) {
/* 125 */       e.printStackTrace();
/*     */     } 
/* 127 */     return players;
/*     */   }
/*     */ 
/*     */   
/*     */   public void startServer(int maxPlayers) {
/* 132 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/* 133 */       Pipeline pipe = jedis.pipelined();
/* 134 */       pipe.sadd("server:type:" + CommonPlugin.getInstance().getServerType().toString().toLowerCase(), new String[] {
/* 135 */             CommonPlugin.getInstance().getServerId() });
/* 136 */       Map<String, String> map = new HashMap<>();
/* 137 */       map.put("type", CommonPlugin.getInstance().getServerType().toString().toLowerCase());
/* 138 */       map.put("maxplayers", maxPlayers + "");
/* 139 */       map.put("joinenabled", CommonPlugin.getInstance().isJoinEnabled() + "");
/* 140 */       map.put("address", CommonPlugin.getInstance().getServerAddress());
/* 141 */       map.put("map", CommonPlugin.getInstance().getMap());
/* 142 */       map.put("time", CommonPlugin.getInstance().getServerTime() + "");
/* 143 */       map.put("state", CommonPlugin.getInstance().getMinigameState().toString().toLowerCase());
/* 144 */       map.put("starttime", System.currentTimeMillis() + "");
/* 145 */       pipe.hmset("server:" + CommonPlugin.getInstance().getServerId(), map);
/* 146 */       pipe.del("server:" + CommonPlugin.getInstance().getServerId() + ":players");
/*     */ 
/*     */       
/* 149 */       ProxiedServer server = new ProxiedServer(CommonPlugin.getInstance().getServerId(), CommonPlugin.getInstance().getServerType(), new HashSet(), maxPlayers, CommonPlugin.getInstance().isJoinEnabled());
/* 150 */       pipe.publish("server_info", CommonConst.GSON
/* 151 */           .toJson(new DataServerMessage(
/* 152 */               CommonPlugin.getInstance().getServerId(), CommonPlugin.getInstance().getServerType(), DataServerMessage.Action.START, new DataServerMessage.StartPayload(
/* 153 */                 CommonPlugin.getInstance().getServerAddress(), server, 
/* 154 */                 System.currentTimeMillis()))));
/* 155 */       pipe.sync();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateStatus() {
/* 161 */     updateStatus(CommonPlugin.getInstance().getMinigameState(), CommonPlugin.getInstance().getMap(), 
/* 162 */         CommonPlugin.getInstance().getServerTime());
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateStatus(MinigameState state, int time) {
/* 167 */     updateStatus(state, CommonPlugin.getInstance().getMap(), time);
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateStatus(MinigameState state, String map, int time) {
/* 172 */     updateStatus(CommonPlugin.getInstance().getServerId(), state, map, time);
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateStatus(String serverId, MinigameState state, String map, int time) {
/* 177 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/* 178 */       Pipeline pipe = jedis.pipelined();
/* 179 */       pipe.hset("server:" + serverId, "map", map);
/* 180 */       pipe.hset("server:" + serverId, "time", Integer.toString(time));
/* 181 */       pipe.hset("server:" + serverId, "state", state.toString().toLowerCase());
/* 182 */       pipe.publish("server_info", CommonConst.GSON
/* 183 */           .toJson(new DataServerMessage(
/* 184 */               CommonPlugin.getInstance().getServerId(), CommonPlugin.getInstance().getServerType(), DataServerMessage.Action.UPDATE, new DataServerMessage.UpdatePayload(time, map, state))));
/*     */       
/* 186 */       pipe.sync();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setJoinEnabled(String serverId, boolean bol) {
/* 192 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/* 193 */       Pipeline pipe = jedis.pipelined();
/* 194 */       pipe.hset("server:" + serverId, "joinenabled", Boolean.toString(bol));
/* 195 */       pipe.publish("server_info", CommonConst.GSON
/* 196 */           .toJson(new DataServerMessage(
/* 197 */               CommonPlugin.getInstance().getServerId(), CommonPlugin.getInstance().getServerType(), DataServerMessage.Action.JOIN_ENABLE, new DataServerMessage.JoinEnablePayload(bol))));
/*     */       
/* 199 */       pipe.sync();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setJoinEnabled(boolean bol) {
/* 205 */     setJoinEnabled(CommonPlugin.getInstance().getServerId(), bol);
/*     */   }
/*     */ 
/*     */   
/*     */   public void stopServer() {
/* 210 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/* 211 */       Pipeline pipe = jedis.pipelined();
/* 212 */       pipe.srem("server:type:" + CommonPlugin.getInstance().getServerType().toString().toLowerCase(), new String[] {
/* 213 */             CommonPlugin.getInstance().getServerId() });
/* 214 */       pipe.del("server:" + CommonPlugin.getInstance().getServerId());
/* 215 */       pipe.del("server:" + CommonPlugin.getInstance().getServerId() + ":players");
/* 216 */       pipe.publish("server_info", CommonConst.GSON
/* 217 */           .toJson(new DataServerMessage(CommonPlugin.getInstance().getServerId(), 
/* 218 */               CommonPlugin.getInstance().getServerType(), DataServerMessage.Action.STOP, new DataServerMessage.StopPayload(
/* 219 */                 CommonPlugin.getInstance().getServerId()))));
/* 220 */       pipe.sync();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTotalMembers(int totalMembers) {
/* 226 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/* 227 */       Pipeline pipe = jedis.pipelined();
/* 228 */       pipe.publish("server_members", CommonConst.GSON
/* 229 */           .toJson((JsonElement)(new JsonBuilder()).addProperty("totalMembers", Integer.valueOf(totalMembers)).build()));
/* 230 */       pipe.sync();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void joinPlayer(UUID uuid, int maxPlayers) {
/* 236 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/* 237 */       Pipeline pipe = jedis.pipelined();
/* 238 */       pipe.sadd("server:" + CommonPlugin.getInstance().getServerId() + ":players", new String[] { uuid.toString() });
/* 239 */       pipe.hset("server:" + CommonPlugin.getInstance().getServerId(), "maxplayers", Integer.toString(maxPlayers));
/* 240 */       pipe.publish("server_info", CommonConst.GSON
/* 241 */           .toJson(new DataServerMessage(CommonPlugin.getInstance().getServerId(), 
/* 242 */               CommonPlugin.getInstance().getServerType(), DataServerMessage.Action.JOIN, new DataServerMessage.JoinPayload(uuid, maxPlayers))));
/*     */       
/* 244 */       pipe.sync();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void leavePlayer(UUID uuid, int maxPlayers) {
/* 250 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/* 251 */       Pipeline pipe = jedis.pipelined();
/* 252 */       pipe.srem("server:" + CommonPlugin.getInstance().getServerId() + ":players", new String[] { uuid.toString() });
/* 253 */       pipe.hset("server:" + CommonPlugin.getInstance().getServerId(), "maxplayers", Integer.toString(maxPlayers));
/* 254 */       pipe.publish("server_info", CommonConst.GSON
/* 255 */           .toJson(new DataServerMessage(
/* 256 */               CommonPlugin.getInstance().getServerId(), CommonPlugin.getInstance().getServerType(), DataServerMessage.Action.LEAVE, new DataServerMessage.LeavePayload(uuid, maxPlayers))));
/*     */       
/* 258 */       pipe.sync();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void sendPacket(Packet packet) {
/* 264 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/* 265 */       Pipeline pipe = jedis.pipelined();
/* 266 */       pipe.publish("server_packet", CommonConst.GSON.toJson(packet));
/* 267 */       pipe.sync();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void closeConnection() {
/* 273 */     this.redisDatabase.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public MongoQuery getQuery() {
/* 278 */     return null;
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/backend/data/impl/ServerDataImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */