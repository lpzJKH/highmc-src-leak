/*     */ package net.highmc.backend.data.impl;
/*     */ 
/*     */ import com.google.gson.JsonArray;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParser;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.UUID;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.backend.data.SkinData;
/*     */ import net.highmc.backend.redis.RedisConnection;
/*     */ import net.highmc.utils.json.JsonUtils;
/*     */ import net.highmc.utils.skin.Skin;
/*     */ import redis.clients.jedis.Jedis;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SkinDataImpl
/*     */   implements SkinData
/*     */ {
/*     */   private static final String BASE_PATH = "skin-data:";
/*     */   private static final int TIME_TO_EXPIRE = 7200;
/*     */   private RedisConnection redisConnection;
/*     */   
/*     */   public SkinDataImpl(RedisConnection redisConnection) {
/*  35 */     this.redisConnection = redisConnection;
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<Skin> loadData(String playerName) {
/*  40 */     try (Jedis jedis = this.redisConnection.getPool().getResource()) {
/*  41 */       boolean exists = (jedis.ttl("skin-data:" + playerName.toLowerCase()).longValue() >= 0L);
/*     */       
/*  43 */       if (exists) {
/*  44 */         Map<String, String> fields = jedis.hgetAll("skin-data:" + playerName.toLowerCase());
/*     */         
/*  46 */         if (fields != null && !fields.isEmpty()) {
/*  47 */           return Optional.of(JsonUtils.mapToObject(fields, Skin.class));
/*     */         }
/*     */       } 
/*     */     } 
/*  51 */     UUID uniqueId = CommonPlugin.getInstance().getUniqueId(playerName);
/*     */     
/*  53 */     if (uniqueId == null) {
/*  54 */       return null;
/*     */     }
/*  56 */     String[] skin = loadSkinById(uniqueId);
/*     */     
/*  58 */     if (skin == null) {
/*  59 */       return Optional.empty();
/*     */     }
/*  61 */     Skin skinData = new Skin(playerName, uniqueId, skin[0], skin[1]);
/*     */     
/*  63 */     save(skinData, 7200);
/*     */     
/*  65 */     return Optional.of(skinData);
/*     */   }
/*     */ 
/*     */   
/*     */   public void save(Skin skin, int seconds) {
/*  70 */     try (Jedis jedis = this.redisConnection.getPool().getResource()) {
/*  71 */       jedis.hmset("skin-data:" + skin.getPlayerName().toLowerCase(), JsonUtils.objectToMap(skin));
/*  72 */       jedis.expire("skin-data:" + skin.getPlayerName().toLowerCase(), 259200);
/*  73 */       jedis.save();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] loadSkinById(UUID uuid) {
/*     */     try {
/*  80 */       URLConnection con = (new URL(String.format("https://sessionserver.mojang.com/session/minecraft/profile/%s?unsigned=false", new Object[] { uuid.toString() }))).openConnection();
/*  81 */       JsonElement element = JsonParser.parseReader(new BufferedReader(new InputStreamReader(con
/*  82 */               .getInputStream(), StandardCharsets.UTF_8)));
/*     */       
/*  84 */       if (element instanceof JsonObject) {
/*  85 */         JsonObject object = element.getAsJsonObject();
/*     */         
/*  87 */         if (object.has("properties")) {
/*  88 */           JsonArray jsonArray = object.get("properties").getAsJsonArray();
/*  89 */           JsonObject jsonObject = jsonArray.get(0).getAsJsonObject();
/*     */           
/*  91 */           String value = jsonObject.get("value").getAsString();
/*  92 */           String signature = jsonObject.has("signature") ? jsonObject.get("signature").getAsString() : "";
/*  93 */           return new String[] { value, signature };
/*     */         } 
/*     */       } 
/*  96 */     } catch (Exception e) {
/*  97 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 100 */     return null;
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/backend/data/impl/SkinDataImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */