/*     */ package net.highmc.backend.data.impl;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonPrimitive;
/*     */ import com.mongodb.client.MongoCursor;
/*     */ import com.mongodb.client.model.Filters;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import java.util.stream.Collectors;
/*     */ import net.highmc.CommonConst;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.backend.Query;
/*     */ import net.highmc.backend.data.MemberData;
/*     */ import net.highmc.backend.mongodb.MongoConnection;
/*     */ import net.highmc.backend.mongodb.MongoQuery;
/*     */ import net.highmc.backend.redis.RedisConnection;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.member.MemberVoid;
/*     */ import net.highmc.member.status.Status;
/*     */ import net.highmc.member.status.StatusType;
/*     */ import net.highmc.packet.Packet;
/*     */ import net.highmc.packet.types.ReportCreatePacket;
/*     */ import net.highmc.packet.types.ReportDeletePacket;
/*     */ import net.highmc.packet.types.ReportFieldPacket;
/*     */ import net.highmc.permission.Group;
/*     */ import net.highmc.report.Report;
/*     */ import net.highmc.utils.json.JsonBuilder;
/*     */ import net.highmc.utils.json.JsonUtils;
/*     */ import org.bson.Document;
/*     */ import org.bson.conversions.Bson;
/*     */ import redis.clients.jedis.Jedis;
/*     */ import redis.clients.jedis.Pipeline;
/*     */ 
/*     */ public class MemberDataImpl implements MemberData {
/*     */   private RedisConnection redisDatabase;
/*     */   private MongoQuery query;
/*     */   private MongoQuery statusQuery;
/*     */   private MongoQuery reportQuery;
/*     */   
/*     */   public RedisConnection getRedisDatabase() {
/*  45 */     return this.redisDatabase;
/*     */   }
/*  47 */   public MongoQuery getQuery() { return this.query; }
/*  48 */   public MongoQuery getStatusQuery() { return this.statusQuery; } public MongoQuery getReportQuery() {
/*  49 */     return this.reportQuery;
/*     */   }
/*     */   public MemberDataImpl(MongoConnection mongoConnection, RedisConnection redisDatabase) {
/*  52 */     this.query = MongoQuery.createDefault(mongoConnection, mongoConnection.getDataBase(), "members");
/*  53 */     this.statusQuery = MongoQuery.createDefault(mongoConnection, mongoConnection.getDataBase(), "status");
/*  54 */     this.reportQuery = MongoQuery.createDefault(mongoConnection, mongoConnection.getDataBase(), "report");
/*  55 */     this.redisDatabase = redisDatabase;
/*     */   }
/*     */   
/*     */   public MemberDataImpl(Query<JsonElement> query, RedisConnection redisDatabase) {
/*  59 */     this.query = (MongoQuery)query;
/*  60 */     this.redisDatabase = redisDatabase;
/*     */   }
/*     */ 
/*     */   
/*     */   public Member loadMember(UUID uuid) {
/*  65 */     return (Member)loadMember(uuid, MemberVoid.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends Member> Collection<T> loadMembersByAddress(String ipAddress, Class<T> clazz) {
/*  70 */     return (Collection<T>)this.query.find("lastIpAddress", ipAddress).stream().map(json -> (Member)CommonConst.GSON.fromJson(json, clazz))
/*  71 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends Member> T loadMember(UUID uuid, Class<T> clazz) {
/*  76 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(uuid);
/*     */     
/*  78 */     if (member == null) {
/*  79 */       member = getRedisPlayer(uuid, clazz);
/*     */       
/*  81 */       if (member == null) {
/*  82 */         JsonElement found = this.query.findOne("uniqueId", uuid.toString());
/*     */         
/*  84 */         if (found != null) {
/*  85 */           member = (Member)CommonConst.GSON.fromJson(CommonConst.GSON.toJson(found), clazz);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/*  90 */     return (member == null) ? null : clazz.cast(member);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends Member> T loadMember(String playerName, boolean ignoreCase, Class<T> clazz) {
/*  95 */     if (ignoreCase) {
/*  96 */       return loadMember(this.query
/*  97 */           .findOne("playerName", (new Document("$regex", "^" + playerName + "$")).append("$options", "i")), clazz);
/*     */     }
/*     */     
/* 100 */     return loadMember(this.query
/* 101 */         .findOne("playerName", playerName), clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Member loadMember(String playerName, boolean ignoreCase) {
/* 107 */     return (Member)loadMember(playerName, ignoreCase, MemberVoid.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends Member> T loadMember(String key, String value, boolean ignoreCase, Class<T> clazz) {
/* 112 */     if (ignoreCase) {
/* 113 */       return loadMember(this.query.findOne(key, (new Document("$regex", "^" + value + "$")).append("$options", "i")), clazz);
/*     */     }
/* 115 */     return loadMember(this.query.findOne(key, value), clazz);
/*     */   }
/*     */   
/*     */   public <T extends Member> T loadMember(JsonElement jsonElement, Class<T> clazz) {
/* 119 */     return (jsonElement == null) ? null : (T)CommonConst.GSON.fromJson(CommonConst.GSON.toJson(jsonElement), clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   public void reloadPlugins() {
/* 124 */     try (Jedis jedis = CommonPlugin.getInstance().getRedisConnection().getPool().getResource()) {
/* 125 */       Set<String> keys = jedis.keys("account:*");
/*     */       
/* 127 */       for (String playerId : keys) {
/* 128 */         jedis.del("account:" + playerId);
/*     */       }
/*     */     } 
/*     */     
/* 132 */     this.query.getCollection().updateMany((Bson)new Document(), 
/* 133 */         Filters.eq("$set", Filters.eq("loginConfiguration.logged", Boolean.valueOf(false))));
/* 134 */     this.query.getCollection().updateMany((Bson)new Document(), Filters.eq("$set", Filters.eq("online", Boolean.valueOf(false))));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends Member> T getRedisPlayer(UUID uuid, Class<T> clazz) {
/*     */     Member player;
/* 140 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/* 141 */       if (!jedis.exists("account:" + uuid.toString()).booleanValue()) {
/* 142 */         return null;
/*     */       }
/* 144 */       Map<String, String> fields = jedis.hgetAll("account:" + uuid.toString());
/*     */       
/* 146 */       if (fields == null || fields.isEmpty() || fields.size() < (Member.class.getDeclaredFields()).length - 1) {
/* 147 */         return null;
/*     */       }
/* 149 */       player = (Member)JsonUtils.mapToObject(fields, clazz);
/*     */     } 
/*     */     
/* 152 */     return clazz.cast(player);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean createMember(Member member) {
/* 157 */     boolean needCreate = (this.query.findOne("uniqueId", member.getUniqueId().toString()) == null);
/*     */     
/* 159 */     if (needCreate) {
/* 160 */       this.query.create(new String[] { CommonConst.GSON.toJson(member) });
/*     */     }
/* 162 */     return needCreate;
/*     */   }
/*     */ 
/*     */   
/*     */   public void saveRedisMember(Member member) {
/* 167 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/* 168 */       jedis.hmset("account:" + member.getUniqueId().toString(), JsonUtils.objectToMap(member));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean deleteMember(UUID uniqueId) {
/* 174 */     boolean needCreate = (this.query.findOne("uniqueId", uniqueId.toString()) == null);
/*     */     
/* 176 */     if (!needCreate) {
/* 177 */       this.query.deleteOne("uniqueId", uniqueId.toString());
/* 178 */       try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/* 179 */         jedis.del("account:" + uniqueId.toString());
/*     */       } 
/* 181 */       return true;
/*     */     } 
/*     */     
/* 184 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateMember(final Member member, final String fieldName) {
/* 189 */     CommonPlugin.getInstance().getPluginPlatform().runAsync(new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 193 */             JsonObject tree = JsonUtils.jsonTree(member);
/*     */             
/* 195 */             if (tree.has(fieldName)) {
/* 196 */               JsonElement element = tree.get(fieldName);
/*     */               
/* 198 */               try (Jedis jedis = MemberDataImpl.this.redisDatabase.getPool().getResource()) {
/* 199 */                 Pipeline pipe = jedis.pipelined();
/* 200 */                 jedis.hset("account:" + member.getUniqueId().toString(), fieldName, 
/* 201 */                     JsonUtils.elementToString(element));
/*     */                 
/* 203 */                 JsonObject json = new JsonObject();
/* 204 */                 json.add("uniqueId", (JsonElement)new JsonPrimitive(member.getUniqueId().toString()));
/* 205 */                 json.add("source", (JsonElement)new JsonPrimitive(CommonPlugin.getInstance().getServerId()));
/* 206 */                 json.add("field", (JsonElement)new JsonPrimitive(fieldName));
/* 207 */                 json.add("value", element);
/* 208 */                 pipe.publish("member_field", json.toString());
/*     */                 
/* 210 */                 pipe.sync();
/* 211 */               } catch (Exception e) {
/* 212 */                 e.printStackTrace();
/*     */               } 
/*     */             } 
/*     */             
/* 216 */             MemberDataImpl.this.query.updateOne("uniqueId", member.getUniqueId().toString(), (JsonElement)(new JsonBuilder())
/* 217 */                 .addProperty("fieldName", fieldName).add("value", tree.get(fieldName)).build());
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public void cacheMember(UUID uniqueId) {
/* 224 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/* 225 */       jedis.expire("account:" + uniqueId.toString(), 300);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean checkCache(UUID uniqueId) {
/* 231 */     boolean bool = false;
/*     */     
/* 233 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/* 234 */       String key = "account:" + uniqueId.toString();
/*     */       
/* 236 */       if (jedis.ttl(key).longValue() >= 0L) {
/* 237 */         bool = (jedis.persist(key).longValue() == 1L);
/*     */       }
/* 239 */     } catch (Exception ex) {
/* 240 */       ex.printStackTrace();
/*     */     } 
/*     */     
/* 243 */     return bool;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Member> getMembersByGroup(Group group) {
/* 248 */     List<Member> list = new ArrayList<>();
/*     */ 
/*     */     
/* 251 */     MongoCursor<Document> iterator = this.query.getCollection().find(Filters.eq("groups." + group.getGroupName().toLowerCase(), Filters.eq("$exists", Boolean.valueOf(true)))).limit(50).iterator();
/*     */     
/* 253 */     while (iterator.hasNext()) {
/* 254 */       list.add(CommonConst.GSON.fromJson(CommonConst.GSON.toJson(iterator.next()), MemberVoid.class));
/*     */     }
/* 256 */     return list;
/*     */   }
/*     */ 
/*     */   
/*     */   public void closeConnection() {
/* 261 */     this.redisDatabase.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRedisCached(String playerName) {
/* 266 */     boolean bool = false;
/*     */     
/* 268 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/* 269 */       String key = "member:mojang-fetcher:" + playerName.toLowerCase();
/* 270 */       long ttl = jedis.ttl(key).longValue();
/*     */       
/* 272 */       if (ttl == -1L) {
/* 273 */         bool = true;
/* 274 */       } else if (ttl > 0L) {
/* 275 */         bool = (jedis.persist(key).longValue() == 1L);
/*     */       } 
/* 277 */     } catch (Exception ex) {
/* 278 */       ex.printStackTrace();
/*     */     } 
/*     */     
/* 281 */     return bool;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isConnectionPremium(String playerName) {
/* 286 */     boolean bool = false;
/*     */     
/* 288 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/* 289 */       String key = "member:mojang-fetcher:" + playerName.toLowerCase();
/* 290 */       bool = StringFormat.parseBoolean(jedis.hget(key, "premium")).getAsBoolean();
/* 291 */     } catch (Exception ex) {
/* 292 */       ex.printStackTrace();
/*     */     } 
/*     */     
/* 295 */     return bool;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setConnectionStatus(String playerName, UUID uniqueId, boolean premium) {
/* 300 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/* 301 */       String key = "member:mojang-fetcher:" + playerName.toLowerCase();
/* 302 */       jedis.hset(key, "premium", "" + premium);
/* 303 */       jedis.hset(key, "uniqueId", uniqueId.toString());
/* 304 */       jedis.expire(key, 900);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public UUID getUniqueId(String playerName) {
/* 310 */     UUID uniqueId = null;
/*     */     
/* 312 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/* 313 */       String key = "member:mojang-fetcher:" + playerName.toLowerCase();
/*     */       
/* 315 */       if (jedis.exists(key).booleanValue())
/* 316 */         uniqueId = UUID.fromString(jedis.hget(key, "uniqueId")); 
/* 317 */     } catch (Exception ex) {
/* 318 */       ex.printStackTrace();
/*     */     } 
/*     */     
/* 321 */     return uniqueId;
/*     */   }
/*     */ 
/*     */   
/*     */   public void cacheConnection(String playerName, boolean premium) {
/* 326 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/* 327 */       jedis.expire("member:mojang-fetcher:" + playerName.toLowerCase(), 3600);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDiscordCached(String discordId) {
/* 333 */     boolean bool = false;
/*     */     
/* 335 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/* 336 */       String key = "discord:" + discordId;
/*     */       
/* 338 */       if (jedis.ttl(key).longValue() >= 0L)
/* 339 */         bool = (jedis.persist(key).longValue() == 1L); 
/* 340 */     } catch (Exception ex) {
/* 341 */       ex.printStackTrace();
/*     */     } 
/*     */     
/* 344 */     return bool;
/*     */   }
/*     */ 
/*     */   
/*     */   public UUID getUniqueIdFromDiscord(String discordId) {
/* 349 */     UUID uniqueId = null;
/*     */     
/* 351 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/* 352 */       String key = "discord:" + discordId;
/*     */       
/* 354 */       if (jedis.exists(key).booleanValue())
/* 355 */         uniqueId = UUID.fromString(jedis.get(key)); 
/* 356 */     } catch (Exception ex) {
/* 357 */       ex.printStackTrace();
/*     */     } 
/*     */     
/* 360 */     return uniqueId;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDiscordCache(String discordId, UUID uniqueId) {
/* 365 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/* 366 */       jedis.set("discord:" + discordId, "uniqueId", uniqueId.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void deleteDiscordCache(String discordId) {
/* 372 */     try (Jedis jedis = this.redisDatabase.getPool().getResource()) {
/* 373 */       jedis.del("discord:" + discordId);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Status loadStatus(UUID uniqueId, StatusType statusType) {
/* 380 */     Document document = (Document)this.statusQuery.getDatabase().getCollection("status-" + statusType.name().toLowerCase()).find(Filters.eq("uniqueId", uniqueId.toString())).first();
/*     */     
/* 382 */     if (document == null) {
/* 383 */       Status status = new Status(uniqueId, statusType);
/* 384 */       createStatus(status);
/* 385 */       return status;
/*     */     } 
/*     */     
/* 388 */     return (Status)CommonConst.GSON.fromJson(CommonConst.GSON.toJson(document), Status.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean createStatus(Status status) {
/* 395 */     Document document = (Document)this.statusQuery.getDatabase().getCollection("status-" + status.getStatusType().name().toLowerCase()).find(Filters.eq("uniqueId", status.getUniqueId().toString())).first();
/*     */     
/* 397 */     if (document == null) {
/* 398 */       this.statusQuery.getDatabase().getCollection("status-" + status.getStatusType().name().toLowerCase())
/* 399 */         .insertOne(Document.parse(CommonConst.GSON.toJson(status)));
/* 400 */       return true;
/*     */     } 
/*     */     
/* 403 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void saveStatus(final Status status, final String fieldName) {
/* 408 */     CommonPlugin.getInstance().getPluginPlatform().runAsync(new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 412 */             JsonObject tree = JsonUtils.jsonTree(status);
/*     */             
/* 414 */             JsonObject jsonObject = (new JsonBuilder()).addProperty("fieldName", fieldName).add("value", tree.get(fieldName)).build();
/*     */             
/* 416 */             Object object = JsonUtils.elementToBson(jsonObject.get("value"));
/*     */             
/* 418 */             if (object == null || jsonObject.get("value").isJsonNull()) {
/* 419 */               MemberDataImpl.this.statusQuery.getDatabase().getCollection("status-" + status.getStatusType().name().toLowerCase())
/* 420 */                 .updateOne(Filters.eq("uniqueId", status.getUniqueId().toString()), (Bson)new Document("$unset", new Document(jsonObject
/* 421 */                       .get("fieldName").getAsString(), "")));
/*     */             } else {
/* 423 */               MemberDataImpl.this.statusQuery.getDatabase().getCollection("status-" + status.getStatusType().name().toLowerCase())
/* 424 */                 .updateOne(Filters.eq("uniqueId", status.getUniqueId().toString()), (Bson)new Document("$set", new Document(jsonObject
/* 425 */                       .get("fieldName").getAsString(), object)));
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public Collection<Report> loadReports() {
/* 432 */     return (Collection<Report>)this.reportQuery.find().stream().map(json -> (Report)CommonConst.GSON.fromJson(json, Report.class))
/* 433 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */   
/*     */   public void createReport(Report report) {
/* 438 */     JsonElement jsonElement = this.reportQuery.findOne("reportId", report.getReportId().toString());
/*     */     
/* 440 */     if (jsonElement == null) {
/* 441 */       this.reportQuery.create(new String[] { CommonConst.GSON.toJson(report) });
/*     */     }
/* 443 */     CommonPlugin.getInstance().getPluginPlatform()
/* 444 */       .runAsync(() -> CommonPlugin.getInstance().getServerData().sendPacket((Packet)new ReportCreatePacket(report)));
/*     */   }
/*     */ 
/*     */   
/*     */   public void deleteReport(UUID reportId) {
/* 449 */     CommonPlugin.getInstance().getPluginPlatform().runAsync(() -> CommonPlugin.getInstance().getServerData().sendPacket((Packet)new ReportDeletePacket(reportId)));
/*     */     
/* 451 */     this.reportQuery.deleteOne("reportId", reportId.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateReport(final Report report, final String fieldName) {
/* 456 */     CommonPlugin.getInstance().getPluginPlatform().runAsync(new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 460 */             JsonObject tree = JsonUtils.jsonTree(report);
/*     */             
/* 462 */             CommonPlugin.getInstance().getServerData().sendPacket((Packet)new ReportFieldPacket(report, fieldName));
/* 463 */             MemberDataImpl.this.reportQuery.updateOne("reportId", report.getReportId().toString(), (JsonElement)(new JsonBuilder())
/* 464 */                 .addProperty("fieldName", fieldName).add("value", tree.get(fieldName)).build());
/*     */           }
/*     */         });
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/backend/data/impl/MemberDataImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */