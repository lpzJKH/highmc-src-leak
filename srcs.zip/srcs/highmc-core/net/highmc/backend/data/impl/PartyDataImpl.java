/*    */ package net.highmc.backend.data.impl;
/*    */ 
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import java.util.UUID;
/*    */ import net.highmc.CommonConst;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.backend.Query;
/*    */ import net.highmc.backend.data.PartyData;
/*    */ import net.highmc.backend.mongodb.MongoConnection;
/*    */ import net.highmc.backend.mongodb.MongoQuery;
/*    */ import net.highmc.member.party.Party;
/*    */ import net.highmc.packet.types.party.PartyCreate;
/*    */ import net.highmc.packet.types.party.PartyDelete;
/*    */ import net.highmc.packet.types.party.PartyField;
/*    */ import net.highmc.utils.json.JsonBuilder;
/*    */ import net.highmc.utils.json.JsonUtils;
/*    */ 
/*    */ public class PartyDataImpl implements PartyData {
/*    */   private MongoQuery query;
/*    */   
/*    */   public MongoQuery getQuery() {
/* 23 */     return this.query;
/*    */   }
/*    */   
/*    */   public PartyDataImpl(MongoConnection mongoConnection) {
/* 27 */     this.query = MongoQuery.createDefault(mongoConnection, mongoConnection.getDataBase(), "party");
/*    */   }
/*    */ 
/*    */   
/*    */   public <T extends Party> T loadParty(UUID partyId, Class<T> clazz) {
/* 32 */     JsonElement jsonElement = this.query.findOne("partyId", partyId.toString());
/* 33 */     return (jsonElement == null) ? null : (T)CommonConst.GSON.fromJson(jsonElement, clazz);
/*    */   }
/*    */ 
/*    */   
/*    */   public void createParty(Party party) {
/* 38 */     JsonElement jsonElement = this.query.findOne("partyId", party.getPartyId().toString());
/*    */     
/* 40 */     if (jsonElement == null) {
/* 41 */       this.query.create(new String[] { CommonConst.GSON.toJson(party) });
/*    */     }
/* 43 */     CommonPlugin.getInstance().getPluginPlatform().runAsync(() -> CommonPlugin.getInstance().getServerData().sendPacket((new PartyCreate(party)).server((String[])party.getMembers().stream().map(()).toArray(()))));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void deleteParty(Party party) {
/* 51 */     JsonElement jsonElement = this.query.findOne("partyId", party.getPartyId().toString());
/*    */     
/* 53 */     if (jsonElement != null) {
/* 54 */       this.query.deleteOne("partyId", party.getPartyId().toString());
/*    */     }
/* 56 */     CommonPlugin.getInstance().getPluginPlatform().runAsync(() -> CommonPlugin.getInstance().getServerData().sendPacket((new PartyDelete(party.getPartyId())).server((String[])party.getMembers().stream().filter(()).map(()).distinct().toArray(()))));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void updateParty(final Party party, final String fieldName) {
/* 65 */     CommonPlugin.getInstance().getPluginPlatform().runAsync(new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 69 */             JsonObject tree = JsonUtils.jsonTree(party);
/*    */             
/* 71 */             CommonPlugin.getInstance().getServerData().sendPacket((new PartyField(party, fieldName)).server((String[])party
/* 72 */                   .getMembers().stream()
/* 73 */                   .filter(id -> (CommonPlugin.getInstance().getMemberManager().getMember(id) != null))
/* 74 */                   .map(id -> CommonPlugin.getInstance().getMemberManager().getMember(id).getActualServerId())
/* 75 */                   .distinct().toArray(x$0 -> new String[x$0])));
/* 76 */             PartyDataImpl.this.query.updateOne("partyId", party.getPartyId().toString(), (JsonElement)(new JsonBuilder())
/* 77 */                 .addProperty("fieldName", fieldName).add("value", tree.get(fieldName)).build());
/*    */           }
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public UUID getPartyId() {
/*    */     UUID id;
/*    */     do {
/* 87 */       id = UUID.randomUUID();
/* 88 */     } while (this.query.findOne("partyId", id.toString()) != null);
/*    */     
/* 90 */     return id;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/backend/data/impl/PartyDataImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */