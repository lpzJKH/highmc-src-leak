package net.highmc.backend.data;

public interface DiscordData {
  String getNameByCode(String paramString, boolean paramBoolean);
  
  String getCodeOrCreate(String paramString1, String paramString2);
}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/backend/data/DiscordData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */