/*     */ package net.highmc.backend;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import net.highmc.utils.Callback;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Query<T>
/*     */ {
/*     */   Collection<T> find();
/*     */   
/*     */   Collection<T> find(String paramString);
/*     */   
/*     */   <GenericType> Collection<T> find(String paramString, GenericType paramGenericType);
/*     */   
/*     */   <GenericType> Collection<T> find(String paramString1, String paramString2, GenericType paramGenericType);
/*     */   
/*     */   <GenericType> T findOne(String paramString, GenericType paramGenericType);
/*     */   
/*     */   <GenericType> T findOne(String paramString1, String paramString2, GenericType paramGenericType);
/*     */   
/*     */   void create(String[] paramArrayOfString);
/*     */   
/*     */   void create(String paramString, String[] paramArrayOfString);
/*     */   
/*     */   <GenericType> void deleteOne(String paramString, GenericType paramGenericType);
/*     */   
/*     */   <GenericType> void deleteOne(String paramString1, String paramString2, GenericType paramGenericType);
/*     */   
/*     */   <GenericType> void updateOne(String paramString, GenericType paramGenericType, T paramT);
/*     */   
/*     */   <GenericType> void updateOne(String paramString1, String paramString2, GenericType paramGenericType, T paramT);
/*     */   
/*     */   <GenericType> Collection<T> ranking(String paramString, GenericType paramGenericType, int paramInt);
/*     */   
/*     */   public static class QueryResponse<T>
/*     */   {
/*     */     private long startTime;
/*     */     private long durationTime;
/*     */     private Callback<T> callback;
/*     */     
/*     */     public long getStartTime() {
/*  97 */       return this.startTime; } public long getDurationTime() {
/*  98 */       return this.durationTime;
/*     */     } public Callback<T> getCallback() {
/* 100 */       return this.callback;
/*     */     }
/*     */     public QueryResponse(Callback<T> callback) {
/* 103 */       this.startTime = System.currentTimeMillis();
/* 104 */       this.callback = callback;
/*     */     }
/*     */     
/*     */     public void callback(T t) {
/* 108 */       this.callback.callback(t);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/backend/Query.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */