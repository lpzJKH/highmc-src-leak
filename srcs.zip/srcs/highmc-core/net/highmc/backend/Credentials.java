/*    */ package net.highmc.backend;
/*    */ public class Credentials {
/*    */   private String hostName;
/*    */   private String userName;
/*    */   
/*    */   public Credentials(String hostName, String userName, String passWord, String database, int port) {
/*  7 */     this.hostName = hostName; this.userName = userName; this.passWord = passWord; this.database = database; this.port = port;
/*    */   } private String passWord; private String database; private int port;
/*    */   public String getHostName() {
/* 10 */     return this.hostName;
/*    */   }
/* 12 */   public String getUserName() { return this.userName; } public String getPassWord() {
/* 13 */     return this.passWord;
/*    */   }
/* 15 */   public String getDatabase() { return this.database; } public int getPort() {
/* 16 */     return this.port;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/backend/Credentials.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */