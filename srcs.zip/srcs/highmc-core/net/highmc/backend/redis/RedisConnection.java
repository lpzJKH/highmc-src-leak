/*    */ package net.highmc.backend.redis;
/*    */ import java.util.logging.Level;
/*    */ import lombok.NonNull;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.backend.Credentials;
/*    */ import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
/*    */ import redis.clients.jedis.JedisPool;
/*    */ import redis.clients.jedis.JedisPoolConfig;
/*    */ import redis.clients.jedis.JedisPubSub;
/*    */ 
/*    */ public class RedisConnection implements Database {
/*    */   @NonNull
/*    */   private final String hostname;
/*    */   
/*    */   public RedisConnection(@NonNull String hostname, @NonNull String password, int port) {
/* 16 */     if (hostname == null) throw new NullPointerException("hostname is marked non-null but is null");  if (password == null) throw new NullPointerException("password is marked non-null but is null");  this.hostname = hostname; this.password = password; this.port = port;
/*    */   }
/*    */   @NonNull
/*    */   private final String password; private final int port;
/*    */   private JedisPool pool;
/*    */   
/*    */   public JedisPool getPool() {
/* 23 */     return this.pool;
/*    */   }
/*    */   
/*    */   public RedisConnection() {
/* 27 */     this("localhost", "", 6379);
/*    */   }
/*    */   
/*    */   public RedisConnection(Credentials credentials) {
/* 31 */     this(credentials.getHostName(), credentials.getPassWord(), credentials.getPort());
/*    */   }
/*    */ 
/*    */   
/*    */   public void connect() {
/* 36 */     JedisPoolConfig config = new JedisPoolConfig();
/* 37 */     config.setMaxTotal(128);
/* 38 */     if (!this.password.isEmpty()) {
/* 39 */       this.pool = new JedisPool((GenericObjectPoolConfig)config, this.hostname, this.port, 0, this.password);
/*    */     } else {
/* 41 */       this.pool = new JedisPool((GenericObjectPoolConfig)config, this.hostname, this.port, 0);
/*    */     } 
/*    */   }
/*    */   
/*    */   public boolean isConnected() {
/* 46 */     return !this.pool.isClosed();
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() {
/* 51 */     if (this.pool != null) {
/* 52 */       this.pool.destroy();
/*    */     }
/*    */   }
/*    */   
/*    */   public static class PubSubListener
/*    */     implements Runnable
/*    */   {
/*    */     private RedisConnection redis;
/*    */     private JedisPubSub jpsh;
/*    */     private final String[] channels;
/*    */     
/*    */     public PubSubListener(RedisConnection redis, JedisPubSub s, String... channels) {
/* 64 */       this.redis = redis;
/* 65 */       this.jpsh = s;
/* 66 */       this.channels = channels;
/*    */     }
/*    */ 
/*    */     
/*    */     public void run() {
/* 71 */       CommonPlugin.getInstance().getLogger().log(Level.INFO, "Loading jedis!");
/*    */       
/* 73 */       try (Jedis jedis = this.redis.getPool().getResource()) {
/*    */         try {
/* 75 */           jedis.subscribe(this.jpsh, this.channels);
/* 76 */         } catch (Exception e) {
/* 77 */           CommonPlugin.getInstance().getLogger().log(Level.INFO, "PubSub error, attempting to recover.", e);
/*    */           try {
/* 79 */             this.jpsh.unsubscribe();
/* 80 */           } catch (Exception exception) {}
/*    */ 
/*    */           
/* 83 */           run();
/*    */         } 
/*    */       } 
/*    */     }
/*    */     
/*    */     public void addChannel(String... channel) {
/* 89 */       this.jpsh.subscribe(channel);
/*    */     }
/*    */     
/*    */     public void removeChannel(String... channel) {
/* 93 */       this.jpsh.unsubscribe(channel);
/*    */     }
/*    */     
/*    */     public void poison() {
/* 97 */       this.jpsh.unsubscribe();
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/backend/redis/RedisConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */