/*    */ package net.highmc.server;
/*    */ 
/*    */ import net.highmc.utils.string.StringFormat;
/*    */ 
/*    */ public enum ServerType
/*    */ {
/*  7 */   BUILD, LOGIN, LOBBY, BW_LOBBY, SW_LOBBY, HG_LOBBY, PVP_LOBBY,
/*    */   
/*  9 */   DUELS,
/*    */   
/* 11 */   FPS, LAVA, ARENA,
/*    */   
/* 13 */   HG, MINIHIGH, EVENTO,
/*    */   
/* 15 */   RANKUP,
/*    */   
/* 17 */   SW_SOLO, SW_DUOS, SW_TRIO, SW_SQUAD,
/*    */   
/* 19 */   BW_SOLO, BW_DUOS, BW_TRIO, BW_SQUAD, BW_1X1, BW_2X2, BW_3X3, BW_4X4,
/*    */   
/* 21 */   BUNGEECORD, DISCORD;
/*    */   
/*    */   public int getPlayersPerTeam() {
/* 24 */     if (name().contains("SOLO") || name().contains("1X1"))
/* 25 */       return 1; 
/* 26 */     if (name().contains("DUO") || name().contains("2X2"))
/* 27 */       return 2; 
/* 28 */     if (name().contains("TRIO") || name().contains("3X3")) {
/* 29 */       return 3;
/*    */     }
/* 31 */     return 4;
/*    */   }
/*    */   
/*    */   public ServerType getServerLobby() {
/* 35 */     if (name().contains("LOBBY"))
/* 36 */       return LOBBY; 
/* 37 */     if (name().contains("BW"))
/* 38 */       return BW_LOBBY; 
/* 39 */     if (name().contains("SW")) {
/* 40 */       return SW_LOBBY;
/*    */     }
/* 42 */     switch (this) {
/*    */       case HG:
/* 44 */         return HG_LOBBY;
/*    */       case ARENA:
/*    */       case FPS:
/*    */       case LAVA:
/* 48 */         return PVP_LOBBY;
/*    */     } 
/* 50 */     return LOBBY;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPvP() {
/* 55 */     switch (this) {
/*    */       case ARENA:
/*    */       case FPS:
/*    */       case LAVA:
/*    */       case PVP_LOBBY:
/* 60 */         return true;
/*    */     } 
/* 62 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isHG() {
/* 67 */     switch (this) {
/*    */       case HG:
/*    */       case EVENTO:
/*    */       case MINIHIGH:
/* 71 */         return true;
/*    */     } 
/* 73 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isLobby() {
/* 78 */     return (name().contains("LOBBY") || this == LOGIN || this == BUILD);
/*    */   }
/*    */   
/*    */   public String getName() {
/* 82 */     StringBuilder stringBuilder = new StringBuilder();
/*    */     
/* 84 */     for (String name : name().split("_")) {
/* 85 */       stringBuilder.append(StringFormat.formatString(name.replace("BW", "Bedwars").replace("SW", "Skywars")))
/* 86 */         .append(" ");
/*    */     }
/*    */     
/* 89 */     return stringBuilder.toString().trim();
/*    */   }
/*    */   
/*    */   public static ServerType getTypeByName(String string) {
/*    */     try {
/* 94 */       return valueOf(string.toUpperCase());
/* 95 */     } catch (Exception ex) {
/* 96 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/server/ServerType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */