/*    */ package net.highmc.server.loadbalancer.server;
/*    */ 
/*    */ import java.util.Set;
/*    */ import java.util.UUID;
/*    */ import net.highmc.server.ServerType;
/*    */ import net.highmc.server.loadbalancer.element.LoadBalancerObject;
/*    */ import net.highmc.server.loadbalancer.element.NumberConnection;
/*    */ import net.md_5.bungee.api.ProxyServer;
/*    */ import net.md_5.bungee.api.config.ServerInfo;
/*    */ 
/*    */ public class ProxiedServer implements LoadBalancerObject, NumberConnection {
/*    */   private String serverId;
/*    */   private ServerType serverType;
/*    */   private Set<UUID> players;
/*    */   
/*    */   public String getServerId() {
/* 17 */     return this.serverId; } private int maxPlayers; private int playersRecord; private boolean joinEnabled; private long startTime; public ServerType getServerType() {
/* 18 */     return this.serverType;
/*    */   } public Set<UUID> getPlayers() {
/* 20 */     return this.players;
/*    */   }
/* 22 */   public void setMaxPlayers(int maxPlayers) { this.maxPlayers = maxPlayers; }
/* 23 */   public int getMaxPlayers() { return this.maxPlayers; }
/* 24 */   public void setPlayersRecord(int playersRecord) { this.playersRecord = playersRecord; } public int getPlayersRecord() {
/* 25 */     return this.playersRecord;
/*    */   }
/* 27 */   public void setJoinEnabled(boolean joinEnabled) { this.joinEnabled = joinEnabled; }
/* 28 */   public boolean isJoinEnabled() { return this.joinEnabled; }
/* 29 */   public void setStartTime(long startTime) { this.startTime = startTime; } public long getStartTime() {
/* 30 */     return this.startTime;
/*    */   }
/*    */   
/*    */   public ProxiedServer(String serverId, ServerType serverType, Set<UUID> players, int maxPlayers, boolean joinEnabled) {
/* 34 */     this.serverId = serverId.toLowerCase();
/* 35 */     this.serverType = serverType;
/* 36 */     this.players = players;
/* 37 */     this.maxPlayers = maxPlayers;
/* 38 */     this.joinEnabled = joinEnabled;
/*    */   }
/*    */   
/*    */   public void setOnlinePlayers(Set<UUID> onlinePlayers) {
/* 42 */     this.players = onlinePlayers;
/*    */   }
/*    */   
/*    */   public void joinPlayer(UUID uuid) {
/* 46 */     this.players.add(uuid);
/* 47 */     this.playersRecord = Math.max(this.playersRecord, this.players.size());
/*    */   }
/*    */   
/*    */   public void leavePlayer(UUID uuid) {
/* 51 */     this.players.remove(uuid);
/*    */   }
/*    */   
/*    */   public int getOnlinePlayers() {
/* 55 */     return this.players.size();
/*    */   }
/*    */   
/*    */   public boolean isFull() {
/* 59 */     return (this.players.size() >= this.maxPlayers);
/*    */   }
/*    */   
/*    */   public ServerInfo getServerInfo() {
/* 63 */     return ProxyServer.getInstance().getServerInfo(this.serverId);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean canBeSelected() {
/* 68 */     return !isFull();
/*    */   }
/*    */ 
/*    */   
/*    */   public int getActualNumber() {
/* 73 */     return getOnlinePlayers();
/*    */   }
/*    */ 
/*    */   
/*    */   public int getMaxNumber() {
/* 78 */     return getMaxPlayers();
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/server/loadbalancer/server/ProxiedServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */