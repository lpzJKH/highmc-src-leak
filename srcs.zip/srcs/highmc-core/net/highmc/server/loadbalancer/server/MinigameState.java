/*    */ package net.highmc.server.loadbalancer.server;
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum MinigameState
/*    */ {
/*    */   MinigameState(boolean decrementTime) {
/*    */     this.decrementTime = decrementTime;
/*    */   }
/*    */   
/*    */   private boolean decrementTime;
/* 12 */   PREGAME(true), WAITING(true), STARTING(true), INVINCIBILITY(true), GAMETIME, WINNING(true), NONE,
/* 13 */   FINAL_BATTLE(true);
/*    */   public boolean isDecrementTime() {
/* 15 */     return this.decrementTime;
/*    */   }
/*    */   public boolean isPregame() {
/* 18 */     switch (this) {
/*    */       case STARTING:
/*    */       case WAITING:
/*    */       case PREGAME:
/* 22 */         return true;
/*    */     } 
/* 24 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isInvencibility() {
/* 29 */     if (this == INVINCIBILITY)
/* 30 */       return true; 
/* 31 */     return false;
/*    */   }
/*    */   
/*    */   public boolean isGametime() {
/* 35 */     return (this == GAMETIME);
/*    */   }
/*    */   
/*    */   public boolean isEnding() {
/* 39 */     return (this == WINNING);
/*    */   }
/*    */   
/*    */   public boolean isState(MinigameState state) {
/* 43 */     return (this == state);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/server/loadbalancer/server/MinigameState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */