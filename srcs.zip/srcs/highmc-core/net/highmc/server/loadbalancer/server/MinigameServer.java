/*    */ package net.highmc.server.loadbalancer.server;
/*    */ 
/*    */ import java.util.Set;
/*    */ import java.util.UUID;
/*    */ import net.highmc.server.ServerType;
/*    */ 
/*    */ public abstract class MinigameServer extends ProxiedServer {
/*    */   private int time;
/*    */   
/*    */   public void setTime(int time) {
/* 11 */     this.time = time; } public void setMap(String map) { this.map = map; } public void setState(MinigameState state) { this.state = state; }
/*    */   
/*    */   public int getTime() {
/* 14 */     return this.time;
/* 15 */   } private String map = "Unknown"; public String getMap() { return this.map; }
/* 16 */    private MinigameState state = MinigameState.WAITING; public MinigameState getState() { return this.state; }
/*    */   
/*    */   public MinigameServer(String serverId, ServerType type, Set<UUID> players, int maxPlayers, boolean joinEnabled) {
/* 19 */     super(serverId, type, players, maxPlayers, joinEnabled);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getActualNumber() {
/* 24 */     return super.getActualNumber();
/*    */   }
/*    */   
/*    */   public abstract boolean isInProgress();
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/server/loadbalancer/server/MinigameServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */