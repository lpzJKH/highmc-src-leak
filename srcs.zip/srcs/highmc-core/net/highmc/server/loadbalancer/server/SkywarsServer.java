/*    */ package net.highmc.server.loadbalancer.server;
/*    */ 
/*    */ import java.util.Set;
/*    */ import java.util.UUID;
/*    */ import net.highmc.server.ServerType;
/*    */ 
/*    */ public class SkywarsServer
/*    */   extends MinigameServer
/*    */ {
/*    */   public SkywarsServer(String serverId, ServerType type, Set<UUID> players, int maxPlayers, boolean joinEnabled) {
/* 11 */     super(serverId, type, players, maxPlayers, joinEnabled);
/* 12 */     setState(MinigameState.WAITING);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean canBeSelected() {
/* 17 */     return (super.canBeSelected() && !isInProgress() && getState() == MinigameState.WAITING);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isInProgress() {
/* 22 */     return (getState() == MinigameState.PREGAME || getState() == MinigameState.GAMETIME || 
/* 23 */       getState() == MinigameState.INVINCIBILITY);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/server/loadbalancer/server/SkywarsServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */