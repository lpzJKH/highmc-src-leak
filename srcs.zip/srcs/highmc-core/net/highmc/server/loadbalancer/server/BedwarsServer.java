/*    */ package net.highmc.server.loadbalancer.server;
/*    */ 
/*    */ import java.util.Set;
/*    */ import java.util.UUID;
/*    */ import net.highmc.server.ServerType;
/*    */ 
/*    */ public class BedwarsServer
/*    */   extends MinigameServer
/*    */ {
/*    */   public BedwarsServer(String serverId, ServerType type, Set<UUID> players, int maxPlayers, boolean joinEnabled) {
/* 11 */     super(serverId, type, players, maxPlayers, joinEnabled);
/* 12 */     setState(MinigameState.WAITING);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean canBeSelected() {
/* 17 */     return (super.canBeSelected() && !isInProgress() && (
/* 18 */       getState() == MinigameState.WAITING || getState() == MinigameState.STARTING));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isInProgress() {
/* 23 */     return (getState() == MinigameState.PREGAME || getState() == MinigameState.GAMETIME || 
/* 24 */       getState() == MinigameState.INVINCIBILITY);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/server/loadbalancer/server/BedwarsServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */