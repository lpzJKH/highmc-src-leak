package net.highmc.server.loadbalancer;

public interface LoadBalancer<T extends net.highmc.server.loadbalancer.element.LoadBalancerObject> {
  T next();
}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/server/loadbalancer/LoadBalancer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */