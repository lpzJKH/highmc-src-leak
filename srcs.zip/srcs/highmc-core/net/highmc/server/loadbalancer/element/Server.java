package net.highmc.server.loadbalancer.element;

public interface Server {
  boolean isJoinEnabled();
}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/server/loadbalancer/element/Server.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */