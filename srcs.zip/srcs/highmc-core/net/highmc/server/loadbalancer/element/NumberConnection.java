package net.highmc.server.loadbalancer.element;

public interface NumberConnection {
  int getActualNumber();
  
  int getMaxNumber();
}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/server/loadbalancer/element/NumberConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */