package net.highmc.server.loadbalancer.element;

public interface LoadBalancerObject {
  String getServerId();
  
  long getStartTime();
  
  boolean canBeSelected();
}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/server/loadbalancer/element/LoadBalancerObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */