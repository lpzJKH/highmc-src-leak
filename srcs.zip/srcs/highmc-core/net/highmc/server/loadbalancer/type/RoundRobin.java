/*    */ package net.highmc.server.loadbalancer.type;
/*    */ 
/*    */ import net.highmc.server.loadbalancer.BaseBalancer;
/*    */ import net.highmc.server.loadbalancer.element.LoadBalancerObject;
/*    */ import net.highmc.server.loadbalancer.element.NumberConnection;
/*    */ 
/*    */ public class RoundRobin<T extends LoadBalancerObject & NumberConnection>
/*    */   extends BaseBalancer<T> {
/*  9 */   private int next = 0;
/*    */   
/*    */   public T next() {
/*    */     LoadBalancerObject loadBalancerObject;
/* 13 */     T obj = null;
/* 14 */     if (this.nextObj != null && !this.nextObj.isEmpty()) {
/* 15 */       while (this.next < this.nextObj.size()) {
/* 16 */         loadBalancerObject = this.nextObj.get(this.next);
/* 17 */         this.next++;
/* 18 */         if (loadBalancerObject == null)
/*    */           continue; 
/* 20 */         if (!loadBalancerObject.canBeSelected()) {
/* 21 */           loadBalancerObject = null;
/*    */         }
/*    */       } 
/*    */     }
/*    */ 
/*    */     
/* 27 */     if (this.next + 1 >= this.nextObj.size())
/* 28 */       this.next = 0; 
/* 29 */     return (T)loadBalancerObject;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getTotalNumber() {
/* 34 */     int number = 0;
/* 35 */     for (LoadBalancerObject loadBalancerObject : this.nextObj) {
/* 36 */       number += ((NumberConnection)loadBalancerObject).getActualNumber();
/*    */     }
/* 38 */     return number;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/server/loadbalancer/type/RoundRobin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */