/*    */ package net.highmc.server.loadbalancer.type;
/*    */ 
/*    */ import net.highmc.server.loadbalancer.BaseBalancer;
/*    */ import net.highmc.server.loadbalancer.element.LoadBalancerObject;
/*    */ import net.highmc.server.loadbalancer.element.NumberConnection;
/*    */ 
/*    */ public class MostConnection<T extends LoadBalancerObject & NumberConnection>
/*    */   extends BaseBalancer<T> {
/*    */   public T next() {
/*    */     LoadBalancerObject loadBalancerObject;
/* 11 */     T obj = null;
/* 12 */     if (this.nextObj != null && !this.nextObj.isEmpty())
/* 13 */       for (LoadBalancerObject loadBalancerObject1 : this.nextObj) {
/* 14 */         if (!loadBalancerObject1.canBeSelected())
/*    */           continue; 
/* 16 */         if (obj == null) {
/* 17 */           loadBalancerObject = loadBalancerObject1;
/*    */           continue;
/*    */         } 
/* 20 */         if (((NumberConnection)loadBalancerObject).getActualNumber() < ((NumberConnection)loadBalancerObject1).getActualNumber()) {
/* 21 */           loadBalancerObject = loadBalancerObject1;
/*    */         }
/*    */       }  
/* 24 */     return (T)loadBalancerObject;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getTotalNumber() {
/* 29 */     int number = 0;
/* 30 */     for (LoadBalancerObject loadBalancerObject : this.nextObj) {
/* 31 */       number += ((NumberConnection)loadBalancerObject).getActualNumber();
/*    */     }
/* 33 */     return number;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/server/loadbalancer/type/MostConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */