/*    */ package net.highmc.server.loadbalancer;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.stream.Collectors;
/*    */ import net.highmc.server.loadbalancer.element.LoadBalancerObject;
/*    */ 
/*    */ public abstract class BaseBalancer<T extends LoadBalancerObject>
/*    */   implements LoadBalancer<T> {
/*    */   private Map<String, T> objects;
/*    */   protected List<T> nextObj;
/*    */   
/*    */   public BaseBalancer() {
/* 17 */     this.objects = new HashMap<>();
/* 18 */     this.nextObj = new ArrayList<>();
/*    */   }
/*    */   
/*    */   public BaseBalancer(Map<String, T> map) {
/* 22 */     addAll(map);
/*    */   }
/*    */   
/*    */   public void add(String id, T obj) {
/* 26 */     this.objects.put(id, obj);
/* 27 */     update();
/*    */   }
/*    */   
/*    */   public T get(String id) {
/* 31 */     return this.objects.get(id);
/*    */   }
/*    */   
/*    */   public void remove(String id) {
/* 35 */     this.objects.remove(id);
/* 36 */     update();
/*    */   }
/*    */   
/*    */   public void addAll(Map<String, T> map) {
/* 40 */     if (this.objects != null)
/* 41 */       this.objects.clear(); 
/* 42 */     this.objects = map;
/* 43 */     update();
/*    */   }
/*    */   
/*    */   public List<T> getList() {
/* 47 */     return this.nextObj;
/*    */   }
/*    */   
/*    */   public void update() {
/* 51 */     if (this.nextObj != null)
/* 52 */       this.nextObj.clear(); 
/* 53 */     this.nextObj = new ArrayList<>();
/* 54 */     this.nextObj.addAll((Collection<? extends T>)this.objects.values().stream().sorted((o1, o2) -> Long.compare(o1.getStartTime(), o2.getStartTime()))
/* 55 */         .collect(Collectors.toList()));
/*    */   }
/*    */   
/*    */   public abstract int getTotalNumber();
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/server/loadbalancer/BaseBalancer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */