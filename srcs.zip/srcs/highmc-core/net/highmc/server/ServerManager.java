/*     */ package net.highmc.server;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import net.highmc.server.loadbalancer.BaseBalancer;
/*     */ import net.highmc.server.loadbalancer.element.LoadBalancerObject;
/*     */ import net.highmc.server.loadbalancer.server.BedwarsServer;
/*     */ import net.highmc.server.loadbalancer.server.HungerGamesServer;
/*     */ import net.highmc.server.loadbalancer.server.MinigameServer;
/*     */ import net.highmc.server.loadbalancer.server.MinigameState;
/*     */ import net.highmc.server.loadbalancer.server.ProxiedServer;
/*     */ import net.highmc.server.loadbalancer.server.SkywarsServer;
/*     */ import net.highmc.server.loadbalancer.type.LeastConnection;
/*     */ import net.highmc.server.loadbalancer.type.MostConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerManager
/*     */ {
/*     */   private int totalMembers;
/*     */   
/*     */   public Map<String, ProxiedServer> getActiveServers() {
/*  34 */     return this.activeServers;
/*  35 */   } public Map<ServerType, BaseBalancer<ProxiedServer>> getBalancers() { return this.balancers; } public int getTotalMembers() {
/*  36 */     return this.totalMembers;
/*     */   }
/*     */   
/*  39 */   private Map<ServerType, BaseBalancer<ProxiedServer>> balancers = new HashMap<>();
/*  40 */   private Map<String, ProxiedServer> activeServers = new HashMap<>();
/*     */   public ServerManager() {
/*  42 */     for (ServerType serverType : ServerType.values()) {
/*  43 */       if (serverType != ServerType.BUNGEECORD)
/*  44 */         this.balancers.put(serverType, 
/*  45 */             serverType.name().contains("LOBBY") ? (BaseBalancer<ProxiedServer>)new LeastConnection() : (BaseBalancer<ProxiedServer>)new MostConnection()); 
/*     */     } 
/*     */   }
/*     */   public BaseBalancer<ProxiedServer> getBalancer(ServerType type) {
/*  49 */     return this.balancers.get(type);
/*     */   }
/*     */   
/*     */   public void putBalancer(ServerType type, BaseBalancer<ProxiedServer> balancer) {
/*  53 */     this.balancers.put(type, balancer);
/*     */   }
/*     */ 
/*     */   
/*     */   public ProxiedServer addActiveServer(String serverAddress, String serverIp, ServerType type, int maxPlayers, long startTime) {
/*  58 */     return updateActiveServer(serverIp, type, new HashSet<>(), maxPlayers, true, startTime);
/*     */   }
/*     */ 
/*     */   
/*     */   public ProxiedServer updateActiveServer(String serverId, ServerType type, Set<UUID> onlinePlayers, int maxPlayers, boolean canJoin, long startTime) {
/*  63 */     return updateActiveServer(serverId, type, onlinePlayers, maxPlayers, canJoin, 0, "Unknown", null, startTime);
/*     */   }
/*     */ 
/*     */   
/*     */   public ProxiedServer updateActiveServer(String serverId, ServerType type, Set<UUID> onlinePlayers, int maxPlayers, boolean canJoin, int tempo, String map, MinigameState state, long startTime) {
/*  68 */     ProxiedServer server = this.activeServers.get(serverId);
/*     */     
/*  70 */     if (server == null) {
/*  71 */       if (type.isLobby()) {
/*  72 */         server = new ProxiedServer(serverId, type, onlinePlayers, maxPlayers, true);
/*  73 */       } else if (type.isHG()) {
/*  74 */         HungerGamesServer hungerGamesServer = new HungerGamesServer(serverId, type, onlinePlayers, maxPlayers, true);
/*  75 */       } else if (type.name().startsWith("SW")) {
/*  76 */         SkywarsServer skywarsServer = new SkywarsServer(serverId, type, onlinePlayers, maxPlayers, true);
/*  77 */       } else if (type.name().startsWith("BW")) {
/*  78 */         BedwarsServer bedwarsServer = new BedwarsServer(serverId, type, onlinePlayers, maxPlayers, true);
/*     */       } else {
/*  80 */         server = new ProxiedServer(serverId, type, onlinePlayers, maxPlayers, true);
/*     */       } 
/*  82 */       this.activeServers.put(serverId.toLowerCase(), server);
/*     */     } 
/*     */     
/*  85 */     server.setOnlinePlayers(onlinePlayers);
/*  86 */     server.setJoinEnabled(canJoin);
/*  87 */     server.setStartTime(startTime);
/*     */     
/*  89 */     if (state != null && server instanceof MinigameServer) {
/*  90 */       ((MinigameServer)server).setState(state);
/*  91 */       ((MinigameServer)server).setTime(tempo);
/*  92 */       ((MinigameServer)server).setMap(map);
/*     */     } 
/*     */     
/*  95 */     addToBalancers(serverId, server);
/*  96 */     return server;
/*     */   }
/*     */   
/*     */   public ProxiedServer getServer(String serverName) {
/* 100 */     return this.activeServers.get(serverName.toLowerCase());
/*     */   }
/*     */   
/*     */   public ProxiedServer getServerByName(String serverName) {
/* 104 */     for (ProxiedServer proxiedServer : this.activeServers.values()) {
/* 105 */       if (proxiedServer.getServerId().toLowerCase().startsWith(serverName.toLowerCase()))
/* 106 */         return proxiedServer; 
/*     */     } 
/* 108 */     return this.activeServers.get(serverName.toLowerCase());
/*     */   }
/*     */   
/*     */   public Collection<ProxiedServer> getServers() {
/* 112 */     return this.activeServers.values();
/*     */   }
/*     */   
/*     */   public void removeActiveServer(String str) {
/* 116 */     if (getServer(str) != null) {
/* 117 */       removeFromBalancers(getServer(str));
/*     */     }
/* 119 */     this.activeServers.remove(str.toLowerCase());
/*     */   }
/*     */   
/*     */   public void addToBalancers(String serverId, ProxiedServer server) {
/* 123 */     BaseBalancer<ProxiedServer> balancer = getBalancer(server.getServerType());
/*     */     
/* 125 */     if (balancer == null) {
/*     */       return;
/*     */     }
/* 128 */     balancer.add(serverId.toLowerCase(), (LoadBalancerObject)server);
/*     */   }
/*     */   
/*     */   public void removeFromBalancers(ProxiedServer serverId) {
/* 132 */     BaseBalancer<ProxiedServer> balancer = getBalancer(serverId.getServerType());
/* 133 */     if (balancer != null)
/* 134 */       balancer.remove(serverId.getServerId().toLowerCase()); 
/*     */   }
/*     */   
/*     */   public void setTotalMembers(int totalMembers) {
/* 138 */     this.totalMembers = totalMembers;
/*     */   }
/*     */   
/*     */   public int getTotalNumber() {
/* 142 */     return this.totalMembers;
/*     */   }
/*     */   
/*     */   public int getTotalNumber(ServerType... serverTypes) {
/* 146 */     int number = 0;
/*     */     
/* 148 */     for (ServerType serverType : serverTypes) {
/* 149 */       number += getBalancer(serverType).getTotalNumber();
/*     */     }
/* 151 */     return number;
/*     */   }
/*     */   
/*     */   public int getTotalNumber(List<ServerType> types) {
/* 155 */     int players = 0;
/*     */     
/* 157 */     for (ServerType type : types) {
/* 158 */       players += getBalancer(type).getTotalNumber();
/*     */     }
/*     */     
/* 161 */     return players;
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/server/ServerManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */