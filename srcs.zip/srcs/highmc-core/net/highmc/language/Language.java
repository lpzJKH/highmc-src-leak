/*    */ package net.highmc.language;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Locale;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.member.Member;
/*    */ 
/*    */ public enum Language
/*    */ {
/*    */   private String languageName;
/*    */   private String languageCode;
/*    */   private String[] languageAliases;
/* 15 */   PORTUGUESE("Português", "pt-br", new String[] { "portugues", "br", "brasileiro" }),
/* 16 */   ENGLISH("English", "en-us", new String[] { "inglês", "ingles", "england", "us", "eua" }); private static final Map<String, Language> LANGUAGE_MAP;
/*    */   public String getLanguageName() {
/* 18 */     return this.languageName; }
/* 19 */   public String getLanguageCode() { return this.languageCode; } public String[] getLanguageAliases() {
/* 20 */     return this.languageAliases;
/*    */   }
/*    */   Language(String languageName, String languageCode, String... languageAliases) {
/* 23 */     this.languageName = languageName;
/* 24 */     this.languageCode = languageCode;
/* 25 */     this.languageAliases = languageAliases;
/*    */   }
/*    */   
/*    */   public String t(String key, String... replaces) {
/* 29 */     return CommonPlugin.getInstance().getPluginInfo().translate(this, key, replaces);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static {
/* 35 */     LANGUAGE_MAP = new HashMap<>();
/*    */     
/* 37 */     for (Language language : values()) {
/* 38 */       LANGUAGE_MAP.put(language.name().toLowerCase(), language);
/* 39 */       LANGUAGE_MAP.put(language.getLanguageName().toLowerCase(), language);
/* 40 */       LANGUAGE_MAP.put(language.getLanguageCode().toLowerCase(), language);
/*    */       
/* 42 */       for (String alias : language.getLanguageAliases()) {
/* 43 */         LANGUAGE_MAP.put(alias.toLowerCase(), language);
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Language getLanguageByName(String languageName) {
/* 56 */     return LANGUAGE_MAP.get(languageName.toLowerCase());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Language getLanguage(UUID uniqueId) {
/* 68 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(uniqueId);
/* 69 */     return (member == null) ? CommonPlugin.getInstance().getPluginInfo().getDefaultLanguage() : member.getLanguage();
/*    */   }
/*    */   
/*    */   public Locale getLocale() {
/* 73 */     String[] split = getLanguageCode().split("-");
/* 74 */     return new Locale(split[0].toLowerCase(), split[1].toUpperCase());
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/language/Language.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */