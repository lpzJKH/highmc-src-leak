/*    */ package net.highmc.report;
/*    */ public class ReportInfo {
/*    */   private String playerName;
/*    */   private String reason;
/*    */   
/*    */   public ReportInfo(String playerName, String reason, long createdAt) {
/*  7 */     this.playerName = playerName; this.reason = reason; this.createdAt = createdAt;
/*    */   }
/*    */   public String getPlayerName() {
/* 10 */     return this.playerName;
/*    */   } public String getReason() {
/* 12 */     return this.reason;
/* 13 */   } private long createdAt = System.currentTimeMillis(); public long getCreatedAt() { return this.createdAt; }
/*    */   
/*    */   public ReportInfo(String playerName, String reason) {
/* 16 */     this.playerName = playerName;
/* 17 */     this.reason = reason;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/report/ReportInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */