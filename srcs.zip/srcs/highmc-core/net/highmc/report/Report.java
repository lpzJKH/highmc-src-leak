/*    */ package net.highmc.report;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.command.CommandSender;
/*    */ import net.highmc.member.Member;
/*    */ 
/*    */ public class Report {
/*    */   private final UUID reportId;
/*    */   private String playerName;
/*    */   private Map<UUID, ReportInfo> reportMap;
/*    */   private UUID lastReport;
/*    */   private long createdAt;
/*    */   private boolean online;
/*    */   
/* 17 */   public UUID getReportId() { return this.reportId; } public String getPlayerName() {
/* 18 */     return this.playerName;
/*    */   } public Map<UUID, ReportInfo> getReportMap() {
/* 20 */     return this.reportMap;
/*    */   }
/*    */   
/*    */   public long getCreatedAt() {
/* 24 */     return this.createdAt; } public boolean isOnline() {
/* 25 */     return this.online;
/*    */   }
/*    */   public Report(Member reported, CommandSender reporter, String reason, boolean online) {
/* 28 */     this.reportId = reported.getUniqueId();
/* 29 */     this.playerName = reported.getName();
/*    */     
/* 31 */     this.reportMap = new HashMap<>();
/* 32 */     this.lastReport = reporter.getUniqueId();
/*    */     
/* 34 */     this.createdAt = System.currentTimeMillis();
/* 35 */     this.online = online;
/*    */     
/* 37 */     addReport(reporter, reason);
/*    */   }
/*    */   
/*    */   public void setOnline(boolean online) {
/* 41 */     this.online = online;
/* 42 */     CommonPlugin.getInstance().getMemberData().updateReport(this, "online");
/*    */   }
/*    */   
/*    */   public void addReport(CommandSender reporter, String reason) {
/* 46 */     this.reportMap.put(reporter.getUniqueId(), new ReportInfo(reporter.getName(), reason));
/* 47 */     this.lastReport = reporter.getUniqueId();
/* 48 */     CommonPlugin.getInstance().getMemberData().updateReport(this, "reportMap");
/* 49 */     CommonPlugin.getInstance().getMemberData().updateReport(this, "lastReport");
/*    */   }
/*    */   
/*    */   public void deleteReport() {
/* 53 */     CommonPlugin.getInstance().getReportManager().deleteReport(this.reportId);
/* 54 */     CommonPlugin.getInstance().getMemberData().deleteReport(this.reportId);
/*    */   }
/*    */   
/*    */   public ReportInfo getLastReport() {
/* 58 */     return this.reportMap.get(this.lastReport);
/*    */   }
/*    */   
/*    */   public long getExpiresAt() {
/* 62 */     return getLastReport().getCreatedAt() + 10800000L;
/*    */   }
/*    */   
/*    */   public boolean hasExpired() {
/* 66 */     return (getExpiresAt() < System.currentTimeMillis());
/*    */   }
/*    */   
/*    */   public void notifyPunish() {
/* 70 */     for (Map.Entry<UUID, ReportInfo> entry : getReportMap().entrySet()) {
/* 71 */       Member member = CommonPlugin.getInstance().getMemberManager().getMember(entry.getKey());
/*    */       
/* 73 */       if (member != null) {
/* 74 */         member.sendMessage("§aUm jogador que você denunciou recentemente foi banido.");
/* 75 */         member.sendMessage("§aObrigado por ajudar nossa comunidade!");
/*    */       } 
/*    */     } 
/*    */     
/* 79 */     deleteReport();
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/report/Report.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */