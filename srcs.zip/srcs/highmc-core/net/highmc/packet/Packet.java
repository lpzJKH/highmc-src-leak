/*    */ package net.highmc.packet;
/*    */ import java.util.List;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.server.ServerType;
/*    */ 
/*    */ public abstract class Packet {
/*    */   private final String source;
/*    */   private final ServerType serverType;
/*    */   private final PacketType packetType;
/*    */   private boolean exclusiveServers;
/*    */   
/*    */   public Packet(String source, ServerType serverType, PacketType packetType, boolean exclusiveServers, List<String> serverList) {
/* 13 */     this.source = source; this.serverType = serverType; this.packetType = packetType; this.exclusiveServers = exclusiveServers; this.serverList = serverList;
/*    */   }
/*    */   
/* 16 */   public String getSource() { return this.source; } public ServerType getServerType() {
/* 17 */     return this.serverType;
/*    */   } public PacketType getPacketType() {
/* 19 */     return this.packetType;
/*    */   } public boolean isExclusiveServers() {
/* 21 */     return this.exclusiveServers;
/* 22 */   } private List<String> serverList = new ArrayList<>(); public List<String> getServerList() { return this.serverList; }
/*    */   
/*    */   public Packet(PacketType packetType) {
/* 25 */     this.source = CommonPlugin.getInstance().getServerId();
/* 26 */     this.serverType = CommonPlugin.getInstance().getServerType();
/* 27 */     this.packetType = packetType;
/*    */   }
/*    */   
/*    */   public Packet server(String... servers) {
/* 31 */     this.exclusiveServers = true;
/*    */     
/* 33 */     for (String server : servers) {
/* 34 */       this.serverList.add(server);
/*    */     }
/* 36 */     return this;
/*    */   }
/*    */   
/*    */   public Packet bungeecord() {
/* 40 */     server(new String[] { "bungeecord.highmc.net" });
/* 41 */     return this;
/*    */   }
/*    */   
/*    */   public Packet discord() {
/* 45 */     server(new String[] { "discord.highmc.net" });
/* 46 */     return this;
/*    */   }
/*    */   
/*    */   public void receive() {}
/*    */   
/*    */   public void send() {}
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/packet/Packet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */