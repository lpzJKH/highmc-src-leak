/*    */ package net.highmc.packet;
/*    */ import net.highmc.packet.types.ActionBar;
/*    */ import net.highmc.packet.types.BroadcastPacket;
/*    */ import net.highmc.packet.types.PlayerMessagePacket;
/*    */ import net.highmc.packet.types.ReportCreatePacket;
/*    */ import net.highmc.packet.types.ReportDeletePacket;
/*    */ import net.highmc.packet.types.ReportFieldPacket;
/*    */ import net.highmc.packet.types.StaffchatBungeePacket;
/*    */ import net.highmc.packet.types.StaffchatDiscordPacket;
/*    */ import net.highmc.packet.types.configuration.ConfigurationUpdate;
/*    */ import net.highmc.packet.types.party.PartyCreate;
/*    */ import net.highmc.packet.types.party.PartyDelete;
/*    */ import net.highmc.packet.types.party.PartyField;
/*    */ import net.highmc.packet.types.skin.SkinChange;
/*    */ import net.highmc.packet.types.staff.Stafflog;
/*    */ import net.highmc.packet.types.staff.TeleportToTarget;
/*    */ 
/*    */ public enum PacketType {
/* 19 */   PLAYER_MESSAGE((Class)PlayerMessagePacket.class), PUNISH_PLAYER((Class)PunishPlayerPacket.class),
/*    */   
/* 21 */   BROADCAST((Class)BroadcastPacket.class), STAFFLOG((Class)Stafflog.class),
/*    */   
/* 23 */   TELEPORT_TO_TARGET((Class)TeleportToTarget.class),
/*    */   
/* 25 */   STAFFCHAT_DISCORD((Class)StaffchatDiscordPacket.class), STAFFCHAT_BUNGEE((Class)StaffchatBungeePacket.class),
/*    */   
/* 27 */   REPORT_CREATE((Class)ReportCreatePacket.class), REPORT_DELETE((Class)ReportDeletePacket.class),
/* 28 */   REPORT_FIELD((Class)ReportFieldPacket.class),
/*    */   
/* 30 */   ACTION_BAR((Class)ActionBar.class),
/*    */   
/* 32 */   SKIN_CHANGE((Class)SkinChange.class),
/*    */   
/* 34 */   CONFIGURATION_UPDATE((Class)ConfigurationUpdate.class), CONFIGURATION_FIELD_UPDATE((Class)ConfigurationFieldUpdate.class),
/*    */   
/* 36 */   PARTY_CREATE((Class)PartyCreate.class), PARTY_FIELD((Class)PartyField.class), PARTY_DELETE((Class)PartyDelete.class);
/*    */   public Class<? extends Packet> getClassType() {
/* 38 */     return this.classType;
/*    */   }
/*    */   
/*    */   PacketType(Class<? extends Packet> classType) {
/*    */     this.classType = classType;
/*    */   }
/*    */   
/*    */   private Class<? extends Packet> classType;
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/packet/PacketType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */