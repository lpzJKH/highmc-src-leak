/*    */ package net.highmc.packet.types;
/*    */ 
/*    */ import com.google.gson.JsonObject;
/*    */ import java.lang.reflect.Field;
/*    */ import java.util.UUID;
/*    */ import net.highmc.CommonConst;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.packet.Packet;
/*    */ import net.highmc.packet.PacketType;
/*    */ import net.highmc.report.Report;
/*    */ import net.highmc.utils.json.JsonBuilder;
/*    */ import net.highmc.utils.json.JsonUtils;
/*    */ import net.highmc.utils.reflection.Reflection;
/*    */ 
/*    */ 
/*    */ public class ReportFieldPacket
/*    */   extends Packet
/*    */ {
/*    */   private UUID reportId;
/*    */   private JsonObject jsonObject;
/*    */   
/*    */   public ReportFieldPacket(Report report, String fieldName) {
/* 23 */     super(PacketType.REPORT_FIELD);
/* 24 */     JsonObject tree = JsonUtils.jsonTree(report);
/*    */     
/* 26 */     this.reportId = report.getReportId();
/* 27 */     this
/* 28 */       .jsonObject = (new JsonBuilder()).addProperty("fieldName", fieldName).add("value", tree.get(fieldName)).build();
/*    */   }
/*    */ 
/*    */   
/*    */   public void receive() {
/* 33 */     Report report = CommonPlugin.getInstance().getReportManager().getReportById(this.reportId);
/*    */     
/* 35 */     if (report != null)
/*    */       try {
/* 37 */         Field f = Reflection.getField(Report.class, this.jsonObject.get("fieldName").getAsString());
/* 38 */         Object object = CommonConst.GSON.fromJson(this.jsonObject.get("value"), f.getGenericType());
/* 39 */         f.setAccessible(true);
/* 40 */         f.set(report, object);
/* 41 */       } catch (IllegalArgumentException|SecurityException|IllegalAccessException e) {
/* 42 */         e.printStackTrace();
/*    */       }  
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/packet/types/ReportFieldPacket.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */