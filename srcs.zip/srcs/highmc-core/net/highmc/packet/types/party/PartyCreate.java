/*    */ package net.highmc.packet.types.party;
/*    */ 
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import net.highmc.CommonConst;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.member.party.Party;
/*    */ import net.highmc.packet.Packet;
/*    */ import net.highmc.packet.PacketType;
/*    */ 
/*    */ public class PartyCreate extends Packet {
/*    */   private JsonObject jsonObject;
/*    */   
/*    */   public JsonObject getJsonObject() {
/* 15 */     return this.jsonObject;
/*    */   }
/*    */   public PartyCreate(Party party) {
/* 18 */     super(PacketType.PARTY_CREATE);
/* 19 */     this.jsonObject = CommonConst.GSON.toJsonTree(party).getAsJsonObject();
/*    */   }
/*    */ 
/*    */   
/*    */   public void receive() {
/* 24 */     Party party = (Party)CommonConst.GSON.fromJson((JsonElement)this.jsonObject, CommonPlugin.getInstance().getPartyClass());
/*    */     
/* 26 */     if (party != null) {
/* 27 */       CommonPlugin.getInstance().getPartyManager().loadParty(party);
/* 28 */       System.out.println("pacote recebido");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/packet/types/party/PartyCreate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */