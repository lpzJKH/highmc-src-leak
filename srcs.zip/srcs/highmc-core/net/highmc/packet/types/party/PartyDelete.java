/*    */ package net.highmc.packet.types.party;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.member.party.Party;
/*    */ import net.highmc.packet.Packet;
/*    */ import net.highmc.packet.PacketType;
/*    */ 
/*    */ public class PartyDelete
/*    */   extends Packet {
/*    */   private UUID partyId;
/*    */   
/*    */   public UUID getPartyId() {
/* 14 */     return this.partyId;
/*    */   }
/*    */   public PartyDelete(UUID partyId) {
/* 17 */     super(PacketType.PARTY_DELETE);
/* 18 */     this.partyId = partyId;
/*    */   }
/*    */ 
/*    */   
/*    */   public void receive() {
/* 23 */     Party party = CommonPlugin.getInstance().getPartyManager().getPartyById(this.partyId);
/*    */     
/* 25 */     if (party != null)
/* 26 */       CommonPlugin.getInstance().getPartyManager().unloadParty(this.partyId); 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/packet/types/party/PartyDelete.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */