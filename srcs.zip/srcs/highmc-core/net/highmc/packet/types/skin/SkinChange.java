/*    */ package net.highmc.packet.types.skin;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import net.highmc.member.Member;
/*    */ import net.highmc.packet.Packet;
/*    */ import net.highmc.packet.PacketType;
/*    */ import net.highmc.utils.skin.Skin;
/*    */ 
/*    */ public class SkinChange extends Packet {
/*    */   private UUID playerId;
/*    */   private Skin skin;
/*    */   
/*    */   public UUID getPlayerId() {
/* 14 */     return this.playerId; } public Skin getSkin() {
/* 15 */     return this.skin;
/*    */   }
/*    */   public SkinChange(UUID playerId, Skin skin) {
/* 18 */     super(PacketType.SKIN_CHANGE);
/* 19 */     bungeecord();
/* 20 */     this.playerId = playerId;
/* 21 */     this.skin = skin;
/*    */   }
/*    */   
/*    */   public SkinChange(Member member) {
/* 25 */     super(PacketType.SKIN_CHANGE);
/* 26 */     bungeecord();
/* 27 */     this.playerId = member.getUniqueId();
/* 28 */     this.skin = member.getSkin();
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/packet/types/skin/SkinChange.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */