/*    */ package net.highmc.packet.types;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import net.highmc.packet.Packet;
/*    */ import net.highmc.packet.PacketType;
/*    */ 
/*    */ public class ActionBar extends Packet {
/*    */   private UUID uniqueId;
/*    */   private String text;
/*    */   
/*    */   public UUID getUniqueId() {
/* 12 */     return this.uniqueId; } public String getText() {
/* 13 */     return this.text;
/*    */   }
/*    */   public ActionBar(UUID uniqueId, String text) {
/* 16 */     super(PacketType.ACTION_BAR);
/* 17 */     this.uniqueId = uniqueId;
/* 18 */     this.text = text;
/*    */   }
/*    */   
/*    */   public void receive() {}
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/packet/types/ActionBar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */