/*    */ package net.highmc.packet.types;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import net.highmc.packet.Packet;
/*    */ import net.highmc.packet.PacketType;
/*    */ import net.highmc.permission.Group;
/*    */ 
/*    */ public class StaffchatDiscordPacket extends Packet {
/*    */   private UUID playerId;
/*    */   private Group playerGroup;
/*    */   private String message;
/*    */   
/* 13 */   public UUID getPlayerId() { return this.playerId; } public Group getPlayerGroup() {
/* 14 */     return this.playerGroup;
/*    */   } public String getMessage() {
/* 16 */     return this.message;
/*    */   }
/*    */   public StaffchatDiscordPacket(UUID playerId, Group playerGroup, String message) {
/* 19 */     super(PacketType.STAFFCHAT_DISCORD);
/* 20 */     this.playerId = playerId;
/* 21 */     this.playerGroup = playerGroup;
/* 22 */     this.message = message;
/* 23 */     discord();
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/packet/types/StaffchatDiscordPacket.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */