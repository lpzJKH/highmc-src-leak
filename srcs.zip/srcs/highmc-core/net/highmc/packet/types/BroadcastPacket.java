/*    */ package net.highmc.packet.types;
/*    */ 
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.member.Member;
/*    */ import net.highmc.packet.Packet;
/*    */ import net.md_5.bungee.api.chat.BaseComponent;
/*    */ import net.md_5.bungee.api.chat.TextComponent;
/*    */ 
/*    */ public class BroadcastPacket extends Packet {
/*    */   private String permission;
/*    */   
/* 12 */   public String getPermission() { return this.permission; } private boolean staff; private TextComponent[] components; public boolean isStaff() {
/* 13 */     return this.staff; } public TextComponent[] getComponents() {
/* 14 */     return this.components;
/*    */   }
/*    */   public BroadcastPacket(String permission, boolean staff, TextComponent... components) {
/* 17 */     super(PacketType.BROADCAST);
/* 18 */     this.permission = permission;
/* 19 */     this.staff = staff;
/* 20 */     this.components = components;
/*    */   }
/*    */   
/*    */   public BroadcastPacket(String permission, boolean staff, String string) {
/* 24 */     this(permission, staff, new TextComponent[] { new TextComponent(string) });
/*    */   }
/*    */ 
/*    */   
/*    */   public void receive() {
/* 29 */     CommonPlugin.getInstance().getMemberManager().getMembers().stream()
/* 30 */       .filter(member -> this.staff ? member.hasPermission(this.permission) : member.isStaff())
/* 31 */       .forEach(member -> member.sendMessage((BaseComponent[])this.components));
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/packet/types/BroadcastPacket.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */