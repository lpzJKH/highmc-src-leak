/*    */ package net.highmc.packet.types;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.PluginInfo;
/*    */ import net.highmc.command.CommandSender;
/*    */ import net.highmc.member.Member;
/*    */ import net.highmc.packet.Packet;
/*    */ import net.highmc.packet.PacketType;
/*    */ import net.highmc.punish.Punish;
/*    */ import net.highmc.punish.PunishType;
/*    */ import net.highmc.utils.DateUtils;
/*    */ import net.md_5.bungee.api.ProxyServer;
/*    */ import net.md_5.bungee.api.connection.ProxiedPlayer;
/*    */ 
/*    */ public class PunishPlayerPacket
/*    */   extends Packet
/*    */ {
/*    */   private UUID playerId;
/*    */   private Punish punish;
/*    */   
/*    */   public PunishPlayerPacket(UUID playerId, Punish punish) {
/* 23 */     super(PacketType.PUNISH_PLAYER);
/* 24 */     bungeecord();
/* 25 */     this.playerId = playerId;
/* 26 */     this.punish = punish;
/*    */   }
/*    */ 
/*    */   
/*    */   public void receive() {
/* 31 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(this.playerId);
/*    */     
/* 33 */     if (member == null) {
/* 34 */       member = CommonPlugin.getInstance().getMemberData().loadMember(this.playerId);
/*    */       
/* 36 */       if (member == null) {
/* 37 */         CommonPlugin.getInstance().debug("Could not find member with UUID " + this.playerId.toString());
/*    */         
/*    */         return;
/*    */       } 
/*    */     } 
/* 42 */     member.getPunishConfiguration().punish(this.punish);
/* 43 */     member.saveConfig();
/*    */     
/* 45 */     ProxiedPlayer player = ProxyServer.getInstance().getPlayer(this.playerId);
/*    */     
/* 47 */     if (player != null && this.punish.getPunishType() == PunishType.BAN)
/* 48 */       player.disconnect(PluginInfo.t((CommandSender)member, "ban-" + (
/* 49 */             this.punish.isPermanent() ? "permanent" : "temporary") + "-kick-message", new String[] { "%reason%", this.punish
/* 50 */               .getPunishReason(), "%expireAt%", 
/* 51 */               DateUtils.getTime(member.getLanguage(), this.punish.getExpireAt()), "%punisher%", this.punish
/* 52 */               .getPunisherName(), "%website%", CommonPlugin.getInstance().getPluginInfo().getWebsite(), "%store%", 
/* 53 */               CommonPlugin.getInstance().getPluginInfo().getStore(), "%discord%", 
/* 54 */               CommonPlugin.getInstance().getPluginInfo().getDiscord() })); 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/packet/types/PunishPlayerPacket.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */