/*    */ package net.highmc.packet.types.configuration;
/*    */ 
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import net.highmc.CommonConst;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.PluginInfo;
/*    */ import net.highmc.packet.Packet;
/*    */ import net.highmc.packet.PacketType;
/*    */ 
/*    */ public class ConfigurationUpdate
/*    */   extends Packet {
/*    */   private JsonObject jsonObject;
/*    */   
/*    */   public ConfigurationUpdate() {
/* 16 */     super(PacketType.CONFIGURATION_UPDATE);
/* 17 */     this.jsonObject = CommonConst.GSON.toJsonTree(CommonPlugin.getInstance().getPluginInfo()).getAsJsonObject();
/*    */   }
/*    */ 
/*    */   
/*    */   public void receive() {
/* 22 */     CommonPlugin.getInstance().setPluginInfo((PluginInfo)CommonConst.GSON.fromJson((JsonElement)this.jsonObject, PluginInfo.class));
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/packet/types/configuration/ConfigurationUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */