/*    */ package net.highmc.packet.types;
/*    */ 
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.packet.Packet;
/*    */ import net.highmc.packet.PacketType;
/*    */ import net.highmc.report.Report;
/*    */ 
/*    */ public class ReportCreatePacket
/*    */   extends Packet {
/*    */   private Report report;
/*    */   
/*    */   public ReportCreatePacket(Report report) {
/* 13 */     super(PacketType.REPORT_CREATE);
/* 14 */     this.report = report;
/*    */   }
/*    */ 
/*    */   
/*    */   public void receive() {
/* 19 */     CommonPlugin.getInstance().getReportManager().loadReport(this.report);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/packet/types/ReportCreatePacket.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */