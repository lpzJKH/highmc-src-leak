/*    */ package net.highmc.packet.types;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.member.Member;
/*    */ import net.highmc.packet.Packet;
/*    */ import net.highmc.packet.PacketType;
/*    */ import net.md_5.bungee.api.chat.BaseComponent;
/*    */ import net.md_5.bungee.api.chat.TextComponent;
/*    */ 
/*    */ public class PlayerMessagePacket extends Packet {
/*    */   private UUID uniqueId;
/*    */   private TextComponent[] components;
/*    */   
/* 15 */   public UUID getUniqueId() { return this.uniqueId; } public TextComponent[] getComponents() {
/* 16 */     return this.components;
/*    */   }
/*    */   public PlayerMessagePacket(UUID uniqueId, TextComponent... components) {
/* 19 */     super(PacketType.PLAYER_MESSAGE);
/* 20 */     this.uniqueId = uniqueId;
/* 21 */     this.components = components;
/*    */   }
/*    */   
/*    */   public PlayerMessagePacket(UUID uniqueId, String message) {
/* 25 */     this(uniqueId, new TextComponent[] { new TextComponent(message) });
/*    */   }
/*    */ 
/*    */   
/*    */   public void receive() {
/* 30 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(this.uniqueId);
/*    */     
/* 32 */     if (member != null)
/* 33 */       member.sendMessage((BaseComponent[])this.components); 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/packet/types/PlayerMessagePacket.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */