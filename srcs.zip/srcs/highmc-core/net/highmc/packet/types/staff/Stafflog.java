/*    */ package net.highmc.packet.types.staff;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.member.Member;
/*    */ import net.highmc.packet.Packet;
/*    */ import net.highmc.packet.PacketType;
/*    */ import net.highmc.utils.string.MessageBuilder;
/*    */ import net.md_5.bungee.api.chat.BaseComponent;
/*    */ import net.md_5.bungee.api.chat.TextComponent;
/*    */ 
/*    */ public class Stafflog extends Packet {
/*    */   private String message;
/*    */   private String hoverMessage;
/*    */   private String clickMessage;
/*    */   private boolean anticheat;
/*    */   
/*    */   public Stafflog(String message) {
/* 19 */     super(PacketType.STAFFLOG);
/* 20 */     bungeecord();
/* 21 */     this.message = message;
/* 22 */     this.hoverMessage = "";
/* 23 */     this.clickMessage = "";
/*    */   }
/*    */   
/*    */   public Stafflog anticheat() {
/* 27 */     this.anticheat = !this.anticheat;
/* 28 */     return this;
/*    */   }
/*    */   
/*    */   public Stafflog(TextComponent textComponent) {
/* 32 */     super(PacketType.STAFFLOG);
/* 33 */     bungeecord();
/* 34 */     this.message = textComponent.toLegacyText();
/*    */     
/* 36 */     if (textComponent.getHoverEvent() != null && textComponent.getHoverEvent().getValue() != null) {
/* 37 */       this.hoverMessage = Arrays.<BaseComponent>stream(textComponent.getHoverEvent().getValue()).map(xva$0 -> TextComponent.toLegacyText(new BaseComponent[] { xva$0 })).reduce("", (a, b) -> a + b);
/*    */     } else {
/* 39 */       this.hoverMessage = "";
/*    */     } 
/* 41 */     if (textComponent.getClickEvent() != null && textComponent.getClickEvent().getValue() != null) {
/* 42 */       this.clickMessage = textComponent.getClickEvent().getValue();
/*    */     } else {
/* 44 */       this.clickMessage = "";
/*    */     } 
/*    */   }
/*    */   
/*    */   public void receive() {
/* 49 */     if (this.anticheat) {
/* 50 */       CommonPlugin.getInstance().getMemberManager().getMembers().stream()
/* 51 */         .filter(member -> (member.isStaff() && member.getMemberConfiguration().isAnticheatImportant()))
/* 52 */         .forEach(member -> member.sendMessage((BaseComponent)(new MessageBuilder(this.message)).setHoverEvent(this.hoverMessage).setClickEvent(this.clickMessage).create()));
/*    */     } else {
/* 54 */       CommonPlugin.getInstance().getMemberManager().staffLog((new MessageBuilder(this.message)).setHoverEvent(this.hoverMessage).setClickEvent(this.clickMessage).create());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/packet/types/staff/Stafflog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */