/*    */ package net.highmc.packet.types.staff;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import net.highmc.packet.Packet;
/*    */ import net.highmc.packet.PacketType;
/*    */ 
/*    */ public class TeleportToTarget extends Packet {
/*    */   private UUID playerId;
/*    */   private UUID targetId;
/*    */   private String targetName;
/*    */   
/* 12 */   public UUID getPlayerId() { return this.playerId; }
/* 13 */   public UUID getTargetId() { return this.targetId; } public String getTargetName() {
/* 14 */     return this.targetName;
/*    */   }
/*    */   public TeleportToTarget(UUID playerId, UUID targetId, String targetName) {
/* 17 */     super(PacketType.TELEPORT_TO_TARGET);
/* 18 */     bungeecord();
/* 19 */     this.playerId = playerId;
/* 20 */     this.targetId = targetId;
/* 21 */     this.targetName = targetName;
/*    */   }
/*    */ 
/*    */   
/*    */   public void receive() {
/* 26 */     System.out.println(12312);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/packet/types/staff/TeleportToTarget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */