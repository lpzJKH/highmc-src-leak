/*    */ package net.highmc.packet.types;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.member.Member;
/*    */ import net.highmc.packet.Packet;
/*    */ import net.highmc.packet.PacketType;
/*    */ import net.md_5.bungee.api.ChatColor;
/*    */ 
/*    */ public class StaffchatBungeePacket extends Packet {
/*    */   private UUID playerId;
/*    */   private String nickname;
/*    */   private String message;
/*    */   
/* 15 */   public UUID getPlayerId() { return this.playerId; } public String getNickname() {
/* 16 */     return this.nickname;
/*    */   } public String getMessage() {
/* 18 */     return this.message;
/*    */   }
/*    */   public StaffchatBungeePacket(UUID playerId, String nickname, String message) {
/* 21 */     super(PacketType.STAFFCHAT_BUNGEE);
/* 22 */     this.playerId = playerId;
/* 23 */     this.nickname = nickname;
/* 24 */     this.message = message;
/* 25 */     bungeecord();
/*    */   }
/*    */   
/*    */   public void receive() {
/*    */     String staffMessage;
/* 30 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(this.playerId);
/*    */ 
/*    */     
/* 33 */     if (member == null) {
/*    */       
/* 35 */       staffMessage = "§7[StaffChat] " + this.nickname + "§7: §f" + ChatColor.translateAlternateColorCodes('&', this.message);
/*    */     
/*    */     }
/*    */     else {
/*    */       
/* 40 */       staffMessage = "§3*§7[StaffChat] " + CommonPlugin.getInstance().getPluginInfo().getTagByGroup(member.getServerGroup()).getStrippedColor() + " " + member.getPlayerName() + "§7: §f" + ChatColor.translateAlternateColorCodes('&', this.message);
/*    */     } 
/* 42 */     CommonPlugin.getInstance().getMemberManager().getMembers().stream().filter(Member::isStaff)
/* 43 */       .forEach(m -> m.sendMessage(staffMessage));
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/packet/types/StaffchatBungeePacket.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */