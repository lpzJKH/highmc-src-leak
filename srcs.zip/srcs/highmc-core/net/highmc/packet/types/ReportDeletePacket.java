/*    */ package net.highmc.packet.types;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.packet.Packet;
/*    */ import net.highmc.packet.PacketType;
/*    */ 
/*    */ public class ReportDeletePacket
/*    */   extends Packet
/*    */ {
/*    */   private UUID reportId;
/*    */   
/*    */   public ReportDeletePacket(UUID reportId) {
/* 14 */     super(PacketType.REPORT_DELETE);
/* 15 */     this.reportId = reportId;
/*    */   }
/*    */ 
/*    */   
/*    */   public void receive() {
/* 20 */     CommonPlugin.getInstance().getReportManager().deleteReport(this.reportId);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/packet/types/ReportDeletePacket.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */