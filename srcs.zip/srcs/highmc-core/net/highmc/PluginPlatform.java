package net.highmc;

import java.util.UUID;
import java.util.logging.Logger;

public interface PluginPlatform {
  UUID getUniqueId(String paramString);
  
  String getName(UUID paramUUID);
  
  void runAsync(Runnable paramRunnable);
  
  void runAsync(Runnable paramRunnable, long paramLong);
  
  void runAsync(Runnable paramRunnable, long paramLong1, long paramLong2);
  
  void run(Runnable paramRunnable, long paramLong);
  
  void run(Runnable paramRunnable, long paramLong1, long paramLong2);
  
  void shutdown(String paramString);
  
  Logger getLogger();
  
  void dispatchCommand(String paramString);
  
  void broadcast(String paramString);
  
  void broadcast(String paramString1, String paramString2);
}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/PluginPlatform.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */