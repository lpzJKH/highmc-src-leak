/*     */ package net.highmc.punish;
/*     */ import java.util.UUID;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.backend.mongodb.MongoQuery;
/*     */ import net.highmc.command.CommandSender;
/*     */ import net.highmc.language.Language;
/*     */ 
/*     */ public class Punish {
/*     */   private final String id;
/*     */   private final UUID playerId;
/*     */   private String playerName;
/*     */   private UUID punisherId;
/*     */   private String punisherName;
/*     */   private String punishReason;
/*     */   
/*     */   public String getId() {
/*  17 */     return this.id;
/*     */   } private long createdAt; private long expireAt; private boolean unpunished; private UUID unpunisherId; private String unpunisherName; private PunishType punishType; public UUID getPlayerId() {
/*  19 */     return this.playerId; } public String getPlayerName() {
/*  20 */     return this.playerName;
/*     */   }
/*  22 */   public UUID getPunisherId() { return this.punisherId; } public String getPunisherName() {
/*  23 */     return this.punisherName;
/*     */   } public String getPunishReason() {
/*  25 */     return this.punishReason;
/*     */   }
/*  27 */   public long getCreatedAt() { return this.createdAt; } public long getExpireAt() {
/*  28 */     return this.expireAt;
/*     */   }
/*  30 */   public boolean isUnpunished() { return this.unpunished; }
/*  31 */   public UUID getUnpunisherId() { return this.unpunisherId; } public String getUnpunisherName() {
/*  32 */     return this.unpunisherName;
/*     */   } public PunishType getPunishType() {
/*  34 */     return this.punishType;
/*     */   }
/*     */   
/*     */   public Punish(UUID playerId, String playerName, UUID punisherId, String punisherName, String punishReason, long expireAt, PunishType punishType) {
/*  38 */     this.id = "#" + randomId(punishType);
/*     */     
/*  40 */     this.playerId = playerId;
/*  41 */     this.playerName = playerName;
/*     */     
/*  43 */     this.punisherId = punisherId;
/*  44 */     this.punisherName = punisherName;
/*     */     
/*  46 */     this.punishReason = punishReason;
/*     */     
/*  48 */     this.createdAt = System.currentTimeMillis();
/*  49 */     this.expireAt = expireAt;
/*     */     
/*  51 */     this.punishType = punishType;
/*     */   }
/*     */ 
/*     */   
/*     */   public Punish(CommandSender punished, CommandSender punisher, String punishReason, long expireAt, PunishType punishType) {
/*  56 */     this(punished.getUniqueId(), punished.getSenderName(), punisher.getUniqueId(), punisher.getName(), punishReason, expireAt, punishType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Punish(CommandSender punished, UUID punisherId, String punisherName, String punishReason, long expireAt, PunishType punishType) {
/*  62 */     this(punished.getUniqueId(), punished.getSenderName(), punisherId, punisherName, punishReason, expireAt, punishType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Punish(UUID playerId, String playerName, CommandSender punisher, String punishReason, PunishType punishType) {
/*  68 */     this(playerId, playerName, punisher.getUniqueId(), punisher.getName(), punishReason, -1L, punishType);
/*     */   }
/*     */   
/*     */   public boolean unpunish(UUID unpunisherId, String unpunisherName) {
/*  72 */     if (isUnpunished()) {
/*  73 */       return false;
/*     */     }
/*  75 */     this.unpunished = true;
/*  76 */     this.unpunisherId = unpunisherId;
/*  77 */     this.unpunisherName = unpunisherName;
/*  78 */     return true;
/*     */   }
/*     */   
/*     */   public boolean unpunish(CommandSender sender) {
/*  82 */     return unpunish(sender.getUniqueId(), sender.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasExpired() {
/*  93 */     return (!isPermanent() && this.expireAt < System.currentTimeMillis());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPermanent() {
/* 104 */     return (this.expireAt == -1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getExpireTime() {
/* 115 */     return isPermanent() ? -1L : (this.expireAt - this.createdAt);
/*     */   }
/*     */   
/*     */   public String getMuteMessage(Language language) {
/* 119 */     return language.t("mute-message", new String[] { "%reason%", getPunishReason(), "%expireAt%", 
/* 120 */           DateUtils.getTime(language, getExpireAt()), "%punisher%", getPunisherName(), "%website%", 
/* 121 */           CommonPlugin.getInstance().getPluginInfo().getWebsite(), "%store%", 
/* 122 */           CommonPlugin.getInstance().getPluginInfo().getStore(), "%discord%", 
/* 123 */           CommonPlugin.getInstance().getPluginInfo().getDiscord() });
/*     */   }
/*     */ 
/*     */   
/*     */   public static String randomId(PunishType punishType) {
/*     */     String id;
/*     */     do {
/* 130 */       id = CodeCreator.DEFAULT_CREATOR.random(6);
/* 131 */     } while (((MongoQuery)CommonPlugin.getInstance().getMemberData().getQuery()).getCollection()
/* 132 */       .find(Filters.eq("punishConfiguration.punishMap." + punishType.name() + ".id", id)) == null);
/*     */     
/* 134 */     return id;
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/punish/Punish.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */