/*    */ package net.highmc.punish;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum PunishType
/*    */ {
/* 10 */   BAN("banido"), MUTE("mutado"), KICK("kickado");
/*    */   public String getDescriminator() {
/* 12 */     return this.descriminator;
/*    */   }
/*    */   
/*    */   private String descriminator;
/*    */   
/*    */   PunishType(String descriminator) {
/*    */     this.descriminator = descriminator;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/punish/PunishType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */