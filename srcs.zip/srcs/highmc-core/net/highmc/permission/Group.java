/*    */ package net.highmc.permission;
/*    */ 
/*    */ 
/*    */ public class Group {
/*    */   private int id;
/*    */   private String groupName;
/*    */   private List<String> permissions;
/*    */   private boolean defaultGroup;
/*    */   private boolean staff;
/*    */   
/* 11 */   public void setId(int id) { this.id = id; } public void setGroupName(String groupName) { this.groupName = groupName; } public void setPermissions(List<String> permissions) { this.permissions = permissions; } public void setDefaultGroup(boolean defaultGroup) { this.defaultGroup = defaultGroup; } public void setStaff(boolean staff) { this.staff = staff; } public Group(int id, String groupName, List<String> permissions, boolean defaultGroup, boolean staff) {
/* 12 */     this.id = id; this.groupName = groupName; this.permissions = permissions; this.defaultGroup = defaultGroup; this.staff = staff;
/*    */   }
/*    */   
/* 15 */   public int getId() { return this.id; } public String getGroupName() {
/* 16 */     return this.groupName;
/*    */   } public List<String> getPermissions() {
/* 18 */     return this.permissions;
/*    */   }
/* 20 */   public boolean isDefaultGroup() { return this.defaultGroup; } public boolean isStaff() {
/* 21 */     return this.staff;
/*    */   }
/*    */   public String getRealPrefix() {
/* 24 */     return CommonPlugin.getInstance().getPluginInfo().getTagByGroup(this).getRealPrefix();
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/permission/Group.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */