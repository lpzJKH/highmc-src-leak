/*    */ package net.highmc.permission;
/*    */ 
/*    */ import java.util.UUID;
/*    */ 
/*    */ public class GroupInfo {
/*    */   private String authorName;
/*    */   private UUID authorId;
/*    */   private long givenDate;
/*    */   private long expireTime;
/*    */   
/* 11 */   public String getAuthorName() { return this.authorName; } public UUID getAuthorId() {
/* 12 */     return this.authorId;
/*    */   }
/* 14 */   public long getGivenDate() { return this.givenDate; } public long getExpireTime() {
/* 15 */     return this.expireTime;
/*    */   }
/*    */   public GroupInfo() {
/* 18 */     this("CONSOLE", UUID.randomUUID(), System.currentTimeMillis(), -1L);
/*    */   }
/*    */   
/*    */   public GroupInfo(String authorName, UUID authorId) {
/* 22 */     this(authorName, authorId, System.currentTimeMillis(), -1L);
/*    */   }
/*    */   
/*    */   public GroupInfo(CommandSender sender) {
/* 26 */     this(sender.getName(), sender.getUniqueId(), System.currentTimeMillis(), -1L);
/*    */   }
/*    */   
/*    */   public GroupInfo(CommandSender sender, long expireTime) {
/* 30 */     this(sender.getName(), sender.getUniqueId(), System.currentTimeMillis(), expireTime);
/*    */   }
/*    */   
/*    */   public GroupInfo(String authorName, long expireTime) {
/* 34 */     this(authorName, UUID.randomUUID(), System.currentTimeMillis(), expireTime);
/*    */   }
/*    */   
/*    */   public GroupInfo(String authorName, UUID authorId, long expireTime) {
/* 38 */     this(authorName, authorId, System.currentTimeMillis(), expireTime);
/*    */   }
/*    */   
/*    */   public GroupInfo(String authorName, UUID authorId, long givenDate, long expireTime) {
/* 42 */     this.authorName = authorName;
/* 43 */     this.authorId = authorId;
/*    */     
/* 45 */     this.givenDate = givenDate;
/* 46 */     this.expireTime = expireTime;
/*    */   }
/*    */   
/*    */   public boolean hasExpired() {
/* 50 */     return (System.currentTimeMillis() > this.expireTime);
/*    */   }
/*    */   
/*    */   public boolean isPermanent() {
/* 54 */     return (this.expireTime <= 0L);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/permission/GroupInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */