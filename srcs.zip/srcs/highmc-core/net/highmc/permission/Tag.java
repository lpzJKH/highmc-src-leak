/*    */ package net.highmc.permission;
/*    */ import java.util.List;
/*    */ import net.md_5.bungee.api.ChatColor;
/*    */ 
/*    */ public class Tag {
/*    */   private int tagId;
/*    */   private String tagName;
/*    */   private String tagPrefix;
/*    */   
/*    */   public Tag(int tagId, String tagName, String tagPrefix, List<String> aliases, boolean exclusive, boolean defaultTag) {
/* 11 */     this.tagId = tagId; this.tagName = tagName; this.tagPrefix = tagPrefix; this.aliases = aliases; this.exclusive = exclusive; this.defaultTag = defaultTag;
/*    */   } private List<String> aliases; private boolean exclusive; private boolean defaultTag; public void setTagId(int tagId) {
/* 13 */     this.tagId = tagId; } public void setTagName(String tagName) { this.tagName = tagName; } public void setTagPrefix(String tagPrefix) { this.tagPrefix = tagPrefix; } public void setAliases(List<String> aliases) { this.aliases = aliases; } public void setExclusive(boolean exclusive) { this.exclusive = exclusive; } public void setDefaultTag(boolean defaultTag) { this.defaultTag = defaultTag; }
/*    */   
/*    */   public int getTagId() {
/* 16 */     return this.tagId;
/*    */   }
/* 18 */   public String getTagName() { return this.tagName; } public String getTagPrefix() {
/* 19 */     return this.tagPrefix;
/*    */   }
/* 21 */   public List<String> getAliases() { return this.aliases; } public boolean isExclusive() {
/* 22 */     return this.exclusive;
/*    */   } public boolean isDefaultTag() {
/* 24 */     return this.defaultTag;
/*    */   }
/*    */   public String getRealPrefix() {
/* 27 */     return this.tagPrefix + ((ChatColor.stripColor(this.tagPrefix).trim().length() > 0) ? " " : "");
/*    */   }
/*    */   
/*    */   public String getStrippedColor() {
/* 31 */     if (this.tagPrefix.length() > 2) {
/* 32 */       return this.tagPrefix;
/*    */     }
/* 34 */     return this.tagPrefix + StringFormat.formatString(this.tagName) + "";
/*    */   }
/*    */   
/*    */   public String getColor() {
/* 38 */     return (this.tagPrefix.length() > 2) ? this.tagPrefix.substring(0, 2) : this.tagPrefix;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/permission/Tag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */