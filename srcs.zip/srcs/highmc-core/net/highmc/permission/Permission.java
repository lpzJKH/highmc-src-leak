/*   */ package net.highmc.permission;
/*   */ 
/*   */ public class Permission
/*   */ {
/*   */   private String permission;
/*   */   
/*   */   public String getPermission() {
/* 8 */     return this.permission;
/*   */   }
/*   */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/permission/Permission.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */