/*    */ package net.highmc.member;
/*    */ import java.util.UUID;
/*    */ import net.highmc.command.CommandSender;
/*    */ 
/*    */ public class Profile {
/*    */   private final UUID uniqueId;
/*    */   
/*    */   public Profile(UUID uniqueId, String playerName, long createdAt) {
/*  9 */     this.uniqueId = uniqueId; this.playerName = playerName; this.createdAt = createdAt;
/*    */   }
/*    */   private final String playerName; private final long createdAt;
/*    */   public UUID getUniqueId() {
/* 13 */     return this.uniqueId;
/* 14 */   } public String getPlayerName() { return this.playerName; } public long getCreatedAt() {
/* 15 */     return this.createdAt;
/*    */   }
/*    */   public Profile(UUID uniqueId, String playerName) {
/* 18 */     this(uniqueId, playerName, System.currentTimeMillis());
/*    */   }
/*    */   
/*    */   public Profile(CommandSender member) {
/* 22 */     this(member.getUniqueId(), member.getName(), System.currentTimeMillis());
/*    */   }
/*    */   
/*    */   public static Profile from(CommandSender sender) {
/* 26 */     return new Profile(sender);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 31 */     if (obj instanceof Profile) {
/* 32 */       Profile profile = (Profile)obj;
/*    */       
/* 34 */       return (profile.getUniqueId().equals(this.uniqueId) || profile.getPlayerName().equals(this.playerName));
/* 35 */     }  if (obj instanceof UUID) {
/* 36 */       UUID uuid = (UUID)obj;
/*    */       
/* 38 */       return uuid.equals(this.uniqueId);
/* 39 */     }  if (obj instanceof String) {
/* 40 */       String string = (String)obj;
/* 41 */       return string.equals(this.playerName);
/*    */     } 
/*    */     
/* 44 */     return super.equals(obj);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/member/Profile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */