/*     */ package net.highmc.member.configuration;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Base64;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import net.highmc.member.Member;
/*     */ 
/*     */ public class LoginConfiguration {
/*     */   private transient Member member;
/*     */   private AccountType accountType;
/*     */   private String password;
/*     */   private boolean logged;
/*     */   
/*     */   public Member getMember() {
/*  16 */     return this.member;
/*     */   } private boolean captcha; private Map<String, Long> sessionMap; private Map<String, Long> timeoutMap; private Map<String, Integer> attempsMap; public AccountType getAccountType() {
/*  18 */     return this.accountType;
/*     */   } public String getPassword() {
/*  20 */     return this.password;
/*     */   } public boolean isCaptcha() {
/*  22 */     return this.captcha;
/*     */   } public Map<String, Long> getSessionMap() {
/*  24 */     return this.sessionMap;
/*     */   }
/*  26 */   public Map<String, Long> getTimeoutMap() { return this.timeoutMap; } public Map<String, Integer> getAttempsMap() {
/*  27 */     return this.attempsMap;
/*     */   }
/*     */   public LoginConfiguration(Member member, AccountType accountType) {
/*  30 */     this.member = member;
/*     */     
/*  32 */     this.accountType = accountType;
/*     */     
/*  34 */     this.password = "";
/*  35 */     this.logged = false;
/*     */     
/*  37 */     this.sessionMap = new HashMap<>();
/*  38 */     this.timeoutMap = new HashMap<>();
/*  39 */     this.attempsMap = new HashMap<>();
/*     */   }
/*     */   
/*     */   public LoginConfiguration(Member member) {
/*  43 */     this(member, AccountType.PREMIUM);
/*     */   }
/*     */   
/*     */   public void setCaptcha(boolean captcha) {
/*  47 */     this.captcha = captcha;
/*  48 */     save();
/*     */   }
/*     */   
/*     */   public boolean isLogged() {
/*  52 */     return (this.accountType == AccountType.PREMIUM) ? true : this.logged;
/*     */   }
/*     */   
/*     */   public boolean reloadSession() {
/*  56 */     if (this.member.getIpAddress() != null && this.sessionMap.containsKey(this.member.getIpAddress())) {
/*  57 */       if (((Long)this.sessionMap.get(this.member.getIpAddress())).longValue() > System.currentTimeMillis()) {
/*  58 */         this.logged = true;
/*  59 */         this.member.sendMessage(this.member.getLanguage().t("login.message.session-restored", new String[0]));
/*  60 */         this.member.sendTitle(this.member.getLanguage().t("login.title.session-restored", new String[0]), this.member
/*  61 */             .getLanguage().t("login.subtitle.session-restored", new String[0]), 10, 40, 10);
/*  62 */         save();
/*  63 */         return true;
/*     */       } 
/*     */       
/*  66 */       this.logged = false;
/*  67 */       this.member.sendMessage(this.member.getLanguage().t("login.message.session-expired", new String[0]));
/*  68 */       this.sessionMap.remove(this.member.getIpAddress());
/*  69 */       save();
/*     */     } 
/*     */     
/*  72 */     return false;
/*     */   }
/*     */   
/*     */   public void startSession() {
/*  76 */     if (this.member.getIpAddress() != null) {
/*  77 */       this.sessionMap.put(this.member.getIpAddress(), Long.valueOf(System.currentTimeMillis() + 604800000L));
/*  78 */       this.member.sendMessage(this.member.getLanguage().t("login.message.session-created", new String[0]));
/*  79 */       save();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void stopSession() {
/*  84 */     if (this.member.getIpAddress() != null && this.sessionMap.containsKey(this.member.getIpAddress())) {
/*  85 */       this.sessionMap.remove(this.member.getIpAddress());
/*  86 */       this.member.sendMessage(this.member.getLanguage().t("login.message.session-stopped", new String[0]));
/*  87 */       save();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void logIn() {
/*  92 */     if (this.member.getIpAddress() != null) {
/*  93 */       this.timeoutMap.remove(this.member.getIpAddress());
/*  94 */       this.attempsMap.remove(this.member.getIpAddress());
/*     */     } 
/*     */     
/*  97 */     this.logged = true;
/*  98 */     save();
/*     */   }
/*     */   
/*     */   public void logOut() {
/* 102 */     this.logged = false;
/* 103 */     save();
/*     */   }
/*     */   
/*     */   public void register(String password) {
/* 107 */     this.password = encode(password);
/* 108 */     logIn();
/* 109 */     save();
/*     */   }
/*     */   
/*     */   public boolean isTimeouted() {
/* 113 */     return (this.member.getIpAddress() != null) ? ((this.timeoutMap.containsKey(this.member.getIpAddress()) && ((Long)this.timeoutMap
/* 114 */       .get(this.member.getIpAddress())).longValue() > System.currentTimeMillis())) : false;
/*     */   }
/*     */   
/*     */   public long getTimeoutTime() {
/* 118 */     if (this.member.getIpAddress() != null) {
/* 119 */       return ((Long)this.timeoutMap.get(this.member.getIpAddress())).longValue();
/*     */     }
/*     */     
/* 122 */     return 0L;
/*     */   }
/*     */   
/*     */   public Integer attemp() {
/* 126 */     if (this.member.getIpAddress() != null) {
/* 127 */       Integer integer = this.attempsMap.computeIfAbsent(this.member.getIpAddress(), v -> Integer.valueOf(0));
/* 128 */       this.attempsMap.put(this.member.getIpAddress(), integer = Integer.valueOf(integer.intValue() + 1));
/*     */       
/* 130 */       if (integer.intValue() >= 5) {
/* 131 */         this.attempsMap.remove(this.member.getIpAddress());
/* 132 */         this.timeoutMap.put(this.member.getIpAddress(), Long.valueOf(System.currentTimeMillis() + 900000L));
/*     */       } 
/*     */       
/* 135 */       save();
/* 136 */       return integer;
/*     */     } 
/*     */     
/* 139 */     return Integer.valueOf(0);
/*     */   }
/*     */   
/*     */   public boolean isPassword(String string) {
/* 143 */     return isRegistered() ? decode(this.password).equals(string) : false;
/*     */   }
/*     */   
/*     */   public boolean isRegistered() {
/* 147 */     return (this.password != null && !this.password.isEmpty());
/*     */   }
/*     */   
/*     */   public void loadConfiguration(Member member) {
/* 151 */     this.member = member;
/*     */     
/* 153 */     Iterator<Map.Entry<String, Long>> iterator = this.timeoutMap.entrySet().iterator();
/* 154 */     boolean save = false;
/*     */     
/* 156 */     while (iterator.hasNext()) {
/* 157 */       Map.Entry<String, Long> next = iterator.next();
/*     */       
/* 159 */       if (((Long)next.getValue()).longValue() < System.currentTimeMillis()) {
/* 160 */         iterator.remove();
/* 161 */         save = true;
/*     */       } 
/*     */     } 
/*     */     
/* 165 */     if (save)
/* 166 */       save(); 
/*     */   }
/*     */   
/*     */   public void setAccountType(AccountType accountType) {
/* 170 */     if (this.accountType == AccountType.NONE) {
/* 171 */       this.accountType = accountType;
/*     */     }
/*     */   }
/*     */   
/*     */   public void save() {
/* 176 */     if (this.member != null)
/* 177 */       this.member.save(new String[] { "loginConfiguration" }); 
/*     */   }
/*     */   
/*     */   public static String encode(String paramString) {
/* 181 */     byte[] encode = Base64.getEncoder().encode(paramString.getBytes());
/* 182 */     return new String(encode, Charset.forName("UTF-8"));
/*     */   }
/*     */   
/*     */   public static String decode(String paramString) {
/* 186 */     byte[] decode = Base64.getDecoder().decode(paramString.getBytes());
/* 187 */     return new String(decode, Charset.forName("UTF-8"));
/*     */   }
/*     */   
/*     */   public enum AccountType
/*     */   {
/* 192 */     PREMIUM, CRACKED, NONE;
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/member/configuration/LoginConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */