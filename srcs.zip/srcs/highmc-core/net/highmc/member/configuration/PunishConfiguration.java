/*    */ package net.highmc.member.configuration;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import java.util.stream.Collectors;
/*    */ import net.highmc.command.CommandSender;
/*    */ import net.highmc.member.Member;
/*    */ import net.highmc.punish.Punish;
/*    */ import net.highmc.punish.PunishType;
/*    */ 
/*    */ public class PunishConfiguration {
/*    */   private transient Member member;
/*    */   private Map<PunishType, List<Punish>> punishMap;
/*    */   
/*    */   public Member getMember() {
/* 20 */     return this.member;
/*    */   } public Map<PunishType, List<Punish>> getPunishMap() {
/* 22 */     return this.punishMap;
/*    */   }
/*    */   public PunishConfiguration(Member member) {
/* 25 */     this.member = member;
/* 26 */     this.punishMap = new HashMap<>();
/*    */   }
/*    */   
/*    */   public Punish getActualPunish(PunishType punishType) {
/* 30 */     return ((List<Punish>)this.punishMap.computeIfAbsent(punishType, v -> new ArrayList())).stream()
/* 31 */       .filter(punish -> (!punish.isUnpunished() && !punish.hasExpired())).findFirst().orElse(null);
/*    */   }
/*    */   
/*    */   public Punish getPunishById(String id, PunishType punishType) {
/* 35 */     return ((List<Punish>)this.punishMap.computeIfAbsent(punishType, v -> new ArrayList())).stream()
/* 36 */       .filter(punish -> punish.getId().equals(id)).findFirst().orElse(null);
/*    */   }
/*    */   
/*    */   public Collection<Punish> getPunish(PunishType punishType) {
/* 40 */     return this.punishMap.containsKey(punishType) ? this.punishMap.get(punishType) : new ArrayList<>();
/*    */   }
/*    */   
/*    */   public Collection<Punish> getPunishById(UUID punisherId, PunishType punishType) {
/* 44 */     return (Collection<Punish>)((List)this.punishMap.computeIfAbsent(punishType, v -> new ArrayList())).stream()
/* 45 */       .filter(punish -> (punish.getPunisherId() == punisherId)).collect(Collectors.toList());
/*    */   }
/*    */   
/*    */   public Collection<Punish> getPunishByName(String punisherName, PunishType punishType) {
/* 49 */     return (Collection<Punish>)((List)this.punishMap.computeIfAbsent(punishType, v -> new ArrayList())).stream()
/* 50 */       .filter(punish -> punish.getPunisherName().equals(punisherName)).collect(Collectors.toList());
/*    */   }
/*    */   
/*    */   public boolean pardon(Punish punish, CommandSender sender) {
/* 54 */     List<Punish> list = this.punishMap.computeIfAbsent(punish.getPunishType(), v -> new ArrayList());
/*    */     
/* 56 */     if (list.stream().filter(p -> p.getId().equals(punish.getId())).findFirst().isPresent()) {
/* 57 */       punish.unpunish(sender);
/* 58 */       return true;
/*    */     } 
/*    */     
/* 61 */     return false;
/*    */   }
/*    */   
/*    */   public void punish(Punish punish) {
/* 65 */     ((List<Punish>)this.punishMap.computeIfAbsent(punish.getPunishType(), v -> new ArrayList())).add(punish);
/*    */   }
/*    */   
/*    */   public void loadConfiguration(Member member) {
/* 69 */     this.member = member;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/member/configuration/PunishConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */