/*     */ package net.highmc.member.configuration;
/*     */ 
/*     */ import net.highmc.member.Member;
/*     */ 
/*     */ public class MemberConfiguration {
/*     */   private transient Member member;
/*     */   
/*     */   public Member getMember() {
/*   9 */     return this.member;
/*     */   } private boolean seeingChat = true;
/*  11 */   public boolean isSeeingChat() { return this.seeingChat; } private boolean partyInvites = true;
/*  12 */   public boolean isPartyInvites() { return this.partyInvites; } private boolean tellEnabled = true; private boolean staffChat; public boolean isTellEnabled() {
/*  13 */     return this.tellEnabled;
/*     */   } private boolean seeingStaffChat; private boolean seeingLogs; private boolean spectatorsEnabled; public boolean isStaffChat() {
/*  15 */     return this.staffChat; }
/*  16 */   public boolean isSeeingStaffChat() { return this.seeingStaffChat; }
/*  17 */   public boolean isSeeingLogs() { return this.seeingLogs; }
/*  18 */   public boolean isSpectatorsEnabled() { return this.spectatorsEnabled; } private boolean reportsEnabled = false; public boolean isReportsEnabled() {
/*  19 */     return this.reportsEnabled;
/*  20 */   } private CheatState cheatState = CheatState.ENABLED; private int adminModeJoin; private boolean adminMode; private boolean adminRemoveItems; public CheatState getCheatState() { return this.cheatState; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAdminModeJoin()
/*     */   {
/*  27 */     return this.adminModeJoin; } public boolean isAdminMode() {
/*  28 */     return this.adminMode;
/*     */   } public boolean isAdminRemoveItems() {
/*  30 */     return this.adminRemoveItems;
/*     */   }
/*     */   public MemberConfiguration(Member member) {
/*  33 */     this.member = member;
/*     */   }
/*     */   
/*     */   public void setCheatState(CheatState cheatState) {
/*  37 */     this.cheatState = cheatState;
/*  38 */     save();
/*     */   }
/*     */   
/*     */   public boolean isAnticheatEnabled() {
/*  42 */     return (this.cheatState == CheatState.ENABLED);
/*     */   }
/*     */   
/*     */   public boolean isAnticheatImportant() {
/*  46 */     return (this.cheatState == CheatState.IMPORTANT || this.cheatState == CheatState.ENABLED);
/*     */   }
/*     */   
/*     */   public void setReportsEnabled(boolean reportsEnabled) {
/*  50 */     this.reportsEnabled = reportsEnabled;
/*  51 */     save();
/*     */   }
/*     */   
/*     */   public void setSpectatorsEnabled(boolean spectatorsEnabled) {
/*  55 */     this.spectatorsEnabled = spectatorsEnabled;
/*  56 */     save();
/*     */   }
/*     */   
/*     */   public void setSeeingLogs(boolean seeingLogs) {
/*  60 */     this.seeingLogs = seeingLogs;
/*  61 */     save();
/*     */   }
/*     */   
/*     */   public void setTellEnabled(boolean tellEnabled) {
/*  65 */     this.tellEnabled = tellEnabled;
/*  66 */     save();
/*     */   }
/*     */   
/*     */   public boolean isAdminOnJoin() {
/*  70 */     return (this.adminModeJoin == 1 || (this.adminModeJoin == 2 && isAdminMode()));
/*     */   }
/*     */   
/*     */   public void setAdminModeJoin(int adminModeJoin) {
/*  74 */     this.adminModeJoin = adminModeJoin;
/*  75 */     save();
/*     */   }
/*     */   
/*     */   public void setAdminRemoveItems(boolean adminRemoveItems) {
/*  79 */     this.adminRemoveItems = adminRemoveItems;
/*  80 */     save();
/*     */   }
/*     */   
/*     */   public void setAdminMode(boolean adminMode) {
/*  84 */     this.adminMode = adminMode;
/*  85 */     save();
/*     */   }
/*     */   
/*     */   public void setSeeingStaffChat(boolean seeingStaffChat) {
/*  89 */     this.seeingStaffChat = seeingStaffChat;
/*  90 */     save();
/*     */   }
/*     */   
/*     */   public void setStaffChat(boolean staffChat) {
/*  94 */     this.staffChat = staffChat;
/*  95 */     save();
/*     */   }
/*     */   
/*     */   public void setSeeingChat(boolean seeingChat) {
/*  99 */     this.seeingChat = seeingChat;
/* 100 */     save();
/*     */   }
/*     */   
/*     */   public void setPartyInvites(boolean partyInvites) {
/* 104 */     this.partyInvites = partyInvites;
/* 105 */     save();
/*     */   }
/*     */   
/*     */   public void loadConfiguration(Member member) {
/* 109 */     this.member = member;
/*     */   }
/*     */   
/*     */   public void save() {
/* 113 */     if (this.member != null)
/* 114 */       this.member.save(new String[] { "memberConfiguration" }); 
/*     */   }
/*     */   
/*     */   public enum CheatState
/*     */   {
/* 119 */     ENABLED, DISABLED, IMPORTANT;
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/member/configuration/MemberConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */