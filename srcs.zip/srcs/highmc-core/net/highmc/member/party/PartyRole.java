/*   */ package net.highmc.member.party;
/*   */ 
/*   */ public enum PartyRole
/*   */ {
/* 5 */   MEMBER, ADMIN, OWNER;
/*   */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/member/party/PartyRole.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */