/*    */ package net.highmc.member.party.event.types;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import net.highmc.member.party.event.PartyEvent;
/*    */ 
/*    */ public class MemberJoinEvent extends PartyEvent {
/*    */   private UUID memberId;
/*    */   
/*    */   public MemberJoinEvent(UUID memberId) {
/* 10 */     this.memberId = memberId;
/*    */   }
/*    */   public UUID getMemberId() {
/* 13 */     return this.memberId;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/member/party/event/types/MemberJoinEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */