package net.highmc.member.party.event;

public abstract class PartyEvent {}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/member/party/event/PartyEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */