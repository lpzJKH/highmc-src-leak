/*     */ package net.highmc.member.party;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import java.util.function.Consumer;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.command.CommandSender;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.member.Profile;
/*     */ import net.highmc.member.party.event.PartyEvent;
/*     */ import net.highmc.member.party.event.types.MemberJoinEvent;
/*     */ import net.highmc.member.party.event.types.MemberLeaveEvent;
/*     */ import net.md_5.bungee.api.chat.BaseComponent;
/*     */ 
/*     */ public abstract class Party {
/*     */   private UUID partyId;
/*     */   private PartyPrivacy partyPrivacy;
/*     */   private Map<UUID, PartyRole> membersMap;
/*     */   private int maxPlayers;
/*     */   
/*  21 */   public void setPartyId(UUID partyId) { this.partyId = partyId; } public void setPartyPrivacy(PartyPrivacy partyPrivacy) { this.partyPrivacy = partyPrivacy; } public void setMembersMap(Map<UUID, PartyRole> membersMap) { this.membersMap = membersMap; } public void setMaxPlayers(int maxPlayers) { this.maxPlayers = maxPlayers; }
/*     */ 
/*     */   
/*  24 */   public UUID getPartyId() { return this.partyId; } public PartyPrivacy getPartyPrivacy() {
/*  25 */     return this.partyPrivacy;
/*     */   }
/*  27 */   public Map<UUID, PartyRole> getMembersMap() { return this.membersMap; } public int getMaxPlayers() {
/*  28 */     return this.maxPlayers;
/*     */   }
/*     */   public Party(UUID partyId, Member member) {
/*  31 */     this.partyId = partyId;
/*  32 */     this.partyPrivacy = PartyPrivacy.PRIVATE;
/*     */     
/*  34 */     this.membersMap = new HashMap<>();
/*  35 */     this.maxPlayers = 12;
/*     */     
/*  37 */     this.membersMap.put(member.getUniqueId(), PartyRole.OWNER);
/*     */   }
/*     */   
/*     */   public boolean openParty(int maxPlayers) {
/*  41 */     if (this.partyPrivacy == PartyPrivacy.PRIVATE && maxPlayers < this.membersMap.size()) {
/*  42 */       this.partyPrivacy = PartyPrivacy.PUBLIC;
/*  43 */       this.maxPlayers = maxPlayers;
/*  44 */       save(new String[] { "partyPrivacy" });
/*  45 */       sendMessage("§aA party foi aberta para no máximo " + maxPlayers + " membros.");
/*  46 */       return true;
/*     */     } 
/*     */     
/*  49 */     return false;
/*     */   }
/*     */   
/*     */   public boolean closeParty() {
/*  53 */     if (this.partyPrivacy == PartyPrivacy.PUBLIC) {
/*  54 */       this.partyPrivacy = PartyPrivacy.PRIVATE;
/*  55 */       save(new String[] { "partyPrivacy" });
/*  56 */       sendMessage("§aA party foi fechada.");
/*  57 */       return true;
/*     */     } 
/*     */     
/*  60 */     return false;
/*     */   }
/*     */   
/*     */   public Collection<UUID> getMembers() {
/*  64 */     return this.membersMap.keySet();
/*     */   }
/*     */   
/*     */   public boolean hasRole(UUID playerId, PartyRole partyRole) {
/*  68 */     return this.membersMap.containsKey(playerId) ? ((((PartyRole)this.membersMap.get(playerId)).ordinal() >= partyRole.ordinal())) : false;
/*     */   }
/*     */   
/*     */   public int size() {
/*  72 */     return this.membersMap.size();
/*     */   }
/*     */   
/*     */   public void disband() {
/*  76 */     sendMessage("§cA party foi desfeita.");
/*  77 */     CommonPlugin.getInstance().getPartyData().deleteParty(this);
/*  78 */     this.membersMap.keySet().stream().map(id -> CommonPlugin.getInstance().getMemberManager().getMember(id))
/*  79 */       .forEach(member -> {
/*     */           if (member != null)
/*     */             member.setPartyId(null); 
/*     */         });
/*  83 */     this.membersMap.clear();
/*  84 */     CommonPlugin.getInstance().getPartyManager().unloadParty(this.partyId);
/*     */   }
/*     */   
/*     */   public boolean addMember(Profile profile) {
/*  88 */     if (this.membersMap.size() >= this.maxPlayers) {
/*  89 */       return false;
/*     */     }
/*     */     
/*  92 */     this.membersMap.put(profile.getUniqueId(), PartyRole.MEMBER);
/*  93 */     save(new String[] { "membersMap" });
/*  94 */     onPartyEvent((PartyEvent)new MemberJoinEvent(profile.getUniqueId()));
/*  95 */     sendMessage("§a" + profile.getPlayerName() + " entrou na party.");
/*  96 */     return true;
/*     */   }
/*     */   
/*     */   public boolean removeMember(Profile profile) {
/* 100 */     if (this.membersMap.containsKey(profile.getUniqueId())) {
/* 101 */       this.membersMap.remove(profile.getUniqueId());
/* 102 */       save(new String[] { "membersMap" });
/* 103 */       onPartyEvent((PartyEvent)new MemberLeaveEvent(profile.getUniqueId()));
/* 104 */       sendMessage("§c" + profile.getPlayerName() + " saiu da party.");
/* 105 */       return true;
/*     */     } 
/*     */     
/* 108 */     return false;
/*     */   }
/*     */   
/*     */   public boolean kickMember(CommandSender sender, Member member) {
/* 112 */     if (this.membersMap.containsKey(member.getUniqueId())) {
/* 113 */       sendMessage("§cO " + sender.getName() + " expulsou o " + member.getPlayerName() + " da party.");
/* 114 */       removeMember(Profile.from((CommandSender)member));
/* 115 */       return true;
/*     */     } 
/*     */     
/* 118 */     return false;
/*     */   }
/*     */   
/*     */   public void sendMessage(String message) {
/* 122 */     forEach(member -> member.sendMessage("§dParty> §f" + message));
/*     */   }
/*     */   
/*     */   public void sendMessage(BaseComponent baseComponent) {
/* 126 */     forEach(member -> member.sendMessage(baseComponent));
/*     */   }
/*     */   
/*     */   public void sendMessage(BaseComponent[] baseComponents) {
/* 130 */     forEach(member -> member.sendMessage(baseComponents));
/*     */   }
/*     */   
/*     */   public void chat(CommandSender sender, String message) {
/* 134 */     forEach(member -> member.sendMessage("§dParty> §7" + sender.getName() + ": §f" + message));
/*     */   }
/*     */   
/*     */   public void onPartyEvent(PartyEvent partyEvent) {
/* 138 */     if (partyEvent instanceof MemberLeaveEvent) {
/* 139 */       onMemberLeave((MemberLeaveEvent)partyEvent);
/* 140 */     } else if (partyEvent instanceof MemberJoinEvent) {
/* 141 */       onMemberJoin((MemberJoinEvent)partyEvent);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void onMemberJoin(MemberJoinEvent partyEvent) {}
/*     */ 
/*     */   
/*     */   public void onMemberLeave(MemberLeaveEvent partyEvent) {}
/*     */ 
/*     */   
/*     */   public void forEach(Consumer<Member> consumer) {
/* 154 */     this.membersMap.keySet().stream().filter(id -> (CommonPlugin.getInstance().getMemberManager().getMember(id) != null))
/* 155 */       .map(id -> CommonPlugin.getInstance().getMemberManager().getMember(id)).forEach(consumer);
/*     */   }
/*     */   
/*     */   public void save(String... fields) {
/* 159 */     for (String fieldName : fields)
/* 160 */       CommonPlugin.getInstance().getPartyData().updateParty(this, fieldName); 
/*     */   }
/*     */   
/*     */   public enum PartyPrivacy
/*     */   {
/* 165 */     PRIVATE, PUBLIC;
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/member/party/Party.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */