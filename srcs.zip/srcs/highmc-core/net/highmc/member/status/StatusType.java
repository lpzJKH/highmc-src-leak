/*   */ package net.highmc.member.status;
/*   */ 
/*   */ public enum StatusType
/*   */ {
/* 5 */   HG, PVP, SKYWARS, BEDWARS;
/*   */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/member/status/StatusType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */