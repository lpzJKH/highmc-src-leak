/*    */ package net.highmc.member.status;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.UUID;
/*    */ import net.highmc.CommonPlugin;
/*    */ 
/*    */ public class Status {
/*    */   private final UUID uniqueId;
/*    */   private final StatusType statusType;
/*    */   private HashMap<String, Integer> integerMap;
/*    */   
/* 12 */   public UUID getUniqueId() { return this.uniqueId; } public StatusType getStatusType() {
/* 13 */     return this.statusType;
/*    */   } public HashMap<String, Integer> getIntegerMap() {
/* 15 */     return this.integerMap;
/*    */   }
/*    */   public Status(UUID uniqueId, StatusType statusType) {
/* 18 */     this.uniqueId = uniqueId;
/* 19 */     this.statusType = statusType;
/*    */     
/* 21 */     this.integerMap = new HashMap<>();
/*    */   }
/*    */   
/*    */   public int getInteger(String key) {
/* 25 */     return getInteger(key, 0);
/*    */   }
/*    */   
/*    */   public int getInteger(Enum<?> enumType) {
/* 29 */     return getInteger(enumType.name().toLowerCase(), 0);
/*    */   }
/*    */   
/*    */   public int getInteger(String key, int defaultValue) {
/* 33 */     if (this.integerMap.containsKey(key.toLowerCase())) {
/* 34 */       return ((Integer)this.integerMap.get(key.toLowerCase())).intValue();
/*    */     }
/* 36 */     return defaultValue;
/*    */   }
/*    */   
/*    */   public int getInteger(Enum<?> enumType, int defaultValue) {
/* 40 */     if (this.integerMap.containsKey(enumType.name().toLowerCase())) {
/* 41 */       return ((Integer)this.integerMap.get(enumType.name().toLowerCase())).intValue();
/*    */     }
/* 43 */     return defaultValue;
/*    */   }
/*    */   
/*    */   public void setInteger(String key, int value) {
/* 47 */     this.integerMap.put(key, Integer.valueOf(value));
/* 48 */     save();
/*    */   }
/*    */   
/*    */   public void setInteger(Enum<?> enumType, int value) {
/* 52 */     this.integerMap.put(enumType.name().toLowerCase(), Integer.valueOf(value));
/* 53 */     save();
/*    */   }
/*    */   
/*    */   public void addInteger(Enum<?> enumType, int value) {
/* 57 */     this.integerMap.put(enumType.name().toLowerCase(), Integer.valueOf(getInteger(enumType, 0) + value));
/* 58 */     save();
/*    */   }
/*    */   
/*    */   public void addInteger(String key, int value) {
/* 62 */     this.integerMap.put(key.toLowerCase(), Integer.valueOf(getInteger(key, 0) + value));
/* 63 */     save();
/*    */   }
/*    */   
/*    */   public void save() {
/* 67 */     save("integerMap");
/*    */   }
/*    */   
/*    */   public void save(String fieldName) {
/* 71 */     CommonPlugin.getInstance().getMemberData().saveStatus(this, fieldName);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/member/status/Status.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */