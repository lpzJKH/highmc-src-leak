/*    */ package net.highmc.member.status.types;
/*    */ 
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.server.ServerType;
/*    */ 
/*    */ public enum BedwarsCategory
/*    */ {
/*  8 */   BEDWARS_MATCH, BEDWARS_LEVEL, BEDWARS_POINTS,
/*    */   
/* 10 */   BEDWARS_KILLS, BEDWARS_FINAL_KILLS, BEDWARS_KILLSTREAK, BEDWARS_DEATHS, BEDWARS_FINAL_DEATHS, BEDWARS_WINS,
/* 11 */   BEDWARS_LOSES, BEDWARS_WINSTREAK,
/*    */   
/* 13 */   BEDWARS_BED_BREAK, BEDWARS_BED_BROKEN;
/*    */   
/*    */   public String getSpecialServer(ServerType serverType) {
/* 16 */     return name().toLowerCase().replace("_", "-") + "-" + serverType.name().toLowerCase().split("_")[1];
/*    */   }
/*    */   
/*    */   public String getSpecialServer() {
/* 20 */     return getSpecialServer(CommonPlugin.getInstance().getServerType());
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/member/status/types/BedwarsCategory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */