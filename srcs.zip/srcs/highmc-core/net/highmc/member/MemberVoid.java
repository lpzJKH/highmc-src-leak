/*    */ package net.highmc.member;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import net.highmc.member.configuration.LoginConfiguration;
/*    */ import net.md_5.bungee.api.chat.BaseComponent;
/*    */ 
/*    */ public class MemberVoid
/*    */   extends Member
/*    */ {
/*    */   public MemberVoid(UUID uniqueId, String playerName) {
/* 11 */     super(uniqueId, playerName, LoginConfiguration.AccountType.NONE);
/*    */   }
/*    */   
/*    */   public MemberVoid(UUID uniqueId, String playerName, LoginConfiguration.AccountType accountType) {
/* 15 */     super(uniqueId, playerName, accountType);
/*    */   }
/*    */   
/*    */   public void sendMessage(String message) {}
/*    */   
/*    */   public void sendMessage(BaseComponent str) {}
/*    */   
/*    */   public void sendMessage(BaseComponent... fromLegacyText) {}
/*    */   
/*    */   public void sendTitle(String title, String subTitle, int fadeIn, int stayIn, int fadeOut) {}
/*    */   
/*    */   public void sendActionBar(String message) {}
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/member/MemberVoid.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */