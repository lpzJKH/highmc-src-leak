/*     */ package net.highmc.member;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.medal.Medal;
/*     */ import net.highmc.permission.Group;
/*     */ import net.highmc.permission.GroupInfo;
/*     */ import net.highmc.permission.Tag;
/*     */ import net.highmc.server.ServerType;
/*     */ import net.highmc.utils.skin.Skin;
/*     */ 
/*     */ public abstract class Member implements CommandSender {
/*     */   private final UUID uniqueId;
/*     */   private String playerName;
/*     */   private Map<String, GroupInfo> groups;
/*     */   private transient String serverGroup;
/*     */   private String tagName;
/*     */   private String medalName;
/*     */   private List<String> permissions;
/*     */   private transient List<String> cachedPermissions;
/*     */   private List<String> medals;
/*     */   private Map<String, Long> cooldownMap;
/*     */   private List<Profile> blockedList;
/*     */   private List<Profile> friendList;
/*     */   private LoginConfiguration loginConfiguration;
/*     */   private MemberConfiguration memberConfiguration;
/*     */   private PunishConfiguration punishConfiguration;
/*     */   private Skin skin;
/*     */   private boolean customSkin;
/*     */   private String fakeName;
/*     */   
/*  36 */   public UUID getUniqueId() { return this.uniqueId; } private String twitterUrl; private String youtubeUrl; private String twitchUrl; private String discordId; private UUID partyId; private String ipAddress; private String lastIpAddress; private long firstLogin; private long lastLogin; private long joinTime; private long onlineTime; private boolean online; private String actualServerId; private ServerType actualServerType; private String lastServerId; private ServerType lastServerType; private Language language; private transient UUID replyId; public String getPlayerName() {
/*  37 */     return this.playerName;
/*     */   } public Map<String, GroupInfo> getGroups() {
/*  39 */     return this.groups;
/*     */   }
/*     */   
/*  42 */   public String getTagName() { return this.tagName; } public String getMedalName() {
/*  43 */     return this.medalName;
/*     */   }
/*  45 */   public List<String> getPermissions() { return this.permissions; }
/*  46 */   public List<String> getCachedPermissions() { return this.cachedPermissions; } public List<String> getMedals() {
/*  47 */     return this.medals;
/*     */   } public Map<String, Long> getCooldownMap() {
/*  49 */     return this.cooldownMap;
/*     */   }
/*  51 */   public List<Profile> getBlockedList() { return this.blockedList; } public List<Profile> getFriendList() {
/*  52 */     return this.friendList;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LoginConfiguration getLoginConfiguration() {
/*  58 */     return this.loginConfiguration;
/*  59 */   } public MemberConfiguration getMemberConfiguration() { return this.memberConfiguration; } public PunishConfiguration getPunishConfiguration() {
/*  60 */     return this.punishConfiguration;
/*     */   }
/*  62 */   public Skin getSkin() { return this.skin; }
/*  63 */   public boolean isCustomSkin() { return this.customSkin; } public String getFakeName() {
/*  64 */     return this.fakeName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTwitterUrl() {
/*  70 */     return this.twitterUrl;
/*  71 */   } public String getYoutubeUrl() { return this.youtubeUrl; } public String getTwitchUrl() {
/*  72 */     return this.twitchUrl;
/*     */   } public String getDiscordId() {
/*  74 */     return this.discordId;
/*     */   } public UUID getPartyId() {
/*  76 */     return this.partyId;
/*     */   }
/*  78 */   public String getIpAddress() { return this.ipAddress; } public String getLastIpAddress() {
/*  79 */     return this.lastIpAddress;
/*     */   }
/*  81 */   public long getFirstLogin() { return this.firstLogin; }
/*  82 */   public long getLastLogin() { return this.lastLogin; } public long getJoinTime() {
/*  83 */     return this.joinTime;
/*     */   } public boolean isOnline() {
/*  85 */     return this.online;
/*     */   }
/*  87 */   public String getActualServerId() { return this.actualServerId; } public ServerType getActualServerType() {
/*  88 */     return this.actualServerType;
/*     */   }
/*  90 */   public String getLastServerId() { return this.lastServerId; } public ServerType getLastServerType() {
/*  91 */     return this.lastServerType;
/*     */   } public Language getLanguage() {
/*  93 */     return this.language;
/*     */   }
/*  95 */   public void setReplyId(UUID replyId) { this.replyId = replyId; } public UUID getReplyId() {
/*  96 */     return this.replyId;
/*     */   }
/*     */   public Member(UUID uniqueId, String playerName, LoginConfiguration.AccountType accountType) {
/*  99 */     this.uniqueId = uniqueId;
/* 100 */     this.playerName = playerName;
/*     */     
/* 102 */     this.groups = new HashMap<>();
/* 103 */     this.cooldownMap = new HashMap<>();
/*     */     
/* 105 */     this.blockedList = new ArrayList<>();
/* 106 */     this.friendList = new ArrayList<>();
/*     */     
/* 108 */     this.loginConfiguration = new LoginConfiguration(this, accountType);
/* 109 */     this.memberConfiguration = new MemberConfiguration(this);
/* 110 */     this.punishConfiguration = new PunishConfiguration(this);
/*     */     
/* 112 */     this.permissions = new ArrayList<>();
/* 113 */     this.cachedPermissions = new ArrayList<>();
/*     */     
/* 115 */     this.medals = new ArrayList<>();
/*     */     
/* 117 */     this.firstLogin = System.currentTimeMillis();
/* 118 */     this.joinTime = System.currentTimeMillis();
/* 119 */     this.lastLogin = System.currentTimeMillis();
/* 120 */     this.onlineTime = -1L;
/* 121 */     this.online = true;
/*     */     
/* 123 */     this.language = CommonPlugin.getInstance().getPluginInfo().getDefaultLanguage();
/* 124 */     handleDefaultGroup();
/*     */   }
/*     */   
/*     */   public boolean block(Profile profile) {
/* 128 */     if (this.blockedList.contains(profile)) {
/* 129 */       return false;
/*     */     }
/* 131 */     this.blockedList.add(profile);
/* 132 */     save(new String[] { "blockedList" });
/* 133 */     return true;
/*     */   }
/*     */   
/*     */   public boolean unblock(Profile profile) {
/* 137 */     if (!this.blockedList.contains(profile)) {
/* 138 */       return false;
/*     */     }
/* 140 */     this.blockedList.remove(profile);
/* 141 */     save(new String[] { "blockedList" });
/* 142 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isUserBlocked(Profile profile) {
/* 146 */     if (this.blockedList == null) {
/* 147 */       this.blockedList = new ArrayList<>();
/*     */     }
/* 149 */     if (profile == null) {
/* 150 */       return false;
/*     */     }
/* 152 */     return this.blockedList.contains(profile);
/*     */   }
/*     */   
/*     */   public boolean hasCooldown(String cooldownId) {
/* 156 */     if (this.cooldownMap == null)
/* 157 */       this.cooldownMap = new HashMap<>(); 
/* 158 */     if (this.cooldownMap.containsKey(cooldownId.toLowerCase())) {
/* 159 */       if (((Long)this.cooldownMap.get(cooldownId.toLowerCase())).longValue() > System.currentTimeMillis()) {
/* 160 */         return true;
/*     */       }
/* 162 */       this.cooldownMap.remove(cooldownId.toLowerCase());
/* 163 */       save(new String[] { "cooldownMap" });
/*     */     } 
/*     */     
/* 166 */     return false;
/*     */   }
/*     */   
/*     */   public String getCooldownFormatted(String cooldownId) {
/* 170 */     return DateUtils.getTime(getLanguage(), ((Long)this.cooldownMap.get(cooldownId.toLowerCase())).longValue());
/*     */   }
/*     */   
/*     */   public void putCooldown(String cooldownId, long cooldown) {
/* 174 */     if (this.cooldownMap == null)
/* 175 */       this.cooldownMap = new HashMap<>(); 
/* 176 */     this.cooldownMap.put(cooldownId.toLowerCase(), Long.valueOf(cooldown));
/* 177 */     save(new String[] { "cooldownMap" });
/*     */   }
/*     */   
/*     */   public void putCooldown(String cooldownId, double seconds) {
/* 181 */     putCooldown(cooldownId, System.currentTimeMillis() + (long)(1000.0D * seconds));
/*     */   }
/*     */   
/*     */   public boolean isUsingFake() {
/* 185 */     return (this.fakeName != null && !this.fakeName.equals(this.playerName));
/*     */   }
/*     */   
/*     */   public void setFakeName(String fakeName) {
/* 189 */     this.fakeName = fakeName;
/* 190 */     save(new String[] { "fakeName" });
/*     */   }
/*     */   
/*     */   public boolean hasCustomSkin() {
/* 194 */     return (this.skin != null && !this.skin.getPlayerName().equals(this.playerName));
/*     */   }
/*     */   
/*     */   public void setSkin(Skin skin) {
/* 198 */     setSkin(skin, false);
/*     */   }
/*     */   
/*     */   public void setSkin(Skin skin, boolean customSkin) {
/* 202 */     this.skin = skin;
/* 203 */     this.customSkin = customSkin;
/* 204 */     save(new String[] { "skin", "customSkin" });
/*     */   }
/*     */   
/*     */   public boolean hasMedal(Medal medal) {
/* 208 */     return this.medals.contains(medal.getMedalName().toLowerCase());
/*     */   }
/*     */   
/*     */   public boolean removeMedal(Medal medal) {
/* 212 */     if (this.medals.contains(medal.getMedalName().toLowerCase())) {
/* 213 */       this.medals.remove(medal.getMedalName().toLowerCase());
/* 214 */       save(new String[] { "medals" });
/* 215 */       return true;
/*     */     } 
/*     */     
/* 218 */     return false;
/*     */   }
/*     */   
/*     */   public boolean addMedal(Medal medal) {
/* 222 */     if (!this.medals.contains(medal.getMedalName().toLowerCase())) {
/* 223 */       this.medals.add(medal.getMedalName().toLowerCase());
/* 224 */       save(new String[] { "medals" });
/* 225 */       return true;
/*     */     } 
/* 227 */     return false;
/*     */   }
/*     */   
/*     */   public void setMedal(Medal medal) {
/* 231 */     if (medal == null) {
/* 232 */       this.medalName = null;
/*     */     } else {
/* 234 */       this.medalName = medal.getMedalName();
/* 235 */     }  save(new String[] { "medalName" });
/*     */   }
/*     */   
/*     */   public Medal getMedal() {
/* 239 */     return (this.medalName == null) ? null : CommonPlugin.getInstance().getPluginInfo().getMedalByName(this.medalName);
/*     */   }
/*     */   
/*     */   public Tag getTag() {
/* 243 */     if (this.tagName == null) {
/* 244 */       this.tagName = CommonPlugin.getInstance().getPluginInfo().getDefaultTag().getTagName();
/* 245 */       save(new String[] { "tag" });
/*     */     } 
/*     */     
/* 248 */     return CommonPlugin.getInstance().getPluginInfo().getTagByName(this.tagName);
/*     */   }
/*     */   
/*     */   public void setTwitterUrl(String twitterUrl) {
/* 252 */     this.twitterUrl = twitterUrl;
/* 253 */     save(new String[] { "twitterUrl" });
/*     */   }
/*     */   
/*     */   public void setYoutubeUrl(String youtubeUrl) {
/* 257 */     this.youtubeUrl = youtubeUrl;
/* 258 */     save(new String[] { "youtubeUrl" });
/*     */   }
/*     */   
/*     */   public void setTwitchUrl(String twitchUrl) {
/* 262 */     this.twitchUrl = twitchUrl;
/* 263 */     save(new String[] { "twitchUrl" });
/*     */   }
/*     */   
/*     */   public void setDiscordId(String discordId) {
/* 267 */     this.discordId = discordId;
/* 268 */     save(new String[] { "discordId" });
/*     */   }
/*     */   
/*     */   public void setPartyId(UUID partyId) {
/* 272 */     this.partyId = partyId;
/* 273 */     save(new String[] { "partyId" });
/*     */   }
/*     */   
/*     */   public void setParty(Party party) {
/* 277 */     if (party == null) {
/* 278 */       this.partyId = null;
/*     */     } else {
/* 280 */       this.partyId = party.getPartyId();
/* 281 */     }  save(new String[] { "partyId" });
/*     */   }
/*     */   
/*     */   public Party getParty() {
/* 285 */     return (this.partyId == null) ? null : CommonPlugin.getInstance().getPartyManager().getPartyById(this.partyId);
/*     */   }
/*     */   public void logIn(@NonNull String playerName, @NonNull String ipAddress) {
/* 288 */     if (playerName == null) throw new NullPointerException("playerName is marked non-null but is null");  if (ipAddress == null) throw new NullPointerException("ipAddress is marked non-null but is null"); 
/* 289 */     this.playerName = playerName;
/* 290 */     this.joinTime = System.currentTimeMillis();
/* 291 */     this.online = true;
/*     */     
/* 293 */     this.ipAddress = ipAddress;
/* 294 */     this.lastIpAddress = this.ipAddress;
/*     */     
/* 296 */     loadConfiguration();
/* 297 */     this.loginConfiguration.logOut();
/*     */     
/* 299 */     save(new String[] { "playerName", "joinTime", "online", "ipAddress", "lastIpAddress" });
/*     */   }
/*     */   
/*     */   public void connect(String serverId, ServerType serverType) {
/* 303 */     this.lastServerId = this.actualServerId;
/* 304 */     this.lastServerType = this.actualServerType;
/*     */     
/* 306 */     this.actualServerId = serverId;
/* 307 */     this.actualServerType = serverType;
/*     */     
/* 309 */     save(new String[] { "lastServerId", "lastServerType", "actualServerId", "actualServerType" });
/* 310 */     loadConfiguration();
/*     */   }
/*     */   
/*     */   public void connect() {
/* 314 */     connect(CommonPlugin.getInstance().getServerId(), CommonPlugin.getInstance().getServerType());
/*     */   }
/*     */   
/*     */   public void setOnline(boolean online) {
/* 318 */     this.online = online;
/* 319 */     save(new String[] { "online" });
/*     */   }
/*     */   
/*     */   public void logOut() {
/* 323 */     this.lastLogin = System.currentTimeMillis();
/* 324 */     this.onlineTime += getSessionTime();
/* 325 */     this.online = false;
/*     */     
/* 327 */     save(new String[] { "lastLogin", "onlineTime", "online" });
/*     */   }
/*     */   
/*     */   public long getOnlineTime() {
/* 331 */     return this.onlineTime + getSessionTime();
/*     */   }
/*     */   
/*     */   public long getSessionTime() {
/* 335 */     if (this.online) {
/* 336 */       return System.currentTimeMillis() - this.joinTime;
/*     */     }
/* 338 */     return 0L;
/*     */   }
/*     */   
/*     */   public void updateGroup() {
/* 342 */     this.serverGroup = null;
/*     */   }
/*     */   
/*     */   public Tag getDefaultTag() {
/* 346 */     Tag tag = CommonPlugin.getInstance().getPluginInfo().getTagByGroup(getServerGroup());
/* 347 */     return (tag == null) ? CommonPlugin.getInstance().getPluginInfo().getDefaultTag() : tag;
/*     */   }
/*     */   
/*     */   public boolean setTag(Tag tag) {
/* 351 */     this.tagName = tag.getTagName();
/* 352 */     save(new String[] { "tagName" });
/* 353 */     return false;
/*     */   }
/*     */   
/*     */   public boolean hasTag(Tag tag) {
/* 357 */     if (tag.isExclusive()) {
/* 358 */       return (hasPermission("tag." + tag.getTagName()) || (
/* 359 */         hasPermission("staff.super") && getDefaultTag().getTagId() < tag.getTagId()));
/*     */     }
/* 361 */     return (tag.isDefaultTag() || getDefaultTag().getTagId() < tag.getTagId() || 
/* 362 */       hasPermission("tag." + tag.getTagName().toLowerCase()));
/*     */   }
/*     */   
/*     */   public boolean addPermission(String permission) {
/* 366 */     if (!this.permissions.contains(permission.toLowerCase())) {
/* 367 */       this.permissions.add(permission.toLowerCase());
/* 368 */       return true;
/*     */     } 
/*     */     
/* 371 */     return false;
/*     */   }
/*     */   
/*     */   public boolean removePermission(String permission) {
/* 375 */     if (this.permissions.contains(permission.toLowerCase())) {
/* 376 */       this.permissions.remove(permission.toLowerCase());
/* 377 */       return true;
/*     */     } 
/*     */     
/* 380 */     return false;
/*     */   }
/*     */   
/*     */   public void removeServerGroup(String groupName) {
/* 384 */     this.groups.remove(groupName.toLowerCase());
/* 385 */     this.serverGroup = getHigherGroup();
/* 386 */     handleDefaultGroup();
/* 387 */     save(new String[] { "groups" });
/*     */   }
/*     */   
/*     */   public void setServerGroup(String groupName, GroupInfo groupInfo) {
/* 391 */     this.groups.clear();
/* 392 */     this.groups.put(groupName.toLowerCase(), groupInfo);
/* 393 */     this.serverGroup = getHigherGroup();
/* 394 */     save(new String[] { "groups" });
/*     */   }
/*     */   
/*     */   public void addServerGroup(String groupName, GroupInfo groupInfo) {
/* 398 */     this.groups.put(groupName.toLowerCase(), groupInfo);
/* 399 */     this.serverGroup = getHigherGroup();
/* 400 */     save(new String[] { "groups" });
/*     */   }
/*     */   
/*     */   public void setLanguage(Language language) {
/* 404 */     this.language = language;
/* 405 */     save(new String[] { "language" });
/*     */   }
/*     */   
/*     */   public boolean isStaff() {
/* 409 */     return CommonPlugin.getInstance().getPluginInfo().getGroupMap().values().stream()
/* 410 */       .filter(group -> (group.isStaff() && hasGroup(group.getGroupName()))).findFirst().isPresent();
/*     */   }
/*     */   
/*     */   private boolean handleDefaultGroup() {
/* 414 */     boolean save = false;
/*     */     
/* 416 */     for (Group group : CommonPlugin.getInstance().getPluginInfo().getGroupMap().values()) {
/* 417 */       if (group.isDefaultGroup() && !hasGroup(group.getGroupName())) {
/* 418 */         this.groups.put(group.getGroupName().toLowerCase(), new GroupInfo());
/* 419 */         save = true;
/*     */       } 
/*     */     } 
/*     */     
/* 423 */     if (save) {
/* 424 */       save(new String[] { "groups" });
/*     */     }
/* 426 */     return save;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean handleCheckGroup() {
/* 436 */     boolean save = false;
/* 437 */     for (UnmodifiableIterator<Map.Entry<String, GroupInfo>> unmodifiableIterator = ImmutableSet.copyOf(getGroups().entrySet()).iterator(); unmodifiableIterator.hasNext(); ) { Map.Entry<String, GroupInfo> entry = unmodifiableIterator.next();
/* 438 */       if (!((GroupInfo)entry.getValue()).isPermanent() && ((GroupInfo)entry.getValue()).getExpireTime() < System.currentTimeMillis()) {
/* 439 */         sendMessage("§cO seu grupo " + 
/* 440 */             CommonPlugin.getInstance().getPluginInfo().getTagByName(entry.getKey()).getRealPrefix() + "§cexpirou.");
/*     */         
/* 442 */         save = true;
/*     */       }  }
/*     */ 
/*     */     
/* 446 */     save = (save && !handleDefaultGroup());
/*     */     
/* 448 */     if (save) {
/* 449 */       save(new String[] { "groups" });
/*     */     }
/* 451 */     return save;
/*     */   }
/*     */   
/*     */   public void saveConfig() {
/* 455 */     save(new String[] { "loginConfiguration", "memberConfiguration", "punishConfiguration" });
/*     */   }
/*     */   
/*     */   public void save(String... fields) {
/* 459 */     for (String fieldName : fields)
/* 460 */       CommonPlugin.getInstance().getMemberData().updateMember(this, fieldName); 
/*     */   }
/*     */   
/*     */   public void loadConfiguration() {
/* 464 */     this.loginConfiguration.loadConfiguration(this);
/* 465 */     this.memberConfiguration.loadConfiguration(this);
/* 466 */     this.punishConfiguration.loadConfiguration(this);
/* 467 */     this.cachedPermissions = new ArrayList<>();
/*     */   }
/*     */   
/*     */   public boolean hasGroup(String groupName) {
/* 471 */     return this.groups.containsKey(groupName.toLowerCase());
/*     */   }
/*     */   
/*     */   public Group getServerGroup() {
/* 475 */     if (this.serverGroup == null) {
/* 476 */       this.serverGroup = getHigherGroup();
/*     */     }
/* 478 */     return CommonPlugin.getInstance().getPluginInfo().getGroupByName(this.serverGroup);
/*     */   }
/*     */   
/*     */   private String getHigherGroup() {
/* 482 */     return ((Group)CommonPlugin.getInstance().getPluginInfo().getGroupMap().values().stream()
/* 483 */       .filter(group -> this.groups.containsKey(group.getGroupName().toLowerCase()))
/* 484 */       .sorted((g1, g2) -> (g1.getId() - g2.getId()) * -1).findFirst()
/* 485 */       .orElse(CommonPlugin.getInstance().getPluginInfo().getDefaultGroup())).getGroupName();
/*     */   }
/*     */   
/*     */   public GroupInfo getServerGroup(String groupName) {
/* 489 */     return this.groups.get(groupName.toLowerCase());
/*     */   }
/*     */   
/*     */   public boolean hasSilentPermission(String permission) {
/* 493 */     if (this.permissions.contains(permission.toLowerCase()) || this.cachedPermissions
/* 494 */       .contains(permission.toLowerCase())) {
/* 495 */       return true;
/*     */     }
/* 497 */     for (Group group : CommonPlugin.getInstance().getPluginInfo().getGroupMap().values().stream()
/* 498 */       .filter(group -> this.groups.containsKey(group.getGroupName())).collect(Collectors.toList())) {
/* 499 */       if (group.getPermissions().contains(permission.toLowerCase())) {
/* 500 */         this.cachedPermissions.add(permission.toLowerCase());
/* 501 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 505 */     return false;
/*     */   }
/*     */   
/*     */   public void sendTitle(String title, String subTitle) {
/* 509 */     sendTitle(title, subTitle, 10, 20, 10);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasPermission(String permission) {
/* 518 */     return hasSilentPermission(permission);
/*     */   }
/*     */   
/*     */   public String getName() {
/* 522 */     return this.playerName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSenderName() {
/* 527 */     return this.playerName;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPlayer() {
/* 532 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTellEnabled(boolean tellEnabled) {
/* 537 */     getMemberConfiguration().setTellEnabled(tellEnabled);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTellEnabled() {
/* 542 */     return getMemberConfiguration().isTellEnabled();
/*     */   }
/*     */   
/*     */   public static Language getLanguage(UUID uniqueId) {
/* 546 */     return Language.getLanguage(uniqueId);
/*     */   }
/*     */   
/*     */   public boolean hasTwitch() {
/* 550 */     return (this.twitchUrl != null && !this.twitchUrl.isEmpty());
/*     */   }
/*     */   
/*     */   public abstract void sendTitle(String paramString1, String paramString2, int paramInt1, int paramInt2, int paramInt3);
/*     */   
/*     */   public abstract void sendActionBar(String paramString);
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/member/Member.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */