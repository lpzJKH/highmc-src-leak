/*    */ package net.highmc.bukkit.gameapi.bedwars.event.island;
/*    */ 
/*    */ import net.highmc.bukkit.event.NormalEvent;
/*    */ import net.highmc.bukkit.gameapi.bedwars.island.Island;
/*    */ 
/*    */ public class IslandLoseEvent
/*    */   extends NormalEvent {
/*    */   public IslandLoseEvent(Island island) {
/*  9 */     this.island = island;
/*    */   } private Island island;
/*    */   public Island getIsland() {
/* 12 */     return this.island;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/event/island/IslandLoseEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */