/*     */ package net.highmc.bukkit.gameapi.bedwars.island;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import java.util.stream.Stream;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.gameapi.GameAPI;
/*     */ import net.highmc.bukkit.gameapi.bedwars.GameMain;
/*     */ import net.highmc.bukkit.gameapi.bedwars.event.island.IslandBedBreakEvent;
/*     */ import net.highmc.bukkit.gameapi.bedwars.event.island.IslandLoseEvent;
/*     */ import net.highmc.bukkit.gameapi.bedwars.event.island.IslandUpgradeEvent;
/*     */ import net.highmc.bukkit.gameapi.bedwars.gamer.Gamer;
/*     */ import net.highmc.bukkit.gameapi.bedwars.generator.Generator;
/*     */ import net.highmc.bukkit.gameapi.bedwars.generator.impl.NormalGenerator;
/*     */ import net.highmc.bukkit.gameapi.bedwars.menu.StoreInventory;
/*     */ import net.highmc.bukkit.gameapi.bedwars.menu.UpgradeInventory;
/*     */ import net.highmc.bukkit.gameapi.bedwars.utils.GamerHelper;
/*     */ import net.highmc.bukkit.gameapi.gamer.Team;
/*     */ import net.highmc.bukkit.utils.Location;
/*     */ import net.highmc.bukkit.utils.player.PlayerHelper;
/*     */ import net.highmc.bukkit.utils.scoreboard.ScoreboardAPI;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.member.status.Status;
/*     */ import net.highmc.member.status.StatusType;
/*     */ import net.highmc.member.status.types.BedwarsCategory;
/*     */ import net.highmc.utils.string.StringFormat;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ 
/*     */ public class Island implements Cloneable {
/*     */   private IslandColor islandColor;
/*     */   private Location spawnLocation;
/*     */   private Location bedLocation;
/*     */   private Location shopLocation;
/*     */   private Location upgradeLocation;
/*     */   
/*     */   public Island(IslandColor islandColor, Location spawnLocation, Location bedLocation, Location shopLocation, Location upgradeLocation, Map<Material, List<Location>> generatorMap, IslandStatus islandStatus, List<Generator> islandGenerators, Map<IslandUpgrade, Integer> upgradeMap, Team team) {
/*  44 */     this.islandColor = islandColor; this.spawnLocation = spawnLocation; this.bedLocation = bedLocation; this.shopLocation = shopLocation; this.upgradeLocation = upgradeLocation; this.generatorMap = generatorMap; this.islandStatus = islandStatus; this.islandGenerators = islandGenerators; this.upgradeMap = upgradeMap; this.team = team;
/*     */   } private Map<Material, List<Location>> generatorMap; private transient IslandStatus islandStatus; private transient List<Generator> islandGenerators; private transient Map<IslandUpgrade, Integer> upgradeMap; private transient Team team;
/*     */   public IslandColor getIslandColor() {
/*  47 */     return this.islandColor;
/*     */   }
/*  49 */   public void setSpawnLocation(Location spawnLocation) { this.spawnLocation = spawnLocation; }
/*  50 */   public Location getSpawnLocation() { return this.spawnLocation; }
/*  51 */   public void setBedLocation(Location bedLocation) { this.bedLocation = bedLocation; } public Location getBedLocation() {
/*  52 */     return this.bedLocation;
/*     */   }
/*  54 */   public void setShopLocation(Location shopLocation) { this.shopLocation = shopLocation; }
/*  55 */   public Location getShopLocation() { return this.shopLocation; }
/*  56 */   public void setUpgradeLocation(Location upgradeLocation) { this.upgradeLocation = upgradeLocation; } public Location getUpgradeLocation() {
/*  57 */     return this.upgradeLocation;
/*     */   } public Map<Material, List<Location>> getGeneratorMap() {
/*  59 */     return this.generatorMap;
/*     */   }
/*  61 */   public void setIslandStatus(IslandStatus islandStatus) { this.islandStatus = islandStatus; }
/*  62 */   public IslandStatus getIslandStatus() { return this.islandStatus; }
/*  63 */   public List<Generator> getIslandGenerators() { return this.islandGenerators; }
/*  64 */   public Map<IslandUpgrade, Integer> getUpgradeMap() { return this.upgradeMap; } public Team getTeam() {
/*  65 */     return this.team;
/*     */   }
/*     */   public Island loadIsland(Team team) {
/*  68 */     String worldName = ((World)Bukkit.getWorlds().stream().findFirst().orElse(null)).getName();
/*     */     
/*  70 */     if (this.spawnLocation == null) {
/*  71 */       this.spawnLocation = new Location(worldName);
/*     */     }
/*  73 */     if (this.bedLocation == null) {
/*  74 */       this.bedLocation = new Location(worldName);
/*     */     }
/*  76 */     if (this.shopLocation == null) {
/*  77 */       this.shopLocation = new Location(worldName);
/*     */     }
/*  79 */     if (this.upgradeLocation == null) {
/*  80 */       this.upgradeLocation = new Location(worldName);
/*     */     }
/*  82 */     this.islandStatus = team.getPlayerSet().isEmpty() ? IslandStatus.LOSER : IslandStatus.ALIVE;
/*  83 */     this.islandGenerators = new ArrayList<>();
/*  84 */     this.upgradeMap = new HashMap<>();
/*     */     
/*  86 */     this.team = team;
/*     */     
/*  88 */     for (Location location : GameMain.getInstance()
/*  89 */       .getNearestBlocksByMaterial(this.bedLocation.getAsLocation(), Material.BED_BLOCK, 4, 2)) {
/*  90 */       if (this.islandStatus == IslandStatus.ALIVE) {
/*  91 */         location.getBlock().setMetadata("bed-island", GameAPI.getInstance().createMeta(this.islandColor)); continue;
/*     */       } 
/*  93 */       location.getBlock().setType(Material.AIR);
/*     */     } 
/*     */     
/*  96 */     for (Location location : GameMain.getInstance()
/*  97 */       .getNearestBlocksByMaterial(this.spawnLocation.getAsLocation(), Material.CHEST, 10, 5)) {
/*     */       
/*  99 */       if (location.getBlock().getType() == Material.CHEST)
/* 100 */         location.getBlock().setMetadata("chest-island", 
/* 101 */             GameAPI.getInstance().createMeta(this.islandColor)); 
/*     */     } 
/* 103 */     return this;
/*     */   }
/*     */   
/*     */   public void upgrade(Player player, IslandUpgrade upgrade) {
/* 107 */     Integer integer = Integer.valueOf(((Integer)this.upgradeMap.computeIfAbsent(upgrade, v -> Integer.valueOf(0))).intValue() + 1);
/*     */     
/* 109 */     if (integer.intValue() <= upgrade.getMaxLevel()) {
/* 110 */       Bukkit.getPluginManager().callEvent((Event)new IslandUpgradeEvent(this, upgrade, integer.intValue()));
/* 111 */       stream(false).forEach(p -> p.sendMessage("§a" + player.getName() + " adquiriu a melhoria: §e" + Language.getLanguage(p.getUniqueId()).t("inventory-upgrade-" + upgrade.name().toLowerCase().replace("_", "-"), new String[] { "%level%", "" + integer })));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 119 */     this.upgradeMap.put(upgrade, integer);
/*     */   }
/*     */   
/*     */   public void removeUpgrade(IslandUpgrade islandUpgrade) {
/* 123 */     this.upgradeMap.remove(islandUpgrade);
/*     */   }
/*     */   
/*     */   public Integer getUpgradeLevel(IslandUpgrade upgrade) {
/* 127 */     return this.upgradeMap.computeIfAbsent(upgrade, v -> Integer.valueOf(0));
/*     */   }
/*     */   
/*     */   public boolean hasUpgrade(IslandUpgrade upgrade) {
/* 131 */     return this.upgradeMap.containsKey(upgrade);
/*     */   }
/*     */   
/*     */   public void handleBreakBed(Player player) {
/* 135 */     if (this.islandStatus == IslandStatus.ALIVE) {
/* 136 */       if (player != null) {
/* 137 */         Island island = GameMain.getInstance().getIslandManager().getIsland(player.getUniqueId());
/*     */         
/* 139 */         if (island == null) {
/*     */           return;
/*     */         }
/* 142 */         Bukkit.getOnlinePlayers().forEach(p -> {
/*     */               Language language = Language.getLanguage(p.getUniqueId());
/*     */ 
/*     */               
/*     */               p.sendMessage(language.t("bedwars.island-bed-broke", new String[] { "%island%", language.t(this.islandColor.name().toLowerCase() + "-name", new String[0]), "%islandColor%", "§" + this.islandColor.getColor().getChar(), "%enimyIsland%", StringFormat.formatString(island.getIslandColor().name()), "%enimyIslandColor%", "§" + island.getIslandColor().getColor().getChar(), "%player%", player.getName() }));
/*     */ 
/*     */               
/*     */               p.playSound(p.getLocation(), Sound.ENDERDRAGON_HIT, 1.0F, 1.0F);
/*     */             });
/*     */       } 
/*     */       
/* 153 */       stream(false).forEach(p -> {
/*     */             PlayerHelper.title(p, "§c§lCAMA DESTRUIDA", "§7Você não renascerá mais.");
/*     */             
/*     */             p.getWorld().playSound(p.getLocation(), Sound.ENDERDRAGON_GROWL, 1.0F, 1.0F);
/*     */           });
/* 158 */       this.islandStatus = IslandStatus.BED_BROKEN;
/* 159 */       Bukkit.getPluginManager().callEvent((Event)new IslandBedBreakEvent(player, this));
/*     */       
/* 161 */       if (stream(false).count() == 0L) {
/* 162 */         handleLose();
/*     */       }
/* 164 */       for (Location location : GameMain.getInstance()
/* 165 */         .getNearestBlocksByMaterial(this.bedLocation.getAsLocation(), Material.BED_BLOCK, 4, 2)) {
/* 166 */         location.getBlock().setType(Material.AIR);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void handleLose() {
/* 172 */     if (this.islandStatus != IslandStatus.LOSER) {
/* 173 */       Bukkit.getOnlinePlayers().forEach(p -> {
/*     */             Language language = Language.getLanguage(p.getUniqueId());
/*     */             
/*     */             p.sendMessage(language.t("bedwars.island-lost", new String[] { "%island%", language.t(this.islandColor.name().toLowerCase() + "-name", new String[0]), "%islandColor%", "§" + this.islandColor.getColor().getChar() }));
/*     */           });
/*     */       
/* 179 */       this.islandStatus = IslandStatus.LOSER;
/* 180 */       Bukkit.getPluginManager().callEvent((Event)new IslandLoseEvent(this));
/*     */       
/* 182 */       if (this.bedLocation.getAsLocation().getBlock().getType() == Material.BED_BLOCK) {
/* 183 */         this.bedLocation.getAsLocation().getBlock().setType(Material.AIR);
/*     */       }
/* 185 */       for (UUID id : getTeam().getPlayerSet()) {
/* 186 */         Status status = CommonPlugin.getInstance().getStatusManager().loadStatus(id, StatusType.BEDWARS);
/*     */         
/* 188 */         status.setInteger((Enum)BedwarsCategory.BEDWARS_WINSTREAK, 0);
/* 189 */         status.setInteger(BedwarsCategory.BEDWARS_WINSTREAK.getSpecialServer(), 0);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void startIsland() {
/* 195 */     loadPlayers();
/* 196 */     loadGenerators();
/* 197 */     loadNpc();
/* 198 */     GameAPI.getInstance().debug("The island " + getIslandColor() + " has been loaded.");
/*     */   }
/*     */   
/*     */   public void loadNpc() {
/* 202 */     GameMain.getInstance().createCharacter(getShopLocation().getAsLocation(), "ZAKl1k", (player, right) -> {
/*     */           new StoreInventory(player);
/*     */           return false;
/* 205 */         }).setDisplayName("§b§lLOJA").line("§eClique para ver mais.");
/* 206 */     GameMain.getInstance().createCharacter(getUpgradeLocation().getAsLocation(), "Kotcka", (player, right) -> {
/*     */           new UpgradeInventory(player);
/*     */           return false;
/* 209 */         }).setDisplayName("§b§lMELHORIAS").line("§eClique para ver mais.");
/*     */   }
/*     */   
/*     */   public void loadPlayers() {
/* 213 */     for (UUID uuid : getTeam().getPlayerSet()) {
/* 214 */       Player player = Bukkit.getPlayer(uuid);
/* 215 */       Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/*     */       
/* 217 */       gamer.setAlive(true);
/*     */       
/* 219 */       player.teleport(getSpawnLocation().getAsLocation());
/* 220 */       player.playSound(player.getLocation(), Sound.FALL_BIG, 1.0F, 1.0F);
/*     */       
/* 222 */       GamerHelper.handlePlayerToGame(player);
/*     */       
/* 224 */       for (Player o : Bukkit.getOnlinePlayers()) {
/* 225 */         ScoreboardAPI.joinTeam(
/* 226 */             ScoreboardAPI.createTeamIfNotExistsToPlayer(o, GameMain.getInstance().getId(this), 
/* 227 */               GameMain.getInstance().getTag(this, Language.getLanguage(o.getUniqueId())), ""), player);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void loadGenerators() {
/* 234 */     for (Map.Entry<Material, List<Location>> entry : getGeneratorMap().entrySet()) {
/* 235 */       for (Location generatorLocation : entry.getValue()) {
/* 236 */         NormalGenerator normalGenerator = new NormalGenerator(generatorLocation.getAsLocation(), entry.getKey());
/*     */         
/* 238 */         if (entry.getKey() == Material.IRON_INGOT) {
/* 239 */           normalGenerator.setGenerateTime((GameMain.getInstance().getPlayersPerTeam() == 1) ? 2000L : 1500L);
/* 240 */         } else if (entry.getKey() == Material.GOLD_INGOT) {
/* 241 */           normalGenerator.setGenerateTime((GameMain.getInstance().getPlayersPerTeam() == 1) ? 8000L : 6000L);
/*     */         } 
/*     */         
/* 244 */         getIslandGenerators().add(normalGenerator);
/* 245 */         GameMain.getInstance().getGeneratorManager().addGenerator((Generator)normalGenerator);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void checkLose() {
/* 251 */     if (this.islandStatus == IslandStatus.BED_BROKEN) {
/* 252 */       boolean alive = false;
/*     */       
/* 254 */       for (UUID uuid : getTeam().getPlayerSet()) {
/* 255 */         Gamer g = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(uuid, Gamer.class);
/*     */         
/* 257 */         if (g.isAlive()) {
/* 258 */           alive = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 263 */       if (!alive)
/* 264 */         handleLose(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Stream<Player> stream(boolean nullable) {
/* 269 */     if (nullable) {
/* 270 */       return getTeam().getPlayerSet().stream().map(id -> Bukkit.getPlayer(id));
/*     */     }
/* 272 */     return getTeam().getPlayerSet().stream().map(id -> Bukkit.getPlayer(id)).filter(player -> (player != null));
/*     */   }
/*     */   
/*     */   public void broadcast(String message) {
/* 276 */     getTeam().getPlayerSet().stream().map(id -> Bukkit.getPlayer(id)).forEach(player -> {
/*     */           if (player != null) {
/*     */             player.sendMessage(message);
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/* 284 */     if (obj instanceof Island) {
/* 285 */       Island island = (Island)obj;
/*     */       
/* 287 */       return (island.getIslandColor() == this.islandColor);
/*     */     } 
/*     */     
/* 290 */     return super.equals(obj);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 295 */     return CommonConst.GSON.toJson(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Island clone() {
/* 300 */     return new Island(this.islandColor, this.spawnLocation, this.bedLocation, this.shopLocation, this.upgradeLocation, this.generatorMap, null, null, null, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public enum IslandStatus
/*     */   {
/* 306 */     ALIVE, BED_BROKEN, LOSER;
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/island/Island.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */