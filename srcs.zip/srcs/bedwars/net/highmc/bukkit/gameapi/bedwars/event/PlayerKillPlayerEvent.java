/*    */ package net.highmc.bukkit.gameapi.bedwars.event;
/*    */ 
/*    */ import lombok.NonNull;
/*    */ import net.highmc.bukkit.event.PlayerEvent;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class PlayerKillPlayerEvent extends PlayerEvent {
/*    */   private Player killer;
/*    */   private boolean finalKill;
/*    */   
/*    */   public Player getKiller() {
/* 12 */     return this.killer; } public boolean isFinalKill() {
/* 13 */     return this.finalKill;
/*    */   }
/*    */   public PlayerKillPlayerEvent(@NonNull Player player, Player killer, boolean finalKill) {
/* 16 */     super(player); if (player == null)
/* 17 */       throw new NullPointerException("player is marked non-null but is null");  this.killer = killer;
/* 18 */     this.finalKill = finalKill;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/event/PlayerKillPlayerEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */