/*    */ package net.highmc.bukkit.gameapi.bedwars.event;
/*    */ 
/*    */ import lombok.NonNull;
/*    */ import net.highmc.bukkit.event.PlayerEvent;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class PlayerSpectateEvent
/*    */   extends PlayerEvent
/*    */ {
/*    */   public PlayerSpectateEvent(@NonNull Player player) {
/* 11 */     super(player);
/*    */     if (player == null)
/*    */       throw new NullPointerException("player is marked non-null but is null"); 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/event/PlayerSpectateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */