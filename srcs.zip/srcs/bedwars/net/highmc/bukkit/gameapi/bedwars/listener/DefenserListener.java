/*     */ package net.highmc.bukkit.gameapi.bedwars.listener;
/*     */ 
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import net.highmc.bukkit.event.UpdateEvent;
/*     */ import net.highmc.bukkit.gameapi.bedwars.GameMain;
/*     */ import net.highmc.bukkit.gameapi.bedwars.gamer.Gamer;
/*     */ import net.highmc.bukkit.gameapi.bedwars.island.Island;
/*     */ import net.highmc.bukkit.gameapi.bedwars.island.IslandColor;
/*     */ import net.highmc.bukkit.gameapi.bedwars.utils.ProgressBar;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.utils.string.StringFormat;
/*     */ import net.minecraft.server.v1_8_R3.AttributeInstance;
/*     */ import net.minecraft.server.v1_8_R3.AttributeModifier;
/*     */ import net.minecraft.server.v1_8_R3.EntityLiving;
/*     */ import net.minecraft.server.v1_8_R3.GenericAttributes;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.craftbukkit.v1_8_R3.entity.CraftEntity;
/*     */ import org.bukkit.entity.Creature;
/*     */ import org.bukkit.entity.Damageable;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.entity.Projectile;
/*     */ import org.bukkit.entity.Silverfish;
/*     */ import org.bukkit.entity.Snowball;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.block.Action;
/*     */ import org.bukkit.event.entity.EntityChangeBlockEvent;
/*     */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*     */ import org.bukkit.event.entity.EntityDeathEvent;
/*     */ import org.bukkit.event.entity.EntityTargetEvent;
/*     */ import org.bukkit.event.entity.PlayerDeathEvent;
/*     */ import org.bukkit.event.entity.ProjectileHitEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefenserListener
/*     */   implements Listener
/*     */ {
/*     */   private static final long IRONGOLEM_TIME = 240000L;
/*     */   private static final long SILVERFISH_TIME = 30000L;
/*  57 */   private Map<Entity, Defenser> defenserMap = new HashMap<>();
/*     */   
/*     */   @EventHandler
/*     */   public void onProjectileHit(ProjectileHitEvent event) {
/*  61 */     if (event.getEntity() instanceof Snowball) {
/*  62 */       Snowball snowball = (Snowball)event.getEntity();
/*     */       
/*  64 */       if (snowball.getShooter() instanceof Player) {
/*  65 */         Player player = (Player)snowball.getShooter();
/*  66 */         Island island = GameMain.getInstance().getIslandManager().getIsland(player.getUniqueId());
/*     */         
/*  68 */         if (island == null) {
/*     */           return;
/*     */         }
/*  71 */         Location location = event.getEntity().getLocation();
/*  72 */         Silverfish silverfish = (Silverfish)location.getWorld().spawn(location, Silverfish.class);
/*     */         
/*  74 */         long time = System.currentTimeMillis() + 30000L;
/*  75 */         int leftTime = (int)(time % System.currentTimeMillis()) / 1000;
/*     */         
/*  77 */         silverfish.setCustomName("§7[" + 
/*  78 */             ProgressBar.getProgressBar(silverfish.getHealth(), silverfish.getMaxHealth(), 5, '▮', ChatColor.AQUA, ChatColor.GRAY) + "§7] §b" + 
/*     */             
/*  80 */             StringFormat.formatTime(leftTime, StringFormat.TimeFormat.SHORT));
/*  81 */         silverfish.setCustomNameVisible(true);
/*     */         
/*  83 */         EntityLiving en = (EntityLiving)((CraftEntity)silverfish).getHandle();
/*  84 */         AttributeInstance speed = en.getAttributeInstance(GenericAttributes.MOVEMENT_SPEED);
/*  85 */         AttributeModifier speedModifier = new AttributeModifier(silverfish.getUniqueId(), "SpeedIncreaser", 1.4D, 1);
/*     */         
/*  87 */         speed.b(speedModifier);
/*  88 */         speed.a(speedModifier);
/*  89 */         this.defenserMap.put(silverfish, new Defenser(island.getIslandColor(), time));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onEntityChangeBlock(EntityChangeBlockEvent event) {
/*  96 */     if (event.getEntity().getType().equals(EntityType.SILVERFISH))
/*  97 */       event.setCancelled(true); 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerInteract(PlayerInteractEvent event) {
/* 102 */     if (event.getItem() == null || event.getAction() != Action.RIGHT_CLICK_BLOCK || event
/* 103 */       .getItem().getType() != Material.MONSTER_EGG) {
/*     */       return;
/*     */     }
/* 106 */     Player player = event.getPlayer();
/* 107 */     Island island = GameMain.getInstance().getIslandManager().getIsland(player.getUniqueId());
/*     */     
/* 109 */     if (island == null) {
/* 110 */       event.setCancelled(true);
/*     */       
/*     */       return;
/*     */     } 
/* 114 */     ItemStack itemStack = event.getItem();
/* 115 */     player.setItemInHand(
/* 116 */         ItemBuilder.fromStack(itemStack).type((itemStack.getAmount() > 1) ? itemStack.getType() : Material.AIR)
/* 117 */         .amount(itemStack.getAmount() - 1).build());
/*     */     
/* 119 */     long time = System.currentTimeMillis() + 240000L;
/* 120 */     int leftTime = (int)(time % System.currentTimeMillis()) / 1000;
/*     */     
/* 122 */     EntityType entityType = EntityType.IRON_GOLEM;
/*     */     
/* 124 */     Entity spawnEntity = event.getClickedBlock().getLocation().getWorld().spawnEntity(event.getClickedBlock().getLocation().clone().add(0.0D, 1.5D, 0.0D), entityType);
/*     */     
/* 126 */     this.defenserMap.put(spawnEntity, new Defenser(island
/* 127 */           .getIslandColor(), System.currentTimeMillis() + 240000L));
/*     */     
/* 129 */     spawnEntity.setCustomName("§7[" + 
/* 130 */         ProgressBar.getProgressBar((int)((Damageable)spawnEntity).getHealth(), 
/* 131 */           (int)((Damageable)spawnEntity).getMaxHealth(), 5, '▮', ChatColor.AQUA, ChatColor.GRAY) + "§7] §b" + 
/* 132 */         StringFormat.formatTime(leftTime, StringFormat.TimeFormat.SHORT));
/* 133 */     spawnEntity.setCustomNameVisible(true);
/* 134 */     ((Damageable)spawnEntity).setMaxHealth(20.0D);
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
/*     */   public void onEntityDamageEntity(EntityDamageByEntityEvent event) {
/* 139 */     if (event.getDamager() instanceof Player || event.getDamager() instanceof Projectile) {
/* 140 */       Entity entity = event.getEntity();
/*     */       
/* 142 */       Player player = (event.getDamager() instanceof Player) ? (Player)event.getDamager() : (Player)((Projectile)event.getDamager()).getShooter();
/*     */       
/* 144 */       Island island = GameMain.getInstance().getIslandManager().getIsland(player.getUniqueId());
/*     */       
/* 146 */       if (island != null && this.defenserMap.containsKey(entity) && ((Defenser)this.defenserMap
/* 147 */         .get(entity)).getIsland() == island.getIslandColor())
/* 148 */         event.setCancelled(true); 
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerDeath(PlayerDeathEvent event) {
/* 154 */     Player player = event.getEntity();
/*     */     
/* 156 */     ImmutableList.copyOf(this.defenserMap.keySet()).stream().map(entity -> (Creature)entity)
/* 157 */       .filter(entity -> (entity.getTarget().getUniqueId() == player.getUniqueId())).forEach(entity -> entity.setTarget(null));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onEntityTarget(EntityTargetEvent event) {
/* 164 */     if (!(event.getTarget() instanceof Player)) {
/*     */       return;
/*     */     }
/*     */     
/* 168 */     Player player = (Player)event.getTarget();
/*     */     
/* 170 */     Island island = GameMain.getInstance().getIslandManager().getIsland(player.getUniqueId());
/*     */     
/* 172 */     if (island == null) {
/* 173 */       event.setCancelled(true);
/*     */       
/*     */       return;
/*     */     } 
/* 177 */     Entity entity = event.getEntity();
/*     */     
/* 179 */     if (this.defenserMap.containsKey(entity)) {
/* 180 */       Defenser defenser = this.defenserMap.get(entity);
/*     */       
/* 182 */       if (defenser.getIsland() == island.getIslandColor())
/* 183 */         event.setCancelled(true); 
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onEntityDeath(EntityDeathEvent event) {
/* 189 */     LivingEntity livingEntity = event.getEntity();
/*     */     
/* 191 */     if (this.defenserMap.containsKey(livingEntity))
/* 192 */       this.defenserMap.remove(livingEntity); 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onUpdate(UpdateEvent event) {
/* 197 */     if (event.getType() == UpdateEvent.UpdateType.SECOND) {
/* 198 */       Iterator<Map.Entry<Entity, Defenser>> iterator = this.defenserMap.entrySet().iterator();
/*     */       
/* 200 */       while (iterator.hasNext()) {
/* 201 */         Map.Entry<Entity, Defenser> entry = iterator.next();
/* 202 */         Entity entity = entry.getKey();
/* 203 */         int leftTime = (int)(((Defenser)entry.getValue()).getExpireTime() - System.currentTimeMillis()) / 1000;
/*     */         
/* 205 */         if (leftTime > 0) {
/* 206 */           Creature creature = (Creature)entity;
/*     */           
/* 208 */           if (creature.getTarget() != null && creature
/* 209 */             .getTarget().getLocation().distance(entity.getLocation()) > 20.0D) {
/* 210 */             creature.setTarget(null);
/*     */           }
/* 212 */           if (creature.getTarget() == null)
/* 213 */             for (Gamer gamer : GameMain.getInstance().getAlivePlayers()) {
/* 214 */               if (gamer.isOnline() && gamer.isAlive()) {
/* 215 */                 Player player = gamer.getPlayer();
/*     */                 
/* 217 */                 if (GameMain.getInstance().getIslandManager().getIsland(player.getUniqueId())
/* 218 */                   .getIslandColor() != ((Defenser)entry.getValue()).getIsland() && 
/* 219 */                   player.getLocation().distance(entity.getLocation()) <= 10.0D)
/* 220 */                   creature.setTarget((LivingEntity)player); 
/*     */               } 
/*     */             }  
/* 223 */           entity.setCustomName("§7[" + 
/* 224 */               ProgressBar.getProgressBar((int)((Damageable)entity).getHealth(), 
/* 225 */                 (int)((Damageable)entity).getMaxHealth(), 5, '▮', ChatColor.AQUA, ChatColor.GRAY) + "§7] §b" + 
/* 226 */               StringFormat.formatTime(leftTime, StringFormat.TimeFormat.SHORT)); continue;
/*     */         } 
/* 228 */         entity.remove();
/* 229 */         iterator.remove();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   public class Defenser { private final IslandColor island;
/*     */     
/*     */     public Defenser(IslandColor island, long expireTime) {
/* 236 */       this.island = island; this.expireTime = expireTime;
/*     */     }
/*     */     private long expireTime;
/*     */     public IslandColor getIsland() {
/* 240 */       return this.island; } public long getExpireTime() {
/* 241 */       return this.expireTime;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/listener/DefenserListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */