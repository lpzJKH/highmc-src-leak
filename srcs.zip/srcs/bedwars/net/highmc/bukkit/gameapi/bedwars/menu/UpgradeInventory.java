/*     */ package net.highmc.bukkit.gameapi.bedwars.menu;
/*     */ 
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.gameapi.GameAPI;
/*     */ import net.highmc.bukkit.gameapi.bedwars.GameMain;
/*     */ import net.highmc.bukkit.gameapi.bedwars.gamer.Gamer;
/*     */ import net.highmc.bukkit.gameapi.bedwars.island.Island;
/*     */ import net.highmc.bukkit.gameapi.bedwars.island.IslandUpgrade;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*     */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*     */ import net.highmc.bukkit.utils.menu.click.MenuClickHandler;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.utils.string.StringFormat;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ 
/*     */ public class UpgradeInventory
/*     */ {
/*     */   public UpgradeInventory(final Player player) {
/*  26 */     Island island = GameMain.getInstance().getIslandManager().getIsland(player.getUniqueId());
/*     */     
/*  28 */     if (island == null) {
/*     */       return;
/*     */     }
/*  31 */     Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/*     */     
/*  33 */     if (!gamer.isAlive()) {
/*     */       return;
/*     */     }
/*     */     
/*  37 */     MenuInventory menuInventory = new MenuInventory("§7Loja do Time", 3);
/*     */     
/*  39 */     for (int i = 0; i < (IslandUpgrade.values()).length; i++) {
/*  40 */       IslandUpgrade upgrade = IslandUpgrade.values()[i];
/*     */       
/*  42 */       handleUpgrade(player, CommonPlugin.getInstance().getPluginInfo().getDefaultLanguage(), island, 10 + i, menuInventory, upgrade);
/*     */     } 
/*     */ 
/*     */     
/*  46 */     menuInventory.open(player);
/*  47 */     (new BukkitRunnable()
/*     */       {
/*     */         public void run()
/*     */         {
/*  51 */           player.updateInventory();
/*     */         }
/*  53 */       }).runTaskLater((Plugin)GameAPI.getInstance(), 1L);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleUpgrade(final Player player, final Language language, final Island island, int slot, MenuInventory menuInventory, final IslandUpgrade upgrade) {
/*  59 */     String lore = "§7" + language.t("inventory-upgrade-" + upgrade.name().toLowerCase().replace("_", "-") + "-description", new String[0]);
/*     */     
/*  61 */     for (int k = 1; k <= upgrade.getMaxLevel(); k++) {
/*  62 */       lore = lore.replace("%price-" + k + "%", "" + upgrade.getLevelsCost()[k - 1]).replace("%check-" + k + "%", 
/*  63 */           (island.getUpgradeLevel(upgrade).intValue() < k) ? "§c✗" : "§a✓");
/*     */     }
/*     */     
/*  66 */     boolean maxLevel = (island.getUpgradeLevel(upgrade).intValue() == upgrade.getMaxLevel());
/*     */     
/*  68 */     boolean enoughDiamonds = maxLevel ? true : player.getInventory().contains(Material.DIAMOND, upgrade.getLevelsCost()[
/*  69 */           Math.min(island.getUpgradeLevel(upgrade).intValue(), (upgrade.getLevelsCost()).length - 1)]);
/*     */     
/*  71 */     lore = lore.replace("%buy%", maxLevel ? language
/*  72 */         .t("inventory-upgrade-max-level-reach-buy", new String[0]) : (
/*  73 */         player.getInventory().contains(Material.DIAMOND, upgrade
/*  74 */           .getLevelsCost()[island.getUpgradeLevel(upgrade).intValue()]) ? language
/*  75 */         .t("inventory-upgrade-diamond-enough", new String[0]) : language
/*  76 */         .t("inventory-upgrade-not-diamond-enough", new String[0])));
/*     */ 
/*     */     
/*  79 */     String level = (upgrade.getMaxLevel() == 1) ? "" : ("" + (maxLevel ? island.getUpgradeLevel(upgrade).intValue() : (island.getUpgradeLevel(upgrade).intValue() + 1)));
/*     */     
/*  81 */     menuInventory.setItem(slot, (new ItemBuilder()).type(upgrade.getIcon())
/*  82 */         .name((maxLevel ? "§a" : (enoughDiamonds ? "§e" : "§c")) + language
/*  83 */           .t("inventory-upgrade-" + upgrade.name().toLowerCase().replace("_", "-"), new String[] { "%level%", level
/*  84 */             })).lore(lore).build(), new MenuClickHandler()
/*     */         {
/*     */           public void onClick(Player p, Inventory inv, ClickType type, ItemStack stack, int slot)
/*     */           {
/*  88 */             if (island.getUpgradeLevel(upgrade).intValue() == upgrade.getMaxLevel()) {
/*  89 */               player.sendMessage(language.t("inventory-upgrade-max-level-reach", new String[] { "%upgrade%", 
/*  90 */                       StringFormat.formatToCamelCase(this.val$upgrade.name().replace("_", " ")) }));
/*  91 */               player.playSound(player.getLocation(), Sound.NOTE_BASS, 1.0F, 1.0F);
/*     */             }
/*  93 */             else if (player.getInventory().contains(Material.DIAMOND, upgrade.getLevelsCost()[
/*  94 */                   Math.min(island.getUpgradeLevel(upgrade).intValue(), (upgrade.getLevelsCost()).length - 1)])) {
/*  95 */               player.getInventory().removeItem(new ItemStack[] { new ItemStack(Material.DIAMOND, this.val$upgrade
/*  96 */                       .getLevelsCost()[this.val$island.getUpgradeLevel(this.val$upgrade).intValue()]) });
/*  97 */               island.upgrade(player, upgrade);
/*  98 */               player.playSound(player.getLocation(), Sound.LEVEL_UP, 1.0F, 1.0F);
/*  99 */               new UpgradeInventory(player);
/*     */             } else {
/* 101 */               player.sendMessage("§%inventory-upgrade-you-doesnt-have-enough-diamond%§");
/* 102 */               player.playSound(player.getLocation(), Sound.NOTE_BASS, 1.0F, 1.0F);
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/menu/UpgradeInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */