/*    */ package net.highmc.bukkit.gameapi.bedwars.event.island;
/*    */ import net.highmc.bukkit.event.NormalEvent;
/*    */ import net.highmc.bukkit.gameapi.bedwars.island.Island;
/*    */ import net.highmc.bukkit.gameapi.bedwars.island.IslandUpgrade;
/*    */ 
/*    */ public class IslandUpgradeEvent extends NormalEvent {
/*    */   private Island island;
/*    */   
/*    */   public IslandUpgradeEvent(Island island, IslandUpgrade upgrade, int level) {
/* 10 */     this.island = island; this.upgrade = upgrade; this.level = level;
/*    */   } private IslandUpgrade upgrade; private int level;
/*    */   public Island getIsland() {
/* 13 */     return this.island; }
/* 14 */   public IslandUpgrade getUpgrade() { return this.upgrade; } public int getLevel() {
/* 15 */     return this.level;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/event/island/IslandUpgradeEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */