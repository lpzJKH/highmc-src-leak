/*    */ package net.highmc.bukkit.gameapi.bedwars.generator.impl;
/*    */ 
/*    */ import net.highmc.bukkit.gameapi.bedwars.generator.Generator;
/*    */ import net.highmc.bukkit.gameapi.bedwars.generator.GeneratorType;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NormalGenerator
/*    */   extends Generator
/*    */ {
/*    */   public NormalGenerator(Location location, Material material) {
/* 15 */     super(location, GeneratorType.NORMAL, new ItemStack(material));
/*    */   }
/*    */ 
/*    */   
/*    */   public Location getDropLocation() {
/* 20 */     if (getDropsLocation().isEmpty()) {
/* 21 */       return getLocation();
/*    */     }
/* 23 */     if (getDropsLocation().size() <= 1) {
/* 24 */       return getDropsLocation().stream().findFirst().orElse(null);
/*    */     }
/*    */     
/* 27 */     return getDropsLocation().get((++this.dropIndex >= getDropsLocation().size()) ? (this.dropIndex = 0) : this.dropIndex);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/generator/impl/NormalGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */