/*    */ package net.highmc.bukkit.gameapi.bedwars.utils;
/*    */ 
/*    */ import com.google.common.base.Strings;
/*    */ import org.bukkit.ChatColor;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProgressBar
/*    */ {
/*    */   public static String getProgressBar(double current, double max, int totalBars, char symbol, ChatColor completedColor, ChatColor notCompletedColor) {
/* 11 */     float percent = (float)((float)current / max);
/* 12 */     int progressBars = (int)(totalBars * percent);
/*    */     
/* 14 */     return Strings.repeat("" + completedColor + symbol, progressBars) + 
/* 15 */       Strings.repeat("" + notCompletedColor + symbol, totalBars - progressBars);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/utils/ProgressBar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */