/*     */ package net.highmc.bukkit.gameapi.bedwars.menu.creator;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.highmc.bukkit.gameapi.bedwars.island.Island;
/*     */ import net.highmc.bukkit.utils.Location;
/*     */ import net.highmc.bukkit.utils.item.ActionItemStack;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*     */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*     */ import net.highmc.bukkit.utils.menu.confirm.ConfirmInventory;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.utils.string.StringFormat;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ public class IslandCreatorGeneratorInventory
/*     */ {
/*     */   public IslandCreatorGeneratorInventory(Player player, Island island) {
/*  26 */     Language language = Language.getLanguage(player.getUniqueId());
/*  27 */     MenuInventory menuInventory = new MenuInventory(language.t("bedwars.inventory.island-generator.title", new String[0]), 4);
/*     */     
/*  29 */     handleItems(player, menuInventory, island);
/*     */     
/*  31 */     menuInventory.setItem(27, (new ItemBuilder()).type(Material.ARROW).name("§%back%§").build(), (p, inv, type, stack, slot) -> new IslandCreatorInventory(player, island));
/*     */ 
/*     */     
/*  34 */     menuInventory.open(player);
/*     */   }
/*     */   
/*     */   private void handleItems(Player player, MenuInventory menuInventory, Island island) {
/*  38 */     List<Location> ironList = island.getGeneratorMap().computeIfAbsent(Material.IRON_INGOT, v -> new ArrayList());
/*  39 */     List<Location> goldList = island.getGeneratorMap().computeIfAbsent(Material.GOLD_INGOT, v -> new ArrayList());
/*     */     
/*  41 */     for (int i = 0; i < 7; i++) {
/*  42 */       Location ironLocation = (i >= ironList.size()) ? null : ironList.get(i);
/*  43 */       int index = i;
/*     */       
/*  45 */       if (ironLocation == null) {
/*  46 */         menuInventory.setItem(10 + i, (new ItemBuilder())
/*  47 */             .name("§c§%empty-slot%§").lore("§7Click to create new generator")
/*  48 */             .type(Material.STAINED_GLASS_PANE).durability(14).build(), (p, inv, type, stack, slot) -> {
/*     */               ironList.add(Location.fromLocation(player.getLocation()));
/*     */               
/*     */               handleItems(player, menuInventory, island);
/*     */             });
/*     */       } else {
/*  54 */         menuInventory.setItem(10 + i, createItem("§7Iron " + (i + 1), ironLocation), (p, inv, type, stack, slot) -> {
/*     */               if (type == ClickType.RIGHT) {
/*     */                 p.teleport(ironLocation.getAsLocation());
/*     */               } else if (type == ClickType.SHIFT) {
/*     */                 ironList.remove(index);
/*     */                 
/*     */                 handleItems(player, menuInventory, island);
/*     */               } else {
/*     */                 handle(player, stack, ironLocation, island);
/*     */               } 
/*     */             });
/*     */       } 
/*  66 */       Location goldLocation = (i >= goldList.size()) ? null : goldList.get(i);
/*     */       
/*  68 */       if (goldLocation == null) {
/*  69 */         menuInventory.setItem(19 + i, (new ItemBuilder())
/*  70 */             .name("§c§%empty-slot%§").lore("§7Click to create new generator")
/*  71 */             .type(Material.STAINED_GLASS_PANE).durability(14).build(), (p, inv, type, stack, slot) -> {
/*     */               goldList.add(Location.fromLocation(player.getLocation()));
/*     */               
/*     */               handleItems(player, menuInventory, island);
/*     */             });
/*     */       } else {
/*  77 */         menuInventory.setItem(19 + i, createItem("§7Gold " + (i + 1), goldLocation), (p, inv, type, stack, slot) -> {
/*     */               if (type == ClickType.RIGHT) {
/*     */                 p.teleport(goldLocation.getAsLocation());
/*     */               } else if (type == ClickType.SHIFT) {
/*     */                 goldList.remove(index);
/*     */                 handleItems(player, menuInventory, island);
/*     */               } else {
/*     */                 handle(player, stack, goldLocation, island);
/*     */               } 
/*     */             });
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private ItemStack createItem(String name, Location location) {
/*  92 */     return (new ItemBuilder()).name(name).type(name.contains("Gold") ? Material.GOLD_INGOT : Material.IRON_INGOT)
/*  93 */       .lore(new String[] { "§fWorld: §7" + location.getWorldName(), "§fLocation: §7" + 
/*     */           
/*  95 */           StringFormat.formatString(", ", new Number[] { Double.valueOf(location.getX()), Double.valueOf(location.getY()), Double.valueOf(location.getZ()) }), "§fYaw: §7" + location
/*  96 */           .getYaw(), "§fPitch: §7" + location.getPitch()
/*  97 */         }).build();
/*     */   }
/*     */   
/*     */   public void handle(Player player, final ItemStack itemStack, final Location location, final Island island) {
/* 101 */     player.getInventory().addItem(new ItemStack[] { (new ActionItemStack(itemStack, new ActionItemStack.Interact()
/*     */             {
/*     */               public boolean onInteract(Player player, Entity entity, Block block, ItemStack item, ActionItemStack.ActionType action)
/*     */               {
/* 105 */                 new ConfirmInventory(player, itemStack.getItemMeta().getDisplayName(), b -> { if (b) { Location newLocation; if (block == null) { newLocation = player.getLocation(); } else { newLocation = block.getLocation(); }  location.set(newLocation); }  while (player.getInventory().contains(itemStack)) player.getInventory().remove(itemStack);  ActionItemStack.unregisterHandler(this); new IslandCreatorGeneratorInventory(player, island); }null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 126 */                 return false;
/*     */               }
/* 128 */             })).getItemStack() });
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/menu/creator/IslandCreatorGeneratorInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */