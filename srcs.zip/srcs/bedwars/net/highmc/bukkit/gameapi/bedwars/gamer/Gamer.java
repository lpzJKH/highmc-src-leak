/*     */ package net.highmc.bukkit.gameapi.bedwars.gamer;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.gameapi.bedwars.GameMain;
/*     */ import net.highmc.bukkit.gameapi.bedwars.event.PlayerLevelUpEvent;
/*     */ import net.highmc.bukkit.gameapi.bedwars.store.ShopCategory;
/*     */ import net.highmc.bukkit.gameapi.gamer.Gamer;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.member.status.Status;
/*     */ import net.highmc.member.status.StatusType;
/*     */ import net.highmc.member.status.types.BedwarsCategory;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.enchantments.Enchantment;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Gamer
/*     */   extends Gamer
/*     */ {
/*     */   public void setFavoriteMap(Map<ShopCategory, Set<Integer>> favoriteMap) {
/*  31 */     this.favoriteMap = favoriteMap; } public void setAlive(boolean alive) { this.alive = alive; } public void setSpectator(boolean spectator) { this.spectator = spectator; } public void setShears(boolean shears) { this.shears = shears; } public void setSwordLevel(SwordLevel swordLevel) { this.swordLevel = swordLevel; } public void setPickaxeLevel(PickaxeLevel pickaxeLevel) { this.pickaxeLevel = pickaxeLevel; } public void setAxeLevel(AxeLevel axeLevel) { this.axeLevel = axeLevel; } public void setArmorLevel(ArmorLevel armorLevel) { this.armorLevel = armorLevel; } public void setKills(int kills) { this.kills = kills; } public void setFinalKills(int finalKills) { this.finalKills = finalKills; } public void setBrokenBeds(int brokenBeds) { this.brokenBeds = brokenBeds; } public void setTeamChat(boolean teamChat) { this.teamChat = teamChat; }
/*     */   
/*     */   private transient boolean alive; private transient boolean spectator; private transient boolean shears; private transient SwordLevel swordLevel; private transient PickaxeLevel pickaxeLevel; private transient AxeLevel axeLevel;
/*  34 */   private Map<ShopCategory, Set<Integer>> favoriteMap = new HashMap<>(); private transient ArmorLevel armorLevel; private transient int kills; private transient int finalKills; private transient int brokenBeds; private boolean teamChat; public Map<ShopCategory, Set<Integer>> getFavoriteMap() { return this.favoriteMap; }
/*     */   
/*     */   public boolean isSpectator() {
/*  37 */     return this.spectator;
/*     */   } public boolean isShears() {
/*  39 */     return this.shears;
/*     */   }
/*  41 */   public SwordLevel getSwordLevel() { return this.swordLevel; }
/*  42 */   public PickaxeLevel getPickaxeLevel() { return this.pickaxeLevel; }
/*  43 */   public AxeLevel getAxeLevel() { return this.axeLevel; } public ArmorLevel getArmorLevel() {
/*  44 */     return this.armorLevel;
/*     */   }
/*  46 */   public int getKills() { return this.kills; }
/*  47 */   public int getFinalKills() { return this.finalKills; } public int getBrokenBeds() {
/*  48 */     return this.brokenBeds;
/*     */   } public boolean isTeamChat() {
/*  50 */     return this.teamChat;
/*     */   }
/*     */   public Gamer(String playerName, UUID uniqueId) {
/*  53 */     super(playerName, uniqueId);
/*  54 */     loadGamer();
/*     */   }
/*     */ 
/*     */   
/*     */   public void loadGamer() {
/*  59 */     super.loadGamer();
/*     */     
/*  61 */     this.alive = false;
/*  62 */     this.spectator = false;
/*     */     
/*  64 */     this.shears = false;
/*  65 */     this.swordLevel = SwordLevel.WOOD;
/*  66 */     this.pickaxeLevel = PickaxeLevel.NONE;
/*  67 */     this.axeLevel = AxeLevel.NONE;
/*  68 */     this.armorLevel = ArmorLevel.LEATHER;
/*     */     
/*  70 */     this.kills = 0;
/*  71 */     this.finalKills = 0;
/*  72 */     this.brokenBeds = 0;
/*     */   }
/*     */   
/*     */   public void addBedBroken() {
/*  76 */     this.brokenBeds++;
/*     */   }
/*     */   
/*     */   public void addKills(boolean finalKill) {
/*  80 */     this.kills++;
/*     */     
/*  82 */     if (finalKill)
/*  83 */       this.finalKills++; 
/*     */   }
/*     */   
/*     */   public boolean isAlive() {
/*  87 */     return (!this.spectator && this.alive);
/*     */   }
/*     */   
/*     */   public boolean addFavorite(ShopCategory storeCategory, int indexOf) {
/*  91 */     Set<Integer> set = this.favoriteMap.computeIfAbsent(storeCategory, v -> new HashSet());
/*     */     
/*  93 */     int integer = 0;
/*     */     
/*  95 */     for (Map.Entry<ShopCategory, Set<Integer>> entry : this.favoriteMap.entrySet()) {
/*  96 */       integer += ((Set)entry.getValue()).size();
/*     */     }
/*     */     
/*  99 */     if (integer < 21) {
/* 100 */       if (!set.contains(Integer.valueOf(indexOf))) {
/* 101 */         set.add(Integer.valueOf(indexOf));
/* 102 */         save("favoriteMap");
/*     */       } 
/* 104 */       return true;
/*     */     } 
/*     */     
/* 107 */     return false;
/*     */   }
/*     */   
/*     */   public boolean removeFavorite(ShopCategory.ShopItem block) {
/* 111 */     for (ShopCategory shopCategory : ShopCategory.values()) {
/* 112 */       List<ShopCategory.ShopItem> list = shopCategory.getShopItem();
/* 113 */       Set<Integer> set = this.favoriteMap.computeIfAbsent(shopCategory, v -> new HashSet());
/* 114 */       int indexOf = list.indexOf(block);
/*     */       
/* 116 */       if (set.contains(Integer.valueOf(indexOf))) {
/* 117 */         set.remove(Integer.valueOf(list.indexOf(block)));
/*     */         
/* 119 */         if (set.isEmpty()) {
/* 120 */           this.favoriteMap.remove(shopCategory);
/* 121 */           save("favoriteMap");
/*     */         } 
/* 123 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 127 */     return false;
/*     */   }
/*     */   
/*     */   public enum SwordLevel
/*     */   {
/* 132 */     WOOD, STONE, IRON, DIAMOND;
/*     */     
/*     */     public SwordLevel getPrevious() {
/* 135 */       if (this == WOOD) {
/* 136 */         return WOOD;
/*     */       }
/* 138 */       return values()[ordinal() - 1];
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public enum ArmorLevel
/*     */   {
/* 145 */     LEATHER, CHAINMAIL, IRON, DIAMOND;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum PickaxeLevel
/*     */   {
/* 153 */     NONE((String)(new ItemBuilder()).build()),
/* 154 */     FIRST((String)(new ItemBuilder()).type(Material.WOOD_PICKAXE).enchantment(Enchantment.DIG_SPEED).build()),
/* 155 */     SECOND((String)(new ItemBuilder()).type(Material.STONE_PICKAXE).enchantment(Enchantment.DIG_SPEED).build()),
/* 156 */     THIRD((String)(new ItemBuilder()).type(Material.IRON_PICKAXE).enchantment(Enchantment.DIG_SPEED, Integer.valueOf(2)).build()),
/* 157 */     FOURTH((String)(new ItemBuilder()).type(Material.GOLD_PICKAXE).enchantment(Enchantment.DIG_SPEED, Integer.valueOf(3)).build()),
/* 158 */     FIFTH((String)(new ItemBuilder()).type(Material.DIAMOND_PICKAXE).enchantment(Enchantment.DIG_SPEED, Integer.valueOf(3)).build()); PickaxeLevel(ItemStack itemStack) { this.itemStack = itemStack; } private ItemStack itemStack;
/*     */     public ItemStack getItemStack() {
/* 160 */       return this.itemStack;
/*     */     }
/*     */     public PickaxeLevel getNext() {
/* 163 */       if (this == values()[(values()).length - 1]) {
/* 164 */         return this;
/*     */       }
/* 166 */       return values()[ordinal() + 1];
/*     */     }
/*     */     
/*     */     public PickaxeLevel getPrevious() {
/* 170 */       if (this == values()[0]) {
/* 171 */         return this;
/*     */       }
/* 173 */       return values()[ordinal() - 1];
/*     */     }
/*     */     
/*     */     public boolean isLastLevel() {
/* 177 */       return (this == values()[(values()).length - 1]);
/*     */     }
/*     */     
/*     */     public ShopCategory.ShopItem getAsShopItem() {
/* 181 */       return new ShopCategory.ShopItem(
/* 182 */           ItemBuilder.fromStack(getItemStack()).lore("§7Nível: §e" + ordinal()).lore("")
/* 183 */           .lore("§7Você sempre renascerá com ao mínimo o primeiro nível.").build(), new ShopCategory.ShopPrice(
/* 184 */             (ordinal() >= FOURTH.ordinal()) ? Material.GOLD_INGOT : Material.IRON_INGOT, 
/* 185 */             (ordinal() >= FOURTH.ordinal()) ? (3 * (ordinal() - FOURTH.ordinal() + 1)) : 10));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum AxeLevel
/*     */   {
/* 194 */     NONE((String)(new ItemBuilder()).build()),
/* 195 */     FIRST((String)(new ItemBuilder()).type(Material.WOOD_AXE).enchantment(Enchantment.DIG_SPEED).build()),
/* 196 */     SECOND((String)(new ItemBuilder()).type(Material.STONE_AXE).enchantment(Enchantment.DIG_SPEED).build()),
/* 197 */     THIRD((String)(new ItemBuilder()).type(Material.IRON_AXE).enchantment(Enchantment.DIG_SPEED, Integer.valueOf(2)).build()),
/* 198 */     FOURTH((String)(new ItemBuilder()).type(Material.GOLD_AXE).enchantment(Enchantment.DIG_SPEED, Integer.valueOf(3)).build()),
/* 199 */     FIFTH((String)(new ItemBuilder()).type(Material.DIAMOND_AXE).enchantment(Enchantment.DIG_SPEED, Integer.valueOf(3)).build()); AxeLevel(ItemStack itemStack) { this.itemStack = itemStack; } private ItemStack itemStack;
/*     */     public ItemStack getItemStack() {
/* 201 */       return this.itemStack;
/*     */     }
/*     */     public AxeLevel getNext() {
/* 204 */       if (this == values()[(values()).length - 1]) {
/* 205 */         return this;
/*     */       }
/* 207 */       return values()[ordinal() + 1];
/*     */     }
/*     */     
/*     */     public AxeLevel getPrevious() {
/* 211 */       if (this == values()[0]) {
/* 212 */         return this;
/*     */       }
/* 214 */       return values()[ordinal() - 1];
/*     */     }
/*     */     
/*     */     public boolean isLastLevel() {
/* 218 */       return (this == values()[(values()).length - 1]);
/*     */     }
/*     */     
/*     */     public ShopCategory.ShopItem getAsShopItem() {
/* 222 */       return new ShopCategory.ShopItem(
/* 223 */           ItemBuilder.fromStack(getItemStack())
/* 224 */           .lore(new String[] { "§7Nível: §e" + ordinal(), "", "§7Você sempre renascerá com ao mínimo o primeiro nível."
/*     */             },
/* 226 */           ).build(), new ShopCategory.ShopPrice(
/* 227 */             (ordinal() >= FOURTH.ordinal()) ? Material.GOLD_INGOT : Material.IRON_INGOT, 
/* 228 */             (ordinal() >= FOURTH.ordinal()) ? (3 * (ordinal() - FOURTH.ordinal() + 1)) : 10));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void checkLevel() {
/* 234 */     Status status = CommonPlugin.getInstance().getStatusManager().loadStatus(getUniqueId(), StatusType.BEDWARS);
/*     */     
/* 236 */     int level = status.getInteger((Enum)BedwarsCategory.BEDWARS_LEVEL);
/* 237 */     int points = status.getInteger((Enum)BedwarsCategory.BEDWARS_POINTS);
/* 238 */     int maxPoints = GameMain.getInstance().getMaxPoints(level);
/*     */     
/* 240 */     if (points > maxPoints) {
/* 241 */       status.setInteger((Enum)BedwarsCategory.BEDWARS_LEVEL, level + 1);
/* 242 */       status.setInteger((Enum)BedwarsCategory.BEDWARS_POINTS, 0);
/* 243 */       status.save();
/* 244 */       Bukkit.getPluginManager().callEvent((Event)new PlayerLevelUpEvent(getPlayer(), this, level));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/gamer/Gamer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */