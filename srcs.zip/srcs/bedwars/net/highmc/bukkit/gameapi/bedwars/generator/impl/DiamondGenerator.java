/*    */ package net.highmc.bukkit.gameapi.bedwars.generator.impl;
/*    */ 
/*    */ import net.highmc.bukkit.gameapi.bedwars.generator.Generator;
/*    */ import net.highmc.bukkit.gameapi.bedwars.generator.GeneratorType;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DiamondGenerator
/*    */   extends Generator
/*    */ {
/*    */   public DiamondGenerator(Location location) {
/* 15 */     super(location, GeneratorType.DIAMOND, new ItemStack(Material.DIAMOND));
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/generator/impl/DiamondGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */