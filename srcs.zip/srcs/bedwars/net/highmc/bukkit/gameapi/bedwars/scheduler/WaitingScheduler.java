/*     */ package net.highmc.bukkit.gameapi.bedwars.scheduler;
/*     */ 
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.event.player.PlayerAdminEvent;
/*     */ import net.highmc.bukkit.event.player.PlayerMoveUpdateEvent;
/*     */ import net.highmc.bukkit.gameapi.GameAPI;
/*     */ import net.highmc.bukkit.gameapi.bedwars.GameMain;
/*     */ import net.highmc.bukkit.gameapi.bedwars.gamer.Gamer;
/*     */ import net.highmc.bukkit.gameapi.scheduler.Scheduler;
/*     */ import net.highmc.bukkit.member.BukkitMember;
/*     */ import net.highmc.bukkit.utils.item.ActionItemStack;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.bukkit.utils.player.PlayerHelper;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.server.ServerType;
/*     */ import net.highmc.server.loadbalancer.server.MinigameState;
/*     */ import net.highmc.utils.string.StringFormat;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.block.BlockBreakEvent;
/*     */ import org.bukkit.event.block.BlockPlaceEvent;
/*     */ import org.bukkit.event.entity.EntityDamageEvent;
/*     */ import org.bukkit.event.player.PlayerBucketEmptyEvent;
/*     */ import org.bukkit.event.player.PlayerDropItemEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.metadata.FixedMetadataValue;
/*     */ import org.bukkit.metadata.MetadataValue;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.potion.PotionEffect;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WaitingScheduler
/*     */   implements Scheduler, Listener
/*     */ {
/*  49 */   private static final ActionItemStack ACTION_ITEM_STACK = new ActionItemStack((new ItemBuilder())
/*  50 */       .name("§aRetornar ao Lobby").type(Material.BED).build(), new ActionItemStack.Interact()
/*     */       {
/*     */         
/*     */         public boolean onInteract(Player player, Entity entity, Block block, ItemStack item, ActionItemStack.ActionType action)
/*     */         {
/*  55 */           GameAPI.getInstance().sendPlayerToServer(player, new ServerType[] {
/*  56 */                 CommonPlugin.getInstance().getServerType().getServerLobby(), ServerType.LOBBY });
/*  57 */           return false;
/*     */         }
/*     */       });
/*     */   
/*     */   private boolean timeWasReduced;
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerJoin(PlayerJoinEvent event) {
/*  65 */     Player player = event.getPlayer();
/*  66 */     Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/*  67 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId());
/*     */     
/*  69 */     player.teleport(GameAPI.getInstance().getLocationManager().getLocation("spawn"));
/*     */     
/*  71 */     player.setHealth(20.0D);
/*  72 */     player.setMaxHealth(20.0D);
/*  73 */     player.setFoodLevel(20);
/*  74 */     player.setLevel(0);
/*  75 */     player.setExp(0.0F);
/*     */     
/*  77 */     player.setAllowFlight(false);
/*  78 */     player.setFlying(false);
/*  79 */     player.setGameMode(GameMode.ADVENTURE);
/*     */     
/*  81 */     player.getInventory().clear();
/*  82 */     player.getInventory().setArmorContents(new ItemStack[4]);
/*  83 */     player.getActivePotionEffects().forEach(potion -> player.removePotionEffect(potion.getType()));
/*     */     
/*  85 */     player.getInventory().setItem(8, ACTION_ITEM_STACK.getItemStack());
/*  86 */     gamer.setAlive(true);
/*  87 */     gamer.setSpectator(false);
/*     */     
/*  89 */     if (player.hasPermission("command.admin") && member.getMemberConfiguration().isAdminOnJoin()) {
/*  90 */       player.setMetadata("admin", (MetadataValue)new FixedMetadataValue((Plugin)GameAPI.getInstance(), Boolean.valueOf(true)));
/*     */     } else {
/*  92 */       broadcast(member.getTag().getRealPrefix(), event.getPlayer().getName(), false);
/*     */     } 
/*     */   }
/*     */   @EventHandler(priority = EventPriority.LOW)
/*     */   public void onPlayerQuit(final PlayerQuitEvent event) {
/*  97 */     final Member member = CommonPlugin.getInstance().getMemberManager().getMember(event.getPlayer().getUniqueId());
/*     */     
/*  99 */     if (!GameAPI.getInstance().getVanishManager().isPlayerInAdmin(event.getPlayer())) {
/* 100 */       (new BukkitRunnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 104 */             WaitingScheduler.this.broadcast(member.getTag().getRealPrefix(), event.getPlayer().getName(), true);
/*     */           }
/* 106 */         }).runTaskLater((Plugin)GameAPI.getInstance(), 7L);
/*     */     }
/* 108 */     if (event.getPlayer().hasMetadata("admin"))
/* 109 */       event.getPlayer().removeMetadata("admin", (Plugin)GameAPI.getInstance()); 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGHEST)
/*     */   public void onPlayerAdmin(PlayerAdminEvent event) {
/* 114 */     Player player = event.getPlayer();
/* 115 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId());
/*     */     
/* 117 */     if (player.hasMetadata("admin")) {
/* 118 */       player.removeMetadata("admin", (Plugin)GameAPI.getInstance());
/*     */     }
/* 120 */     else if (event.getAdminMode() == PlayerAdminEvent.AdminMode.ADMIN) {
/* 121 */       broadcast(member.getTag().getRealPrefix(), event.getPlayer().getName(), true);
/*     */     } else {
/* 123 */       broadcast(member.getTag().getRealPrefix(), event.getPlayer().getName(), false);
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerDropItem(PlayerDropItemEvent event) {
/* 129 */     event.setCancelled(true);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onBlockBreak(BlockBreakEvent event) {
/* 134 */     event.setCancelled(
/* 135 */         !((BukkitMember)CommonPlugin.getInstance().getMemberManager().getMember(event.getPlayer().getUniqueId(), BukkitMember.class)).isBuildEnabled());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onBlockPlace(BlockPlaceEvent event) {
/* 140 */     event.setCancelled(
/* 141 */         !((BukkitMember)CommonPlugin.getInstance().getMemberManager().getMember(event.getPlayer().getUniqueId(), BukkitMember.class)).isBuildEnabled());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerBucketEmpty(PlayerBucketEmptyEvent event) {
/* 146 */     event.setCancelled(
/* 147 */         !((BukkitMember)CommonPlugin.getInstance().getMemberManager().getMember(event.getPlayer().getUniqueId(), BukkitMember.class)).isBuildEnabled());
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGHEST)
/*     */   public void onPlayerInteract(PlayerInteractEvent event) {
/* 152 */     event.setCancelled(
/* 153 */         !((BukkitMember)CommonPlugin.getInstance().getMemberManager().getMember(event.getPlayer().getUniqueId(), BukkitMember.class)).isBuildEnabled());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerMoveUpdate(PlayerMoveUpdateEvent event) {
/* 158 */     if (event.getTo().getY() < 10.0D)
/* 159 */       event.getPlayer().teleport(GameAPI.getInstance().getLocationManager().getLocation("spawn")); 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onEntityDamage(EntityDamageEvent event) {
/* 164 */     event.setCancelled(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void pulse() {
/* 169 */     int time = GameAPI.getInstance().getTime();
/*     */     
/* 171 */     if (GameAPI.getInstance().isConsoleControl()) {
/* 172 */       int alivePlayers = GameMain.getInstance().getAlivePlayers().size();
/*     */       
/* 174 */       if (alivePlayers < Bukkit.getMaxPlayers() / 2) {
/* 175 */         GameAPI.getInstance().setTimer(false);
/* 176 */         GameAPI.getInstance().setTime(60);
/* 177 */         GameAPI.getInstance().setState(MinigameState.WAITING);
/*     */         
/*     */         return;
/*     */       } 
/* 181 */       if (GameAPI.getInstance().isTimer()) {
/* 182 */         if (!this.timeWasReduced && alivePlayers == Bukkit.getMaxPlayers() && time > 15) {
/* 183 */           GameAPI.getInstance().setTime(10);
/* 184 */           Bukkit.broadcastMessage("§eTempo alterado para §b10 segundos§e pois a sala está lotada.");
/* 185 */           this.timeWasReduced = true;
/*     */         } 
/*     */       } else {
/* 188 */         GameAPI.getInstance().setTimer(true);
/* 189 */         GameAPI.getInstance().setState(MinigameState.STARTING);
/*     */       } 
/*     */     } 
/*     */     
/* 193 */     String s = (time <= 3) ? "§4" : ((time < 5) ? "§c" : ((time < 30) ? "§e" : "§a"));
/*     */     
/* 195 */     if (time > 0 && (time <= 5 || time % 30 == 0 || time == 15)) {
/* 196 */       Bukkit.getOnlinePlayers().forEach(player -> {
/*     */             PlayerHelper.title(player, s + StringFormat.formatTime(Language.getLanguage(player.getUniqueId()), time), " ");
/*     */             
/*     */             player.sendMessage(Language.getLanguage(player.getUniqueId()).t("bedwars-game-will-start", new String[] { "%time%", s + time }));
/*     */             
/*     */             player.playSound(player.getLocation(), Sound.CLICK, 1.0F, 1.0F);
/*     */           });
/*     */     }
/*     */     
/* 205 */     if (time <= 0) {
/* 206 */       GameMain.getInstance().startGame();
/* 207 */       Bukkit.broadcastMessage("§eO jogo iniciou.");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void broadcast(String tag, String playerName, boolean leave) {
/* 212 */     if (leave) {
/* 213 */       Bukkit.broadcastMessage(tag + playerName + " §esaiu na sala (§b" + 
/* 214 */           GameMain.getInstance().getAlivePlayers().size() + "§e/§b" + Bukkit.getMaxPlayers() + "§e)");
/*     */     } else {
/* 216 */       Bukkit.broadcastMessage(tag + playerName + " §eentrou na sala (§b" + 
/* 217 */           GameMain.getInstance().getAlivePlayers().size() + "§e/§b" + Bukkit.getMaxPlayers() + "§e)");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/scheduler/WaitingScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */