/*     */ package net.highmc.bukkit.gameapi.bedwars.manager;
/*     */ 
/*     */ import com.google.common.collect.ImmutableSet;
/*     */ import com.google.common.collect.UnmodifiableIterator;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.highmc.bukkit.event.UpdateEvent;
/*     */ import net.highmc.bukkit.gameapi.GameAPI;
/*     */ import net.highmc.bukkit.gameapi.bedwars.GameMain;
/*     */ import net.highmc.bukkit.gameapi.bedwars.generator.Generator;
/*     */ import net.highmc.bukkit.gameapi.bedwars.generator.GeneratorType;
/*     */ import net.highmc.bukkit.gameapi.bedwars.generator.impl.DiamondGenerator;
/*     */ import net.highmc.bukkit.gameapi.bedwars.generator.impl.EmeraldGenerator;
/*     */ import net.highmc.bukkit.utils.Location;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeneratorManager
/*     */ {
/*  32 */   private Map<GeneratorType, List<Generator>> generatorMap = new HashMap<>();
/*     */   public GeneratorManager() {
/*  34 */     for (GeneratorType generatorType : GeneratorType.values()) {
/*  35 */       if (generatorType != GeneratorType.NORMAL) {
/*     */ 
/*     */         
/*  38 */         List<Location> list = GameMain.getInstance().getConfiguration().getList(generatorType.getConfigFieldName(), new ArrayList(), true, Location.class);
/*     */ 
/*     */         
/*  41 */         for (Location location : list) {
/*  42 */           createGenerator(generatorType, location, false);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void createGenerator(GeneratorType generatorType, Location location, boolean save) {
/*  49 */     Generator generator = (generatorType == GeneratorType.DIAMOND) ? (Generator)new DiamondGenerator(location.getAsLocation()) : (Generator)new EmeraldGenerator(location.getAsLocation());
/*     */     
/*  51 */     ((List<Generator>)this.generatorMap.computeIfAbsent(generatorType, v -> new ArrayList())).add(generator);
/*     */     
/*  53 */     if (save)
/*  54 */       GameMain.getInstance().getConfiguration().addElementToList(generatorType.getConfigFieldName(), location); 
/*     */   }
/*     */   
/*     */   public boolean setLocation(GeneratorType generatorType, int index, Location fromLocation, boolean save) {
/*  58 */     Generator generator = ((List<Generator>)this.generatorMap.computeIfAbsent(generatorType, v -> new ArrayList())).get(index);
/*     */     
/*  60 */     if (generator == null) {
/*  61 */       return false;
/*     */     }
/*  63 */     generator.setLocation(fromLocation.getAsLocation());
/*     */     
/*  65 */     if (save) {
/*  66 */       return GameMain.getInstance().getConfiguration().setElementToList(generatorType.getConfigFieldName(), index, fromLocation);
/*     */     }
/*     */     
/*  69 */     return true;
/*     */   }
/*     */   
/*     */   public void startGenerators() {
/*  73 */     this.generatorMap.values().forEach(list -> list.forEach(Generator::handleHologram));
/*  74 */     Bukkit.getPluginManager().registerEvents(new GeneratorListener(), (Plugin)GameAPI.getInstance());
/*     */   }
/*     */   
/*     */   public Generator getGenerator(GeneratorType generatorType, int asInt) {
/*  78 */     return this.generatorMap.containsKey(generatorType) ? ((List<Generator>)this.generatorMap.get(generatorType)).get(asInt) : null;
/*     */   }
/*     */   
/*     */   public List<Generator> getGenerators(GeneratorType generatorType) {
/*  82 */     return this.generatorMap.get(generatorType);
/*     */   }
/*     */   
/*     */   public List<Generator> getGenerators() {
/*  86 */     List<Generator> generator = new ArrayList<>();
/*     */     
/*  88 */     for (GeneratorType generatorType : GeneratorType.values()) {
/*  89 */       if (this.generatorMap.containsKey(generatorType)) {
/*  90 */         generator.addAll(this.generatorMap.get(generatorType));
/*     */       }
/*     */     } 
/*  93 */     return generator;
/*     */   }
/*     */   
/*     */   public void addGenerator(Generator createGenerator) {
/*  97 */     ((List<Generator>)this.generatorMap.computeIfAbsent(createGenerator.getGeneratorType(), v -> new ArrayList())).add(createGenerator);
/*     */   }
/*     */   
/*     */   public class GeneratorListener
/*     */     implements Listener {
/*     */     public GeneratorListener() {
/* 103 */       Bukkit.getPluginManager().registerEvents(this, (Plugin)GameAPI.getInstance());
/*     */     }
/*     */     
/*     */     @EventHandler
/*     */     public void onUpdate(UpdateEvent event) {
/* 108 */       if (event.getCurrentTick() % 3L == 0L)
/* 109 */         for (UnmodifiableIterator<Map.Entry<GeneratorType, List<Generator>>> unmodifiableIterator = ImmutableSet.copyOf(GeneratorManager.this.generatorMap.entrySet()).iterator(); unmodifiableIterator.hasNext(); ) { Map.Entry<GeneratorType, List<Generator>> entry = unmodifiableIterator.next();
/* 110 */           for (Generator generator : entry.getValue()) {
/* 111 */             generator.animate();
/* 112 */             generator.updateHologram();
/*     */             
/* 114 */             if (generator.getLastGenerate() + generator.getGenerateTime() <= System.currentTimeMillis())
/* 115 */               generator.generate(); 
/*     */           }  }
/*     */          
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/manager/GeneratorManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */