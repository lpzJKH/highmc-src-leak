/*    */ package net.highmc.bukkit.gameapi.bedwars;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import net.highmc.bukkit.gameapi.bedwars.menu.FinderInventory;
/*    */ import net.highmc.bukkit.utils.item.ActionItemStack;
/*    */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.block.Block;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GameConst
/*    */ {
/* 20 */   public static final Map<Material, Double> DAMAGE_PER_ITEM = new HashMap<>();
/*    */   
/*    */   public static final int STARTING_TIME = 60;
/*    */   
/*    */   public static final int DEFAULT_UPGRADE = 360;
/*    */   
/*    */   public static final String INVENCIBILITY_METADATA = "invencibility";
/*    */   
/*    */   public static final String BED_METADATA = "bed-island";
/*    */   
/*    */   public static final String CHEST_METADATA = "chest-island";
/*    */   
/*    */   public static final String PLAYER_TARGET_METADATA = "player-target";
/*    */   
/*    */   public static final String PLAYER_ARMOR_METADATA = "player-armor";
/*    */   
/*    */   public static final int REWARD_FOR_BREAKBED = 20;
/*    */   public static final int REWARD_FOR_ENDKILL = 10;
/*    */   public static final int REWARD_FOR_KILL = 5;
/*    */   public static final int REWARD_FOR_WIN = 50;
/*    */   public static final int MULTIPLER = 1;
/*    */   public static final double PLAYER_YBOOST_IF_OFFGROUND = 0.8D;
/*    */   public static final double YBOOST_IF_ONGROUND = 1.2D;
/*    */   public static final double PLAYER_YBOOST_IF_ONGROUND = 0.6D;
/*    */   public static final double YBOOST_IF_OFFGROUND = 0.3D;
/*    */   public static final double BOOST_IF_OFFGROUND = 1.0D;
/*    */   public static final double BOOST_IF_ONGROUND = 0.5D;
/*    */   public static final double PLAYER_BOOST_IF_OFFGROUND = 2.8D;
/*    */   public static final double PLAYER_BOOST_IF_ONGROUND = 5.8D;
/*    */   public static final double TNT_BOOST_MULTIPLIER_ONGROUND = 1.5D;
/*    */   public static final double TNT_BOOST_MULTIPLIER_OFFGROUND = 1.5D;
/*    */   public static final double TNT_BOOST_Y_MULTIPLIER_ONGROUND = 0.5D;
/*    */   public static final double TNT_BOOST_Y_MULTIPLIER_OFFGROUND = 0.9D;
/*    */   
/* 54 */   public static final ActionItemStack FINDER = new ActionItemStack((new ItemBuilder()).type(Material.COMPASS).build(), new ActionItemStack.Interact()
/*    */       {
/*    */ 
/*    */         
/*    */         public boolean onInteract(Player player, Entity entity, Block block, ItemStack item, ActionItemStack.ActionType action)
/*    */         {
/* 60 */           new FinderInventory(player);
/* 61 */           return false;
/*    */         }
/*    */       });
/*    */   
/*    */   public static final String SHOP_NPC = "ZAKl1k";
/*    */   public static final String UPGRADE_NPC = "Kotcka";
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/GameConst.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */