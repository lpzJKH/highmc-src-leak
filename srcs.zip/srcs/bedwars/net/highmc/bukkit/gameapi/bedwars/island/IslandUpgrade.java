/*    */ package net.highmc.bukkit.gameapi.bedwars.island;
/*    */ 
/*    */ import org.bukkit.Material;
/*    */ 
/*    */ 
/*    */ public enum IslandUpgrade
/*    */ {
/*    */   private Material icon;
/*    */   private int maxLevel;
/* 10 */   SHARPNESS(Material.IRON_SWORD, new int[] { 4 }), ARMOR_REINFORCEMENT(Material.IRON_CHESTPLATE, new int[] { 2, 4, 8, 16 }),
/* 11 */   HASTE(Material.GOLD_PICKAXE, new int[] { 2, 4 }), FORGE(Material.FURNACE, new int[] { 4, 8, 12, 16 }), REGENERATION(Material.BEACON, new int[] { 1 }),
/* 12 */   TRAP(Material.TRIPWIRE_HOOK, new int[] { 1 }); private int[] levelsCost;
/*    */   public Material getIcon() {
/* 14 */     return this.icon;
/*    */   }
/* 16 */   public int getMaxLevel() { return this.maxLevel; } public int[] getLevelsCost() {
/* 17 */     return this.levelsCost;
/*    */   }
/*    */   IslandUpgrade(Material icon, int... cost) {
/* 20 */     this.icon = icon;
/* 21 */     this.maxLevel = cost.length;
/* 22 */     this.levelsCost = new int[cost.length];
/*    */     
/* 24 */     for (int i = 0; i < this.levelsCost.length; i++)
/* 25 */       this.levelsCost[i] = cost[i] * getMultiplier(); 
/*    */   }
/*    */   
/*    */   public int getMultiplier() {
/* 29 */     return 1;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/island/IslandUpgrade.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */