/*    */ package net.highmc.bukkit.gameapi.bedwars.event.island;
/*    */ import net.highmc.bukkit.event.NormalEvent;
/*    */ import net.highmc.bukkit.gameapi.bedwars.island.Island;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class IslandBedBreakEvent extends NormalEvent {
/*    */   private Player player;
/*    */   private Island island;
/*    */   
/*    */   public IslandBedBreakEvent(Player player, Island island) {
/* 11 */     this.player = player; this.island = island;
/*    */   }
/*    */   
/* 14 */   public Player getPlayer() { return this.player; } public Island getIsland() {
/* 15 */     return this.island;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/event/island/IslandBedBreakEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */