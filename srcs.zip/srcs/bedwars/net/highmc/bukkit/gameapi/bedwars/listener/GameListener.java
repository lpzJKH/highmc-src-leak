/*     */ package net.highmc.bukkit.gameapi.bedwars.listener;
/*     */ 
/*     */ import com.comphenix.protocol.PacketType;
/*     */ import com.comphenix.protocol.ProtocolLibrary;
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import com.google.common.collect.UnmodifiableIterator;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import java.util.stream.Collectors;
/*     */ import net.highmc.CommonConst;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.bukkit.event.UpdateEvent;
/*     */ import net.highmc.bukkit.event.player.PlayerAdminEvent;
/*     */ import net.highmc.bukkit.event.player.PlayerMoveUpdateEvent;
/*     */ import net.highmc.bukkit.gameapi.GameAPI;
/*     */ import net.highmc.bukkit.gameapi.bedwars.GameMain;
/*     */ import net.highmc.bukkit.gameapi.bedwars.event.PlayerKillPlayerEvent;
/*     */ import net.highmc.bukkit.gameapi.bedwars.event.island.IslandLoseEvent;
/*     */ import net.highmc.bukkit.gameapi.bedwars.gamer.Gamer;
/*     */ import net.highmc.bukkit.gameapi.bedwars.generator.Generator;
/*     */ import net.highmc.bukkit.gameapi.bedwars.island.Island;
/*     */ import net.highmc.bukkit.gameapi.bedwars.island.IslandColor;
/*     */ import net.highmc.bukkit.gameapi.bedwars.island.IslandUpgrade;
/*     */ import net.highmc.bukkit.gameapi.bedwars.utils.GamerHelper;
/*     */ import net.highmc.bukkit.gameapi.event.GamerLoadEvent;
/*     */ import net.highmc.bukkit.gameapi.gamer.Gamer;
/*     */ import net.highmc.bukkit.utils.PacketBuilder;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.bukkit.utils.player.PlayerHelper;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.member.status.Status;
/*     */ import net.highmc.member.status.StatusType;
/*     */ import net.highmc.member.status.types.BedwarsCategory;
/*     */ import net.highmc.packet.Packet;
/*     */ import net.highmc.packet.types.staff.Stafflog;
/*     */ import net.highmc.server.loadbalancer.server.MinigameState;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.enchantments.Enchantment;
/*     */ import org.bukkit.entity.Egg;
/*     */ import org.bukkit.entity.Item;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.entity.Projectile;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.block.Action;
/*     */ import org.bukkit.event.block.BlockBreakEvent;
/*     */ import org.bukkit.event.block.BlockPhysicsEvent;
/*     */ import org.bukkit.event.block.BlockPlaceEvent;
/*     */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*     */ import org.bukkit.event.entity.EntityDamageEvent;
/*     */ import org.bukkit.event.entity.EntityDeathEvent;
/*     */ import org.bukkit.event.entity.PlayerDeathEvent;
/*     */ import org.bukkit.event.entity.ProjectileLaunchEvent;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*     */ import org.bukkit.event.inventory.InventoryType;
/*     */ import org.bukkit.event.player.AsyncPlayerChatEvent;
/*     */ import org.bukkit.event.player.PlayerBedEnterEvent;
/*     */ import org.bukkit.event.player.PlayerBucketEmptyEvent;
/*     */ import org.bukkit.event.player.PlayerBucketFillEvent;
/*     */ import org.bukkit.event.player.PlayerDropItemEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.event.player.PlayerPickupItemEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.PlayerInventory;
/*     */ import org.bukkit.metadata.MetadataValue;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.potion.PotionEffect;
/*     */ import org.bukkit.potion.PotionEffectType;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GameListener
/*     */   implements Listener
/*     */ {
/*  99 */   private List<Material> dropableItems = Arrays.asList(new Material[] { Material.DIAMOND, Material.EMERALD, Material.GOLD_INGOT, Material.POTION });
/*     */   
/* 101 */   private Map<UUID, Long> playerJoinMap = new HashMap<>();
/*     */   
/*     */   @EventHandler
/*     */   public void onProjectileLaunch(ProjectileLaunchEvent event) {
/* 105 */     if (!(event.getEntity() instanceof Egg) || !(event.getEntity().getShooter() instanceof Player)) {
/*     */       return;
/*     */     }
/* 108 */     final Egg egg = (Egg)event.getEntity();
/* 109 */     Player player = (Player)egg.getShooter();
/* 110 */     final Island island = GameMain.getInstance().getIslandManager().getIsland(player.getUniqueId());
/*     */     
/* 112 */     if (island == null) {
/*     */       return;
/*     */     }
/* 115 */     final int distance = 40;
/*     */     
/* 117 */     final Location startLocation = egg.getLocation().clone();
/* 118 */     List<Block> lineOfSight = player.getLineOfSight((Set)null, distance);
/*     */     
/* 120 */     for (Block block : lineOfSight) {
/* 121 */       Block highestBlockAt = block.getWorld().getHighestBlockAt(block.getLocation());
/*     */       
/* 123 */       if (!isPlaceable(highestBlockAt.getLocation())) {
/* 124 */         player.getInventory().addItem(new ItemStack[] { ItemBuilder.fromStack(player.getItemInHand()).amount(1).build() });
/* 125 */         player.sendMessage("§cVocê não pode jogar o ovo nessa direção.");
/* 126 */         event.setCancelled(true);
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 131 */     (new BukkitRunnable()
/*     */       {
/*     */         public void run()
/*     */         {
/* 135 */           Location eggLocation = egg.getLocation().subtract(0.0D, 2.5D, 0.0D);
/*     */           
/* 137 */           if (eggLocation.getY() <= 70.0D) {
/* 138 */             egg.remove();
/*     */           }
/* 140 */           if (egg.isDead() || GameListener.this.distanceSquared(eggLocation, startLocation, distance)) {
/* 141 */             cancel();
/*     */             
/*     */             return;
/*     */           } 
/* 145 */           if (eggLocation.getBlock().getType() == Material.AIR) {
/* 146 */             final Location location = eggLocation.getBlock().getLocation().add(0.5D, 0.0D, 0.5D);
/*     */             
/* 148 */             (new BukkitRunnable()
/*     */               {
/*     */                 public void run()
/*     */                 {
/* 152 */                   for (int x = -1; x < 1; x++) {
/* 153 */                     for (int z = -1; z < 1; z++) {
/* 154 */                       Location newLocation = location.clone().add(x, 0.0D, z);
/*     */                       
/* 156 */                       if (newLocation.getBlock().getType() == Material.AIR) {
/* 157 */                         GameMain.getInstance().getBlockManager().setBlockFast(newLocation, Material.WOOL, 
/* 158 */                             (byte)island.getIslandColor().getWoolId(), place -> GameMain.getInstance().getPlayersBlock().add(place));
/*     */                       }
/*     */                     }
/*     */                   
/*     */                   } 
/*     */                 }
/* 164 */               }).runTaskLater((Plugin)GameAPI.getInstance(), 5L);
/*     */           } 
/*     */         }
/* 167 */       }).runTaskTimer((Plugin)GameAPI.getInstance(), 5L, 0L);
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onGamerLoad(GamerLoadEvent event) {
/* 173 */     Player player = event.getPlayer();
/*     */     
/* 175 */     if (this.playerJoinMap.containsKey(player.getUniqueId())) {
/*     */       return;
/*     */     }
/* 178 */     Island island = getIsland(player.getUniqueId());
/*     */     
/* 180 */     if (island == null && 
/* 181 */       !player.hasPermission("command.admin")) {
/* 182 */       event.setCancelled(true);
/* 183 */       event.setReason("§cO jogo já iniciou!");
/*     */       return;
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
/*     */   public void onAsyncPlayerChat(AsyncPlayerChatEvent event) {
/*     */     String message;
/* 191 */     Player player = event.getPlayer();
/* 192 */     Gamer gamer = (Gamer)GameMain.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/*     */     
/* 194 */     if (gamer == null) {
/*     */       return;
/*     */     }
/* 197 */     Island island = getIsland(player.getUniqueId());
/*     */     
/* 199 */     if (island == null) {
/*     */       return;
/*     */     }
/* 202 */     event.setCancelled(true);
/*     */ 
/*     */ 
/*     */     
/* 206 */     if (island.getIslandStatus() != Island.IslandStatus.LOSER) {
/* 207 */       boolean solo = CommonPlugin.getInstance().getServerType().name().contains("SOLO");
/* 208 */       boolean global = solo;
/*     */       
/* 210 */       Status status = GameAPI.getInstance().getPlugin().getStatusManager().loadStatus(player.getUniqueId(), StatusType.BEDWARS);
/*     */ 
/*     */       
/* 213 */       int level = status.getInteger((Enum)BedwarsCategory.BEDWARS_LEVEL);
/* 214 */       message = GameMain.getInstance().createMessage(player, event.getMessage(), island, global, global ? (!solo) : true, level);
/*     */ 
/*     */       
/* 217 */       if (!global)
/* 218 */         event.getRecipients().removeIf(p -> !island.getTeam().getPlayerSet().contains(p.getUniqueId())); 
/*     */     } else {
/* 220 */       event.getRecipients().removeIf(p -> !GameMain.getInstance().hasLose(p.getUniqueId()));
/* 221 */       message = "§7[ESPECTADORES] " + player.getName() + ": " + event.getMessage();
/*     */     } 
/*     */     
/* 224 */     event.getRecipients().forEach(ps -> ps.sendMessage(message));
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInventoryClose(InventoryCloseEvent event) {
/* 229 */     if (event.getInventory().getHolder() instanceof net.highmc.bukkit.utils.menu.MenuHolder) {
/*     */       return;
/*     */     }
/* 232 */     Player player = (Player)event.getPlayer();
/* 233 */     Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/*     */     
/* 235 */     if (gamer == null || !gamer.isAlive()) {
/*     */       return;
/*     */     }
/* 238 */     Inventory inventory = event.getInventory();
/* 239 */     PlayerInventory playerInventory = player.getInventory();
/*     */     
/* 241 */     for (ItemStack itemStack : inventory.getContents()) {
/* 242 */       if (itemStack != null)
/*     */       {
/*     */         
/* 245 */         if (itemStack.getType() == Material.WOOD_SWORD || itemStack.getType() == Material.SHEARS || itemStack
/* 246 */           .getType() == gamer.getAxeLevel().getItemStack().getType() || itemStack
/* 247 */           .getType() == gamer.getPickaxeLevel().getItemStack().getType()) {
/* 248 */           inventory.remove(itemStack);
/* 249 */           playerInventory.addItem(new ItemStack[] { itemStack });
/*     */         } 
/*     */       }
/*     */     } 
/* 253 */     int swordCount = getSwordCount((Inventory)playerInventory);
/* 254 */     int woodSwordCount = getItemCount(player, Material.WOOD_SWORD);
/*     */     
/* 256 */     if (getSwordCount((Inventory)playerInventory) == 0) {
/* 257 */       playerInventory
/* 258 */         .addItem(new ItemStack[] {
/* 259 */             (new ItemBuilder()).type(Material.WOOD_SWORD)
/* 260 */             .enchantment(Enchantment.DAMAGE_ALL, GameMain.getInstance().getIslandManager()
/* 261 */               .getIsland(player.getUniqueId()).getUpgradeLevel(IslandUpgrade.SHARPNESS))
/* 262 */             .build()
/*     */           });
/*     */     }
/* 265 */     if (swordCount != woodSwordCount)
/* 266 */       for (ItemStack itemStack : playerInventory.getContents()) {
/* 267 */         if (itemStack != null && itemStack.getType() == Material.WOOD_SWORD) {
/* 268 */           playerInventory.removeItem(new ItemStack[] { itemStack });
/*     */         }
/*     */       }  
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInventoryClick(InventoryClickEvent event) {
/* 275 */     if (event.getSlotType() == InventoryType.SlotType.CRAFTING || event.getSlotType() == InventoryType.SlotType.ARMOR) {
/* 276 */       event.setCancelled(true);
/*     */       return;
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
/*     */   public void onPlayerDropItem(PlayerDropItemEvent event) {
/* 283 */     Player player = event.getPlayer();
/*     */     
/* 285 */     if (player.getAllowFlight()) {
/* 286 */       event.setCancelled(true);
/*     */       
/*     */       return;
/*     */     } 
/* 290 */     Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/* 291 */     ItemStack itemStack = event.getItemDrop().getItemStack();
/*     */     
/* 293 */     if (itemStack.getType().name().contains("SWORD")) {
/* 294 */       if (itemStack.getType() == Material.WOOD_SWORD) {
/* 295 */         event.setCancelled(true);
/* 296 */       } else if (getSwordCount(player) == 0) {
/* 297 */         player.getInventory()
/* 298 */           .setItemInHand((new ItemBuilder()).type(Material.WOOD_SWORD)
/* 299 */             .enchantment(Enchantment.DAMAGE_ALL, GameMain.getInstance().getIslandManager()
/* 300 */               .getIsland(player.getUniqueId()).getUpgradeLevel(IslandUpgrade.SHARPNESS))
/* 301 */             .build());
/* 302 */         gamer.setSwordLevel(Gamer.SwordLevel.WOOD);
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 308 */     if (itemStack.getType().name().contains("HELMET") || itemStack.getType().name().contains("CHESTPLATE") || itemStack
/* 309 */       .getType().name().contains("LEGGINGS") || itemStack.getType().name().contains("BOOTS") || itemStack
/* 310 */       .getType().name().contains("AXE") || itemStack.getType().name().contains("PICKAXE") || itemStack
/* 311 */       .getType().name().contains("SHEARS")) {
/* 312 */       event.setCancelled(true);
/*     */       
/*     */       return;
/*     */     } 
/* 316 */     if (gamer.isAlive() && (player.getFallDistance() > 2.0F || player.getLocation().getY() < 20.0D)) {
/* 317 */       event.setCancelled(true);
/* 318 */       player.sendMessage(Language.getLanguage(player.getUniqueId()).t("bedwars.drop-item.void-drop", new String[0]));
/*     */       
/*     */       return;
/*     */     } 
/* 322 */     if (this.dropableItems.contains(event.getItemDrop().getItemStack().getType())) {
/* 323 */       List<Block> lineOfSight = player.getLineOfSight((Set)null, 5);
/*     */       
/* 325 */       for (Block block : lineOfSight) {
/* 326 */         Block highestBlockAt = block.getWorld().getHighestBlockAt(block.getLocation());
/*     */         
/* 328 */         if (highestBlockAt == null || highestBlockAt.getLocation().getY() == 0.0D) {
/* 329 */           event.setCancelled(true);
/* 330 */           player.sendMessage(
/* 331 */               Language.getLanguage(player.getUniqueId()).t("bedwars.drop-item.no-block-to-drop", new String[0]));
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
/*     */   public void onPlayerPickupItem(PlayerPickupItemEvent event) {
/* 340 */     Player player = event.getPlayer();
/* 341 */     Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/*     */     
/* 343 */     if (!gamer.isAlive()) {
/* 344 */       event.setCancelled(true);
/*     */       
/*     */       return;
/*     */     } 
/* 348 */     if (event.getItem().getItemStack().getType().toString().contains("SWORD") && 
/* 349 */       getItemCount(player, Material.WOOD_SWORD) == 1) {
/* 350 */       for (ItemStack itemStack1 : player.getInventory().getContents()) {
/* 351 */         if (itemStack1 != null && itemStack1.getType() == Material.WOOD_SWORD) {
/* 352 */           player.getInventory().removeItem(new ItemStack[] { itemStack1 });
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 357 */       gamer.setSwordLevel(
/* 358 */           Gamer.SwordLevel.valueOf(event.getItem().getItemStack().getType().name().replace("_SWORD", "")));
/*     */       
/*     */       return;
/*     */     } 
/* 362 */     Item item = event.getItem();
/* 363 */     ItemStack itemStack = item.getItemStack();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 368 */     Collection<Player> playerList = (Collection<Player>)GameMain.getInstance().getAlivePlayers().stream().filter(g -> (g.isAlive() && g.getPlayer() != null && g.getPlayer().getLocation().distance(item.getLocation()) <= 3.0D)).map(Gamer::getPlayer).collect(Collectors.toList());
/*     */     
/* 370 */     if (playerList.size() > 1 && itemStack.getAmount() > playerList.size()) {
/* 371 */       int itemPerPlayer = itemStack.getAmount() / playerList.size();
/* 372 */       int remeaning = itemStack.getAmount() - itemPerPlayer * playerList.size();
/*     */       
/* 374 */       for (Player target : playerList) {
/* 375 */         target.getInventory().addItem(new ItemStack[] { ItemBuilder.fromStack(itemStack).amount(itemPerPlayer).build() });
/*     */         try {
/* 377 */           ProtocolLibrary.getProtocolManager().sendServerPacket(target, (new PacketBuilder(PacketType.Play.Server.COLLECT))
/* 378 */               .writeInteger(0, item.getEntityId())
/* 379 */               .writeInteger(1, target.getEntityId()).build());
/* 380 */         } catch (InvocationTargetException e) {
/* 381 */           e.printStackTrace();
/*     */         } 
/*     */       } 
/*     */       
/* 385 */       item.remove();
/* 386 */       event.setCancelled(true);
/*     */       
/* 388 */       if (remeaning > 0)
/* 389 */         player.getInventory().addItem(new ItemStack[] { ItemBuilder.fromStack(itemStack).amount(remeaning).build() }); 
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
/*     */   public void onEntityDamage(EntityDamageEvent event) {
/* 395 */     if (event.getEntity() instanceof Player) {
/* 396 */       Player player = (Player)event.getEntity();
/* 397 */       Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/*     */       
/* 399 */       if (!gamer.isAlive()) {
/* 400 */         event.setCancelled(true);
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
/*     */   public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
/* 408 */     if (event.getDamager() instanceof org.bukkit.entity.IronGolem) {
/* 409 */       event.setDamage(6.0D);
/*     */     }
/* 411 */     if (event.getEntity() instanceof org.bukkit.entity.Fireball) {
/* 412 */       event.setCancelled(true);
/*     */       
/*     */       return;
/*     */     } 
/* 416 */     if (event.getEntity() instanceof Player) {
/* 417 */       Player player = (Player)event.getEntity();
/* 418 */       Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/*     */       
/* 420 */       if (!gamer.isAlive()) {
/* 421 */         event.setCancelled(true);
/*     */         
/*     */         return;
/*     */       } 
/* 425 */       for (ItemStack itemStack : player.getInventory().getArmorContents()) {
/* 426 */         itemStack.setDurability((short)0);
/*     */       }
/*     */       
/* 429 */       Player damager = null;
/*     */       
/* 431 */       if (event.getDamager() instanceof Player) {
/* 432 */         damager = (Player)event.getDamager();
/* 433 */       } else if (event.getDamager() instanceof Projectile) {
/* 434 */         Projectile projectile = (Projectile)event.getDamager();
/*     */         
/* 436 */         if (projectile.getShooter() instanceof Player) {
/* 437 */           damager = (Player)projectile.getShooter();
/*     */         }
/*     */       } 
/*     */       
/* 441 */       if (!(damager instanceof Player)) {
/*     */         return;
/*     */       }
/* 444 */       Gamer damagerGamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(damager.getUniqueId(), Gamer.class);
/*     */       
/* 446 */       if (!damagerGamer.isAlive()) {
/* 447 */         event.setCancelled(true);
/*     */         
/*     */         return;
/*     */       } 
/* 451 */       Island island = getIsland(player.getUniqueId());
/* 452 */       Island islandDamager = getIsland(damager.getUniqueId());
/*     */       
/* 454 */       if (island.getIslandColor() == islandDamager.getIslandColor())
/* 455 */         event.setCancelled(true); 
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerMoveUpdate(PlayerMoveUpdateEvent event) {
/* 461 */     Player player = event.getPlayer();
/* 462 */     Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/* 463 */     Island island = getIsland(player.getUniqueId());
/*     */     
/* 465 */     if (gamer.isAlive() && event.getTo().getY() <= GameMain.getInstance().getMinimunY()) {
/* 466 */       boolean finalKill = (island.getIslandStatus() != Island.IslandStatus.ALIVE);
/*     */       
/* 468 */       handleDeath(gamer, player);
/*     */       
/* 470 */       if (island.getIslandStatus() == Island.IslandStatus.LOSER) {
/* 471 */         spectate(player);
/*     */         
/*     */         return;
/*     */       } 
/* 475 */       if (finalKill) {
/* 476 */         island.checkLose();
/* 477 */         spectate(player);
/*     */       } else {
/* 479 */         respawn(player);
/*     */       } 
/*     */     } 
/* 482 */     if (player.hasMetadata("player-target"))
/* 483 */       if (gamer.isAlive()) {
/*     */         
/* 485 */         MetadataValue orElse = player.getMetadata("player-target").stream().findFirst().orElse(null);
/*     */         
/* 487 */         UUID uuid = UUID.fromString(orElse.asString());
/* 488 */         Player target = Bukkit.getPlayer(uuid);
/*     */         
/* 490 */         if (target == null) {
/*     */           return;
/*     */         }
/*     */         
/* 494 */         PlayerHelper.actionbar(player, "§aRastreando: §f" + target.getName() + " §7(" + CommonConst.DECIMAL_FORMAT
/* 495 */             .format(target.getLocation().distance(player.getLocation())) + " blocos)");
/*     */         
/* 497 */         player.setCompassTarget(target.getLocation());
/*     */       } else {
/* 499 */         player.removeMetadata("player-target", (Plugin)GameAPI.getInstance());
/*     */       }  
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onIslandLose(IslandLoseEvent event) {
/* 505 */     GameMain.getInstance().checkWinner();
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerDeath(PlayerDeathEvent event) {
/* 510 */     event.setDeathMessage(null);
/* 511 */     Player player = event.getEntity();
/* 512 */     Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/*     */     
/* 514 */     if (gamer.isSpectator()) {
/*     */       return;
/*     */     }
/* 517 */     if (gamer.isAlive()) {
/* 518 */       boolean finalKill = (getIsland(player.getUniqueId()).getIslandStatus() == Island.IslandStatus.BED_BROKEN);
/*     */       
/* 520 */       if (player.getKiller() instanceof Player) {
/* 521 */         Player killer = player.getKiller();
/*     */         
/* 523 */         for (ItemStack itemStack : event.getDrops()) {
/* 524 */           if (this.dropableItems.contains(itemStack.getType()))
/* 525 */             killer.getInventory().addItem(new ItemStack[] { itemStack }); 
/*     */         } 
/* 527 */         Bukkit.getPluginManager().callEvent((Event)new PlayerKillPlayerEvent(player, killer, finalKill));
/*     */       } 
/*     */       
/* 530 */       handleDeath(gamer, player);
/*     */       
/* 532 */       event.getDrops().clear();
/* 533 */       event.setDroppedExp(0);
/*     */       
/* 535 */       getIsland(player.getUniqueId()).checkLose();
/* 536 */       player.removeMetadata("player-armor", (Plugin)GameAPI.getInstance());
/*     */       
/* 538 */       if (finalKill) {
/* 539 */         spectate(player);
/*     */       } else {
/* 541 */         respawn(player);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   private void handleDeath(Gamer gamer, Player player) {
/* 546 */     boolean finalKill = (getIsland(player.getUniqueId()).getIslandStatus() == Island.IslandStatus.BED_BROKEN);
/*     */     
/* 548 */     player.setHealth(20.0D);
/* 549 */     player.setMaxHealth(20.0D);
/* 550 */     player.setLevel(0);
/* 551 */     player.setExp(0.0F);
/*     */     
/* 553 */     player.getInventory().clear();
/* 554 */     player.getInventory().setArmorContents(new ItemStack[4]);
/*     */     
/* 556 */     gamer.setAlive(false);
/* 557 */     gamer.setSwordLevel(Gamer.SwordLevel.WOOD);
/*     */     
/* 559 */     if (player.getKiller() instanceof Player) {
/* 560 */       Bukkit.getPluginManager().callEvent((Event)new PlayerKillPlayerEvent(player, player.getKiller(), finalKill));
/*     */     }
/* 562 */     if (gamer.getPickaxeLevel().ordinal() >= Gamer.PickaxeLevel.values()[2].ordinal()) {
/* 563 */       gamer.setPickaxeLevel(gamer.getPickaxeLevel().getPrevious());
/*     */     }
/* 565 */     if (gamer.getAxeLevel().ordinal() >= Gamer.AxeLevel.values()[2].ordinal()) {
/* 566 */       gamer.setAxeLevel(gamer.getAxeLevel().getPrevious());
/*     */     }
/* 568 */     broadcastDeath(player, player.getKiller(), finalKill);
/*     */   }
/*     */   
/*     */   public void broadcastDeath(Player player, Player killer, boolean finalKill) {
/* 572 */     Island island = getIsland(player.getUniqueId());
/* 573 */     StringBuilder stringBuilder = new StringBuilder();
/*     */     
/* 575 */     if (killer == null) {
/* 576 */       stringBuilder.append("§7" + island.getIslandColor().getColor() + player.getName() + " §7foi morto.");
/*     */     } else {
/* 578 */       Island killerIsland = getIsland(killer.getUniqueId());
/* 579 */       stringBuilder.append("§7" + island.getIslandColor().getColor() + player.getName() + " §7foi morto por " + killerIsland
/* 580 */           .getIslandColor().getColor() + killer.getName() + "§7.");
/*     */     } 
/*     */     
/* 583 */     if (finalKill) {
/* 584 */       stringBuilder.append(" ").append("§b§lFINAL KILL");
/*     */     }
/* 586 */     Bukkit.broadcastMessage(stringBuilder.toString().trim());
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGHEST)
/*     */   public void onPlayerJoin(PlayerJoinEvent event) {
/* 591 */     Player player = event.getPlayer();
/*     */     
/* 593 */     if (this.playerJoinMap.containsKey(player.getUniqueId())) {
/* 594 */       this.playerJoinMap.remove(player.getUniqueId());
/*     */     }
/* 596 */     Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/* 597 */     Island island = getIsland(player.getUniqueId());
/*     */     
/* 599 */     if (island != null && island.getIslandStatus() == Island.IslandStatus.ALIVE && !gamer.isSpectator()) {
/* 600 */       respawn(player);
/*     */       
/*     */       return;
/*     */     } 
/* 604 */     spectate(player);
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.NORMAL)
/*     */   public void onPlayerQuit(PlayerQuitEvent event) {
/* 609 */     Player player = event.getPlayer();
/* 610 */     Gamer gamer = (Gamer)GameMain.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/* 611 */     Island island = getIsland(player.getUniqueId());
/*     */     
/* 613 */     if (island != null && GameAPI.getInstance().getState() == MinigameState.GAMETIME) {
/* 614 */       if (gamer.isAlive()) {
/* 615 */         if (island.getIslandStatus() == Island.IslandStatus.BED_BROKEN) {
/* 616 */           broadcastDeath(player, null, true);
/* 617 */           gamer.setSpectator(true);
/*     */         } else {
/* 619 */           this.playerJoinMap.put(player.getUniqueId(), Long.valueOf(System.currentTimeMillis()));
/* 620 */           Bukkit.broadcastMessage("§7" + island
/* 621 */               .getIslandColor().getColor() + player.getName() + " §7desconectou.");
/*     */         } 
/*     */       }
/*     */       
/* 625 */       island.checkLose();
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onUpdate(UpdateEvent event) {
/* 631 */     if (event.getType() == UpdateEvent.UpdateType.SECOND) {
/* 632 */       for (UnmodifiableIterator<Map.Entry<UUID, Long>> unmodifiableIterator = ImmutableList.copyOf(this.playerJoinMap.entrySet()).iterator(); unmodifiableIterator.hasNext(); ) { Map.Entry<UUID, Long> next = unmodifiableIterator.next();
/* 633 */         if (((Long)next.getValue()).longValue() + 45000L < System.currentTimeMillis()) {
/* 634 */           this.playerJoinMap.remove(next.getKey());
/* 635 */           Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(next.getKey(), Gamer.class);
/*     */           
/* 637 */           gamer.setAlive(false);
/* 638 */           gamer.setSpectator(true);
/*     */           
/* 640 */           Island island = getIsland(gamer.getUniqueId());
/*     */           
/* 642 */           if (island != null) {
/* 643 */             if (island.getIslandStatus() == Island.IslandStatus.ALIVE && island.getTeam().getPlayerSet().stream()
/* 644 */               .map(id -> (Gamer)GameAPI.getInstance().getGamerManager().getGamer(id, Gamer.class))
/* 645 */               .filter(g -> g.isAlive()).count() == 0L) {
/* 646 */               island.handleBreakBed(null);
/*     */             }
/* 648 */             island.checkLose();
/*     */           } 
/*     */           
/* 651 */           Bukkit.broadcastMessage("§7" + island.getIslandColor().getColor() + gamer.getPlayerName() + " §7foi morto. §b§lFINAL KILL");
/*     */         }  }
/*     */     
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerInteract(PlayerInteractEvent event) {
/* 660 */     Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(event.getPlayer().getUniqueId(), Gamer.class);
/*     */     
/* 662 */     if (!gamer.isAlive()) {
/* 663 */       event.setCancelled(true);
/*     */       
/*     */       return;
/*     */     } 
/* 667 */     if (event.getAction() != Action.RIGHT_CLICK_BLOCK) {
/*     */       return;
/*     */     }
/* 670 */     Block block = event.getClickedBlock();
/*     */     
/* 672 */     if (block.getType() == Material.FURNACE || block.getType() == Material.ANVIL || block
/* 673 */       .getType() == Material.ENCHANTMENT_TABLE || block.getType() == Material.WORKBENCH) {
/* 674 */       event.setCancelled(true);
/*     */       
/*     */       return;
/*     */     } 
/* 678 */     if (block.getType() != Material.CHEST) {
/*     */       return;
/*     */     }
/* 681 */     Island playerIsland = getIsland(event.getPlayer().getUniqueId());
/*     */     
/* 683 */     if (playerIsland == null) {
/* 684 */       event.setCancelled(true);
/*     */       
/*     */       return;
/*     */     } 
/* 688 */     if (block.hasMetadata("chest-island")) {
/* 689 */       MetadataValue metadataValue = block.getMetadata("chest-island").stream().findFirst().orElse(null);
/* 690 */       Island island = getIsland((IslandColor)metadataValue.value());
/*     */       
/* 692 */       if (playerIsland.getIslandColor() != island.getIslandColor() && island
/* 693 */         .getIslandStatus() == Island.IslandStatus.ALIVE) {
/* 694 */         event.setCancelled(true);
/* 695 */         event.getPlayer()
/* 696 */           .sendMessage("§cVocê não pode abrir o baú do inimigo enquanto ele ainda estiver vivo.");
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerBedEnter(PlayerBedEnterEvent event) {
/* 703 */     event.setCancelled(true);
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
/*     */   public void onBlockBreak(BlockBreakEvent event) {
/* 708 */     Player player = event.getPlayer();
/*     */     
/* 710 */     if (player.getAllowFlight()) {
/* 711 */       event.setCancelled(true);
/*     */       
/*     */       return;
/*     */     } 
/* 715 */     Island playerIsland = getIsland(player.getUniqueId());
/*     */     
/* 717 */     if (playerIsland == null) {
/* 718 */       event.setCancelled(true);
/*     */       
/*     */       return;
/*     */     } 
/* 722 */     if (event.getBlock().getType() == Material.BED_BLOCK) {
/* 723 */       double distance = player.getLocation().distance(event.getBlock().getLocation());
/*     */       
/* 725 */       if (distance > 12.0D) {
/* 726 */         CommonPlugin.getInstance().getServerData().sendPacket((Packet)new Stafflog("O jogador " + player
/* 727 */               .getName() + " quebrou uma cama a " + distance + " blocos de distancia"));
/* 728 */         event.setCancelled(true);
/*     */         
/*     */         return;
/*     */       } 
/* 732 */       if (event.getBlock().hasMetadata("bed-island")) {
/*     */         
/* 734 */         MetadataValue metadataValue = event.getBlock().getMetadata("bed-island").stream().findFirst().orElse(null);
/*     */         
/* 736 */         Island island = GameMain.getInstance().getIslandManager().getIsland((IslandColor)metadataValue.value());
/*     */         
/* 738 */         if (playerIsland.getIslandColor() != island.getIslandColor()) {
/* 739 */           island.handleBreakBed(event.getPlayer());
/*     */           
/* 741 */           for (Location location : GameMain.getInstance()
/* 742 */             .getNearestBlocksByMaterial(event.getBlock().getLocation(), Material.BED_BLOCK, 2)) {
/* 743 */             location.getBlock().setType(Material.AIR);
/*     */           }
/*     */           
/* 746 */           ((Gamer)GameAPI.getInstance().getGamerManager().getGamer(event.getPlayer().getUniqueId(), Gamer.class))
/* 747 */             .addBedBroken();
/*     */         } else {
/* 749 */           event.setCancelled(true);
/*     */         } 
/*     */       } 
/*     */       return;
/*     */     } 
/* 754 */     if (GameMain.getInstance().getPlayersBlock().contains(event.getBlock().getLocation())) {
/* 755 */       GameMain.getInstance().getPlayersBlock().remove(event.getBlock().getLocation());
/*     */     } else {
/* 757 */       event.setCancelled(true);
/* 758 */       player.sendMessage(Language.getLanguage(player.getUniqueId()).t("bedwars-cant-break-this-block", new String[0]));
/*     */     } 
/*     */     
/* 761 */     if (player.getItemInHand() != null && player.getItemInHand().getType().name().contains("AXE")) {
/* 762 */       player.getItemInHand().setDurability((short)0);
/* 763 */       player.updateInventory();
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
/*     */   public void onBlockPlace(final BlockPlaceEvent event) {
/* 769 */     if (!isPlaceable(event.getBlock().getLocation())) {
/* 770 */       event.setCancelled(true);
/* 771 */       event.getPlayer().sendMessage(
/* 772 */           Language.getLanguage(event.getPlayer().getUniqueId()).t("bedwars.block-place.can-not-place-here", new String[0]));
/*     */       
/*     */       return;
/*     */     } 
/* 776 */     if (event.getBlock().getType() == Material.SPONGE) {
/* 777 */       (new BukkitRunnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 781 */             event.getBlock().setType(Material.AIR);
/*     */           }
/* 783 */         }).runTaskLater((Plugin)GameAPI.getInstance(), 3L);
/*     */       
/*     */       return;
/*     */     } 
/* 787 */     if (event.getBlock().getType() == Material.CHEST) {
/* 788 */       event.setCancelled(true);
/* 789 */       int amount = Math.max(event.getItemInHand().getAmount() - 1, 0);
/*     */       
/* 791 */       if (amount == 0) {
/* 792 */         event.getPlayer().setItemInHand(null);
/*     */       } else {
/* 794 */         event.getItemInHand().setAmount(amount);
/*     */       } 
/* 796 */       if (GameMain.getInstance().getTowerSchematic() == null) {
/* 797 */         event.getPlayer().sendMessage("§cNão foi possível spawnar a construção.");
/*     */         
/*     */         return;
/*     */       } 
/* 801 */       (new BukkitRunnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 805 */             BukkitCommon.getInstance().getBlockManager().spawn(event.getBlock().getLocation(), 
/* 806 */                 GameMain.getInstance().getTowerSchematic());
/*     */           }
/* 808 */         }).runTaskLater((Plugin)GameAPI.getInstance(), 3L);
/*     */       
/*     */       return;
/*     */     } 
/* 812 */     GameMain.getInstance().getPlayersBlock().add(event.getBlock().getLocation());
/*     */   }
/*     */   
/*     */   public boolean distanceSquared(Location locatioTo, Location locationFrom, double radius) {
/* 816 */     Location spawnLocation = locationFrom;
/* 817 */     double distX = locatioTo.getX() - spawnLocation.getX();
/* 818 */     double distZ = locatioTo.getZ() - spawnLocation.getZ();
/*     */     
/* 820 */     double distance = distX * distX + distZ * distZ;
/* 821 */     return (distance > radius * radius);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onBlockPhysics(BlockPhysicsEvent event) {
/* 826 */     if (event.getBlock().getType() == Material.BED_BLOCK)
/* 827 */       event.setCancelled(true); 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
/*     */   public void onPlayerAdmin(PlayerAdminEvent event) {
/* 832 */     Island island = getIsland(event.getPlayer().getUniqueId());
/*     */     
/* 834 */     if (island != null) {
/* 835 */       island.checkLose();
/*     */     }
/* 837 */     GameMain.getInstance().checkWinner();
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onEntityDeath(EntityDeathEvent event) {
/* 842 */     if (!(event.getEntity() instanceof Player)) {
/* 843 */       event.setDroppedExp(0);
/* 844 */       event.getDrops().clear();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void spectate(Player player) {
/* 849 */     if (player.getLocation().getY() <= 20.0D) {
/* 850 */       player.teleport(BukkitCommon.getInstance().getLocationManager().getLocation("central"));
/*     */     }
/*     */     
/* 853 */     GamerHelper.handleSpectate(player);
/* 854 */     ((Gamer)GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class)).setSpectator(true);
/* 855 */     GameAPI.getInstance().getVanishManager().updateVanishToPlayer(player);
/*     */     
/* 857 */     player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 20, 254));
/*     */   }
/*     */   
/*     */   private void respawn(final Player player) {
/* 861 */     final Language language = Language.getLanguage(player.getUniqueId());
/* 862 */     final Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/* 863 */     final Island island = getIsland(player.getUniqueId());
/*     */     
/* 865 */     if (player.getLocation().getY() < 20.0D) {
/* 866 */       player.teleport(GameAPI.getInstance().getLocationManager().getLocation("central"));
/*     */     } else {
/* 868 */       player.teleport(player.getLocation().add(0.0D, 2.5D, 0.0D));
/*     */     } 
/* 870 */     player.getInventory().clear();
/* 871 */     player.getInventory().setArmorContents(new ItemStack[4]);
/* 872 */     player.setAllowFlight(true);
/* 873 */     player.setFlying(true);
/* 874 */     player.setMetadata("invencibility", 
/* 875 */         GameAPI.getInstance().createMeta(Long.valueOf(System.currentTimeMillis() + 5000L)));
/*     */     
/* 877 */     player.getActivePotionEffects().forEach(potion -> player.removePotionEffect(potion.getType()));
/* 878 */     player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 140, 2));
/* 879 */     player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 20, 254));
/* 880 */     GamerHelper.hidePlayer(player);
/*     */     
/* 882 */     (new BukkitRunnable()
/*     */       {
/* 884 */         int time = 5;
/*     */ 
/*     */ 
/*     */         
/*     */         public void run() {
/* 889 */           if (player == null || !player.isOnline()) {
/* 890 */             cancel();
/*     */             
/*     */             return;
/*     */           } 
/* 894 */           if (this.time == 0) {
/* 895 */             GameMain.getInstance().getVanishManager().showPlayer(player);
/* 896 */             player.setFallDistance(-1.0F);
/* 897 */             player.teleport(island.getSpawnLocation().getAsLocation());
/* 898 */             gamer.setAlive(true);
/* 899 */             GamerHelper.handlePlayerToGame(player);
/* 900 */             PlayerHelper.title(player, language.t("bedwars-title-respawn", new String[0]), language
/* 901 */                 .t("bedwars-subtitle-respawn", new String[0]), 10, 20, 10);
/* 902 */             player.sendMessage(language.t("bedwars.message.respawn", new String[0]));
/* 903 */             GamerHelper.setPlayerProtection(player, 5);
/* 904 */             cancel();
/*     */           } else {
/* 906 */             PlayerHelper.title(player, language.t("bedwars-title-you-are-dead", new String[0]), language
/* 907 */                 .t("bedwars-subtitle-you-are-dead", new String[] { "%time%", "" + this.time }), 0, 20, 20);
/* 908 */             player.sendMessage(language.t("bedwars.message.respawning", new String[] { "%time%", "" + this.time }));
/*     */           } 
/*     */           
/* 911 */           this.time--;
/*     */         }
/* 914 */       }).runTaskTimer((Plugin)GameAPI.getInstance(), 20L, 20L);
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
/*     */   public void onPlayerBucketEmpty(final PlayerBucketEmptyEvent event) {
/* 919 */     (new BukkitRunnable()
/*     */       {
/*     */         public void run()
/*     */         {
/* 923 */           event.getPlayer().getInventory().remove(Material.BUCKET);
/*     */         }
/* 925 */       }).runTaskLater((Plugin)GameAPI.getInstance(), 3L);
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGHEST)
/*     */   public void onPlayerBucketEmpty(PlayerBucketFillEvent event) {
/* 930 */     event.setCancelled(true);
/*     */   }
/*     */   
/*     */   private int getSwordCount(Player player) {
/* 934 */     return getSwordCount((Inventory)player.getInventory());
/*     */   }
/*     */   
/*     */   private int getSwordCount(Inventory playerInventory) {
/* 938 */     int count = 0;
/* 939 */     for (int slot = 0; slot < playerInventory.getSize(); slot++) {
/* 940 */       ItemStack itemStack = playerInventory.getContents()[slot];
/*     */       
/* 942 */       if (itemStack != null && itemStack.getType().toString().contains("SWORD"))
/* 943 */         count++; 
/*     */     } 
/* 945 */     return count;
/*     */   }
/*     */   
/*     */   private int getItemCount(Player player, Material material) {
/* 949 */     int count = 0;
/*     */     
/* 951 */     for (int slot = 0; slot < player.getInventory().getSize(); slot++) {
/* 952 */       ItemStack itemStack = player.getInventory().getContents()[slot];
/*     */       
/* 954 */       if (itemStack != null && itemStack.getType() == material) {
/* 955 */         count++;
/*     */       }
/*     */     } 
/* 958 */     return count;
/*     */   }
/*     */   
/*     */   public boolean isPlaceable(Location location) {
/* 962 */     if (location.getY() >= GameMain.getInstance().getMaxHeight()) {
/* 963 */       return false;
/*     */     }
/* 965 */     if (GameMain.getInstance().getGeneratorManager().getGenerators().stream()
/* 966 */       .filter(generator -> (!distanceSquared(generator.getLocation(), location, 3.0D) && location.getY() < generator.getLocation().getY() + 6.0D))
/*     */       
/* 968 */       .findFirst().isPresent()) {
/* 969 */       return false;
/*     */     }
/* 971 */     Optional<Generator> optionalGenerator = GameMain.getInstance().getIslandManager().getClosestGenerator(location);
/*     */     
/* 973 */     if (location.distance(((Generator)optionalGenerator.get()).getLocation()) <= GameMain.getInstance()
/* 974 */       .getMinimunDistanceToPlaceBlocks()) {
/* 975 */       return false;
/*     */     }
/* 977 */     return true;
/*     */   }
/*     */   
/*     */   public Island getIsland(IslandColor islandColor) {
/* 981 */     return GameMain.getInstance().getIslandManager().getIsland(islandColor);
/*     */   }
/*     */   
/*     */   public Island getIsland(UUID playerId) {
/* 985 */     return GameMain.getInstance().getIslandManager().getIsland(playerId);
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/listener/GameListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */