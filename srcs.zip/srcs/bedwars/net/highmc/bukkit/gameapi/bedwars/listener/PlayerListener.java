/*    */ package net.highmc.bukkit.gameapi.bedwars.listener;
/*    */ 
/*    */ import net.highmc.bukkit.event.player.PlayerAdminEvent;
/*    */ import net.highmc.bukkit.gameapi.GameAPI;
/*    */ import net.highmc.bukkit.gameapi.bedwars.event.PlayerLevelUpEvent;
/*    */ import net.highmc.bukkit.gameapi.bedwars.gamer.Gamer;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.block.Block;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.block.Action;
/*    */ import org.bukkit.event.entity.CreatureSpawnEvent;
/*    */ import org.bukkit.event.entity.EntityExplodeEvent;
/*    */ import org.bukkit.event.entity.FoodLevelChangeEvent;
/*    */ import org.bukkit.event.inventory.CraftItemEvent;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ import org.bukkit.event.player.PlayerTeleportEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlayerListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
/*    */   public void onPlayerAdmin(PlayerAdminEvent event) {
/* 28 */     Player player = event.getPlayer();
/* 29 */     Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/*    */     
/* 31 */     if (event.getAdminMode() == PlayerAdminEvent.AdminMode.ADMIN) {
/* 32 */       gamer.setSpectator(true);
/*    */     } else {
/* 34 */       gamer.setSpectator(false);
/*    */     } 
/*    */   }
/*    */   @EventHandler(priority = EventPriority.HIGHEST)
/*    */   public void onPlayerInteract(PlayerInteractEvent event) {
/* 39 */     if (event.getAction() == Action.PHYSICAL)
/* 40 */       event.setCancelled(true); 
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerLevelUp(PlayerLevelUpEvent event) {
/* 45 */     Player player = event.getPlayer();
/*    */     
/* 47 */     if (player != null) {
/* 48 */       player.setExp(0.0F);
/* 49 */       player.setTotalExperience(0);
/* 50 */       player.setLevel(event.getLevel());
/*    */     } 
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerTeleport(PlayerTeleportEvent event) {
/* 56 */     if (event.getCause() == PlayerTeleportEvent.TeleportCause.ENDER_PEARL) {
/* 57 */       event.setCancelled(true);
/* 58 */       event.getPlayer().teleport(event.getTo());
/* 59 */       event.getPlayer().setFallDistance(-1.0F);
/*    */     } 
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onBlockList(EntityExplodeEvent event) {
/* 65 */     event.blockList().removeIf(b -> (b.getType() == Material.GLASS));
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onCraftItem(CraftItemEvent event) {
/* 70 */     event.setCancelled(true);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onFoodLevelChange(FoodLevelChangeEvent event) {
/* 75 */     event.setCancelled(true);
/*    */   }
/*    */   
/*    */   @EventHandler(priority = EventPriority.LOWEST)
/*    */   public void onCreatureSpawn(CreatureSpawnEvent event) {
/* 80 */     if (event.getSpawnReason() != CreatureSpawnEvent.SpawnReason.CUSTOM)
/* 81 */       event.setCancelled(true); 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/listener/PlayerListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */