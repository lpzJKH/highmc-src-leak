/*     */ package net.highmc.bukkit.gameapi.bedwars.menu.creator;
/*     */ 
/*     */ import net.highmc.bukkit.gameapi.bedwars.island.Island;
/*     */ import net.highmc.bukkit.utils.Location;
/*     */ import net.highmc.bukkit.utils.item.ActionItemStack;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*     */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*     */ import net.highmc.bukkit.utils.menu.confirm.ConfirmInventory;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.utils.string.StringFormat;
/*     */ import net.md_5.bungee.api.ChatColor;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ public class IslandCreatorInventory
/*     */ {
/*     */   public IslandCreatorInventory(Player player, Island island) {
/*  24 */     Language language = Language.getLanguage(player.getUniqueId());
/*  25 */     MenuInventory menuInventory = new MenuInventory(language.t("bedwars.inventory.island-creator.name", new String[] { "%island%", 
/*  26 */             StringFormat.formatString(island.getIslandColor().name()) }), 3);
/*     */     
/*  28 */     menuInventory.setItem(10, (new ItemBuilder())
/*  29 */         .name("§aSpawn Location").type(Material.PAPER)
/*  30 */         .lore(new String[] { "§fWorld: §7" + island.getSpawnLocation().getWorldName(), "§fLocation: §7" + 
/*  31 */             StringFormat.formatString(", ", new Number[] { Double.valueOf(island.getSpawnLocation().getX()), 
/*  32 */                 Double.valueOf(island.getSpawnLocation().getY()), Double.valueOf(island.getSpawnLocation().getZ())
/*  33 */               }), "§fYaw: §7" + island.getSpawnLocation().getYaw(), "§fPitch: §7" + island
/*  34 */             .getSpawnLocation().getPitch()
/*  35 */           }).build(), (p, inv, type, stack, slot) -> {
/*     */           if (type == ClickType.RIGHT) {
/*     */             p.teleport(island.getSpawnLocation().getAsLocation());
/*     */           } else {
/*     */             handle(p, island, stack, menuInventory, ());
/*     */           } 
/*     */         });
/*     */ 
/*     */     
/*  44 */     menuInventory.setItem(11, (new ItemBuilder())
/*  45 */         .name("§aBed Location").type(Material.BED)
/*  46 */         .lore(new String[] { "§fWorld: §7" + island.getBedLocation().getWorldName(), "§fLocation: §7" + 
/*  47 */             StringFormat.formatString(", ", new Number[] { Double.valueOf(island.getBedLocation().getX()), 
/*  48 */                 Double.valueOf(island.getBedLocation().getY()), Double.valueOf(island.getBedLocation().getZ())
/*  49 */               }), "§fYaw: §7" + island.getBedLocation().getYaw(), "§fPitch: §7" + island
/*  50 */             .getBedLocation().getPitch()
/*  51 */           }).build(), (p, inv, type, stack, slot) -> {
/*     */           if (type == ClickType.RIGHT) {
/*     */             p.teleport(island.getBedLocation().getAsLocation());
/*     */           } else {
/*     */             handle(p, island, stack, menuInventory, ());
/*     */           } 
/*     */         });
/*     */ 
/*     */     
/*  60 */     menuInventory.setItem(12, (new ItemBuilder())
/*  61 */         .name("§aShop Location").type(Material.EMERALD)
/*  62 */         .lore(new String[] { "§fWorld: §7" + island.getShopLocation().getWorldName(), "§fLocation: §7" + 
/*  63 */             StringFormat.formatString(", ", new Number[] { Double.valueOf(island.getShopLocation().getX()), 
/*  64 */                 Double.valueOf(island.getShopLocation().getY()), Double.valueOf(island.getShopLocation().getZ())
/*  65 */               }), "§fYaw: §7" + island.getShopLocation().getYaw(), "§fPitch: §7" + island
/*  66 */             .getShopLocation().getPitch()
/*  67 */           }).build(), (p, inv, type, stack, slot) -> {
/*     */           if (type == ClickType.RIGHT) {
/*     */             p.teleport(island.getShopLocation().getAsLocation());
/*     */           } else {
/*     */             handle(p, island, stack, menuInventory, ());
/*     */           } 
/*     */         });
/*     */ 
/*     */     
/*  76 */     menuInventory.setItem(13, (new ItemBuilder())
/*  77 */         .name("§aUpgrade Location").type(Material.DIAMOND)
/*  78 */         .lore(new String[] { "§fWorld: §7" + island.getUpgradeLocation().getWorldName(), "§fLocation: §7" + 
/*  79 */             StringFormat.formatString(", ", new Number[] { Double.valueOf(island.getUpgradeLocation().getX()), 
/*  80 */                 Double.valueOf(island.getUpgradeLocation().getY()), Double.valueOf(island.getUpgradeLocation().getZ())
/*  81 */               }), "§fYaw: §7" + island.getUpgradeLocation().getYaw(), "§fPitch: §7" + island
/*  82 */             .getUpgradeLocation().getPitch()
/*  83 */           }).build(), (p, inv, type, stack, slot) -> {
/*     */           if (type == ClickType.RIGHT) {
/*     */             p.teleport(island.getUpgradeLocation().getAsLocation());
/*     */           } else {
/*     */             handle(p, island, stack, menuInventory, ());
/*     */           } 
/*     */         });
/*     */ 
/*     */     
/*  92 */     menuInventory.setItem(14, (new ItemBuilder()).name("§aGenerators").type(Material.FURNACE).build(), (p, inv, type, stack, slot) -> new IslandCreatorGeneratorInventory(player, island));
/*     */ 
/*     */     
/*  95 */     menuInventory.setItem(16, (new ItemBuilder()).name("§aSave").type(Material.ENCHANTED_BOOK).build(), (p, inv, type, stack, slot) -> {
/*     */           p.performCommand("config bedwars save");
/*     */           
/*     */           p.closeInventory();
/*     */           
/*     */           if (p.getInventory().getItemInHand().getType() == Material.BARRIER) {
/*     */             p.getInventory().removeItem(new ItemStack[] { p.getInventory().getItemInHand() });
/*     */           }
/*     */         });
/* 104 */     menuInventory.open(player);
/*     */   }
/*     */ 
/*     */   
/*     */   private void handle(Player player, final Island island, final ItemStack itemStack, MenuInventory menuInventory, final ConfirmHandler confirmHandler) {
/* 109 */     player.getInventory().addItem(new ItemStack[] { (new ActionItemStack((new ItemBuilder())
/* 110 */             .type(itemStack.getType()).name(itemStack.getItemMeta().getDisplayName()).build(), new ActionItemStack.Interact()
/*     */             {
/*     */ 
/*     */ 
/*     */               
/*     */               public boolean onInteract(Player player, Entity entity, Block block, ItemStack item, ActionItemStack.ActionType action)
/*     */               {
/* 117 */                 new ConfirmInventory(player, "§7" + 
/* 118 */                     ChatColor.stripColor(itemStack.getItemMeta().getDisplayName()), b -> { if (b) { player.getInventory().remove(item); ActionItemStack.unregisterHandler(this); confirmHandler.confirm(); new IslandCreatorInventory(player, island); }  }null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 130 */                 return false;
/*     */               }
/* 132 */             })).getItemStack() });
/*     */     
/* 134 */     player.closeInventory();
/*     */   }
/*     */   
/*     */   public static interface ConfirmHandler {
/*     */     void confirm();
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/menu/creator/IslandCreatorInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */