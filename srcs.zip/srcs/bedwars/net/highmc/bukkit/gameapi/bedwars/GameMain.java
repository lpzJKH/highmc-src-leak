/*     */ package net.highmc.bukkit.gameapi.bedwars;
/*     */ import com.comphenix.protocol.PacketType;
/*     */ import com.comphenix.protocol.ProtocolLibrary;
/*     */ import com.comphenix.protocol.events.ListenerPriority;
/*     */ import com.comphenix.protocol.events.PacketAdapter;
/*     */ import com.comphenix.protocol.events.PacketEvent;
/*     */ import com.comphenix.protocol.events.PacketListener;
/*     */ import com.comphenix.protocol.wrappers.WrappedChatComponent;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Paths;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.stream.Collectors;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.gameapi.GameAPI;
/*     */ import net.highmc.bukkit.gameapi.bedwars.event.IslandWinEvent;
/*     */ import net.highmc.bukkit.gameapi.bedwars.gamer.Gamer;
/*     */ import net.highmc.bukkit.gameapi.bedwars.generator.Generator;
/*     */ import net.highmc.bukkit.gameapi.bedwars.generator.GeneratorType;
/*     */ import net.highmc.bukkit.gameapi.bedwars.island.Island;
/*     */ import net.highmc.bukkit.gameapi.bedwars.listener.PlayerListener;
/*     */ import net.highmc.bukkit.gameapi.bedwars.listener.ScoreboardListener;
/*     */ import net.highmc.bukkit.gameapi.bedwars.manager.GeneratorManager;
/*     */ import net.highmc.bukkit.gameapi.bedwars.manager.IslandManager;
/*     */ import net.highmc.bukkit.gameapi.bedwars.scheduler.GameScheduler;
/*     */ import net.highmc.bukkit.gameapi.bedwars.scheduler.WaitingScheduler;
/*     */ import net.highmc.bukkit.gameapi.scheduler.Scheduler;
/*     */ import net.highmc.bukkit.utils.player.PlayerHelper;
/*     */ import net.highmc.bukkit.utils.worldedit.schematic.Schematic;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.medal.Medal;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.server.ServerType;
/*     */ import net.highmc.server.loadbalancer.server.MinigameState;
/*     */ import net.highmc.utils.configuration.Configuration;
/*     */ import net.highmc.utils.configuration.impl.JsonConfiguration;
/*     */ import net.highmc.utils.string.StringFormat;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Difficulty;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.WorldBorder;
/*     */ import org.bukkit.WorldCreator;
/*     */ import org.bukkit.craftbukkit.libs.joptsimple.internal.Strings;
/*     */ import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Item;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.HandlerList;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.entity.ItemSpawnEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ 
/*     */ public class GameMain extends GameAPI implements Listener {
/*  63 */   public static final char[] CHARS = "abcdefghijklmnoprstuvwxyz".toCharArray(); private static GameMain instance; private GeneratorManager generatorManager; private IslandManager islandManager;
/*     */   public static GameMain getInstance() {
/*  65 */     return instance;
/*     */   }
/*     */   
/*  68 */   public GeneratorManager getGeneratorManager() { return this.generatorManager; } public IslandManager getIslandManager() {
/*  69 */     return this.islandManager;
/*     */   } public void setGeneratorUpgrade(NextUpgrade generatorUpgrade) {
/*  71 */     this.generatorUpgrade = generatorUpgrade;
/*  72 */   } private NextUpgrade generatorUpgrade = createUpgrade(GeneratorType.DIAMOND, 2, 360); private double minimunDistanceToPlaceBlocks; private double minimunY; public NextUpgrade getGeneratorUpgrade() { return this.generatorUpgrade; }
/*     */   
/*  74 */   public double getMinimunDistanceToPlaceBlocks() { return this.minimunDistanceToPlaceBlocks; } public double getMinimunY() {
/*  75 */     return this.minimunY;
/*  76 */   } private int playersPerTeam = 1; public void setPlayersPerTeam(int playersPerTeam) { this.playersPerTeam = playersPerTeam; } public int getPlayersPerTeam() {
/*  77 */     return this.playersPerTeam;
/*  78 */   } private int teamPerGame = 8; private double maxHeight; public void setTeamPerGame(int teamPerGame) { this.teamPerGame = teamPerGame; }
/*  79 */   public int getTeamPerGame() { return this.teamPerGame; }
/*  80 */   public void setMaxHeight(double maxHeight) { this.maxHeight = maxHeight; } public double getMaxHeight() {
/*  81 */     return this.maxHeight;
/*  82 */   } private List<Location> playersBlock = new ArrayList<>(); private Schematic towerSchematic; private JsonConfiguration configuration; public List<Location> getPlayersBlock() { return this.playersBlock; }
/*     */    public Schematic getTowerSchematic() {
/*  84 */     return this.towerSchematic;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onLoad() {
/*  90 */     super.onLoad();
/*     */     
/*  92 */     instance = this;
/*  93 */     loadConfiguration();
/*     */     
/*  95 */     setGamerClass(Gamer.class);
/*  96 */     setCollectionName("bedwars-gamer");
/*  97 */     setUnloadGamer(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/* 102 */     super.onEnable();
/*     */     
/*     */     try {
/* 105 */       this.towerSchematic = Schematic.getInstance().loadSchematic(new File(getDataFolder(), "tower.schematic"));
/* 106 */     } catch (IOException|net.highmc.bukkit.utils.worldedit.schematic.DataException iOException) {}
/*     */ 
/*     */     
/* 109 */     WorldCreator.name("spawn").createWorld();
/*     */     
/* 111 */     this.generatorManager = new GeneratorManager();
/* 112 */     this.islandManager = new IslandManager();
/*     */     
/* 114 */     setTime(60);
/* 115 */     setState(MinigameState.STARTING);
/* 116 */     setPlayersPerTeam(getPlugin().getServerType().getPlayersPerTeam());
/* 117 */     setTeamPerGame(getPlugin().getServerType().name().contains("X") ? 2 : (getPlayersPerTeam() * 8));
/* 118 */     setMaxPlayers(8 * getPlayersPerTeam());
/* 119 */     startScheduler((Scheduler)new WaitingScheduler());
/*     */     
/* 121 */     Bukkit.getPluginManager().registerEvents(this, (Plugin)this);
/* 122 */     Bukkit.getPluginManager().registerEvents((Listener)new PlayerListener(), (Plugin)this);
/* 123 */     Bukkit.getPluginManager().registerEvents((Listener)new ScoreboardListener(), (Plugin)this);
/*     */     
/* 125 */     Bukkit.getWorlds().forEach(world -> {
/*     */           world.setAutoSave(false);
/*     */           
/*     */           world.getEntitiesByClass(Item.class).forEach(());
/*     */           
/*     */           (((CraftWorld)world).getHandle()).savingDisabled = true;
/*     */           world.setDifficulty(Difficulty.NORMAL);
/*     */         });
/* 133 */     ProtocolLibrary.getProtocolManager().addPacketListener((PacketListener)new PacketAdapter((Plugin)this, ListenerPriority.NORMAL, new PacketType[] { PacketType.Play.Server.CHAT })
/*     */         {
/*     */           public void onPacketSending(PacketEvent e)
/*     */           {
/* 137 */             if (e.getPacketType() == PacketType.Play.Server.CHAT || e.getPacketType() == PacketType.Play.Client.CHAT) {
/*     */               
/*     */               try {
/* 140 */                 String json = ((WrappedChatComponent)e.getPacket().getChatComponents().read(0)).getJson();
/* 141 */                 if (json.equals("{\"translate\":\"tile.bed.noSleep\"}") || json.equals("{\"translate\":\"tile.bed.notValid\"}"))
/* 142 */                   e.setCancelled(true); 
/* 143 */               } catch (Exception exception) {}
/*     */             }
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onItemSpawn(ItemSpawnEvent event) {
/* 152 */     if (event.getEntity().getItemStack().getType() == Material.BED || event.getEntity().getItemStack().getType() == Material.BED_BLOCK)
/* 153 */       event.setCancelled(true); 
/*     */   }
/*     */   
/*     */   public Configuration getConfiguration() {
/* 157 */     return CommonPlugin.getInstance().getConfigurationManager().getConfigByName("bedwars");
/*     */   }
/*     */   
/*     */   private void loadConfiguration() {
/* 161 */     this.configuration = (JsonConfiguration)CommonPlugin.getInstance().getConfigurationManager().loadConfig("bedwars.json", Paths.get(getDataFolder().toURI()).getParent().getParent().toFile(), true, JsonConfiguration.class);
/*     */     
/*     */     try {
/* 164 */       this.configuration.loadConfig();
/* 165 */     } catch (Exception e) {
/* 166 */       e.printStackTrace();
/* 167 */       getPlugin().getPluginPlatform().shutdown("Cannot load the configuration bedwars.json.");
/*     */       
/*     */       return;
/*     */     } 
/* 171 */     setMap((String)this.configuration.get("mapName", "Unknown"));
/*     */     
/* 173 */     this.maxHeight = ((Double)this.configuration.get("maxHeight", Double.valueOf(100.0D))).doubleValue();
/* 174 */     this.minimunDistanceToPlaceBlocks = ((Double)this.configuration.get("distance-to-place-blocks", Double.valueOf(12.0D))).doubleValue();
/* 175 */     this.minimunY = ((Double)this.configuration.get("minimunY", Double.valueOf(10.0D))).doubleValue();
/*     */     
/* 177 */     debug("The configuration bedwars.json has been loaded!");
/*     */   }
/*     */   
/*     */   public void setMinimunY(double minimunY) {
/* 181 */     this.minimunY = minimunY;
/* 182 */     this.configuration.set("minimunY", Double.valueOf(10.0D));
/*     */     try {
/* 184 */       this.configuration.saveConfig();
/* 185 */     } catch (Exception e) {
/* 186 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setMinimunDistanceToPlaceBlocks(double minimunDistanceToPlaceBlocks) {
/* 191 */     this.minimunDistanceToPlaceBlocks = minimunDistanceToPlaceBlocks;
/* 192 */     this.configuration.set("distance-to-place-blocks", Double.valueOf(12.0D));
/*     */     
/*     */     try {
/* 195 */       this.configuration.saveConfig();
/* 196 */     } catch (Exception e) {
/* 197 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getId(Island island) {
/* 202 */     return CHARS[island.getIslandColor().getColor().ordinal()] + "";
/*     */   }
/*     */   
/*     */   public String getTag(Island island, Language language) {
/* 206 */     return "" + island.getIslandColor().getColor() + ChatColor.BOLD + language.t(island.getIslandColor().name().toLowerCase() + "-symbol", new String[0]) + island.getIslandColor().getColor() + " ";
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/* 211 */     Bukkit.getWorld("world").getEntities().forEach(entity -> {
/*     */           if (!(entity instanceof org.bukkit.entity.ItemFrame))
/*     */             entity.remove(); 
/*     */         });
/* 215 */     super.onDisable();
/*     */   }
/*     */   
/*     */   public int getMaxTeams() {
/* 219 */     return getTeamPerGame();
/*     */   }
/*     */   
/*     */   public void startGame() {
/* 223 */     for (Scheduler scheduler : getSchedulerManager().getSchedulers()) {
/* 224 */       getSchedulerManager().unloadScheduler(scheduler);
/*     */       
/* 226 */       if (scheduler instanceof WaitingScheduler) {
/* 227 */         HandlerList.unregisterAll((Listener)scheduler);
/*     */       }
/*     */     } 
/*     */     
/* 231 */     setUnloadGamer(false);
/* 232 */     GameAPI.getInstance().setState(MinigameState.GAMETIME);
/* 233 */     GameAPI.getInstance().startScheduler((Scheduler)new GameScheduler());
/*     */   }
/*     */   
/*     */   public List<Gamer> getAlivePlayers() {
/* 237 */     return GameAPI.getInstance().getGamerManager().filter(gamer -> gamer.isAlive(), Gamer.class);
/*     */   }
/*     */   
/*     */   public void checkWinner() {
/* 241 */     List<Island> islandList = (List<Island>)getInstance().getIslandManager().values().stream().filter(island -> (island.getIslandStatus() != Island.IslandStatus.LOSER)).collect(Collectors.toList());
/*     */     
/* 243 */     if (islandList.isEmpty()) {
/* 244 */       handleServer();
/* 245 */     } else if (islandList.size() == 1) {
/* 246 */       Island islandWinner = islandList.stream().findFirst().orElse(null);
/* 247 */       setState(MinigameState.WINNING);
/*     */       
/* 249 */       Bukkit.getPluginManager().callEvent((Event)new IslandWinEvent(islandWinner));
/*     */       
/* 251 */       Bukkit.getOnlinePlayers().forEach(player -> {
/*     */             Island island = getInstance().getIslandManager().getIsland(player.getUniqueId());
/*     */             
/*     */             if (island == islandWinner) {
/*     */               player.setAllowFlight(true);
/*     */               
/*     */               player.setFlying(true);
/*     */               
/*     */               PlayerHelper.title(player, "§%bedwars-title-win%§", "§%bedwars-subtitle-win%§", 10, 200, 10);
/*     */             } else {
/*     */               PlayerHelper.title(player, "§%bedwars-title-lose%§", "§%bedwars-subtitle-lose%§", 10, 200, 10);
/*     */             } 
/*     */           });
/* 264 */       List<Gamer> topGamers = (List<Gamer>)GameAPI.getInstance().getGamerManager().stream(Gamer.class).filter(gamer -> (!getVanishManager().isPlayerInAdmin(gamer.getUniqueId()) && getIslandManager().getIsland(gamer.getUniqueId()) != null)).sorted((o1, o2) -> o2.getFinalKills() - o1.getFinalKills()).collect(Collectors.toList());
/* 265 */       Gamer gamer = GameAPI.getInstance().getGamerManager().sort((o1, o2) -> o2.getBrokenBeds() - o1.getBrokenBeds(), Gamer.class).stream().findFirst().orElse(null);
/*     */       
/* 267 */       Bukkit.getOnlinePlayers().forEach(player -> {
/*     */             Language language = Language.getLanguage(player.getUniqueId());
/*     */             
/*     */             player.sendMessage("§a§m" + Strings.repeat('-', 64));
/*     */             
/*     */             player.sendMessage(StringFormat.centerString("§b§lBed Wars", 128));
/*     */             
/*     */             player.sendMessage(StringFormat.centerString("§eVencedor §7- " + islandWinner.getIslandColor().getColor() + "Time §%" + islandWinner.getIslandColor().name().toLowerCase() + "-name%§", 128));
/*     */             
/*     */             player.sendMessage("");
/*     */             
/*     */             player.sendMessage(StringFormat.centerString(language.t("bedwars.win-message.top-final-kills", new String[0]), 128));
/*     */             
/*     */             for (int i = 1; i <= Math.min(topGamers.size(), 3); i++) {
/*     */               player.sendMessage(StringFormat.centerString(((i == 1) ? "§a" : ((i == 2) ? "§e" : "§c")) + i + "° §7" + ((Gamer)topGamers.get(i - 1)).getPlayerName() + " §b- §f" + ((Gamer)topGamers.get(i - 1)).getFinalKills(), 128));
/*     */             }
/*     */             player.sendMessage("");
/*     */             player.sendMessage(StringFormat.centerString(language.t("bedwars.win-message.top-bed-broker", new String[0]), 128));
/*     */             player.sendMessage(StringFormat.centerString("§7" + gamer.getPlayerName() + " §b- §f" + gamer.getBrokenBeds(), 128));
/*     */             player.sendMessage(" ");
/*     */             player.sendMessage("§a§m" + Strings.repeat('-', 64));
/*     */           });
/* 289 */       handleServer();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void handleServer() {
/* 294 */     (new BukkitRunnable()
/*     */       {
/* 296 */         int time = 0;
/*     */ 
/*     */         
/*     */         public void run() {
/* 300 */           if (Bukkit.getOnlinePlayers().isEmpty()) {
/* 301 */             Bukkit.shutdown();
/*     */             
/*     */             return;
/*     */           } 
/* 305 */           if (++this.time == 8) {
/* 306 */             Bukkit.getOnlinePlayers().forEach(player -> GameAPI.getInstance().sendPlayerToServer(player, new ServerType[] { CommonPlugin.getInstance().getServerType(), CommonPlugin.getInstance().getServerType().getServerLobby(), ServerType.LOBBY }));
/*     */           
/*     */           }
/* 309 */           else if (this.time == 12) {
/* 310 */             Bukkit.shutdown();
/*     */           }
/*     */         
/*     */         }
/* 314 */       }).runTaskTimer((Plugin)GameAPI.getInstance(), 20L, 20L);
/*     */   }
/*     */   
/*     */   public List<Location> getNearestBlocksByMaterial(Location location, Material material, int radius, int height) {
/* 318 */     List<Location> locationList = new ArrayList<>();
/*     */     
/* 320 */     for (int x = -radius; x < radius; x++) {
/* 321 */       for (int y = -height; y < height; y++) {
/* 322 */         for (int z = -radius; z < radius; z++) {
/* 323 */           Location loc = location.clone().add(x, y, z);
/*     */           
/* 325 */           if (loc.getBlock().getType() == material) {
/* 326 */             locationList.add(loc.getBlock().getLocation());
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 332 */     return locationList;
/*     */   }
/*     */   
/*     */   public List<Location> getNearestBlocksByMaterial(Location location, Material material, int radius) {
/* 336 */     return getNearestBlocksByMaterial(location, material, radius, 0);
/*     */   }
/*     */   
/*     */   public NextUpgrade createUpgrade(GeneratorType generatorType, int level, int timer) {
/* 340 */     return new NextUpgrade(generatorType.name().toLowerCase() + "-" + level, timer, v -> {
/*     */           if (generatorType == GeneratorType.EMERALD && level == 3) {
/*     */             setGeneratorUpgrade(new NextUpgrade("Deathmatch", GameAPI.getInstance().getTime() + 1 + 360 - 60, ()));
/*     */             return;
/*     */           } 
/*     */           GeneratorType newUpgrade = (generatorType == GeneratorType.DIAMOND) ? GeneratorType.EMERALD : GeneratorType.DIAMOND;
/*     */           setGeneratorUpgrade(createUpgrade(newUpgrade, ((Generator)getGeneratorManager().getGenerators(newUpgrade).stream().findFirst().orElse(null)).getLevel() + 1, GameAPI.getInstance().getTime() + 1 + 360));
/*     */           List<Generator> list = getGeneratorManager().getGenerators(generatorType);
/*     */           for (Generator generator : list) {
/*     */             generator.setLevel(generator.getLevel() + 1);
/*     */           }
/*     */           if (generatorType == GeneratorType.DIAMOND) {
/*     */             generatorType.setTimer(generatorType.getTimer() - (level - 1) * 5);
/*     */           } else {
/*     */             generatorType.setTimer(generatorType.getTimer() - (level - 1) * 10);
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createMessage(Player player, String message, Island island, boolean global, boolean globaPrefix, int level) {
/* 374 */     String levelFormatted = "§7[" + getColorByLevel(level) + "§7]";
/*     */     
/* 376 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId());
/* 377 */     Medal medal = member.getMedal();
/*     */     
/* 379 */     return ((globaPrefix ? (global ? "§6[G] " : "") : "") + island.getIslandColor().getColor() + "[§%" + island.getIslandColor().name().toLowerCase() + "-symbol%§] " + levelFormatted + " " + ((medal == null) ? "" : (medal.getChatColor() + medal.getSymbol() + " ")) + member.getTag().getRealPrefix() + player.getName() + " §7» §f" + message).trim();
/*     */   } public class NextUpgrade { private String name;
/*     */     public NextUpgrade(String name, int timer, Consumer<Void> consumer) {
/* 382 */       this.name = name; this.timer = timer; this.consumer = consumer;
/*     */     }
/*     */     private int timer; private Consumer<Void> consumer;
/*     */     public String getName() {
/* 386 */       return this.name; } public int getTimer() {
/* 387 */       return this.timer;
/*     */     } public Consumer<Void> getConsumer() {
/* 389 */       return this.consumer;
/*     */     } }
/*     */ 
/*     */   
/*     */   public boolean hasLose(UUID uniqueId) {
/* 394 */     Island island = getIslandManager().getIsland(uniqueId);
/*     */     
/* 396 */     return (island == null) ? true : ((island.getIslandStatus() == Island.IslandStatus.LOSER));
/*     */   }
/*     */   
/*     */   public boolean isSpectator(UUID uniqueId) {
/* 400 */     Gamer gamer = (Gamer)getGamerManager().getGamer(uniqueId, Gamer.class);
/*     */     
/* 402 */     return (gamer == null) ? false : gamer.isSpectator();
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/GameMain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */