/*    */ package net.highmc.bukkit.gameapi.bedwars.listener;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import net.highmc.bukkit.event.player.PlayerDamagePlayerEvent;
/*    */ import net.highmc.bukkit.gameapi.GameAPI;
/*    */ import net.highmc.bukkit.gameapi.bedwars.utils.GamerHelper;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerQuitEvent;
/*    */ import org.bukkit.metadata.MetadataValue;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CombatListener
/*    */   implements Listener
/*    */ {
/* 24 */   private Map<UUID, Combat> playerMap = new HashMap<>(); public Map<UUID, Combat> getPlayerMap() { return this.playerMap; }
/*    */   
/*    */   @EventHandler(priority = EventPriority.HIGHEST)
/*    */   public void onPlayerDamagePlayer(PlayerDamagePlayerEvent event) {
/* 28 */     Player player = event.getPlayer();
/*    */     
/* 30 */     if (GamerHelper.isPlayerProtection(player)) {
/* 31 */       event.setCancelled(true);
/*    */       
/*    */       return;
/*    */     } 
/* 35 */     if (player.hasMetadata("invencibility")) {
/*    */       
/* 37 */       MetadataValue metadataValue = player.getMetadata("invencibility").stream().findFirst().orElse(null);
/*    */       
/* 39 */       if (metadataValue.asLong() > System.currentTimeMillis()) {
/* 40 */         event.setCancelled(true);
/*    */         
/*    */         return;
/*    */       } 
/* 44 */       player.removeMetadata("invencibility", (Plugin)GameAPI.getInstance());
/*    */       
/*    */       return;
/*    */     } 
/* 48 */     Player damager = event.getDamager();
/*    */     
/* 50 */     if (GamerHelper.isPlayerProtection(damager)) {
/* 51 */       GamerHelper.removePlayerProtection(damager);
/*    */     }
/* 53 */     if (damager.hasMetadata("invencibility")) {
/* 54 */       damager.removeMetadata("invencibility", (Plugin)GameAPI.getInstance());
/*    */     }
/* 56 */     if (damager.getItemInHand() != null && damager.getItemInHand().getType().name().contains("SWORD")) {
/* 57 */       damager.getItemInHand().setDurability((short)0);
/* 58 */       damager.updateInventory();
/*    */     } 
/*    */     
/* 61 */     this.playerMap.put(player.getUniqueId(), new Combat(damager.getUniqueId(), System.currentTimeMillis()));
/* 62 */     this.playerMap.put(damager.getUniqueId(), new Combat(player.getUniqueId(), System.currentTimeMillis()));
/*    */     
/* 64 */     event.setDamage(event.getDamage() * 1.2D);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerQuit(PlayerQuitEvent event) {
/* 69 */     if (this.playerMap.containsKey(event.getPlayer().getUniqueId()))
/* 70 */       this.playerMap.remove(event.getPlayer().getUniqueId()); 
/*    */   }
/*    */   public class Combat { private UUID lastPlayer;
/*    */     public Combat(UUID lastPlayer, long createdAt) {
/* 74 */       this.lastPlayer = lastPlayer; this.createdAt = createdAt;
/*    */     } private long createdAt;
/*    */     public UUID getLastPlayer() {
/* 77 */       return this.lastPlayer; } public long getCreatedAt() {
/* 78 */       return this.createdAt;
/*    */     } }
/*    */ 
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/listener/CombatListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */