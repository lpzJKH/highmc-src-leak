/*     */ package net.highmc.bukkit.gameapi.bedwars.store;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.enchantments.Enchantment;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.potion.PotionEffect;
/*     */ import org.bukkit.potion.PotionEffectType;
/*     */ 
/*     */ public enum ShopCategory {
/*     */   ShopCategory(String name, Material material, List<ShopItem> shopItem) {
/*     */     this.name = name;
/*     */     this.material = material;
/*     */     this.shopItem = shopItem;
/*     */   }
/*     */   
/*     */   private String name;
/*     */   private Material material;
/*  23 */   FAVORITES("Compra rápida", Material.NETHER_STAR, new ArrayList<>()),
/*     */   
/*  25 */   BLOCKS("Blocos", Material.WOOD, Arrays.asList(new ShopItem[] { new ShopItem((new ItemBuilder())
/*  26 */           .type(Material.WOOL).name("Lã").amount(16).build(), new ShopPrice(Material.IRON_INGOT, 4)), new ShopItem((new ItemBuilder())
/*     */           
/*  28 */           .type(Material.STAINED_CLAY).name("Argila").amount(16).build(), new ShopPrice(Material.IRON_INGOT, 12)), new ShopItem((new ItemBuilder())
/*     */ 
/*     */           
/*  31 */           .type(Material.STAINED_GLASS).name("Vidro à prova de explosões").amount(4).build(), new ShopPrice(Material.IRON_INGOT, 12)), new ShopItem((new ItemBuilder())
/*     */           
/*  33 */           .type(Material.ENDER_STONE).name("Pedra do fim").amount(12).build(), new ShopPrice(Material.IRON_INGOT, 24)), new ShopItem((new ItemBuilder())
/*     */           
/*  35 */           .type(Material.LADDER).name("Escada").amount(16).build(), new ShopPrice(Material.IRON_INGOT, 4)), new ShopItem((new ItemBuilder())
/*     */           
/*  37 */           .type(Material.WOOD).name("Madeira").amount(16).build(), new ShopPrice(Material.GOLD_INGOT, 4)), new ShopItem((new ItemBuilder())
/*     */           
/*  39 */           .type(Material.OBSIDIAN).name("Obsidian").amount(4).build(), new ShopPrice(Material.EMERALD, 4))
/*     */       })),
/*  41 */   SWORDS("Espadas", Material.GOLD_SWORD, 
/*  42 */     Arrays.asList(new ShopItem[] {
/*  43 */         new ShopItem((new ItemBuilder()).type(Material.STONE_SWORD).name("Espada de Pedra").build(), new ShopPrice(Material.IRON_INGOT, 10)), new ShopItem((new ItemBuilder())
/*     */           
/*  45 */           .type(Material.IRON_SWORD).name("Espada de Ferro").build(), new ShopPrice(Material.GOLD_INGOT, 7)), new ShopItem((new ItemBuilder())
/*     */           
/*  47 */           .type(Material.DIAMOND_SWORD).name("Espada de Diamante").build(), new ShopPrice(Material.EMERALD, 4)), new ShopItem((new ItemBuilder())
/*     */           
/*  49 */           .type(Material.STICK).enchantment(Enchantment.KNOCKBACK)
/*  50 */           .name("Graveto com Repulsão").build(), new ShopPrice(Material.GOLD_INGOT, 5)) })),
/*  51 */   ARMOR("Armaduras", Material.CHAINMAIL_BOOTS, 
/*  52 */     Arrays.asList(new ShopItem[] {
/*  53 */         new ShopItem((new ItemBuilder()).type(Material.CHAINMAIL_BOOTS).name("Armadura de Malha").build(), new ShopPrice(Material.IRON_INGOT, 30)), new ShopItem((new ItemBuilder())
/*     */           
/*  55 */           .type(Material.IRON_BOOTS).name("Armadura de Ferro").build(), new ShopPrice(Material.GOLD_INGOT, 12)), new ShopItem((new ItemBuilder())
/*     */           
/*  57 */           .type(Material.DIAMOND_BOOTS).name("Armadura de Diamante").build(), new ShopPrice(Material.EMERALD, 6))
/*     */       })),
/*  59 */   EQUIP("Equipamentos", Material.STONE_PICKAXE, 
/*  60 */     Arrays.asList(new ShopItem[] {
/*  61 */         new ShopItem((new ItemBuilder()).type(Material.SHEARS).name("Tesoura").build(), new ShopPrice(Material.IRON_INGOT, 20)), new ShopItem((new ItemBuilder())
/*     */           
/*  63 */           .type(Material.GOLD_PICKAXE).name("Picareta").build(), new ShopPrice(Material.IRON_INGOT, 1)), new ShopItem((new ItemBuilder())
/*     */           
/*  65 */           .type(Material.GOLD_AXE).name("Machado").build(), new ShopPrice(Material.IRON_INGOT, 1))
/*     */       })),
/*  67 */   ARCHERS("Arcos", Material.BOW, 
/*  68 */     Arrays.asList(new ShopItem[] {
/*  69 */         new ShopItem((new ItemBuilder()).type(Material.ARROW).name("Flecha").amount(8).build(), new ShopPrice(Material.GOLD_INGOT, 2)), new ShopItem((new ItemBuilder())
/*     */           
/*  71 */           .type(Material.BOW).name("Arco").build(), new ShopPrice(Material.GOLD_INGOT, 12)), new ShopItem((new ItemBuilder())
/*     */           
/*  73 */           .type(Material.BOW).name("Arco (Força I)")
/*  74 */           .enchantment(Enchantment.ARROW_DAMAGE).build(), new ShopPrice(Material.GOLD_INGOT, 24)), new ShopItem((new ItemBuilder())
/*     */           
/*  76 */           .type(Material.BOW).name("Arco (Força I e Impacto I)")
/*  77 */           .enchantment(Enchantment.ARROW_DAMAGE).enchantment(Enchantment.ARROW_KNOCKBACK)
/*  78 */           .build(), new ShopPrice(Material.EMERALD, 6))
/*     */       })),
/*  80 */   POTIONS("Poções", Material.BREWING_STAND_ITEM, Arrays.asList(new ShopItem[] { new ShopItem((new ItemBuilder())
/*     */ 
/*     */           
/*  83 */           .name("Poção de Agilidade II (45 Segundos)").type(Material.POTION)
/*  84 */           .potion(new PotionEffect(PotionEffectType.SPEED, 900, 1)).durability(8226).build(), new ShopPrice(Material.EMERALD, 1)), new ShopItem((new ItemBuilder())
/*     */ 
/*     */ 
/*     */           
/*  88 */           .name("Poção de Invisibilidade (30 Segundos)").type(Material.POTION)
/*  89 */           .potion(new PotionEffect(PotionEffectType.INVISIBILITY, 600, 0)).durability(8238).build(), new ShopPrice(Material.EMERALD, 2)), new ShopItem((new ItemBuilder())
/*     */ 
/*     */ 
/*     */           
/*  93 */           .name("Poção de Super Pulo V (45 Segundos)").type(Material.POTION)
/*  94 */           .potion(new PotionEffect(PotionEffectType.JUMP, 900, 4)).durability(8203).build(), new ShopPrice(Material.EMERALD, 1))
/*     */       })),
/*  96 */   UTILITIES("Utilidades", Material.TNT, Arrays.asList(new ShopItem[] { new ShopItem((new ItemBuilder())
/*     */           
/*  98 */           .type(Material.GOLDEN_APPLE).name("Maça dourada").build(), new ShopPrice(Material.GOLD_INGOT, 3)), new ShopItem((new ItemBuilder())
/*     */           
/* 100 */           .type(Material.SNOW_BALL).name("Traça").build(), new ShopPrice(Material.IRON_INGOT, 40)), new ShopItem((new ItemBuilder())
/*     */ 
/*     */           
/* 103 */           .type(Material.FIREBALL).name("Bola de Fogo").build(), new ShopPrice(Material.IRON_INGOT, 40)), new ShopItem((new ItemBuilder())
/*     */           
/* 105 */           .type(Material.MONSTER_EGG).name("Defesa dos Sonhos").build(), new ShopPrice(Material.IRON_INGOT, 120)), new ShopItem((new ItemBuilder())
/*     */ 
/*     */           
/* 108 */           .type(Material.TNT).name("TNT").build(), new ShopPrice(Material.GOLD_INGOT, 4)), new ShopItem((new ItemBuilder())
/*     */ 
/*     */           
/* 111 */           .type(Material.ENDER_PEARL).name("Pérola do Fim").build(), new ShopPrice(Material.EMERALD, 4)), new ShopItem((new ItemBuilder())
/*     */ 
/*     */           
/* 114 */           .type(Material.WATER_BUCKET).name("Balde de Água").build(), new ShopPrice(Material.GOLD_INGOT, 3)), new ShopItem((new ItemBuilder())
/*     */ 
/*     */           
/* 117 */           .type(Material.MILK_BUCKET).name("Leite Mágico").build(), new ShopPrice(Material.GOLD_INGOT, 4)), new ShopItem((new ItemBuilder())
/*     */ 
/*     */           
/* 120 */           .type(Material.SPONGE).name("Esponja").amount(4).build(), new ShopPrice(Material.GOLD_INGOT, 3)), new ShopItem((new ItemBuilder())
/*     */ 
/*     */           
/* 123 */           .type(Material.EGG).name("Ovo").build(), new ShopPrice(Material.EMERALD, 2)), new ShopItem((new ItemBuilder())
/*     */           
/* 125 */           .type(Material.COMPASS).name("Rastreador").build(), new ShopPrice(Material.EMERALD, 2)) })); private List<ShopItem> shopItem; public static final Map<String, ShopCategory> MAP;
/*     */   
/*     */   public String getName() {
/* 128 */     return this.name; }
/* 129 */   public Material getMaterial() { return this.material; } public List<ShopItem> getShopItem() {
/* 130 */     return this.shopItem;
/*     */   }
/*     */ 
/*     */   
/*     */   static {
/* 135 */     MAP = new HashMap<>();
/*     */     
/* 137 */     for (ShopCategory category : values()) {
/* 138 */       MAP.put(category.name().toLowerCase(), category);
/* 139 */       MAP.put(category.getMaterial().name().toLowerCase(), category);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static ShopCategory getCategoryByName(String name) {
/* 144 */     return MAP.get(name.toLowerCase());
/*     */   }
/*     */   
/*     */   public static ShopCategory getCategoryByIcon(Material material) {
/* 148 */     return MAP.get(material.name().toLowerCase());
/*     */   } public static class ShopItem { private ItemStack stack;
/*     */     public ShopItem(ItemStack stack, ShopCategory.ShopPrice price) {
/* 151 */       this.stack = stack; this.price = price;
/*     */     }
/*     */     private ShopCategory.ShopPrice price;
/*     */     public ItemStack getStack() {
/* 155 */       return this.stack; } public ShopCategory.ShopPrice getPrice() {
/* 156 */       return this.price;
/*     */     } }
/*     */   public static class ShopPrice { private Material material; private int amount;
/*     */     public ShopPrice(Material material, int amount) {
/* 160 */       this.material = material; this.amount = amount;
/*     */     }
/*     */     
/*     */     public Material getMaterial() {
/* 164 */       return this.material; } public int getAmount() {
/* 165 */       return this.amount;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/store/ShopCategory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */