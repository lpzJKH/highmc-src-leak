/*    */ package net.highmc.bukkit.gameapi.bedwars.event;
/*    */ 
/*    */ import lombok.NonNull;
/*    */ import net.highmc.bukkit.event.PlayerCancellableEvent;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class PlayerBoughtItemEvent
/*    */   extends PlayerCancellableEvent {
/*    */   private ItemStack itemStack;
/*    */   
/*    */   public ItemStack getItemStack() {
/* 13 */     return this.itemStack; } public void setItemStack(ItemStack itemStack) {
/* 14 */     this.itemStack = itemStack;
/*    */   }
/*    */   
/*    */   public PlayerBoughtItemEvent(@NonNull Player player, ItemStack itemStack) {
/* 18 */     super(player); if (player == null)
/* 19 */       throw new NullPointerException("player is marked non-null but is null");  this.itemStack = itemStack;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/event/PlayerBoughtItemEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */