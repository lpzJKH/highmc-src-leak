/*     */ package net.highmc.bukkit.gameapi.bedwars.utils;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.gameapi.GameAPI;
/*     */ import net.highmc.bukkit.gameapi.bedwars.GameMain;
/*     */ import net.highmc.bukkit.gameapi.bedwars.event.PlayerBoughtItemEvent;
/*     */ import net.highmc.bukkit.gameapi.bedwars.event.PlayerSpectateEvent;
/*     */ import net.highmc.bukkit.gameapi.bedwars.gamer.Gamer;
/*     */ import net.highmc.bukkit.gameapi.bedwars.island.Island;
/*     */ import net.highmc.bukkit.gameapi.bedwars.island.IslandUpgrade;
/*     */ import net.highmc.bukkit.gameapi.bedwars.menu.SpectatorInventory;
/*     */ import net.highmc.bukkit.gameapi.bedwars.store.ShopCategory;
/*     */ import net.highmc.bukkit.utils.item.ActionItemStack;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.member.status.Status;
/*     */ import net.highmc.member.status.StatusType;
/*     */ import net.highmc.member.status.types.BedwarsCategory;
/*     */ import net.highmc.server.ServerType;
/*     */ import net.md_5.bungee.api.ChatColor;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.enchantments.Enchantment;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.metadata.MetadataValue;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.potion.PotionEffect;
/*     */ import org.bukkit.potion.PotionEffectType;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ import org.bukkit.scoreboard.Criterias;
/*     */ import org.bukkit.scoreboard.DisplaySlot;
/*     */ import org.bukkit.scoreboard.Objective;
/*     */ import org.bukkit.scoreboard.Scoreboard;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GamerHelper
/*     */ {
/*  50 */   public static final ActionItemStack PLAYERS = new ActionItemStack((new ItemBuilder())
/*  51 */       .name("§aTeleportador").type(Material.COMPASS).build(), new ActionItemStack.Interact()
/*     */       {
/*     */         
/*     */         public boolean onInteract(Player player, Entity entity, Block block, ItemStack item, ActionItemStack.ActionType action)
/*     */         {
/*  56 */           new SpectatorInventory(player);
/*  57 */           return false;
/*     */         }
/*     */       });
/*     */   
/*  61 */   public static final ActionItemStack PLAY_AGAIN = new ActionItemStack((new ItemBuilder())
/*  62 */       .name("§aJogar novamente").type(Material.PAPER).build(), new ActionItemStack.Interact()
/*     */       {
/*     */         
/*     */         public boolean onInteract(Player player, Entity entity, Block block, ItemStack item, ActionItemStack.ActionType action)
/*     */         {
/*  67 */           GameAPI.getInstance().sendPlayerToServer(player, new ServerType[] { CommonPlugin.getInstance().getServerType() });
/*  68 */           return false;
/*     */         }
/*     */       });
/*     */   
/*  72 */   public static final ActionItemStack LOBBY = new ActionItemStack((new ItemBuilder())
/*  73 */       .name("§aVoltar ao lobby").type(Material.BED).build(), new ActionItemStack.Interact()
/*     */       {
/*     */         
/*     */         public boolean onInteract(Player player, Entity entity, Block block, ItemStack item, ActionItemStack.ActionType action)
/*     */         {
/*  78 */           GameAPI.getInstance().sendPlayerToServer(player, new ServerType[] {
/*  79 */                 CommonPlugin.getInstance().getServerType().getServerLobby() });
/*  80 */           return false;
/*     */         }
/*     */       });
/*     */ 
/*     */ 
/*     */   
/*     */   public static void handlePlayerToSpawn(Player player) {
/*  87 */     handlePlayer(player);
/*  88 */     player.getInventory().setItem(8, LOBBY.getItemStack());
/*     */   }
/*     */   
/*     */   public static boolean isPlayerProtection(Player player) {
/*  92 */     if (player.hasMetadata("bed-island")) {
/*  93 */       MetadataValue metadataValue = player.getMetadata("bed-island").stream().findFirst().orElse(null);
/*     */       
/*  95 */       if (metadataValue.asLong() > System.currentTimeMillis()) {
/*  96 */         return true;
/*     */       }
/*  98 */       metadataValue.invalidate();
/*     */     } 
/*     */     
/* 101 */     return false;
/*     */   }
/*     */   
/*     */   public static void setPlayerProtection(Player player, int seconds) {
/* 105 */     player.setMetadata("bed-island", 
/* 106 */         GameAPI.getInstance().createMeta(Long.valueOf(System.currentTimeMillis() + (seconds * 1000))));
/*     */   }
/*     */   
/*     */   public static void removePlayerProtection(Player player) {
/* 110 */     player.removeMetadata("bed-island", (Plugin)GameAPI.getInstance());
/*     */   }
/*     */   
/*     */   public static void handlePlayerToGame(Player player) {
/* 114 */     Island island = GameMain.getInstance().getIslandManager().getIsland(player.getUniqueId());
/*     */     
/* 116 */     if (island == null) {
/*     */       return;
/*     */     }
/* 119 */     Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/*     */     
/* 121 */     handlePlayer(player);
/*     */     
/* 123 */     if (island.hasUpgrade(IslandUpgrade.HASTE)) {
/* 124 */       player.addPotionEffect(new PotionEffect(PotionEffectType.FAST_DIGGING, 199980, island
/* 125 */             .getUpgradeLevel(IslandUpgrade.HASTE).intValue() - 1));
/*     */     }
/* 127 */     player.getInventory().setItem(0, (new ItemBuilder())
/* 128 */         .type(Material.valueOf(gamer.getSwordLevel().name() + "_SWORD"))
/* 129 */         .enchantment(Enchantment.DAMAGE_ALL, island.getUpgradeLevel(IslandUpgrade.SHARPNESS)).build());
/*     */     
/* 131 */     if (gamer.getAxeLevel() != Gamer.AxeLevel.NONE) {
/* 132 */       player.getInventory().addItem(new ItemStack[] { gamer.getAxeLevel().getItemStack() });
/*     */     }
/* 134 */     if (gamer.getPickaxeLevel() != Gamer.PickaxeLevel.NONE) {
/* 135 */       player.getInventory().addItem(new ItemStack[] { gamer.getPickaxeLevel().getItemStack() });
/*     */     }
/* 137 */     if (gamer.isShears()) {
/* 138 */       player.getInventory().addItem(new ItemStack[] { (new ItemBuilder()).type(Material.SHEARS).build() });
/*     */     }
/* 140 */     handleArmor(player);
/* 141 */     handleHeart(player);
/*     */     
/* 143 */     Status status = CommonPlugin.getInstance().getStatusManager().loadStatus(player.getUniqueId(), StatusType.BEDWARS);
/*     */ 
/*     */     
/* 146 */     if (player != null) {
/* 147 */       updatePoints(player, status);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void handleHeart(Player player) {
/* 152 */     Scoreboard scoreboard = player.getScoreboard();
/*     */     
/* 154 */     if (scoreboard.getObjective("showhealth") == null) {
/* 155 */       Objective objective = scoreboard.registerNewObjective("showhealth", Criterias.HEALTH);
/* 156 */       objective.setDisplaySlot(DisplaySlot.BELOW_NAME);
/* 157 */       objective.setDisplayName(ChatColor.DARK_RED + "♥");
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void updatePoints(Player player, Status status) {
/* 162 */     player.setExp(0.0F);
/* 163 */     player.setTotalExperience(0);
/* 164 */     player.setLevel(status.getInteger((Enum)BedwarsCategory.BEDWARS_LEVEL));
/* 165 */     player.setExp((status.getInteger((Enum)BedwarsCategory.BEDWARS_POINTS) / 
/* 166 */         GameMain.getInstance().getMaxPoints(player.getLevel())));
/*     */   }
/*     */   
/*     */   public static void handleSpectate(final Player player) {
/* 170 */     Bukkit.getPluginManager().callEvent((Event)new PlayerSpectateEvent(player));
/*     */     
/* 172 */     (new BukkitRunnable()
/*     */       {
/*     */         public void run()
/*     */         {
/* 176 */           GamerHelper.handlePlayer(player);
/*     */           
/* 178 */           player.getInventory().setItem(0, GamerHelper.PLAYERS.getItemStack());
/* 179 */           player.getInventory().setItem(7, GamerHelper.PLAY_AGAIN.getItemStack());
/* 180 */           player.getInventory().setItem(8, GamerHelper.LOBBY.getItemStack());
/*     */           
/* 182 */           player.setGameMode(GameMode.ADVENTURE);
/* 183 */           player.setAllowFlight(true);
/* 184 */           player.setFlying(true);
/* 185 */           player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 199980, 2));
/*     */           
/* 187 */           GamerHelper.hidePlayer(player);
/*     */         }
/* 189 */       }).runTaskLater((Plugin)GameAPI.getInstance(), 3L);
/*     */   }
/*     */   
/*     */   public static void handlePlayer(Player player) {
/* 193 */     player.setFallDistance(-1.0F);
/* 194 */     player.setHealth(20.0D);
/* 195 */     player.setMaxHealth(20.0D);
/* 196 */     player.setFoodLevel(20);
/* 197 */     player.setLevel(0);
/* 198 */     player.setExp(0.0F);
/*     */     
/* 200 */     player.setAllowFlight(false);
/* 201 */     player.setFlying(false);
/* 202 */     player.setGameMode(GameMode.SURVIVAL);
/*     */     
/* 204 */     player.getInventory().clear();
/* 205 */     player.getInventory().setArmorContents(new ItemStack[4]);
/* 206 */     player.getActivePotionEffects().forEach(potion -> player.removePotionEffect(potion.getType()));
/*     */   }
/*     */   
/*     */   private static String getYaw(Location location) {
/* 210 */     float yaw = location.getYaw();
/* 211 */     if (yaw < 0.0F) {
/* 212 */       yaw += 360.0F;
/*     */     }
/* 214 */     if (yaw >= 315.0F || yaw < 45.0F)
/* 215 */       return "S"; 
/* 216 */     if (yaw < 135.0F)
/* 217 */       return "W"; 
/* 218 */     if (yaw < 225.0F)
/* 219 */       return "N"; 
/* 220 */     if (yaw < 315.0F) {
/* 221 */       return "E";
/*     */     }
/* 223 */     return "N";
/*     */   }
/*     */   
/*     */   public static Location forwardLocationByPlayerRotation(Location locationToRotate, Location location, int blocks) {
/* 227 */     switch (getYaw(locationToRotate)) {
/*     */       case "N":
/* 229 */         return location.clone().add(0.0D, 0.0D, -blocks);
/*     */       case "W":
/* 231 */         return location.clone().add(-blocks, 0.0D, 0.0D);
/*     */       case "S":
/* 233 */         return location.clone().add(0.0D, 0.0D, blocks);
/*     */       case "E":
/* 235 */         return location.clone().add(blocks, 0.0D, 0.0D);
/*     */     } 
/* 237 */     return location.clone();
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<Player> getPlayersNear(Location location, double radius) {
/* 242 */     return (List<Player>)Bukkit.getOnlinePlayers().stream().filter(player -> (location.distance(player.getLocation()) <= radius))
/* 243 */       .collect(Collectors.toList());
/*     */   }
/*     */   
/*     */   public static Location forwardLocationByPlayerRotation(Player player, Location location, int blocks) {
/* 247 */     return forwardLocationByPlayerRotation(player.getLocation(), location, blocks);
/*     */   }
/*     */   
/*     */   public static List<Block> getNearbyBlocks(Location location, int radius) {
/* 251 */     List<Block> blocks = new ArrayList<>();
/*     */     
/* 253 */     for (int x = location.getBlockX() - radius; x <= location.getBlockX() + radius; x++) {
/* 254 */       for (int y = location.getBlockY() - radius; y <= location.getBlockY() + radius; y++) {
/* 255 */         for (int z = location.getBlockZ() - radius; z <= location.getBlockZ() + radius; z++) {
/* 256 */           blocks.add(location.getWorld().getBlockAt(x, y, z));
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 261 */     return blocks;
/*     */   }
/*     */   
/*     */   public static Player getMoreNearbyPlayers(Location location, double radius) {
/* 265 */     Player nearby = null;
/* 266 */     for (Player player : getPlayersNear(location, radius)) {
/* 267 */       if (nearby == null) {
/* 268 */         nearby = player; continue;
/* 269 */       }  if (nearby.getLocation().distance(location) > player.getLocation().distance(location))
/* 270 */         nearby = player; 
/* 271 */     }  return nearby;
/*     */   }
/*     */   
/*     */   public static void handleRemoveArmor(Player player) {
/* 275 */     player.getInventory().setHelmet(null);
/* 276 */     player.getInventory().setChestplate(null);
/* 277 */     player.getInventory().setLeggings(null);
/* 278 */     player.getInventory().setBoots(null);
/*     */   }
/*     */   
/*     */   public static void handleArmor(Player player) {
/* 282 */     Island island = GameMain.getInstance().getIslandManager().getIsland(player.getUniqueId());
/* 283 */     Gamer gamer = (Gamer)GameMain.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/*     */     
/* 285 */     if (island == null) {
/*     */       return;
/*     */     }
/* 288 */     player.getInventory().setHelmet((new ItemBuilder()).type(Material.LEATHER_HELMET)
/* 289 */         .color(island.getIslandColor().getColorEquivalent()).enchantment(Enchantment.PROTECTION_ENVIRONMENTAL, island
/* 290 */           .getUpgradeLevel(IslandUpgrade.ARMOR_REINFORCEMENT))
/* 291 */         .build());
/*     */     
/* 293 */     player.getInventory().setChestplate((new ItemBuilder()).type(Material.LEATHER_CHESTPLATE)
/* 294 */         .color(island.getIslandColor().getColorEquivalent()).enchantment(Enchantment.PROTECTION_ENVIRONMENTAL, island
/* 295 */           .getUpgradeLevel(IslandUpgrade.ARMOR_REINFORCEMENT))
/* 296 */         .build());
/*     */     
/* 298 */     player.getInventory()
/* 299 */       .setLeggings((new ItemBuilder()).type(Material.valueOf(gamer.getArmorLevel().name() + "_LEGGINGS"))
/* 300 */         .color(island.getIslandColor().getColorEquivalent())
/* 301 */         .enchantment(Enchantment.PROTECTION_ENVIRONMENTAL, island
/* 302 */           .getUpgradeLevel(IslandUpgrade.ARMOR_REINFORCEMENT))
/* 303 */         .build());
/*     */     
/* 305 */     player.getInventory().setBoots((new ItemBuilder()).type(Material.valueOf(gamer.getArmorLevel().name() + "_BOOTS"))
/* 306 */         .color(island.getIslandColor().getColorEquivalent()).enchantment(Enchantment.PROTECTION_ENVIRONMENTAL, island
/* 307 */           .getUpgradeLevel(IslandUpgrade.ARMOR_REINFORCEMENT))
/* 308 */         .build());
/*     */   }
/*     */   
/*     */   public static void hidePlayer(Player player) {
/* 312 */     GameMain.getInstance().getVanishManager().setPlayerVanishToGroup(player, 
/* 313 */         CommonPlugin.getInstance().getPluginInfo().getHighGroup());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void buyItem(Player player, ShopCategory.ShopItem shopItem) {
/* 322 */     PlayerBoughtItemEvent playerBoughtItemEvent = new PlayerBoughtItemEvent(player, (new ItemBuilder()).type(shopItem.getStack().getType()).durability(shopItem.getStack().getDurability()).amount(shopItem.getStack().getAmount()).potion(ItemBuilder.fromStack(shopItem.getStack()).getPotions()).enchantment(shopItem.getStack().getEnchantments()).build());
/* 323 */     Bukkit.getPluginManager().callEvent((Event)playerBoughtItemEvent);
/*     */     
/* 325 */     if (!playerBoughtItemEvent.isCancelled()) {
/* 326 */       player.getInventory().removeItem(new ItemStack[] { (new ItemBuilder()).type(shopItem.getPrice().getMaterial())
/* 327 */             .amount(shopItem.getPrice().getAmount()).build() });
/*     */       
/* 329 */       if (playerBoughtItemEvent.getItemStack() != null) {
/* 330 */         player.getInventory().addItem(new ItemStack[] { playerBoughtItemEvent.getItemStack() });
/*     */       }
/* 332 */       player.playSound(player.getLocation(), Sound.NOTE_PLING, 1.0F, 1.0F);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/utils/GamerHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */