/*    */ package net.highmc.bukkit.gameapi.bedwars.event;
/*    */ 
/*    */ import lombok.NonNull;
/*    */ import net.highmc.bukkit.event.PlayerEvent;
/*    */ import net.highmc.bukkit.gameapi.bedwars.gamer.Gamer;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class PlayerLevelUpEvent extends PlayerEvent {
/*    */   private Gamer gamer;
/*    */   private int level;
/*    */   
/*    */   public Gamer getGamer() {
/* 13 */     return this.gamer; } public int getLevel() {
/* 14 */     return this.level;
/*    */   }
/*    */   public PlayerLevelUpEvent(@NonNull Player player, Gamer gamer, int level) {
/* 17 */     super(player); if (player == null)
/* 18 */       throw new NullPointerException("player is marked non-null but is null");  this.gamer = gamer;
/* 19 */     this.level = level;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/event/PlayerLevelUpEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */