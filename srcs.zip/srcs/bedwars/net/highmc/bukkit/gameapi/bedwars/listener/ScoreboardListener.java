/*     */ package net.highmc.bukkit.gameapi.bedwars.listener;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import java.util.stream.Collectors;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.event.UpdateEvent;
/*     */ import net.highmc.bukkit.event.member.PlayerLanguageChangeEvent;
/*     */ import net.highmc.bukkit.event.player.PlayerAdminEvent;
/*     */ import net.highmc.bukkit.gameapi.GameAPI;
/*     */ import net.highmc.bukkit.gameapi.bedwars.GameMain;
/*     */ import net.highmc.bukkit.gameapi.bedwars.event.PlayerSpectateEvent;
/*     */ import net.highmc.bukkit.gameapi.bedwars.event.island.IslandBedBreakEvent;
/*     */ import net.highmc.bukkit.gameapi.bedwars.event.island.IslandLoseEvent;
/*     */ import net.highmc.bukkit.gameapi.bedwars.gamer.Gamer;
/*     */ import net.highmc.bukkit.gameapi.bedwars.island.Island;
/*     */ import net.highmc.bukkit.gameapi.event.GameStateChangeEvent;
/*     */ import net.highmc.bukkit.utils.scoreboard.ScoreHelper;
/*     */ import net.highmc.bukkit.utils.scoreboard.Scoreboard;
/*     */ import net.highmc.server.loadbalancer.server.MinigameState;
/*     */ import net.highmc.utils.string.StringFormat;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScoreboardListener
/*     */   implements Listener
/*     */ {
/*  38 */   private String text = "";
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGHEST)
/*     */   public void onPlayerJoin(PlayerJoinEvent event) {
/*  42 */     handleScoreboard(event.getPlayer());
/*     */     
/*  44 */     (new BukkitRunnable()
/*     */       {
/*     */         public void run()
/*     */         {
/*  48 */           ScoreboardListener.this.updatePlayers(GameMain.getInstance().getAlivePlayers().size());
/*     */           
/*  50 */           if (GameAPI.getInstance().getState() == MinigameState.GAMETIME)
/*  51 */             ScoreboardListener.this.updateIsland(null); 
/*     */         }
/*  53 */       }).runTaskLater((Plugin)GameAPI.getInstance(), 7L);
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGHEST)
/*     */   public void onPlayerQuit(PlayerQuitEvent event) {
/*  58 */     (new BukkitRunnable()
/*     */       {
/*     */         public void run()
/*     */         {
/*  62 */           ScoreboardListener.this.updatePlayers(GameMain.getInstance().getAlivePlayers().size());
/*     */           
/*  64 */           if (GameAPI.getInstance().getState() == MinigameState.GAMETIME)
/*  65 */             ScoreboardListener.this.updateIsland(null); 
/*     */         }
/*  67 */       }).runTaskLater((Plugin)GameAPI.getInstance(), 7L);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerLanguageChange(PlayerLanguageChangeEvent event) {
/*  72 */     handleScoreboard(event.getPlayer());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerSpectate(PlayerSpectateEvent event) {
/*  77 */     (new BukkitRunnable()
/*     */       {
/*     */         public void run()
/*     */         {
/*  81 */           ScoreboardListener.this.updateIsland(null);
/*     */         }
/*  83 */       }).runTaskLater((Plugin)GameAPI.getInstance(), 7L);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerAdmin(PlayerAdminEvent event) {
/*  88 */     (new BukkitRunnable()
/*     */       {
/*     */         public void run()
/*     */         {
/*  92 */           ScoreboardListener.this.updatePlayers(GameMain.getInstance().getAlivePlayers().size());
/*     */         }
/*  94 */       }).runTaskLater((Plugin)GameAPI.getInstance(), 7L);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onGameStateChange(GameStateChangeEvent event) {
/*  99 */     if (event.getState().isGametime())
/* 100 */       (new BukkitRunnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 104 */             Bukkit.getOnlinePlayers().forEach(player -> {
/*     */                   if (player.getPlayer() != null)
/*     */                     ScoreboardListener.this.handleScoreboard(player.getPlayer()); 
/*     */                 });
/*     */           }
/* 109 */         }).runTaskLater((Plugin)GameAPI.getInstance(), 7L); 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onIslandBreakEvent(IslandBedBreakEvent event) {
/* 114 */     updateScoreboard();
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onIslandLoseEvent(IslandLoseEvent event) {
/* 119 */     updateScoreboard();
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onUpdate(UpdateEvent event) {
/* 124 */     if (event.getType() == UpdateEvent.UpdateType.TICK && event.getCurrentTick() % 10L == 0L) {
/* 125 */       if (this.text.length() >= 3) {
/* 126 */         this.text = "";
/*     */       } else {
/* 128 */         this.text += ".";
/*     */       } 
/* 130 */       if (!GameAPI.getInstance().isTimer()) {
/* 131 */         updateTimer();
/*     */         return;
/*     */       } 
/* 134 */     } else if (event.getType() == UpdateEvent.UpdateType.SECOND && GameAPI.getInstance().isTimer()) {
/* 135 */       updateTimer();
/*     */     } 
/*     */   }
/*     */   private void handleScoreboard(Player player) {
/* 139 */     Scoreboard scoreboard = new Scoreboard(player, "§6§lBED WARS");
/*     */     
/* 141 */     if (GameAPI.getInstance().getState().isPregame()) {
/* 142 */       scoreboard.add(8, "§e");
/* 143 */       scoreboard.add(7, "§%scoreboard-map%§: §7" + GameAPI.getInstance().getMapName());
/* 144 */       scoreboard.add(6, "§%scoreboard-players%§: §7" + GameMain.getInstance().getAlivePlayers().size() + "/" + 
/* 145 */           Bukkit.getMaxPlayers());
/* 146 */       scoreboard.add(5, "");
/* 147 */       scoreboard.add(4, "§%scoreboard-starting%§: §7" + 
/* 148 */           StringFormat.formatTime(GameAPI.getInstance().getTime(), StringFormat.TimeFormat.DOUBLE_DOT));
/* 149 */       scoreboard.add(3, "§%scoreboard-mode%§: §7" + 
/* 150 */           StringFormat.formatString(CommonPlugin.getInstance().getServerType().name().split("_")[1]));
/* 151 */       scoreboard.add(2, "");
/* 152 */       scoreboard.add(1, "§e" + CommonPlugin.getInstance().getPluginInfo().getWebsite());
/*     */     } else {
/* 154 */       if (GameMain.getInstance().getGeneratorUpgrade() != null && GameMain.getInstance().getGeneratorUpgrade().getTimer() - GameAPI.getInstance().getTime() > 0) {
/* 155 */         scoreboard.add(14, "§e");
/* 156 */         scoreboard.add(13, "§%scoreboard-" + 
/*     */             
/* 158 */             GameMain.getInstance().getGeneratorUpgrade().getName().toLowerCase() + "-upgrade%§: §7" + 
/*     */             
/* 160 */             StringFormat.formatTime(GameMain.getInstance().getGeneratorUpgrade().getTimer() - 
/* 161 */               GameAPI.getInstance().getTime(), StringFormat.TimeFormat.DOUBLE_DOT));
/*     */       } 
/*     */       
/* 164 */       scoreboard.add(12, "");
/*     */       
/* 166 */       updateIsland(scoreboard);
/*     */       
/* 168 */       scoreboard.add(2, "");
/* 169 */       scoreboard.add(1, "§ewww." + CommonPlugin.getInstance().getPluginInfo().getWebsite());
/*     */     } 
/*     */     
/* 172 */     ScoreHelper.getInstance().setScoreboard(player, scoreboard);
/*     */   }
/*     */   
/*     */   private void updateScoreboard() {
/* 176 */     updateIsland(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateIsland(Scoreboard scoreboard) {
/* 183 */     List<Island> islandList = (List<Island>)GameMain.getInstance().getIslandManager().values().stream().sorted((i1, i2) -> Character.valueOf(GameMain.CHARS[i1.getIslandColor().getColor().ordinal()]).compareTo(Character.valueOf(GameMain.CHARS[i2.getIslandColor().getColor().ordinal()]))).collect(Collectors.toList());
/*     */     
/* 185 */     for (int i = 0; i < islandList.size(); i++) {
/* 186 */       Island island = islandList.get(i);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 195 */       String status = (island.getIslandStatus() == Island.IslandStatus.ALIVE) ? (((island.stream(false).count() >= 1L) ? "§a" : "§e") + "✔") : ((island.getIslandStatus() == Island.IslandStatus.BED_BROKEN) ? ("§a" + island.getTeam().getPlayerSet().stream().filter(uuid -> !((Gamer)GameAPI.getInstance().getGamerManager().getGamer(uuid, Gamer.class)).isSpectator()).count()) : "§c✖");
/*     */ 
/*     */       
/* 198 */       int index = getInitialIslandIndex() - i;
/*     */ 
/*     */       
/* 201 */       String text = "" + island.getIslandColor().getColor() + ChatColor.BOLD + "§%" + island.getIslandColor().name().toLowerCase() + "-symbol%§ §f§%" + island.getIslandColor().name().toLowerCase() + "-name%§ " + status;
/*     */       
/* 203 */       if (scoreboard == null) {
/* 204 */         for (Player player : Bukkit.getOnlinePlayers()) {
/* 205 */           Island playerIsland = GameMain.getInstance().getIslandManager().getIsland(player.getUniqueId());
/* 206 */           boolean sameIsland = (playerIsland == island);
/*     */           
/* 208 */           ScoreHelper.getInstance().addScoreboard(player, index, text + (sameIsland ? " §7§%scoreboard-you%§" : ""));
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 213 */         boolean sameIsland = (GameMain.getInstance().getIslandManager().getIsland(scoreboard.getPlayer().getUniqueId()) == island);
/* 214 */         scoreboard.add(index, text + (sameIsland ? " §7§%scoreboard-you%§" : ""));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void updateTimer() {
/* 220 */     if (GameAPI.getInstance().getState().isPregame()) {
/* 221 */       ScoreHelper.getInstance().updateScoreboard(4, "§%scoreboard-starting%§: §7" + 
/* 222 */           StringFormat.formatTime(GameAPI.getInstance().getTime(), StringFormat.TimeFormat.SHORT));
/*     */     }
/* 224 */     else if (GameMain.getInstance().getGeneratorUpgrade() != null && GameMain.getInstance().getGeneratorUpgrade().getTimer() - GameAPI.getInstance().getTime() > 0) {
/* 225 */       ScoreHelper.getInstance().updateScoreboard(13, "§%scoreboard-" + 
/*     */           
/* 227 */           GameMain.getInstance().getGeneratorUpgrade().getName().toLowerCase() + "-upgrade%§: §7" + 
/*     */           
/* 229 */           StringFormat.formatTime(GameMain.getInstance().getGeneratorUpgrade().getTimer() - 
/* 230 */             GameAPI.getInstance().getTime(), StringFormat.TimeFormat.DOUBLE_DOT));
/*     */     } else {
/* 232 */       ScoreHelper.getInstance().removeScoreboard(14);
/* 233 */       ScoreHelper.getInstance().removeScoreboard(13);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void updatePlayers(int players) {
/* 239 */     if (GameAPI.getInstance().getState().isPregame())
/* 240 */       ScoreHelper.getInstance().updateScoreboard(6, "§%scoreboard-players%§: §7" + players + "/" + 
/* 241 */           Bukkit.getMaxPlayers()); 
/*     */   }
/*     */   
/*     */   public int getInitialIslandIndex() {
/* 245 */     return 11;
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/listener/ScoreboardListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */