/*     */ package net.highmc.bukkit.gameapi.bedwars.menu;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import net.highmc.bukkit.gameapi.GameAPI;
/*     */ import net.highmc.bukkit.gameapi.bedwars.GameMain;
/*     */ import net.highmc.bukkit.gameapi.bedwars.gamer.Gamer;
/*     */ import net.highmc.bukkit.gameapi.bedwars.island.Island;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*     */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.enchantments.Enchantment;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ public class FinderInventory
/*     */ {
/*     */   public FinderInventory(Player player) {
/*  24 */     Island playerIsland = GameMain.getInstance().getIslandManager().getIsland(player.getUniqueId());
/*     */     
/*  26 */     if (playerIsland == null) {
/*     */       return;
/*     */     }
/*  29 */     Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/*     */     
/*  31 */     if (!gamer.isAlive()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  38 */     List<Island> islands = (List<Island>)GameMain.getInstance().getIslandManager().getIslands().stream().filter(island -> (island.getIslandColor() != playerIsland.getIslandColor() && island.getIslandStatus() != Island.IslandStatus.LOSER)).collect(Collectors.toList());
/*     */     
/*  40 */     if (islands.stream().filter(island -> (island.getIslandStatus() == Island.IslandStatus.ALIVE)).count() > 0L) {
/*  41 */       player.sendMessage("§cVocê só poderá usar a bússola quando todas as camas foram quebradas.");
/*     */       
/*     */       return;
/*     */     } 
/*  45 */     MenuInventory menuInventory = new MenuInventory("§7Rastreador", 4);
/*     */     
/*  47 */     int slot = 10;
/*     */     
/*  49 */     for (Iterator<Island> iterator = islands.iterator(); iterator.hasNext(); ) { Island island = iterator.next();
/*  50 */       if (playerIsland.getIslandColor() == island.getIslandColor() || island
/*  51 */         .getIslandStatus() == Island.IslandStatus.LOSER) {
/*     */         continue;
/*     */       }
/*  54 */       menuInventory.setItem(slot, (new ItemBuilder())
/*     */           
/*  56 */           .name(island.getIslandColor().getColor() + "§%" + island
/*  57 */             .getIslandColor().name().toLowerCase() + "-name%§")
/*  58 */           .type(Material.WOOL).durability(island.getIslandColor().getWoolId())
/*  59 */           .lore("\n§7Clique para ativar o rastreador no time " + island.getIslandColor().getColor() + "§%" + island
/*  60 */             .getIslandColor().name().toLowerCase() + "-name%§")
/*  61 */           .build(), (p, inv, type, stack, s) -> {
/*     */             int amount = (int)Arrays.<ItemStack>asList(player.getInventory().getContents()).stream().filter(()).count();
/*     */ 
/*     */             
/*     */             if (amount >= 1) {
/*     */               player.sendMessage("§cCompre outro rastreador para poder marcar outro jogador.");
/*     */ 
/*     */               
/*     */               return;
/*     */             } 
/*     */ 
/*     */             
/*     */             Player nearPlayer = island.stream(false).sorted(()).findFirst().orElse(null);
/*     */ 
/*     */             
/*     */             if (nearPlayer == null) {
/*     */               p.sendMessage("§cNenhum jogador deste time para rastrear no momento.");
/*     */ 
/*     */               
/*     */               return;
/*     */             } 
/*     */ 
/*     */             
/*     */             for (int i = 0; i < (p.getInventory().getContents()).length; i++) {
/*     */               ItemStack itemStack = p.getInventory().getContents()[i];
/*     */ 
/*     */               
/*     */               if (itemStack != null && itemStack.getType() == Material.COMPASS) {
/*     */                 p.getInventory().setItem(i, ItemBuilder.fromStack(itemStack).name(island.getIslandColor().getColor() + "Time §%" + island.getIslandColor().name().toLowerCase() + "-name%§").enchantment(Enchantment.DURABILITY, Integer.valueOf(1)).build());
/*     */ 
/*     */                 
/*     */                 break;
/*     */               } 
/*     */             } 
/*     */ 
/*     */             
/*     */             p.setMetadata("player-target", GameMain.getInstance().createMeta(nearPlayer.getUniqueId().toString()));
/*     */           });
/*     */       
/* 100 */       if (slot % 9 == 7) {
/* 101 */         slot += 3;
/*     */         
/*     */         continue;
/*     */       } 
/* 105 */       slot++; }
/*     */ 
/*     */     
/* 108 */     menuInventory.open(player);
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/menu/FinderInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */