/*     */ package net.highmc.bukkit.gameapi.bedwars.manager;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.UUID;
/*     */ import java.util.stream.Collectors;
/*     */ import net.highmc.bukkit.gameapi.GameAPI;
/*     */ import net.highmc.bukkit.gameapi.bedwars.GameMain;
/*     */ import net.highmc.bukkit.gameapi.bedwars.gamer.Gamer;
/*     */ import net.highmc.bukkit.gameapi.bedwars.generator.Generator;
/*     */ import net.highmc.bukkit.gameapi.bedwars.island.Island;
/*     */ import net.highmc.bukkit.gameapi.bedwars.island.IslandColor;
/*     */ import net.highmc.bukkit.gameapi.gamer.Gamer;
/*     */ import net.highmc.bukkit.gameapi.gamer.Team;
/*     */ import net.highmc.member.party.Party;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IslandManager
/*     */ {
/*  30 */   private Map<IslandColor, Island> islandMap = new HashMap<>();
/*  31 */   private Map<UUID, IslandColor> playerMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<Island> loadIsland() {
/*  36 */     List<Island> islandList = new ArrayList<>(GameMain.getInstance().getConfiguration().getList("islands", Island.class));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  47 */     List<Gamer> playerList = (List<Gamer>)GameAPI.getInstance().getGamerManager().getGamers(Gamer.class).stream().filter(gamer -> (gamer.isAlive() && gamer.getPlayer() != null)).sorted((o1, o2) -> { Party o1Party = GameAPI.getInstance().getPlugin().getPartyManager().getPartyById(o1.getUniqueId()); Party o2Party = GameAPI.getInstance().getPlugin().getPartyManager().getPartyById(o2.getUniqueId()); return (o1Party == null || o2Party == null) ? 0 : o1Party.getPartyId().compareTo(o2Party.getPartyId()); }).collect(Collectors.toList());
/*  48 */     List<Team> teamList = new ArrayList<>();
/*     */     
/*  50 */     for (int i = 0; i < GameMain.getInstance().getMaxTeams(); i++) {
/*  51 */       teamList.add(new Team(i, GameMain.getInstance().getPlayersPerTeam()));
/*     */     }
/*  53 */     boolean stop = true;
/*     */     
/*  55 */     for (Team team : teamList) {
/*  56 */       if (team.isFull()) {
/*     */         continue;
/*     */       }
/*  59 */       for (int j = 0; j < GameMain.getInstance().getPlayersPerTeam(); j++) {
/*  60 */         Gamer player = playerList.stream().findFirst().orElse(null);
/*     */         
/*  62 */         if (player != null) {
/*     */ 
/*     */           
/*  65 */           playerList.remove(player);
/*  66 */           team.addPlayer(player.getUniqueId());
/*     */         } 
/*     */       } 
/*  69 */       if (team.getPlayerSet().size() >= 1) {
/*  70 */         stop = false;
/*     */       }
/*  72 */       Island island = islandList.stream().findAny().orElse(null);
/*     */       
/*  74 */       if (island == null) {
/*  75 */         team.getPlayerSet().stream().map(id -> GameAPI.getInstance().getGamerManager().getGamer(id))
/*  76 */           .forEach(gamer -> {
/*     */               if (gamer.getPlayer() != null)
/*     */                 gamer.getPlayer().kickPlayer("§%bedwars.kick.island-not-found%§"); 
/*     */               GameAPI.getInstance().getGamerManager().unloadGamer(gamer.getUniqueId());
/*     */             });
/*     */         continue;
/*     */       } 
/*  83 */       island.loadIsland(team);
/*  84 */       island.getTeam().getPlayerSet().forEach(id -> (IslandColor)this.playerMap.put(id, island.getIslandColor()));
/*  85 */       this.islandMap.put(island.getIslandColor(), island);
/*  86 */       islandList.remove(island);
/*     */     } 
/*     */ 
/*     */     
/*  90 */     if (stop) {
/*  91 */       Bukkit.shutdown();
/*     */     }
/*  93 */     return this.islandMap.values();
/*     */   }
/*     */   
/*     */   public Island getIsland(IslandColor islandColor) {
/*  97 */     return this.islandMap.get(islandColor);
/*     */   }
/*     */   
/*     */   public Island getIsland(UUID uniqueId) {
/* 101 */     return this.playerMap.containsKey(uniqueId) ? this.islandMap.get(this.playerMap.get(uniqueId)) : null;
/*     */   }
/*     */   
/*     */   public Collection<Island> values() {
/* 105 */     return this.islandMap.values();
/*     */   }
/*     */   
/*     */   public Island getClosestIsland(Location location) {
/* 109 */     return this.islandMap.values().stream()
/* 110 */       .sorted((o1, o2) -> (int)(o1.getSpawnLocation().getAsLocation().distance(location) - o2.getSpawnLocation().getAsLocation().distance(location)))
/*     */       
/* 112 */       .findFirst().orElse(null);
/*     */   }
/*     */   
/*     */   public Collection<Island> getIslands() {
/* 116 */     return this.islandMap.values();
/*     */   }
/*     */   
/*     */   public Optional<Generator> getClosestGenerator(Location location) {
/* 120 */     return GameMain.getInstance().getIslandManager().getClosestIsland(location).getIslandGenerators().stream()
/* 121 */       .findFirst();
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/manager/IslandManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */