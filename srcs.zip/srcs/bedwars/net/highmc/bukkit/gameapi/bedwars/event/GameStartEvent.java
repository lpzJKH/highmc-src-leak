package net.highmc.bukkit.gameapi.bedwars.event;

import net.highmc.bukkit.event.NormalEvent;

public class GameStartEvent extends NormalEvent {}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/event/GameStartEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */