/*     */ package net.highmc.bukkit.gameapi.bedwars.listener;
/*     */ 
/*     */ import java.util.UUID;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.gameapi.GameAPI;
/*     */ import net.highmc.bukkit.gameapi.bedwars.event.IslandWinEvent;
/*     */ import net.highmc.bukkit.gameapi.bedwars.event.PlayerKillPlayerEvent;
/*     */ import net.highmc.bukkit.gameapi.bedwars.event.island.IslandBedBreakEvent;
/*     */ import net.highmc.bukkit.gameapi.bedwars.gamer.Gamer;
/*     */ import net.highmc.bukkit.gameapi.bedwars.island.Island;
/*     */ import net.highmc.bukkit.gameapi.bedwars.utils.GamerHelper;
/*     */ import net.highmc.member.status.Status;
/*     */ import net.highmc.member.status.StatusType;
/*     */ import net.highmc.member.status.types.BedwarsCategory;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.entity.PlayerDeathEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StatusListener
/*     */   implements Listener
/*     */ {
/*     */   @EventHandler
/*     */   public void onIslandWin(IslandWinEvent event) {
/*  27 */     Island island = event.getIsland();
/*     */     
/*  29 */     for (UUID id : island.getTeam().getPlayerSet()) {
/*  30 */       Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(id, Gamer.class);
/*  31 */       Status status = CommonPlugin.getInstance().getStatusManager().loadStatus(id, StatusType.BEDWARS);
/*     */       
/*  33 */       status.addInteger((Enum)BedwarsCategory.BEDWARS_POINTS, 50);
/*  34 */       status.addInteger((Enum)BedwarsCategory.BEDWARS_WINS, 1);
/*  35 */       status.addInteger(BedwarsCategory.BEDWARS_WINS.getSpecialServer(), 1);
/*  36 */       status.addInteger((Enum)BedwarsCategory.BEDWARS_WINSTREAK, 1);
/*  37 */       status.addInteger(BedwarsCategory.BEDWARS_WINSTREAK.getSpecialServer(), 1);
/*     */       
/*  39 */       status.save();
/*     */       
/*  41 */       gamer.checkLevel();
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onIslandBedBroken(IslandBedBreakEvent event) {
/*  47 */     Player player = event.getPlayer();
/*     */     
/*  49 */     if (player != null) {
/*  50 */       Status status = CommonPlugin.getInstance().getStatusManager().loadStatus(player.getUniqueId(), StatusType.BEDWARS);
/*     */ 
/*     */       
/*  53 */       status.setInteger((Enum)BedwarsCategory.BEDWARS_POINTS, status
/*  54 */           .getInteger((Enum)BedwarsCategory.BEDWARS_POINTS) + 20);
/*  55 */       status.addInteger((Enum)BedwarsCategory.BEDWARS_BED_BREAK, 1);
/*  56 */       status.addInteger(BedwarsCategory.BEDWARS_BED_BREAK.getSpecialServer(), 1);
/*  57 */       status.save();
/*     */     } 
/*     */     
/*  60 */     for (UUID playerId : event.getIsland().getTeam().getPlayerSet()) {
/*  61 */       Status status = CommonPlugin.getInstance().getStatusManager().loadStatus(playerId, StatusType.BEDWARS);
/*  62 */       status.addInteger((Enum)BedwarsCategory.BEDWARS_BED_BROKEN, 1);
/*  63 */       status.addInteger(BedwarsCategory.BEDWARS_BED_BROKEN.getSpecialServer(), 1);
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerDeath(PlayerDeathEvent event) {
/*  69 */     Player player = event.getEntity();
/*  70 */     Status status = CommonPlugin.getInstance().getStatusManager().loadStatus(player.getUniqueId(), StatusType.BEDWARS);
/*     */ 
/*     */     
/*  73 */     status.setInteger((Enum)BedwarsCategory.BEDWARS_KILLSTREAK, 0);
/*  74 */     status.setInteger(BedwarsCategory.BEDWARS_KILLSTREAK.getSpecialServer(), 0);
/*     */     
/*  76 */     status.addInteger((Enum)BedwarsCategory.BEDWARS_DEATHS, 1);
/*  77 */     status.addInteger(BedwarsCategory.BEDWARS_DEATHS.getSpecialServer(), 1);
/*     */     
/*  79 */     status.save();
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerKillPlayer(PlayerKillPlayerEvent event) {
/*  84 */     Player killer = event.getKiller();
/*     */     
/*  86 */     Status status = CommonPlugin.getInstance().getStatusManager().loadStatus(killer.getUniqueId(), StatusType.BEDWARS);
/*     */ 
/*     */     
/*  89 */     status.addInteger((Enum)BedwarsCategory.BEDWARS_POINTS, 5);
/*     */     
/*  91 */     status.addInteger((Enum)BedwarsCategory.BEDWARS_KILLS, 1);
/*  92 */     status.addInteger(BedwarsCategory.BEDWARS_KILLS.getSpecialServer(), 1);
/*  93 */     status.addInteger((Enum)BedwarsCategory.BEDWARS_KILLSTREAK, 1);
/*  94 */     status.addInteger(BedwarsCategory.BEDWARS_KILLSTREAK.getSpecialServer(), 1);
/*     */     
/*  96 */     status.save();
/*  97 */     GamerHelper.updatePoints(killer, status);
/*     */     
/*  99 */     Gamer killerGamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(killer.getUniqueId(), Gamer.class);
/*     */     
/* 101 */     killerGamer.addKills(event.isFinalKill());
/* 102 */     killerGamer.checkLevel();
/*     */     
/* 104 */     if (event.isFinalKill()) {
/* 105 */       status.addInteger((Enum)BedwarsCategory.BEDWARS_POINTS, 10);
/* 106 */       status.addInteger((Enum)BedwarsCategory.BEDWARS_FINAL_KILLS, 1);
/* 107 */       status.addInteger(BedwarsCategory.BEDWARS_FINAL_KILLS.getSpecialServer(), 1);
/*     */       
/* 109 */       status = CommonPlugin.getInstance().getStatusManager().loadStatus(event.getPlayer().getUniqueId(), StatusType.BEDWARS);
/*     */ 
/*     */       
/* 112 */       status.addInteger((Enum)BedwarsCategory.BEDWARS_FINAL_DEATHS, 1);
/* 113 */       status.addInteger(BedwarsCategory.BEDWARS_FINAL_DEATHS.getSpecialServer(), 1);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/listener/StatusListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */