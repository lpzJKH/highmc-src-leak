/*    */ package net.highmc.bukkit.gameapi.bedwars.generator;
/*    */ 
/*    */ import org.bukkit.ChatColor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum GeneratorType
/*    */ {
/*    */   GeneratorType(int timer, ChatColor color) {
/*    */     this.timer = timer;
/*    */     this.color = color;
/*    */   }
/*    */   
/* 15 */   EMERALD(60, ChatColor.DARK_GREEN), DIAMOND(30, ChatColor.AQUA), NORMAL;
/*    */   private ChatColor color;
/* 17 */   private int timer = 1; public void setTimer(int timer) { this.timer = timer; }
/* 18 */   public int getTimer() { return this.timer; } public ChatColor getColor() {
/* 19 */     return this.color;
/*    */   }
/*    */   public GeneratorType getNextUpgrade() {
/* 22 */     if (ordinal() - 1 < 0) {
/* 23 */       return values()[(values()).length - 2];
/*    */     }
/* 25 */     return values()[ordinal() - 1];
/*    */   }
/*    */   
/*    */   public String getConfigFieldName() {
/* 29 */     return name().toLowerCase() + "Generator";
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/generator/GeneratorType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */