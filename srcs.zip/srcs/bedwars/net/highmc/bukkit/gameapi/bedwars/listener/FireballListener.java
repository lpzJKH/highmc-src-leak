/*     */ package net.highmc.bukkit.gameapi.bedwars.listener;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.highmc.CommonConst;
/*     */ import net.highmc.bukkit.gameapi.GameAPI;
/*     */ import net.highmc.bukkit.gameapi.bedwars.GameMain;
/*     */ import net.highmc.bukkit.gameapi.bedwars.utils.GamerHelper;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.block.BlockFace;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Fireball;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.entity.TNTPrimed;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.block.Action;
/*     */ import org.bukkit.event.block.BlockExplodeEvent;
/*     */ import org.bukkit.event.block.BlockIgniteEvent;
/*     */ import org.bukkit.event.block.BlockPlaceEvent;
/*     */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*     */ import org.bukkit.event.entity.EntityDamageEvent;
/*     */ import org.bukkit.event.entity.EntityExplodeEvent;
/*     */ import org.bukkit.event.entity.ExplosionPrimeEvent;
/*     */ import org.bukkit.event.entity.ProjectileHitEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.metadata.FixedMetadataValue;
/*     */ import org.bukkit.metadata.MetadataValue;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FireballListener
/*     */   implements Listener
/*     */ {
/*     */   @EventHandler
/*     */   public void onPlayerInteract(PlayerInteractEvent event) {
/*  46 */     if (event.getItem() == null)
/*     */       return; 
/*  48 */     if (event.getAction() == Action.RIGHT_CLICK_BLOCK || event.getAction() == Action.RIGHT_CLICK_AIR) {
/*  49 */       Player player = event.getPlayer();
/*  50 */       if (event.getItem().getType() == Material.FIREBALL) {
/*     */         
/*  52 */         player.setItemInHand((event.getItem().getAmount() > 1) ? (new ItemBuilder())
/*  53 */             .type(Material.FIREBALL).amount(event.getItem().getAmount() - 1).build() : new ItemStack(Material.AIR));
/*     */ 
/*     */         
/*  56 */         Fireball fireball = (Fireball)player.launchProjectile(Fireball.class);
/*  57 */         fireball.setYield(0.0F);
/*  58 */         fireball.setFireTicks(-1);
/*  59 */         fireball.setIsIncendiary(false);
/*     */         
/*  61 */         fireball.setMetadata("boost", GameAPI.getInstance().createMeta(player.getName()));
/*  62 */         player.setMetadata("no-damage-by-entity", GameAPI.getInstance().createMeta(Integer.valueOf(fireball.getEntityId())));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
/*     */   public void onBlockPlace(BlockPlaceEvent event) {
/*  69 */     Block block = event.getBlock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     if (block.getType() == Material.TNT) {
/*  77 */       block.setType(Material.AIR);
/*  78 */       Player player = event.getPlayer();
/*  79 */       player.setItemInHand((player.getItemInHand().getAmount() > 1) ? (new ItemBuilder())
/*  80 */           .type(Material.TNT).amount(player.getItemInHand().getAmount() - 1).build() : new ItemStack(Material.AIR));
/*     */       
/*  82 */       TNTPrimed tntPrimed = (TNTPrimed)block.getWorld().spawn(event.getBlock().getLocation().clone().add(0.5D, 0.5D, 0.5D), TNTPrimed.class);
/*     */       
/*  84 */       player.setMetadata("no-damage-by-entity", GameAPI.getInstance().createMeta(Integer.valueOf(tntPrimed.getEntityId())));
/*     */       
/*  86 */       tntPrimed.setFuseTicks(48);
/*  87 */       Bukkit.getScheduler()
/*  88 */         .runTaskLater((Plugin)GameMain.getInstance(), () -> tntPrimed.setMetadata("location", (MetadataValue)new FixedMetadataValue((Plugin)GameMain.getInstance(), CommonConst.GSON.toJson(event.getPlayer().getLocation().serialize()))), 40L);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  93 */       tntPrimed.setMetadata("boost", GameAPI.getInstance().createMeta(event.getPlayer().getName()));
/*  94 */       event.setCancelled(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onProjectileHit(ProjectileHitEvent event) {
/* 100 */     if (event.getEntity() instanceof Fireball) {
/* 101 */       Fireball entity = (Fireball)event.getEntity();
/* 102 */       Location location = entity.getLocation();
/*     */       
/* 104 */       if (entity.hasMetadata("boost")) {
/* 105 */         Player player = Bukkit.getPlayer(((MetadataValue)entity.getMetadata("boost").get(0)).asString());
/* 106 */         if (player == null) {
/* 107 */           player = GamerHelper.getMoreNearbyPlayers(location, 6.0D);
/*     */         }
/*     */         
/* 110 */         if (player == null) {
/*     */           return;
/*     */         }
/*     */         
/* 114 */         if (entity.getType() == EntityType.FIREBALL || entity.getType() == EntityType.SMALL_FIREBALL) {
/* 115 */           makeExplosion(location, EntityType.FIREBALL);
/*     */           
/* 117 */           for (Player ps : GamerHelper.getPlayersNear(location, 3.0D)) {
/* 118 */             if (ps.hasMetadata("onlyboost-onground") && (
/* 119 */               (MetadataValue)ps.getMetadata("onlyboost-onground").get(0)).asLong() > System.currentTimeMillis()) {
/* 120 */               ps.removeMetadata("onlyboost-onground", (Plugin)GameMain.getInstance());
/*     */               
/* 122 */               if (!ps.isOnGround()) {
/*     */                 continue;
/*     */               }
/*     */             } 
/*     */             
/* 127 */             ps.setVelocity((ps == player) ? 
/* 128 */                 fireballBoost(ps, (Entity)entity, true) : fireballBoost(ps, (Entity)entity, false));
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector tntBoost(Location location, Player player) {
/* 138 */     boolean onGround = player.isOnGround();
/*     */     
/* 140 */     double multiplier = onGround ? 1.5D : 1.5D;
/*     */ 
/*     */     
/* 143 */     double Y = onGround ? 0.5D : 0.9D;
/*     */     
/* 145 */     if (player.getLocation().distance(location) <= 2.7D && (
/* 146 */       GamerHelper.forwardLocationByPlayerRotation(player, location, 3).add(0.0D, 1.0D, 0.0D).getBlock()
/* 147 */       .getType() != Material.AIR || 
/* 148 */       GamerHelper.forwardLocationByPlayerRotation(player, location, 3).add(0.0D, 2.0D, 0.0D).getBlock()
/* 149 */       .getType() != Material.AIR)) {
/* 150 */       location = GamerHelper.forwardLocationByPlayerRotation(player, location, 3);
/*     */     }
/*     */     
/* 153 */     return player.getLocation().subtract(location).toVector().normalize().multiply(multiplier).setY(Y);
/*     */   }
/*     */   
/*     */   public Vector fireballBoost(Player player, Entity entity, boolean moreBoost) {
/* 157 */     Location entityLocation = entity.getLocation();
/*     */     
/* 159 */     boolean onGround = player.isOnGround();
/*     */     
/* 161 */     double multiplier = moreBoost ? (onGround ? 5.8D : 2.8D) : (onGround ? 0.5D : 1.0D);
/*     */ 
/*     */     
/* 164 */     double Y = moreBoost ? (onGround ? 0.6D : 0.8D) : (onGround ? 1.2D : 0.3D);
/*     */ 
/*     */     
/* 167 */     if (player.getLocation().distance(entityLocation) <= 2.7D && (
/* 168 */       GamerHelper.forwardLocationByPlayerRotation(player, entityLocation, 3).add(0.0D, 1.0D, 0.0D).getBlock()
/* 169 */       .getType() != Material.AIR || 
/* 170 */       GamerHelper.forwardLocationByPlayerRotation(player, entityLocation, 3).add(0.0D, 2.0D, 0.0D).getBlock()
/* 171 */       .getType() != Material.AIR)) {
/* 172 */       entityLocation = GamerHelper.forwardLocationByPlayerRotation(player, entityLocation, 3);
/*     */     }
/* 174 */     return player.getLocation().subtract(entityLocation).toVector().normalize().multiply(multiplier).setY(Y);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onExplosion(BlockExplodeEvent event) {
/* 179 */     event.setCancelled(true);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onExplosion(EntityExplodeEvent event) {
/* 184 */     event.setCancelled(true);
/*     */   }
/*     */   
/*     */   public void makeExplosion(Location explosionLocation, EntityType entityType) {
/* 188 */     explosionLocation.getWorld().createExplosion(explosionLocation, 1.0F);
/*     */     
/* 190 */     for (Block block : GamerHelper.getNearbyBlocks(explosionLocation, (entityType == EntityType.PRIMED_TNT || entityType == EntityType.MINECART_TNT) ? 3 : 2)) {
/*     */       
/* 192 */       if (!GameMain.getInstance().getPlayersBlock().contains(block.getLocation())) {
/*     */         continue;
/*     */       }
/* 195 */       if (block.getType() == Material.OBSIDIAN) {
/*     */         continue;
/*     */       }
/* 198 */       if (checkIfBlockIsProtected(block)) {
/*     */         continue;
/*     */       }
/* 201 */       if (entityType != EntityType.PRIMED_TNT && entityType != EntityType.MINECART_TNT && block
/* 202 */         .getType() == Material.ENDER_STONE) {
/*     */         continue;
/*     */       }
/* 205 */       block.setType(Material.AIR);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean checkIfBlockIsProtected(Block block) {
/* 210 */     List<Block> blocks = Arrays.asList(new Block[] { block.getRelative(BlockFace.NORTH), block.getRelative(BlockFace.SOUTH), block
/* 211 */           .getRelative(BlockFace.WEST), block.getRelative(BlockFace.EAST), block.getRelative(BlockFace.UP), block
/* 212 */           .getRelative(BlockFace.DOWN) });
/*     */     
/* 214 */     for (Block b : blocks) {
/* 215 */       if (b.getType().name().contains("GLASS")) {
/* 216 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 220 */     return false;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onExplosionPrime(ExplosionPrimeEvent event) {
/* 225 */     event.setCancelled(true);
/* 226 */     Entity entity = event.getEntity();
/*     */     
/* 228 */     if (entity.getType() == EntityType.FIREBALL || entity.getType() == EntityType.SMALL_FIREBALL) {
/*     */       return;
/*     */     }
/* 231 */     Location loc = event.getEntity().getLocation();
/* 232 */     makeExplosion(loc, EntityType.PRIMED_TNT);
/*     */     
/* 234 */     if (entity.hasMetadata("boost")) {
/* 235 */       Player player = Bukkit.getPlayer(((MetadataValue)entity.getMetadata("boost").get(0)).asString());
/* 236 */       for (Player ps : GamerHelper.getPlayersNear(loc, 6.0D)) {
/* 237 */         if (ps == player) {
/* 238 */           ps.setVelocity(tntBoost(loc, ps));
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onBlockIgnite(BlockIgniteEvent event) {
/* 246 */     event.setCancelled(true);
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.LOWEST)
/*     */   public void onEntityDamage(EntityDamageEvent event) {
/* 251 */     if (event.getEntity() instanceof Player) {
/* 252 */       Player player = (Player)event.getEntity();
/* 253 */       if (event.getCause() == EntityDamageEvent.DamageCause.FALL || event.getCause() == EntityDamageEvent.DamageCause.FALLING_BLOCK) {
/* 254 */         if (player.hasMetadata("onlyboost-onground") && ((MetadataValue)player
/* 255 */           .getMetadata("onlyboost-onground").get(0)).asLong() > System.currentTimeMillis())
/* 256 */           event.setDamage(event.getDamage() / 2.0D); 
/* 257 */       } else if (event.getCause() == EntityDamageEvent.DamageCause.BLOCK_EXPLOSION || event
/* 258 */         .getCause() == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION || event.getCause() == EntityDamageEvent.DamageCause.CUSTOM || event
/* 259 */         .getCause() == EntityDamageEvent.DamageCause.FIRE_TICK) {
/*     */         
/* 261 */         player.setFireTicks(-1);
/* 262 */         if (player.hasMetadata("no-damage-by-entity")) {
/* 263 */           event.setDamage(0.0D);
/* 264 */           event.setCancelled(true);
/* 265 */           player.removeMetadata("no-damage-by-entity", (Plugin)GameMain.getInstance());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.LOWEST)
/*     */   public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
/* 273 */     if ((event.getDamager() instanceof Fireball || event.getDamager() instanceof TNTPrimed) && 
/* 274 */       event.getEntity() instanceof Player) {
/* 275 */       Player player = (Player)event.getEntity();
/* 276 */       if (player.hasMetadata("no-damage-by-entity")) {
/* 277 */         player.setFireTicks(-1);
/* 278 */         event.setDamage(0.0D);
/* 279 */         event.setCancelled(true);
/* 280 */         player.removeMetadata("no-damage-by-entity", (Plugin)GameMain.getInstance());
/* 281 */         player.setMetadata("nofall", GameAPI.getInstance().createMeta(Long.valueOf(System.currentTimeMillis() + 3000L)));
/*     */       } 
/*     */       return;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/listener/FireballListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */