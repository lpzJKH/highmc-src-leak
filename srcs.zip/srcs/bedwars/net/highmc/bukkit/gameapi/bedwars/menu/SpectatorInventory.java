/*    */ package net.highmc.bukkit.gameapi.bedwars.menu;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ import net.highmc.CommonConst;
/*    */ import net.highmc.bukkit.gameapi.bedwars.GameMain;
/*    */ import net.highmc.bukkit.gameapi.bedwars.gamer.Gamer;
/*    */ import net.highmc.bukkit.gameapi.bedwars.island.Island;
/*    */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*    */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*    */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class SpectatorInventory {
/*    */   public SpectatorInventory(Player player) {
/* 20 */     MenuInventory menuInventory = new MenuInventory("§7Espectadores", 5);
/*    */     
/* 22 */     int w = 10;
/*    */ 
/*    */     
/* 25 */     List<Gamer> gamerList = (List<Gamer>)GameMain.getInstance().getGamerManager().getGamers(Gamer.class).stream().collect(Collectors.toList());
/*    */     
/* 27 */     for (Gamer gamer : gamerList) {
/* 28 */       Island island = GameMain.getInstance().getIslandManager().getIsland(gamer.getUniqueId());
/*    */       
/* 30 */       if (island == null || island.getIslandStatus() == Island.IslandStatus.LOSER) {
/*    */         continue;
/*    */       }
/* 33 */       Player playerGamer = gamer.getPlayer();
/*    */       
/* 35 */       menuInventory.setItem(w, (new ItemBuilder())
/* 36 */           .name(((gamer.isOnline() && gamer.isAlive()) ? "§a" : "§e") + gamer.getPlayerName())
/* 37 */           .type(Material.SKULL_ITEM).durability(3).lore(new String[] { "§fVida: §7" + (
/*    */               
/* 39 */               !gamer.isOnline() ? "0" : CommonConst.DECIMAL_FORMAT
/* 40 */               .format(playerGamer
/* 41 */                 .getHealth() / playerGamer.getMaxHealth() * 100.0D)) + "%", "§fTime: " + island
/*    */               
/* 43 */               .getIslandColor().getColor() + "§%" + island
/* 44 */               .getIslandColor().name().toLowerCase() + "-name%§", "", "§eClique para teletransportar."
/*    */             },
/* 46 */           ).build(), (p, inv, type, stack, slot) -> {
/*    */             p.teleport((Entity)playerGamer);
/*    */             
/*    */             p.closeInventory();
/*    */           });
/* 51 */       if (w % 9 == 7) {
/* 52 */         w += 3;
/*    */         
/*    */         continue;
/*    */       } 
/* 56 */       w++;
/*    */     } 
/*    */     
/* 59 */     menuInventory.open(player);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/menu/SpectatorInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */