/*     */ package net.highmc.bukkit.gameapi.bedwars.listener;
/*     */ 
/*     */ import net.highmc.bukkit.gameapi.GameAPI;
/*     */ import net.highmc.bukkit.gameapi.bedwars.GameConst;
/*     */ import net.highmc.bukkit.gameapi.bedwars.GameMain;
/*     */ import net.highmc.bukkit.gameapi.bedwars.event.PlayerBoughtItemEvent;
/*     */ import net.highmc.bukkit.gameapi.bedwars.gamer.Gamer;
/*     */ import net.highmc.bukkit.gameapi.bedwars.island.Island;
/*     */ import net.highmc.bukkit.gameapi.bedwars.island.IslandUpgrade;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.language.Language;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.enchantments.Enchantment;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IslandListener
/*     */   implements Listener
/*     */ {
/*     */   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
/*     */   public void onPlayerBoughtItem(PlayerBoughtItemEvent event) {
/*  27 */     Player player = event.getPlayer();
/*  28 */     Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/*  29 */     Island island = GameMain.getInstance().getIslandManager().getIsland(player.getUniqueId());
/*     */     
/*  31 */     if (island != null) {
/*  32 */       int slot; String swordType; String start; int i; Gamer.SwordLevel swordLevel; Gamer.ArmorLevel armorLevel; switch (event.getItemStack().getType()) {
/*     */         case COMPASS:
/*  34 */           player.getInventory().remove(Material.COMPASS);
/*  35 */           event.setItemStack(GameConst.FINDER.getItemStack());
/*     */           break;
/*     */         
/*     */         case WOOL:
/*  39 */           event.setItemStack(ItemBuilder.fromStack(event.getItemStack())
/*  40 */               .durability(island.getIslandColor().getWoolId()).build());
/*     */           break;
/*     */         case HARD_CLAY:
/*  43 */           event.setItemStack(ItemBuilder.fromStack(event.getItemStack()).type(Material.STAINED_CLAY)
/*  44 */               .durability(island.getIslandColor().getWoolId()).build());
/*     */           break;
/*     */         case SHEARS:
/*  47 */           if (gamer.isShears()) {
/*  48 */             event.setCancelled(true);
/*  49 */             player.sendMessage(Language.getLanguage(player.getUniqueId()).t("bedwars.you-already-have-shears", new String[0])); break;
/*     */           } 
/*  51 */           gamer.setShears(true);
/*     */           break;
/*     */         
/*     */         case DIAMOND_AXE:
/*     */         case GOLD_AXE:
/*     */         case IRON_AXE:
/*     */         case STONE_AXE:
/*     */         case WOOD_AXE:
/*  59 */           if (gamer.getAxeLevel() == gamer.getAxeLevel().getNext()) {
/*  60 */             event.setCancelled(true);
/*  61 */             player.sendMessage("");
/*     */             
/*     */             return;
/*     */           } 
/*  65 */           gamer.setAxeLevel(gamer.getAxeLevel().getNext());
/*     */           
/*  67 */           slot = -1;
/*     */           
/*  69 */           for (i = 0; i < (player.getInventory().getContents()).length; i++) {
/*  70 */             ItemStack itemStack = player.getInventory().getContents()[i];
/*     */             
/*  72 */             if (itemStack != null && itemStack
/*  73 */               .getType() == gamer.getAxeLevel().getPrevious().getItemStack().getType()) {
/*  74 */               player.getInventory().removeItem(new ItemStack[] { itemStack });
/*  75 */               slot = i;
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*  80 */           if (slot == -1) {
/*  81 */             player.getInventory().addItem(new ItemStack[] { gamer.getAxeLevel().getItemStack() });
/*     */           } else {
/*  83 */             player.getInventory().setItem(slot, gamer.getAxeLevel().getItemStack());
/*     */           } 
/*  85 */           event.setItemStack(null);
/*     */           break;
/*     */         
/*     */         case DIAMOND_PICKAXE:
/*     */         case GOLD_PICKAXE:
/*     */         case IRON_PICKAXE:
/*     */         case STONE_PICKAXE:
/*     */         case WOOD_PICKAXE:
/*  93 */           if (gamer.getPickaxeLevel() == gamer.getPickaxeLevel().getNext()) {
/*  94 */             event.setCancelled(true);
/*     */             
/*     */             return;
/*     */           } 
/*  98 */           gamer.setPickaxeLevel(gamer.getPickaxeLevel().getNext());
/*     */           
/* 100 */           if (gamer.getPickaxeLevel().ordinal() == 1) {
/* 101 */             player.getInventory().addItem(new ItemStack[] { gamer.getPickaxeLevel().getItemStack() });
/*     */           } else {
/* 103 */             slot = -1;
/*     */             
/* 105 */             for (i = 0; i < (player.getInventory().getContents()).length; i++) {
/* 106 */               ItemStack itemStack = player.getInventory().getContents()[i];
/*     */               
/* 108 */               if (itemStack != null && itemStack.getType() == gamer.getPickaxeLevel().getPrevious()
/* 109 */                 .getItemStack().getType()) {
/* 110 */                 player.getInventory().removeItem(new ItemStack[] { itemStack });
/* 111 */                 slot = i;
/*     */                 
/*     */                 break;
/*     */               } 
/*     */             } 
/* 116 */             if (slot == -1) {
/* 117 */               player.getInventory().addItem(new ItemStack[] { gamer.getPickaxeLevel().getItemStack() });
/*     */             } else {
/* 119 */               player.getInventory().setItem(slot, gamer.getPickaxeLevel().getItemStack());
/*     */             } 
/*     */           } 
/* 122 */           event.setItemStack(null);
/*     */           break;
/*     */         
/*     */         case STONE_SWORD:
/*     */         case IRON_SWORD:
/*     */         case DIAMOND_SWORD:
/* 128 */           swordType = event.getItemStack().getType().name().split("_")[0];
/* 129 */           swordLevel = Gamer.SwordLevel.valueOf(swordType);
/*     */           
/* 131 */           if (gamer.getSwordLevel() == swordLevel || gamer.getSwordLevel().ordinal() > swordLevel.ordinal()) {
/* 132 */             player.getInventory().addItem(new ItemStack[] { ItemBuilder.fromStack(event.getItemStack())
/* 133 */                   .enchantment(Enchantment.DAMAGE_ALL, island.getUpgradeLevel(IslandUpgrade.SHARPNESS))
/* 134 */                   .build() });
/*     */           } else {
/* 136 */             if (gamer.getSwordLevel() == Gamer.SwordLevel.WOOD) {
/* 137 */               int j = -1;
/*     */               
/* 139 */               for (int k = 0; k < (player.getInventory().getContents()).length; k++) {
/* 140 */                 ItemStack itemStack = player.getInventory().getContents()[k];
/*     */                 
/* 142 */                 if (itemStack != null && itemStack.getType() == 
/* 143 */                   Material.valueOf(gamer.getSwordLevel().name() + "_SWORD")) {
/* 144 */                   player.getInventory().removeItem(new ItemStack[] { itemStack });
/* 145 */                   j = k;
/*     */                   
/*     */                   break;
/*     */                 } 
/*     */               } 
/* 150 */               if (j != -1)
/* 151 */                 player.getInventory().setItem(j, 
/* 152 */                     ItemBuilder.fromStack(event.getItemStack()).enchantment(Enchantment.DAMAGE_ALL, island
/* 153 */                       .getUpgradeLevel(IslandUpgrade.SHARPNESS)).build()); 
/*     */             } else {
/* 155 */               player.getInventory().addItem(new ItemStack[] { (new ItemBuilder())
/* 156 */                     .type(Material.valueOf(swordLevel.name() + "_SWORD"))
/* 157 */                     .enchantment(Enchantment.DAMAGE_ALL, island.getUpgradeLevel(IslandUpgrade.SHARPNESS))
/* 158 */                     .build() });
/*     */             } 
/* 160 */             gamer.setSwordLevel(swordLevel);
/*     */           } 
/*     */ 
/*     */           
/* 164 */           event.setItemStack(null);
/*     */           break;
/*     */         
/*     */         case DIAMOND_BOOTS:
/*     */         case IRON_BOOTS:
/*     */         case CHAINMAIL_BOOTS:
/* 170 */           start = event.getItemStack().getType().name().split("_")[0];
/* 171 */           armorLevel = Gamer.ArmorLevel.valueOf(start);
/*     */           
/* 173 */           if (gamer.getArmorLevel() == armorLevel) {
/* 174 */             event.setCancelled(true);
/* 175 */             player.sendMessage("§cVocê já está usando essa armadura.");
/*     */             
/*     */             return;
/*     */           } 
/* 179 */           if (armorLevel.ordinal() < gamer.getArmorLevel().ordinal()) {
/* 180 */             event.setCancelled(true);
/* 181 */             player.sendMessage("§cVocê não pode comprar essa armadura enquanto estiver usando uma de nível superior.");
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/* 186 */           player.getInventory()
/* 187 */             .setLeggings((new ItemBuilder()).type(Material.valueOf(start + "_LEGGINGS"))
/* 188 */               .enchantment(Enchantment.PROTECTION_ENVIRONMENTAL, island
/* 189 */                 .getUpgradeLevel(IslandUpgrade.ARMOR_REINFORCEMENT))
/* 190 */               .build());
/* 191 */           player.getInventory()
/* 192 */             .setBoots((new ItemBuilder()).type(Material.valueOf(start + "_BOOTS"))
/* 193 */               .enchantment(Enchantment.PROTECTION_ENVIRONMENTAL, island
/* 194 */                 .getUpgradeLevel(IslandUpgrade.ARMOR_REINFORCEMENT))
/* 195 */               .build());
/*     */           
/* 197 */           gamer.setArmorLevel(armorLevel);
/* 198 */           event.setItemStack(null);
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/listener/IslandListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */