/*     */ package net.highmc.bukkit.gameapi.bedwars.listener;
/*     */ 
/*     */ import net.highmc.bukkit.gameapi.GameAPI;
/*     */ import net.highmc.bukkit.gameapi.bedwars.gamer.Gamer;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.block.BlockBreakEvent;
/*     */ import org.bukkit.event.block.BlockPlaceEvent;
/*     */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*     */ import org.bukkit.event.entity.EntityDamageEvent;
/*     */ import org.bukkit.event.player.PlayerBucketEmptyEvent;
/*     */ import org.bukkit.event.player.PlayerDropItemEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.event.player.PlayerPickupItemEvent;
/*     */ 
/*     */ public class SpectatorListener
/*     */   implements Listener
/*     */ {
/*     */   @EventHandler(priority = EventPriority.LOW)
/*     */   public void onEntityDamage(EntityDamageEvent event) {
/*  23 */     if (event.getEntity() instanceof Player) {
/*  24 */       Player player = (Player)event.getEntity();
/*  25 */       Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/*     */       
/*  27 */       if (gamer.isSpectator()) {
/*  28 */         event.setCancelled(true);
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.LOW)
/*     */   public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
/*  36 */     if (event.getEntity() instanceof Player) {
/*  37 */       Player player = (Player)event.getEntity();
/*  38 */       Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/*     */       
/*  40 */       if (gamer.isSpectator()) {
/*  41 */         event.setCancelled(true);
/*     */         
/*     */         return;
/*     */       } 
/*  45 */       if (event.getDamager() instanceof Player) {
/*  46 */         Player damager = (Player)event.getDamager();
/*  47 */         Gamer damagerGamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(damager.getUniqueId(), Gamer.class);
/*     */ 
/*     */         
/*  50 */         if (damagerGamer.isSpectator()) {
/*  51 */           event.setCancelled(true);
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.LOW)
/*     */   public void onPlayerBucketEmpty(PlayerBucketEmptyEvent event) {
/*  60 */     Player player = event.getPlayer();
/*  61 */     Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/*     */     
/*  63 */     if (gamer.isSpectator())
/*  64 */       event.setCancelled(true); 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.LOW)
/*     */   public void onBlockBreak(BlockBreakEvent event) {
/*  69 */     Player player = event.getPlayer();
/*  70 */     Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/*     */     
/*  72 */     if (gamer.isSpectator())
/*  73 */       event.setCancelled(true); 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.LOW)
/*     */   public void onBlockPlace(BlockPlaceEvent event) {
/*  78 */     Player player = event.getPlayer();
/*  79 */     Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/*     */     
/*  81 */     if (gamer.isSpectator())
/*  82 */       event.setCancelled(true); 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.LOW)
/*     */   public void onPlayerInteract(PlayerInteractEvent event) {
/*  87 */     Player player = event.getPlayer();
/*  88 */     Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/*     */     
/*  90 */     if (gamer.isSpectator())
/*  91 */       event.setCancelled(true); 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.LOW)
/*     */   public void onPlayerDropItem(PlayerDropItemEvent event) {
/*  96 */     Player player = event.getPlayer();
/*  97 */     Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/*     */     
/*  99 */     if (gamer.isSpectator())
/* 100 */       event.setCancelled(true); 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.LOW)
/*     */   public void onPlayerPickupItem(PlayerPickupItemEvent event) {
/* 105 */     Player player = event.getPlayer();
/* 106 */     Gamer gamer = (Gamer)GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
/*     */     
/* 108 */     if (gamer.isSpectator())
/* 109 */       event.setCancelled(true); 
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/listener/SpectatorListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */