/*    */ package net.highmc.bukkit.gameapi.bedwars.generator.impl;
/*    */ 
/*    */ import net.highmc.bukkit.gameapi.bedwars.generator.Generator;
/*    */ import net.highmc.bukkit.gameapi.bedwars.generator.GeneratorType;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmeraldGenerator
/*    */   extends Generator
/*    */ {
/*    */   public EmeraldGenerator(Location location) {
/* 15 */     super(location, GeneratorType.EMERALD, new ItemStack(Material.EMERALD));
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/generator/impl/EmeraldGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */