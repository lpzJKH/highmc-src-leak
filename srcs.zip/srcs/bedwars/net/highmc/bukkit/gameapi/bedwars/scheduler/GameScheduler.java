/*     */ package net.highmc.bukkit.gameapi.bedwars.scheduler;
/*     */ 
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import com.google.common.collect.UnmodifiableIterator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.event.UpdateEvent;
/*     */ import net.highmc.bukkit.gameapi.GameAPI;
/*     */ import net.highmc.bukkit.gameapi.bedwars.GameMain;
/*     */ import net.highmc.bukkit.gameapi.bedwars.event.GameStartEvent;
/*     */ import net.highmc.bukkit.gameapi.bedwars.event.PlayerSpectateEvent;
/*     */ import net.highmc.bukkit.gameapi.bedwars.island.Island;
/*     */ import net.highmc.bukkit.gameapi.bedwars.listener.CombatListener;
/*     */ import net.highmc.bukkit.gameapi.bedwars.listener.DefenserListener;
/*     */ import net.highmc.bukkit.gameapi.bedwars.listener.FireballListener;
/*     */ import net.highmc.bukkit.gameapi.bedwars.listener.GameListener;
/*     */ import net.highmc.bukkit.gameapi.bedwars.listener.IslandListener;
/*     */ import net.highmc.bukkit.gameapi.bedwars.listener.SpectatorListener;
/*     */ import net.highmc.bukkit.gameapi.bedwars.listener.StatusListener;
/*     */ import net.highmc.bukkit.gameapi.bedwars.listener.UpgradeListener;
/*     */ import net.highmc.bukkit.gameapi.bedwars.utils.GamerHelper;
/*     */ import net.highmc.bukkit.gameapi.scheduler.Scheduler;
/*     */ import net.highmc.bukkit.utils.scoreboard.ScoreboardAPI;
/*     */ import net.highmc.language.Language;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.entity.EntityDamageEvent;
/*     */ import org.bukkit.event.player.PlayerItemConsumeEvent;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.inventory.meta.PotionMeta;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.potion.PotionEffect;
/*     */ import org.bukkit.potion.PotionEffectType;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ import org.bukkit.scoreboard.NameTagVisibility;
/*     */ import org.bukkit.scoreboard.Team;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GameScheduler
/*     */   implements Listener, Scheduler
/*     */ {
/*     */   private Map<UUID, Long> playerInvisibleMap;
/*     */   
/*     */   public GameScheduler() {
/*  54 */     GameAPI.getInstance().setUnloadGamer(false);
/*  55 */     GameAPI.getInstance().setTagControl(false);
/*  56 */     GameAPI.getInstance().setTime(0);
/*     */     
/*  58 */     this.playerInvisibleMap = new HashMap<>();
/*     */     
/*  60 */     Bukkit.getOnlinePlayers().forEach(player -> ScoreboardAPI.leaveCurrentTeamForOnlinePlayers(player));
/*     */     
/*  62 */     for (Island island : GameMain.getInstance().getIslandManager().loadIsland()) {
/*  63 */       island.startIsland();
/*     */       
/*  65 */       for (UUID uuid : island.getTeam().getPlayerSet()) {
/*  66 */         Player player = Bukkit.getPlayer(uuid);
/*     */         
/*  68 */         for (Player o : Bukkit.getOnlinePlayers()) {
/*  69 */           ScoreboardAPI.joinTeam(
/*  70 */               ScoreboardAPI.createTeamIfNotExistsToPlayer(o, GameMain.getInstance().getId(island), 
/*  71 */                 GameMain.getInstance().getTag(island, Language.getLanguage(o.getUniqueId())), ""), player);
/*     */         }
/*     */ 
/*     */         
/*  75 */         GamerHelper.setPlayerProtection(player, 5);
/*     */       } 
/*     */     } 
/*     */     
/*  79 */     GameAPI.getInstance().getVanishManager().getPlayersInAdmin().forEach(id -> {
/*     */           Player player = Bukkit.getPlayer(id);
/*     */           if (player != null) {
/*     */             loadTags(player);
/*     */           }
/*     */         });
/*  85 */     Bukkit.getPluginManager().registerEvents((Listener)new CombatListener(), (Plugin)GameAPI.getInstance());
/*  86 */     Bukkit.getPluginManager().registerEvents((Listener)new GameListener(), (Plugin)GameAPI.getInstance());
/*  87 */     Bukkit.getPluginManager().registerEvents((Listener)new FireballListener(), (Plugin)GameAPI.getInstance());
/*  88 */     Bukkit.getPluginManager().registerEvents((Listener)new IslandListener(), (Plugin)GameAPI.getInstance());
/*  89 */     Bukkit.getPluginManager().registerEvents((Listener)new DefenserListener(), (Plugin)GameAPI.getInstance());
/*  90 */     Bukkit.getPluginManager().registerEvents((Listener)new SpectatorListener(), (Plugin)GameAPI.getInstance());
/*  91 */     Bukkit.getPluginManager().registerEvents((Listener)new StatusListener(), (Plugin)GameAPI.getInstance());
/*  92 */     Bukkit.getPluginManager().registerEvents((Listener)new UpgradeListener(), (Plugin)GameAPI.getInstance());
/*  93 */     Bukkit.getPluginManager().callEvent((Event)new GameStartEvent());
/*     */     
/*  95 */     Bukkit.getWorlds().stream().filter(world -> world.getName().equals("spawn")).findFirst().ifPresent(world -> Bukkit.unloadWorld(world, false));
/*     */ 
/*     */ 
/*     */     
/*  99 */     GameMain.getInstance().getGeneratorManager().startGenerators();
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerSpectate(PlayerSpectateEvent event) {
/* 104 */     Player player = event.getPlayer();
/* 105 */     loadTags(player);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerJoin(PlayerJoinEvent event) {
/* 110 */     Player player = event.getPlayer();
/* 111 */     loadTags(player);
/*     */   }
/*     */   
/*     */   private void loadTags(Player player) {
/* 115 */     Island playerIsland = GameMain.getInstance().getIslandManager().getIsland(player.getUniqueId());
/*     */     
/* 117 */     for (Player online : Bukkit.getOnlinePlayers()) {
/* 118 */       Island island = GameMain.getInstance().getIslandManager().getIsland(online.getUniqueId());
/*     */       
/* 120 */       ScoreboardAPI.joinTeam(ScoreboardAPI.createTeamIfNotExistsToPlayer(player, (island == null || island
/* 121 */             .getIslandStatus() == Island.IslandStatus.LOSER) ? "z" : 
/* 122 */             GameMain.getInstance().getId(island), (island == null || island
/* 123 */             .getIslandStatus() == Island.IslandStatus.LOSER) ? "§8" : 
/* 124 */             GameMain.getInstance().getTag(island, Language.getLanguage(player.getUniqueId())), ""), online);
/*     */       
/* 126 */       ScoreboardAPI.joinTeam(ScoreboardAPI.createTeamIfNotExistsToPlayer(online, (playerIsland == null || playerIsland
/* 127 */             .getIslandStatus() == Island.IslandStatus.LOSER) ? "z" : 
/* 128 */             GameMain.getInstance().getId(playerIsland), (playerIsland == null || playerIsland
/* 129 */             .getIslandStatus() == Island.IslandStatus.LOSER) ? "§8" : 
/* 130 */             GameMain.getInstance().getTag(playerIsland, Language.getLanguage(player.getUniqueId())), ""), player);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerItemConsume(PlayerItemConsumeEvent event) {
/* 137 */     if (event.getItem().getType() == Material.POTION) {
/* 138 */       final Player player = event.getPlayer();
/* 139 */       PotionMeta potionMeta = (PotionMeta)event.getItem().getItemMeta();
/* 140 */       Island island = GameMain.getInstance().getIslandManager().getIsland(player.getUniqueId());
/*     */       
/* 142 */       (new BukkitRunnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 146 */             player.getInventory().remove(Material.GLASS_BOTTLE);
/*     */           }
/* 148 */         }).runTaskLater((Plugin)GameAPI.getInstance(), 3L);
/*     */       
/* 150 */       if (island == null) {
/*     */         return;
/*     */       }
/* 153 */       if (potionMeta.hasCustomEffect(PotionEffectType.INVISIBILITY)) {
/* 154 */         potionMeta.getCustomEffects().stream()
/* 155 */           .filter(potion -> (potion.getType().getId() == PotionEffectType.INVISIBILITY.getId())).findFirst()
/* 156 */           .ifPresent(potionEffect -> {
/*     */               player.removeMetadata("invencibility", (Plugin)GameAPI.getInstance());
/*     */               int duration = potionEffect.getDuration();
/*     */               if (registerInvisibleTeam(player, island)) {
/*     */                 GamerHelper.handleRemoveArmor(player);
/*     */               }
/*     */               this.playerInvisibleMap.put(player.getUniqueId(), Long.valueOf(System.currentTimeMillis() + (duration / 20 * 1000)));
/*     */             });
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onUpdate(UpdateEvent event) {
/* 172 */     if (event.getType() == UpdateEvent.UpdateType.SECOND) {
/* 173 */       for (UnmodifiableIterator<Map.Entry<UUID, Long>> unmodifiableIterator = ImmutableList.copyOf(this.playerInvisibleMap.entrySet()).iterator(); unmodifiableIterator.hasNext(); ) { Map.Entry<UUID, Long> entry = unmodifiableIterator.next();
/* 174 */         Player player = Bukkit.getPlayer(entry.getKey());
/*     */         
/* 176 */         if (player == null) {
/* 177 */           this.playerInvisibleMap.remove(entry.getKey()); continue;
/*     */         } 
/* 179 */         if (((Long)entry.getValue()).longValue() < System.currentTimeMillis()) {
/* 180 */           if (player.isOnline() && unregisterInvisibleTeam(player, 
/* 181 */               GameMain.getInstance().getIslandManager().getIsland(player.getUniqueId()))) {
/* 182 */             GamerHelper.handleArmor(player);
/*     */           }
/* 184 */           this.playerInvisibleMap.remove(entry.getKey());
/*     */         }  }
/*     */     
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onEntityDamage(EntityDamageEvent event) {
/* 193 */     if (!(event.getEntity() instanceof Player)) {
/*     */       return;
/*     */     }
/* 196 */     final Player player = (Player)event.getEntity();
/*     */     
/* 198 */     if (player.hasMetadata("invencibility"))
/* 199 */       if (player.hasPotionEffect(PotionEffectType.INVISIBILITY)) {
/* 200 */         player.getActivePotionEffects().stream()
/* 201 */           .filter(potion -> (potion.getType().getId() == PotionEffectType.INVISIBILITY.getId())).findFirst()
/* 202 */           .ifPresent(potion -> {
/*     */               int duration = potion.getDuration();
/*     */               
/*     */               final Island island = GameMain.getInstance().getIslandManager().getIsland(player.getUniqueId());
/*     */               
/*     */               if (unregisterInvisibleTeam(player, island)) {
/*     */                 GamerHelper.handleArmor(player);
/*     */                 if (duration - 100 > 0)
/*     */                   (new BukkitRunnable()
/*     */                     {
/*     */                       public void run()
/*     */                       {
/* 214 */                         if (GameScheduler.this.registerInvisibleTeam(player, island)) {
/* 215 */                           GamerHelper.handleRemoveArmor(player);
/*     */                         }
/*     */                       }
/*     */                     }).runTaskLater((Plugin)GameAPI.getInstance(), 80L); 
/*     */               } 
/*     */             });
/*     */       } else {
/* 222 */         player.removeMetadata("invencibility", (Plugin)GameAPI.getInstance());
/*     */       }  
/*     */   }
/*     */   
/*     */   private boolean unregisterInvisibleTeam(Player player, Island island) {
/* 227 */     if (player.hasMetadata("invencibility")) {
/* 228 */       String teamId = GameMain.getInstance().getId(island);
/* 229 */       String teamTag = GameMain.getInstance().getTag(island, Language.getLanguage(player.getUniqueId()));
/*     */       
/* 231 */       for (Player o : Bukkit.getOnlinePlayers()) {
/* 232 */         ScoreboardAPI.leaveTeam(o, teamId + "i", player);
/* 233 */         ScoreboardAPI.joinTeam(ScoreboardAPI.createTeamIfNotExistsToPlayer(o, teamId, teamTag, ""), player);
/*     */       } 
/*     */       
/* 236 */       player.removeMetadata("invencibility", (Plugin)GameAPI.getInstance());
/* 237 */       return true;
/*     */     } 
/*     */     
/* 240 */     return false;
/*     */   }
/*     */   
/*     */   private boolean registerInvisibleTeam(Player player, Island island) {
/* 244 */     if (!player.hasMetadata("invencibility")) {
/* 245 */       String teamId = GameMain.getInstance().getId(island);
/* 246 */       String teamTag = GameMain.getInstance().getTag(island, Language.getLanguage(player.getUniqueId()));
/*     */       
/* 248 */       for (Player o : Bukkit.getOnlinePlayers()) {
/* 249 */         Team createTeamIfNotExistsToPlayer = ScoreboardAPI.createTeamIfNotExistsToPlayer(o, teamId + "i", teamTag, "");
/*     */         
/* 251 */         ScoreboardAPI.joinTeam(createTeamIfNotExistsToPlayer, player);
/* 252 */         createTeamIfNotExistsToPlayer.setNameTagVisibility(NameTagVisibility.NEVER);
/*     */       } 
/*     */       
/* 255 */       player.setMetadata("invencibility", GameAPI.getInstance().createMeta(Boolean.valueOf(true)));
/* 256 */       return true;
/*     */     } 
/*     */     
/* 259 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void pulse() {
/* 264 */     int time = GameAPI.getInstance().getTime();
/*     */     
/* 266 */     if (GameMain.getInstance().getGeneratorUpgrade() != null && GameMain.getInstance().getGeneratorUpgrade().getTimer() - GameAPI.getInstance().getTime() - 1 == 0) {
/* 267 */       GameMain.getInstance().getGeneratorUpgrade().getConsumer().accept(null);
/*     */     }
/*     */     
/* 270 */     if (time >= 2100) {
/* 271 */       Bukkit.broadcastMessage("§cNenhum time ganhou a partida.");
/* 272 */       Bukkit.getOnlinePlayers().forEach(player -> GameMain.getInstance().sendPlayerToServer(player, CommonPlugin.getInstance().getServerId()));
/* 273 */       Bukkit.shutdown();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/scheduler/GameScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */