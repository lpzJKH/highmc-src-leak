/*    */ package net.highmc.bukkit.gameapi.bedwars.menu.creator;
/*    */ 
/*    */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class GeneratorCreatorInventory
/*    */ {
/*    */   public GeneratorCreatorInventory(Player player) {
/* 10 */     MenuInventory menuInventory = new MenuInventory("§7Criar geradores", 3);
/*    */     
/* 12 */     menuInventory.open(player);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/menu/creator/GeneratorCreatorInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */