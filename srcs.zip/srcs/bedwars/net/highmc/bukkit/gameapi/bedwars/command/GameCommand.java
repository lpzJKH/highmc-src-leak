/*    */ package net.highmc.bukkit.gameapi.bedwars.command;
/*    */ 
/*    */ import com.google.common.base.Joiner;
/*    */ import net.highmc.bukkit.gameapi.GameAPI;
/*    */ import net.highmc.bukkit.gameapi.bedwars.GameMain;
/*    */ import net.highmc.bukkit.gameapi.bedwars.island.Island;
/*    */ import net.highmc.bukkit.gameapi.bedwars.store.ShopCategory;
/*    */ import net.highmc.bukkit.gameapi.bedwars.utils.GamerHelper;
/*    */ import net.highmc.bukkit.member.BukkitMember;
/*    */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*    */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*    */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*    */ import net.highmc.command.CommandArgs;
/*    */ import net.highmc.command.CommandClass;
/*    */ import net.highmc.command.CommandFramework.Command;
/*    */ import net.highmc.member.status.Status;
/*    */ import net.highmc.member.status.StatusType;
/*    */ import net.highmc.member.status.types.BedwarsCategory;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class GameCommand
/*    */   implements CommandClass
/*    */ {
/*    */   @Command(name = "global", aliases = {"shout", "g"}, console = false)
/*    */   public void globalCommand(CommandArgs cmdArgs) {
/* 30 */     Player sender = ((BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class)).getPlayer();
/*    */     
/* 32 */     if (GameMain.getInstance().getPlayersPerTeam() == 1) {
/* 33 */       sender.sendMessage("§cO comando está desativado nessa sala.");
/*    */       
/*    */       return;
/*    */     } 
/* 37 */     String[] args = cmdArgs.getArgs();
/*    */     
/* 39 */     if (!GameAPI.getInstance().getState().isGametime()) {
/* 40 */       sender.sendMessage("§cO jogo ainda não começou.");
/*    */       
/*    */       return;
/*    */     } 
/* 44 */     if (args.length == 0) {
/* 45 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs
/* 46 */           .getLabel() + " <message>§f para mandar uma mensagem no servidor.");
/*    */       
/*    */       return;
/*    */     } 
/* 50 */     Island island = GameMain.getInstance().getIslandManager().getIsland(sender.getUniqueId());
/*    */     
/* 52 */     if (island == null) {
/* 53 */       sender.sendMessage("§cSomente jogadores com uma ilha podem utilizar esse comando.");
/*    */       
/*    */       return;
/*    */     } 
/* 57 */     if (island.getIslandStatus() == Island.IslandStatus.LOSER) {
/* 58 */       sender.sendMessage("§cVocê não pode mais falar no chat.");
/*    */     } else {
/* 60 */       Status status = GameAPI.getInstance().getPlugin().getStatusManager().loadStatus(sender.getUniqueId(), StatusType.BEDWARS);
/*    */ 
/*    */       
/* 63 */       int level = status.getInteger((Enum)BedwarsCategory.BEDWARS_LEVEL);
/* 64 */       String message = GameMain.getInstance().createMessage(sender, Joiner.on(' ').join((Object[])args), island, true, true, level);
/*    */ 
/*    */       
/* 67 */       Bukkit.getOnlinePlayers().forEach(ps -> ps.sendMessage(message));
/*    */     } 
/*    */   }
/*    */   
/*    */   @Command(name = "rastreador", aliases = {"bussola", "compass"}, console = false)
/*    */   public void rastreadorCommand(CommandArgs cmdArgs) {
/* 73 */     MenuInventory menuInventory = new MenuInventory("§7Rastreador", 3);
/*    */     
/* 75 */     menuInventory.setItem(13, (new ItemBuilder())
/* 76 */         .name("§aRastreador").lore("§22 esmeraldas").type(Material.COMPASS).build(), (player, inv, type, stack, slot) -> GamerHelper.buyItem(player, new ShopCategory.ShopItem(stack, new ShopCategory.ShopPrice(Material.EMERALD, 2))));
/*    */ 
/*    */ 
/*    */     
/* 80 */     menuInventory.open(((BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class)).getPlayer());
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/command/GameCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */