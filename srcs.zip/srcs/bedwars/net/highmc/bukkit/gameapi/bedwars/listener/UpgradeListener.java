/*     */ package net.highmc.bukkit.gameapi.bedwars.listener;
/*     */ 
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.stream.Stream;
/*     */ import net.highmc.CommonConst;
/*     */ import net.highmc.bukkit.event.UpdateEvent;
/*     */ import net.highmc.bukkit.gameapi.GameAPI;
/*     */ import net.highmc.bukkit.gameapi.bedwars.GameMain;
/*     */ import net.highmc.bukkit.gameapi.bedwars.event.island.IslandUpgradeEvent;
/*     */ import net.highmc.bukkit.gameapi.bedwars.gamer.Gamer;
/*     */ import net.highmc.bukkit.gameapi.bedwars.generator.Generator;
/*     */ import net.highmc.bukkit.gameapi.bedwars.generator.impl.NormalGenerator;
/*     */ import net.highmc.bukkit.gameapi.bedwars.island.Island;
/*     */ import net.highmc.bukkit.gameapi.bedwars.island.IslandUpgrade;
/*     */ import net.highmc.bukkit.utils.Location;
/*     */ import net.highmc.bukkit.utils.player.PlayerHelper;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Effect;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.Chest;
/*     */ import org.bukkit.enchantments.Enchantment;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.player.PlayerItemConsumeEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.potion.PotionEffect;
/*     */ import org.bukkit.potion.PotionEffectType;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UpgradeListener
/*     */   implements Listener
/*     */ {
/*     */   private static final double ISLAND_DISTANCE = 25.0D;
/*  51 */   private Map<Island, Integer> regenMap = new HashMap<>();
/*  52 */   private Map<UUID, Long> trapBlockMap = new HashMap<>();
/*  53 */   private List<Island> trapList = new ArrayList<>();
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onUpdateEvent(UpdateEvent event) {
/*  58 */     if (event.getType() == UpdateEvent.UpdateType.SECOND) {
/*  59 */       this.regenMap.entrySet().forEach(entry -> {
/*     */             Location location = ((Generator)((Island)entry.getKey()).getIslandGenerators().stream().findFirst().orElse(null)).getLocation();
/*     */ 
/*     */ 
/*     */             
/*     */             for (int i = 0; i <= 40; i++) {
/*     */               Location particleLocation = new Location(location.getWorld(), location.getX() + Math.random() * 16.666666666666668D * (CommonConst.RANDOM.nextBoolean() ? -1 : true), location.getY() + Math.random() * 8.333333333333334D, location.getZ() + Math.random() * 16.666666666666668D * (CommonConst.RANDOM.nextBoolean() ? -1 : true));
/*     */ 
/*     */               
/*     */               location.getWorld().playEffect(particleLocation, Effect.HAPPY_VILLAGER, 1);
/*     */             } 
/*     */           });
/*     */ 
/*     */       
/*  73 */       ImmutableList.copyOf(this.regenMap.entrySet()).forEach(entry -> map((Island)entry.getKey()).filter(()).forEach(()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  83 */       ImmutableList.copyOf(this.trapList).forEach(island -> Bukkit.getOnlinePlayers().stream().filter(()).forEach(()));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerConsume(PlayerItemConsumeEvent event) {
/* 106 */     if (event.getItem().getType() == Material.MILK_BUCKET) {
/* 107 */       event.setCancelled(true);
/*     */       
/* 109 */       final Player player = event.getPlayer();
/*     */       
/* 111 */       (new BukkitRunnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 115 */             player.getInventory().remove(Material.MILK_BUCKET);
/* 116 */             player.removePotionEffect(PotionEffectType.BLINDNESS);
/* 117 */             player.removePotionEffect(PotionEffectType.SLOW);
/*     */             
/* 119 */             if (!UpgradeListener.this.trapBlockMap.containsKey(player.getUniqueId()))
/* 120 */               UpgradeListener.this.trapBlockMap.put(player.getUniqueId(), Long.valueOf(System.currentTimeMillis() + 30000L)); 
/*     */           }
/* 122 */         }).runTaskLater((Plugin)GameAPI.getInstance(), 3L);
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onIslandUpgrade(IslandUpgradeEvent event) {
/* 128 */     Island island = event.getIsland();
/*     */     
/* 130 */     IslandUpgrade upgrade = event.getUpgrade();
/* 131 */     int level = event.getLevel();
/*     */     
/* 133 */     switch (upgrade) {
/*     */       case SHARPNESS:
/* 135 */         forEach(island, gamer -> {
/*     */               if (gamer.getPlayer() == null) {
/*     */                 return;
/*     */               }
/*     */               
/*     */               for (ItemStack itemStack : gamer.getPlayer().getInventory().getContents()) {
/*     */                 if (itemStack != null && itemStack.getType().name().contains("SWORD")) {
/*     */                   itemStack.addEnchantment(Enchantment.DAMAGE_ALL, level);
/*     */                 }
/*     */               } 
/*     */               
/*     */               for (ItemStack itemStack : gamer.getPlayer().getEnderChest().getContents()) {
/*     */                 if (itemStack != null && itemStack.getType().name().contains("SWORD")) {
/*     */                   itemStack.addEnchantment(Enchantment.DAMAGE_ALL, level);
/*     */                 }
/*     */               } 
/*     */             });
/* 152 */         for (Location location : GameMain.getInstance()
/* 153 */           .getNearestBlocksByMaterial(island.getSpawnLocation().getAsLocation(), Material.CHEST, 10, 5)) {
/* 154 */           Chest chest = (Chest)location.getBlock().getState();
/*     */           
/* 156 */           for (ItemStack itemStack : chest.getInventory().getContents()) {
/* 157 */             if (itemStack != null && 
/* 158 */               itemStack.getType().name().contains("SWORD")) {
/* 159 */               itemStack.addEnchantment(Enchantment.DAMAGE_ALL, level);
/*     */             }
/*     */           } 
/*     */         } 
/*     */         break;
/*     */       case ARMOR_REINFORCEMENT:
/* 165 */         forEach(island, gamer -> {
/*     */               if (gamer.getPlayer() == null) {
/*     */                 return;
/*     */               }
/*     */               for (ItemStack itemStack : gamer.getPlayer().getInventory().getArmorContents()) {
/*     */                 if (itemStack != null) {
/*     */                   itemStack.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, level);
/*     */                 }
/*     */               } 
/*     */             });
/*     */         break;
/*     */       case HASTE:
/* 177 */         forEach(island, gamer -> {
/*     */               if (gamer.getPlayer() == null) {
/*     */                 return;
/*     */               }
/*     */               gamer.getPlayer().addPotionEffect(new PotionEffect(PotionEffectType.FAST_DIGGING, 199980, level - 1), true);
/*     */             });
/*     */         break;
/*     */       
/*     */       case TRAP:
/* 186 */         this.trapList.add(island);
/*     */         break;
/*     */       
/*     */       case REGENERATION:
/* 190 */         this.regenMap.put(island, Integer.valueOf(level));
/*     */         break;
/*     */       
/*     */       case FORGE:
/* 194 */         if (level == 1) {
/* 195 */           island.getIslandGenerators().stream().limit(3L)
/* 196 */             .filter(generator -> (generator.getItemStack().getType() == Material.IRON_INGOT))
/* 197 */             .forEach(generator -> {
/*     */                 generator.setGenerateTime(generator.getGenerateTime() - 1000L);
/*     */                 generator.setLevel(generator.getLevel() + 1);
/*     */               });
/* 201 */           island.getIslandGenerators().stream()
/* 202 */             .filter(generator -> (generator.getItemStack().getType() == Material.GOLD_INGOT))
/* 203 */             .forEach(generator -> {
/*     */                 generator.setGenerateTime(generator.getGenerateTime() - 1000L); generator.setLevel(generator.getLevel() + 1);
/*     */               }); break;
/*     */         } 
/* 207 */         if (level == 2) {
/* 208 */           island.getIslandGenerators().stream().forEach(generator -> {
/*     */                 generator.setGenerateTime(generator.getGenerateTime() - 1000L); generator.setLevel(generator.getLevel() + 1);
/*     */               }); break;
/*     */         } 
/* 212 */         if (level == 3) {
/*     */           
/* 214 */           NormalGenerator normalGenerator = new NormalGenerator(((Location)((List<Location>)island.getGeneratorMap().get(Material.GOLD_INGOT)).stream().findFirst().orElse(null)).getAsLocation(), Material.EMERALD);
/*     */           
/* 216 */           normalGenerator.setGenerateTime(15000L);
/*     */           
/* 218 */           island.getIslandGenerators().add(normalGenerator); break;
/* 219 */         }  if (level == 4) {
/* 220 */           island.getIslandGenerators().stream().forEach(generator -> {
/*     */                 generator.setGenerateTime(Math.max(generator.getGenerateTime() - 2L, 0L));
/*     */                 generator.setLevel(generator.getLevel() + 1);
/*     */               });
/*     */         }
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Stream<Gamer> map(Island island) {
/* 231 */     return island.getTeam().getPlayerSet().stream()
/* 232 */       .map(id -> (Gamer)GameAPI.getInstance().getGamerManager().getGamer(id, Gamer.class))
/* 233 */       .filter(gamer -> (gamer.getPlayer() != null && gamer.isAlive()));
/*     */   }
/*     */   
/*     */   private void forEach(Island island, Consumer<Gamer> consumer) {
/* 237 */     island.getTeam().getPlayerSet().stream()
/* 238 */       .map(id -> (Gamer)GameAPI.getInstance().getGamerManager().getGamer(id, Gamer.class))
/* 239 */       .filter(gamer -> (gamer.getPlayer() != null && gamer.isAlive())).forEach(consumer);
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/listener/UpgradeListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */