/*    */ package net.highmc.bukkit.gameapi.bedwars.island;
/*    */ 
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.Color;
/*    */ 
/*    */ public enum IslandColor {
/*    */   IslandColor(ChatColor color, int woolId) {
/*    */     this.color = color;
/*    */     this.woolId = woolId;
/*    */   }
/*    */   
/*    */   private ChatColor color;
/* 13 */   WHITE(ChatColor.WHITE, 0), RED(ChatColor.RED, 14), PINK(ChatColor.LIGHT_PURPLE, 6), CYAN(ChatColor.AQUA, 3),
/* 14 */   YELLOW(ChatColor.YELLOW, 4), GREEN(ChatColor.GREEN, 5), BLUE(ChatColor.BLUE, 11), GRAY(ChatColor.DARK_GRAY, 8),
/* 15 */   ORANGE(ChatColor.GOLD, 1); private int woolId;
/*    */   public ChatColor getColor() {
/* 17 */     return this.color; } public int getWoolId() {
/* 18 */     return this.woolId;
/*    */   }
/*    */   public Color getColorEquivalent() {
/* 21 */     switch (this.color) {
/*    */       case AQUA:
/* 23 */         return Color.AQUA;
/*    */       case BLACK:
/* 25 */         return Color.BLACK;
/*    */       case BLUE:
/* 27 */         return Color.BLUE;
/*    */       case DARK_AQUA:
/* 29 */         return Color.BLUE;
/*    */       case DARK_BLUE:
/* 31 */         return Color.BLUE;
/*    */       case DARK_GRAY:
/* 33 */         return Color.GRAY;
/*    */       case DARK_GREEN:
/* 35 */         return Color.GREEN;
/*    */       case DARK_PURPLE:
/* 37 */         return Color.PURPLE;
/*    */       case DARK_RED:
/* 39 */         return Color.RED;
/*    */       case GOLD:
/* 41 */         return Color.YELLOW;
/*    */       case GRAY:
/* 43 */         return Color.GRAY;
/*    */       case GREEN:
/* 45 */         return Color.GREEN;
/*    */       case LIGHT_PURPLE:
/* 47 */         return Color.PURPLE;
/*    */       case RED:
/* 49 */         return Color.RED;
/*    */       case WHITE:
/* 51 */         return Color.WHITE;
/*    */       case YELLOW:
/* 53 */         return Color.YELLOW;
/*    */     } 
/* 55 */     return null;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/island/IslandColor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */