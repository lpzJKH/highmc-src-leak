package net.highmc.bukkit.gameapi.bedwars.menu;

import net.highmc.bukkit.gameapi.bedwars.store.ShopCategory;
import org.bukkit.entity.Player;

public class FavoriteConfigInventory {
  public FavoriteConfigInventory(Player player, ShopCategory storeCategory, int index, ShopCategory.ShopItem shopItem) {}
}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/menu/FavoriteConfigInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */