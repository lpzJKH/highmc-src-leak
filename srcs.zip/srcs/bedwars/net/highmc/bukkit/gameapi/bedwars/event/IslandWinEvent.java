/*    */ package net.highmc.bukkit.gameapi.bedwars.event;
/*    */ 
/*    */ import net.highmc.bukkit.event.NormalEvent;
/*    */ import net.highmc.bukkit.gameapi.bedwars.island.Island;
/*    */ 
/*    */ public class IslandWinEvent extends NormalEvent {
/*    */   public IslandWinEvent(Island island) {
/*  8 */     this.island = island;
/*    */   }
/*    */   private Island island;
/*    */   public Island getIsland() {
/* 12 */     return this.island;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/event/IslandWinEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */