/*     */ package net.highmc.bukkit.gameapi.bedwars.generator;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.bukkit.gameapi.bedwars.GameMain;
/*     */ import net.highmc.bukkit.utils.floatingitem.CustomItem;
/*     */ import net.highmc.bukkit.utils.floatingitem.impl.HeadCustomItem;
/*     */ import net.highmc.bukkit.utils.hologram.Hologram;
/*     */ import net.highmc.bukkit.utils.hologram.impl.SimpleHologram;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.utils.string.StringFormat;
/*     */ import net.minecraft.server.v1_8_R3.Packet;
/*     */ import net.minecraft.server.v1_8_R3.PacketPlayOutEntity;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
/*     */ import org.bukkit.entity.Item;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public abstract class Generator
/*     */ {
/*     */   private Location location;
/*     */   private GeneratorType generatorType;
/*     */   
/*     */   public Location getLocation() {
/*  30 */     return this.location; } public GeneratorType getGeneratorType() {
/*  31 */     return this.generatorType;
/*     */   }
/*  33 */   private int level = 1; private long lastGenerate; public int getLevel() { return this.level; } public long getLastGenerate() {
/*  34 */     return this.lastGenerate;
/*  35 */   } private Hologram hologram; private CustomItem customItem; private ItemStack itemStack; private long generateTime = 4000L; private List<Location> dropsLocation; protected int dropIndex; private float yaw; public void setGenerateTime(long generateTime) { this.generateTime = generateTime; } public long getGenerateTime() {
/*  36 */     return this.generateTime;
/*     */   }
/*  38 */   public Hologram getHologram() { return this.hologram; } public CustomItem getCustomItem() {
/*  39 */     return this.customItem;
/*     */   } public ItemStack getItemStack() {
/*  41 */     return this.itemStack;
/*     */   }
/*  43 */   public List<Location> getDropsLocation() { return this.dropsLocation; } public int getDropIndex() {
/*  44 */     return this.dropIndex;
/*     */   } public float getYaw() {
/*  46 */     return this.yaw;
/*     */   }
/*     */   public Generator(Location location, GeneratorType generatorType, ItemStack itemStack) {
/*  49 */     this.location = location.getBlock().getLocation().add(0.5D, 0.5D, 0.5D);
/*  50 */     this.generatorType = generatorType;
/*  51 */     this.itemStack = itemStack;
/*  52 */     this.generateTime = ((generatorType.getTimer() - 1) * 1000);
/*  53 */     this.dropsLocation = findBlocks();
/*     */   }
/*     */   
/*     */   public Location getDropLocation() {
/*  57 */     return this.location;
/*     */   }
/*     */   
/*     */   public void animate() {
/*  61 */     if (this.customItem instanceof HeadCustomItem) {
/*  62 */       HeadCustomItem headCustomItem = (HeadCustomItem)this.customItem;
/*     */       
/*  64 */       this.yaw = (this.yaw >= 180.0F || this.yaw + 5.0F >= 180.0F) ? -180.0F : (this.yaw + 5.0F);
/*     */ 
/*     */       
/*  67 */       PacketPlayOutEntity.PacketPlayOutEntityLook packetPlayOutEntityLook = new PacketPlayOutEntity.PacketPlayOutEntityLook(headCustomItem.getArmorStand().getEntityId(), (byte)(int)(this.yaw * 256.0F / 360.0F), (byte)0, false);
/*     */       
/*  69 */       for (Player player : Bukkit.getOnlinePlayers())
/*  70 */         (((CraftPlayer)player).getHandle()).playerConnection.sendPacket((Packet)packetPlayOutEntityLook); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Generator handleHologram() {
/*  75 */     if (this.generatorType != GeneratorType.NORMAL) {
/*  76 */       this
/*     */         
/*  78 */         .hologram = (Hologram)new SimpleHologram(this.generatorType.getColor() + "§n§%" + this.generatorType.name().toLowerCase() + "%§ I", this.location.clone().add(0.0D, 1.0D, 0.0D));
/*  79 */       this.hologram.line("§a-/-");
/*  80 */       this.hologram.spawn();
/*  81 */       BukkitCommon.getInstance().getHologramManager().registerHologram(this.hologram);
/*  82 */       this
/*  83 */         .customItem = (new HeadCustomItem(this.location.clone().add(0.0D, 0.7D, 0.0D), (new ItemBuilder()).type(Material.valueOf(getGeneratorType().name() + "_BLOCK")).build())).spawn();
/*     */     } 
/*  85 */     return this;
/*     */   }
/*     */   
/*     */   public void setLocation(Location location) {
/*  89 */     this.location = location;
/*     */     
/*  91 */     if (this.hologram != null) {
/*  92 */       this.hologram.teleport(location.clone().add(0.0D, 1.8D, 0.0D));
/*  93 */       this.customItem.teleport(location.clone().add(0.0D, 1.5D, 0.0D));
/*  94 */       handleHologram();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setLevel(int level) {
/*  99 */     this.level = level;
/*     */     
/* 101 */     if (this.generatorType != GeneratorType.NORMAL && this.hologram != null)
/* 102 */       this.hologram.setDisplayName(this.generatorType.getColor() + "§n§%" + this.generatorType.name().toLowerCase() + "%§ " + 
/* 103 */           StringFormat.formatRomane(level)); 
/*     */   }
/*     */   
/*     */   public void updateHologram() {
/* 107 */     if (this.hologram != null) {
/* 108 */       int seconds = (int)(this.lastGenerate + this.generateTime - System.currentTimeMillis()) / 1000;
/*     */       
/* 110 */       if (this.generatorType != GeneratorType.NORMAL && this.hologram != null) {
/* 111 */         ((Hologram)this.hologram.getLines().stream().findFirst().orElse(null)).setDisplayName("§eGera em §c" + ((seconds < 0) ? 0 : seconds) + "§e.");
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void generate() {
/* 117 */     Location location = getDropLocation();
/* 118 */     int items = 0;
/*     */ 
/*     */     
/* 121 */     for (Item item : location.getWorld().getEntitiesByClass(Item.class).stream().filter(entity -> (entity.getLocation().distance(location) <= 5.0D)).collect(Collectors.toList())) {
/* 122 */       if (item.getItemStack().getType() == this.itemStack.getType()) {
/* 123 */         items += item.getItemStack().getAmount();
/*     */       }
/*     */     } 
/* 126 */     int multiplier = getLevel() - 1;
/*     */     
/* 128 */     switch (this.itemStack.getType()) {
/*     */       case IRON_INGOT:
/* 130 */         if (items >= 48 + multiplier * 16)
/*     */           return; 
/*     */         break;
/*     */       case GOLD_INGOT:
/* 134 */         if (items >= 12 + multiplier * 4)
/*     */           return; 
/*     */         break;
/*     */       case DIAMOND:
/* 138 */         if (items >= 4 + multiplier * 2)
/*     */           return; 
/*     */         break;
/*     */       case EMERALD:
/* 142 */         if (items >= 2 + multiplier * 2) {
/*     */           return;
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 149 */     Item dropItem = location.getWorld().dropItem(location.clone(), this.itemStack);
/* 150 */     dropItem.setVelocity(new Vector(0, 0, 0));
/* 151 */     this.lastGenerate = System.currentTimeMillis();
/*     */   }
/*     */   
/*     */   private List<Location> findBlocks() {
/* 155 */     List<Location> dropsLocation = GameMain.getInstance().getNearestBlocksByMaterial(this.location, Material.STEP, 4, 1);
/*     */     
/* 157 */     if (dropsLocation.isEmpty()) {
/* 158 */       dropsLocation = GameMain.getInstance().getNearestBlocksByMaterial(this.location, Material.IRON_BLOCK, 4, 1);
/*     */     }
/* 160 */     return (List<Location>)dropsLocation.stream()
/* 161 */       .map(location -> location.add(0.5D, (location.getBlock().getType() == Material.STEP) ? 0.5D : 1.25D, 0.5D))
/* 162 */       .collect(Collectors.toList());
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/bedwars/generator/Generator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */