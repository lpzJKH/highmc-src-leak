/*    */ package net.highmc.bukkit.pvp.event;
/*    */ 
/*    */ import net.highmc.bukkit.event.PlayerEvent;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class PlayerSpawnEvent
/*    */   extends PlayerEvent
/*    */ {
/*    */   public PlayerSpawnEvent(Player player) {
/* 10 */     super(player);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/HighPvP.jar!/net/highmc/bukkit/pvp/event/PlayerSpawnEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */