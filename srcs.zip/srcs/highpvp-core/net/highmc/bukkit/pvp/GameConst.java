/*    */ package net.highmc.bukkit.pvp;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ public class GameConst
/*    */ {
/*    */   public static final long COMBATLOG_DELAY = 12000L;
/*    */   public static final String COMBATLOG_METADATA = "combatlog";
/* 11 */   public static final List<String> BLOCKED_COMMANDS = Arrays.asList(new String[] { "spawn" });
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/HighPvP.jar!/net/highmc/bukkit/pvp/GameConst.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */