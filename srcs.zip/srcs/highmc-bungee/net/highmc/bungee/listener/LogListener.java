/*    */ package net.highmc.bungee.listener;
/*    */ 
/*    */ import net.highmc.CommonConst;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.bungee.event.player.PlayerPardonedEvent;
/*    */ import net.highmc.bungee.event.player.PlayerPunishEvent;
/*    */ import net.highmc.command.CommandSender;
/*    */ import net.highmc.member.Member;
/*    */ import net.highmc.punish.Punish;
/*    */ import net.highmc.punish.PunishType;
/*    */ import net.highmc.utils.DateUtils;
/*    */ import net.md_5.bungee.api.plugin.Listener;
/*    */ import net.md_5.bungee.event.EventHandler;
/*    */ 
/*    */ public class LogListener implements Listener {
/*    */   @EventHandler
/*    */   public void onPlayerPunish(PlayerPunishEvent event) {
/* 18 */     Member target = event.getPunished();
/* 19 */     CommandSender sender = event.getSender();
/* 20 */     Punish punish = event.getPunish();
/*    */     
/* 22 */     if (punish.getPunisherId().equals(CommonConst.CONSOLE_ID)) {
/* 23 */       CommonPlugin.getInstance().getMemberManager().getMembers().stream().filter(Member::isStaff)
/* 24 */         .forEach(member -> member.sendMessage("§cO jogador " + target.getName() + " foi " + punish.getPunishType().getDescriminator() + " do servidor por " + punish.getPunishReason() + " pelo CONSOLE."));
/*    */ 
/*    */ 
/*    */       
/*    */       return;
/*    */     } 
/*    */ 
/*    */     
/* 32 */     switch (punish.getPunishType()) {
/*    */       case KICK:
/* 34 */         CommonPlugin.getInstance().getMemberManager().staffLog("§cO jogador " + target.getPlayerName() + " foi kickado do servidor por " + punish
/* 35 */             .getPunishReason() + " pelo " + sender.getName() + ".", false);
/*    */         return;
/*    */     } 
/*    */     
/* 39 */     CommonPlugin.getInstance().getMemberManager().getMembers().stream().forEach(member -> {
/*    */           if (member.isStaff()) {
/*    */             member.sendMessage("§cO jogador " + target.getPlayerName() + " foi " + punish.getPunishType().getDescriminator().toLowerCase() + " " + (punish.isPermanent() ? "permanentemente" : (" temporariamente com duração de " + DateUtils.formatDifference(CommonPlugin.getInstance().getPluginInfo().getDefaultLanguage(), punish.getExpireTime() / 1000L))) + " por " + punish.getPunishReason() + " pelo " + sender.getName() + ".");
/*    */           } else {
/*    */             member.sendMessage("§cO jogador " + target.getName() + " foi banido " + (punish.isPermanent() ? "permanentemente" : "temporariamente") + " do servidor.");
/*    */           } 
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerPardoned(PlayerPardonedEvent event) {
/* 58 */     Member target = event.getPunished();
/* 59 */     CommandSender sender = event.getSender();
/*    */     
/* 61 */     Punish punish = event.getPunish();
/*    */     
/* 63 */     CommonPlugin.getInstance().getMemberManager()
/* 64 */       .staffLog("§eO jogador " + target.getPlayerName() + " foi des" + punish
/* 65 */         .getPunishType().getDescriminator().toLowerCase() + " pelo " + sender.getName() + ".", false);
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/listener/LogListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */