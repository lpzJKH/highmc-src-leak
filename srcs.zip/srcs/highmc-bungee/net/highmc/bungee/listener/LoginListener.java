/*     */ package net.highmc.bungee.listener;
/*     */ 
/*     */ import com.google.common.base.Charsets;
/*     */ import com.google.common.cache.Cache;
/*     */ import com.google.common.cache.CacheBuilder;
/*     */ import com.google.common.cache.CacheLoader;
/*     */ import com.google.common.cache.LoadingCache;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import net.highmc.CommonConst;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bungee.BungeeMain;
/*     */ import net.md_5.bungee.api.event.ClientConnectEvent;
/*     */ import net.md_5.bungee.api.event.PreLoginEvent;
/*     */ import net.md_5.bungee.api.plugin.Listener;
/*     */ import net.md_5.bungee.api.plugin.Plugin;
/*     */ import net.md_5.bungee.event.EventHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoginListener
/*     */   implements Listener
/*     */ {
/*     */   private static final int MAX_CONNECTIONS_PER_IP = 10;
/*     */   private static final int MAX_CONNECTIONS = 25;
/*     */   
/*  37 */   private Cache<String, Integer> loginCache = (Cache<String, Integer>)CacheBuilder.newBuilder().expireAfterWrite(5L, TimeUnit.SECONDS)
/*  38 */     .build(new CacheLoader<String, Integer>()
/*     */       {
/*     */         public Integer load(String name) throws Exception {
/*  41 */           return Integer.valueOf(1);
/*     */         }
/*     */       });
/*  44 */   private LoadingCache<String, Integer> throttleCache = CacheBuilder.newBuilder().expireAfterWrite(5L, TimeUnit.SECONDS)
/*  45 */     .build(new CacheLoader<String, Integer>()
/*     */       {
/*     */         public Integer load(String name) throws Exception {
/*  48 */           return Integer.valueOf(0);
/*     */         }
/*     */       });
/*     */   
/*  52 */   private Map<String, Long> blockMap = new HashMap<>();
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onClient(ClientConnectEvent event) {
/*  57 */     SocketAddress socket = event.getSocketAddress();
/*     */     
/*  59 */     if (!(socket instanceof InetSocketAddress)) {
/*  60 */       event.setCancelled(true);
/*     */       
/*     */       return;
/*     */     } 
/*  64 */     InetSocketAddress inetSocketAddress = (InetSocketAddress)socket;
/*  65 */     String ipAddress = inetSocketAddress.getHostString();
/*     */     
/*  67 */     if (isIpBlocked(ipAddress)) {
/*  68 */       event.setCancelled(true);
/*     */       
/*     */       return;
/*     */     } 
/*  72 */     int throttle = ((Integer)this.throttleCache.getUnchecked(ipAddress)).intValue();
/*     */     
/*  74 */     if (throttle >= 10) {
/*  75 */       event.setCancelled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPreLogin(PreLoginEvent event) {
/*  81 */     SocketAddress socket = event.getConnection().getSocketAddress();
/*     */     
/*  83 */     if (!(socket instanceof InetSocketAddress)) {
/*  84 */       event.setCancelled(true);
/*  85 */       event.setCancelReason("§cWe cannot load your ip address.");
/*     */       
/*     */       return;
/*     */     } 
/*  89 */     String playerName = event.getConnection().getName();
/*  90 */     String ipAddress = ((InetSocketAddress)socket).getHostString();
/*     */     
/*  92 */     int throttle = ((Integer)this.throttleCache.getUnchecked(ipAddress)).intValue();
/*     */     
/*  94 */     if (throttle >= 3) {
/*  95 */       event.setCancelled(true);
/*  96 */       event.setCancelReason("§cAguarde para tentar uma nova conexão.");
/*     */       
/*     */       return;
/*     */     } 
/* 100 */     this.throttleCache.put(ipAddress, Integer.valueOf(throttle + 1));
/* 101 */     int connections = this.throttleCache.asMap().size();
/*     */     
/* 103 */     if (connections >= 25) {
/* 104 */       CommonPlugin.getInstance().debug("The connection of player " + playerName + " (" + ipAddress + ") have been forced to pass as premium because the server reach the maximum connetions per attemps (" + connections + " connections current).");
/*     */ 
/*     */       
/* 107 */       event.getConnection().setOnlineMode(true);
/*     */       
/*     */       return;
/*     */     } 
/* 111 */     if (playerName.toLowerCase().contains("mcstorm")) {
/* 112 */       event.setCancelled(true);
/* 113 */       event.setCancelReason("§cSua conta não foi carregada. [BungeeCord: 02]");
/* 114 */       block(ipAddress, "the name of player contains \"mcstorm\"");
/*     */       
/*     */       return;
/*     */     } 
/* 118 */     if (!CommonConst.NAME_PATTERN.matcher(playerName).matches()) {
/* 119 */       event.setCancelReason("§cSeu nome no jogo é inválido.\n§cPara entrar no servidor utilize um nome com até 16 caracteres, números ou \"_\".");
/*     */       
/* 121 */       event.setCancelled(true);
/*     */       
/*     */       return;
/*     */     } 
/* 125 */     if (this.loginCache.asMap().containsKey(ipAddress)) {
/* 126 */       if (((Integer)this.loginCache.asMap().get(ipAddress)).intValue() >= 10) {
/* 127 */         event.setCancelReason("§cSua conta foi bloqueada por múltiplas conexões simultâneas.");
/* 128 */         event.setCancelled(true);
/* 129 */         this.loginCache.invalidate(ipAddress);
/* 130 */         this.throttleCache.invalidate(ipAddress);
/* 131 */         block(ipAddress, "multiple connections while verifing in mojang");
/*     */         
/*     */         return;
/*     */       } 
/* 135 */       this.loginCache.put(ipAddress, Integer.valueOf(((Integer)this.loginCache.asMap().get(ipAddress)).intValue() + 1));
/*     */     } 
/*     */     
/* 138 */     if (CommonPlugin.getInstance().getPluginInfo().isPiratePlayersEnabled()) {
/* 139 */       event.registerIntent((Plugin)BungeeMain.getInstance());
/*     */       
/* 141 */       CommonPlugin.getInstance().getPluginPlatform().runAsync(() -> {
/*     */             boolean onlineMode = true;
/*     */             
/*     */             if (CommonPlugin.getInstance().getMemberData().isRedisCached(playerName)) {
/*     */               onlineMode = CommonPlugin.getInstance().getMemberData().isConnectionPremium(playerName);
/*     */               
/*     */               CommonPlugin.getInstance().debug("The player " + event.getConnection().getName() + " is " + (onlineMode ? "premium" : "cracked") + " (cached)");
/*     */             } else {
/*     */               boolean save = true;
/*     */               
/*     */               this.loginCache.put(ipAddress, Integer.valueOf(1));
/*     */               
/*     */               UUID uniqueId = CommonPlugin.getInstance().getUuidFetcher().getUniqueId(playerName);
/*     */               
/*     */               if (uniqueId == null) {
/*     */                 onlineMode = false;
/*     */               } else {
/*     */                 CommonPlugin.getInstance().debug("The player " + playerName + " have the UUID " + uniqueId);
/*     */               } 
/*     */               
/*     */               if (save) {
/*     */                 CommonPlugin.getInstance().getMemberData().setConnectionStatus(playerName, (uniqueId == null) ? UUID.nameUUIDFromBytes(("OfflinePlayer:" + playerName).getBytes(Charsets.UTF_8)) : uniqueId, onlineMode);
/*     */               }
/*     */               
/*     */               CommonPlugin.getInstance().debug("The player " + event.getConnection().getName() + " is " + (onlineMode ? "premium" : "cracked") + " (not cached)");
/*     */             } 
/*     */             
/*     */             CommonPlugin.getInstance().debug("The number of " + connections + " connections currently.");
/*     */             
/*     */             event.getConnection().setOnlineMode(onlineMode);
/*     */             
/*     */             event.completeIntent((Plugin)BungeeMain.getInstance());
/*     */             
/*     */             this.throttleCache.invalidate(ipAddress);
/*     */             this.loginCache.invalidate(ipAddress);
/*     */           });
/*     */     } else {
/* 178 */       event.getConnection().setOnlineMode(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isIpBlocked(String hostString) {
/* 183 */     if (this.blockMap.containsKey(hostString)) {
/* 184 */       if (((Long)this.blockMap.get(hostString)).longValue() > System.currentTimeMillis()) {
/* 185 */         return true;
/*     */       }
/* 187 */       this.blockMap.remove(hostString);
/*     */     } 
/*     */     
/* 190 */     return false;
/*     */   }
/*     */   
/*     */   private void block(String ipAddress, String reason) {
/* 194 */     this.blockMap.put(ipAddress, Long.valueOf(System.currentTimeMillis() + 1800000L));
/* 195 */     CommonPlugin.getInstance().debug("The ip " + ipAddress + " has been blocked because " + reason);
/*     */   }
/*     */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/listener/LoginListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */