/*     */ package net.highmc.bungee.listener;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bungee.BungeeMain;
/*     */ import net.highmc.bungee.member.BungeeMember;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.member.party.Party;
/*     */ import net.highmc.member.party.PartyRole;
/*     */ import net.highmc.server.ServerType;
/*     */ import net.highmc.server.loadbalancer.server.ProxiedServer;
/*     */ import net.highmc.utils.string.StringFormat;
/*     */ import net.md_5.bungee.api.Callback;
/*     */ import net.md_5.bungee.api.ProxyServer;
/*     */ import net.md_5.bungee.api.ServerPing;
/*     */ import net.md_5.bungee.api.connection.PendingConnection;
/*     */ import net.md_5.bungee.api.connection.ProxiedPlayer;
/*     */ import net.md_5.bungee.api.event.ProxyPingEvent;
/*     */ import net.md_5.bungee.api.event.SearchServerEvent;
/*     */ import net.md_5.bungee.api.event.ServerConnectEvent;
/*     */ import net.md_5.bungee.api.event.ServerConnectedEvent;
/*     */ import net.md_5.bungee.api.event.ServerKickEvent;
/*     */ import net.md_5.bungee.api.plugin.Listener;
/*     */ import net.md_5.bungee.api.plugin.Plugin;
/*     */ import net.md_5.bungee.event.EventHandler;
/*     */ 
/*     */ public class ServerListener
/*     */   implements Listener
/*     */ {
/*  34 */   private static final String MOTD_HEADER = StringFormat.centerString("§d§l§oHIGH§f§l§oMC §b» §a[1.7 - 1.19]", 127);
/*  35 */   private static final String MOTD_FOOTER = StringFormat.centerString("§6§lNOVIDADES: §evenha conferir!", 127);
/*  36 */   private static final String MAINTENANCE_FOOTER = StringFormat.centerString("§cO servidor está em manutenção.", 127);
/*  37 */   private static final String SERVER_NOT_FOUND = StringFormat.centerString("§cServidor inserido não existe.");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   private Set<UUID> playerUpdateSet = new HashSet<>();
/*     */   
/*     */   @EventHandler
/*     */   public void onSearchServer(SearchServerEvent event) {
/*  51 */     BungeeMember member = (BungeeMember)CommonPlugin.getInstance().getMemberManager().getMember(event.getPlayer().getUniqueId(), BungeeMember.class);
/*     */ 
/*     */     
/*  54 */     member.setProxiedPlayer(event.getPlayer());
/*  55 */     member.loadConfiguration();
/*     */     
/*  57 */     boolean logged = member.getLoginConfiguration().isLogged();
/*  58 */     boolean refreshLogin = logged ? false : member.getLoginConfiguration().reloadSession();
/*     */     
/*  60 */     logged = (logged || refreshLogin);
/*     */ 
/*     */     
/*  63 */     ProxiedServer server = BungeeMain.getInstance().getServerManager().getServer(getServerIp(event.getPlayer().getPendingConnection()));
/*     */     
/*  65 */     if (logged && server != null && server.getServerInfo() != null) {
/*  66 */       event.setServer(server.getServerInfo());
/*     */       
/*     */       return;
/*     */     } 
/*  70 */     if (logged && System.currentTimeMillis() - member.getLastLogin() <= 15000L && member
/*  71 */       .getActualServerId() != null && !member.getActualServerType().name().contains("LOBBY")) {
/*  72 */       server = BungeeMain.getInstance().getServerManager().getServer(member.getActualServerId());
/*     */       
/*  74 */       if (server != null && server.getServerInfo() != null) {
/*  75 */         event.setServer(server.getServerInfo());
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/*  81 */     server = BungeeMain.getInstance().getServerManager().getBalancer(logged ? ServerType.LOBBY : ServerType.LOGIN).getList().stream().findFirst().orElse(null);
/*     */     
/*  83 */     if (server == null || server.getServerInfo() == null) {
/*  84 */       event.setCancelled(true);
/*  85 */       event.setCancelMessage(Language.getLanguage(event.getPlayer().getUniqueId())
/*  86 */           .t(logged ? "server-fallback-not-found" : "login.kick.login-not-available", new String[0]));
/*     */       
/*     */       return;
/*     */     } 
/*  90 */     if (refreshLogin) {
/*  91 */       this.playerUpdateSet.add(member.getUniqueId());
/*     */     }
/*  93 */     event.setServer(server.getServerInfo());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onServerConnect(ServerConnectEvent event) {
/*  98 */     BungeeMember member = (BungeeMember)CommonPlugin.getInstance().getMemberManager().getMember(event.getPlayer().getUniqueId(), BungeeMember.class);
/*     */ 
/*     */     
/* 101 */     if (member == null) {
/* 102 */       event.setCancelled(true);
/* 103 */       event.getPlayer().disconnect("§cHouve um problema com a sua conta!");
/*     */       
/*     */       return;
/*     */     } 
/* 107 */     boolean logged = member.getLoginConfiguration().isLogged();
/*     */     
/* 109 */     if (!logged && BungeeMain.getInstance().getServerManager().getServer(event.getTarget().getName())
/* 110 */       .getServerType() != ServerType.LOGIN) {
/*     */       
/* 112 */       boolean disconnect = (event.getPlayer().getServer() == null || event.getPlayer().getServer().getInfo() == null);
/* 113 */       String message = member.getLanguage().t(disconnect ? "login.kick.not-logged" : "login.message.not-logged", new String[] { "%website%", 
/* 114 */             CommonPlugin.getInstance().getPluginInfo().getWebsite() });
/*     */       
/* 116 */       if (disconnect) {
/* 117 */         event.getPlayer().disconnect(message);
/*     */       } else {
/* 119 */         event.setCancelled(true);
/* 120 */         event.getPlayer().sendMessage(message);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onServerConnected(ServerConnectedEvent event) {
/* 127 */     BungeeMember member = (BungeeMember)CommonPlugin.getInstance().getMemberManager().getMember(event.getPlayer().getUniqueId(), BungeeMember.class);
/*     */ 
/*     */     
/* 130 */     if (member == null) {
/*     */       return;
/*     */     }
/* 133 */     if (this.playerUpdateSet.contains(member.getUniqueId())) {
/* 134 */       ProxyServer.getInstance().getScheduler().schedule((Plugin)BungeeMain.getInstance(), () -> member.saveConfig(), 3L, TimeUnit.SECONDS);
/*     */     }
/*     */ 
/*     */     
/* 138 */     ProxiedServer server = BungeeMain.getInstance().getServerManager().getServer(event.getServer().getInfo().getName());
/*     */     
/* 140 */     if (server.getServerType().isLobby()) {
/*     */       return;
/*     */     }
/* 143 */     Party party = member.getParty();
/*     */     
/* 145 */     if (party != null && party.hasRole(member.getUniqueId(), PartyRole.OWNER)) {
/* 146 */       if (server.getOnlinePlayers() + party.getMembers().size() > server.getMaxPlayers()) {
/* 147 */         member.sendMessage("§eO servidor não suporta todos os membros da sua party, talvez alguns dos jogadores não sejam teletransportados.");
/*     */       }
/*     */       
/* 150 */       party.getMembers().stream()
/* 151 */         .map(id -> (BungeeMember)CommonPlugin.getInstance().getMemberManager().getMember(id, BungeeMember.class))
/* 152 */         .forEach(partyMember -> {
/*     */             if (partyMember != null && !partyMember.getActualServerId().equals(event.getServer().getInfo().getName())) {
/*     */               partyMember.getProxiedPlayer().connect(event.getServer().getInfo());
/*     */             }
/*     */           });
/*     */     } 
/*     */ 
/*     */     
/* 160 */     member.handleCheckGroup();
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onServerKick(ServerKickEvent event) {
/* 166 */     if (event.getKickReason().toLowerCase().contains("kick") || event
/* 167 */       .getKickReason().toLowerCase().contains("expulso")) {
/*     */       return;
/*     */     }
/*     */     
/* 171 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(event.getPlayer().getUniqueId());
/*     */     
/* 173 */     if (member != null && !member.getLoginConfiguration().isLogged()) {
/*     */       return;
/*     */     }
/* 176 */     ProxiedPlayer player = event.getPlayer();
/*     */     
/* 178 */     ProxiedServer kickedFrom = BungeeMain.getInstance().getServerManager().getServer(event.getKickedFrom().getName());
/*     */ 
/*     */ 
/*     */     
/* 182 */     ProxiedServer server = (kickedFrom == null) ? (ProxiedServer)BungeeMain.getInstance().getServerManager().getBalancer(ServerType.LOBBY).next() : (ProxiedServer)getFirstIfNull(
/* 183 */         BungeeMain.getInstance().getServerManager()
/* 184 */         .getBalancer(kickedFrom.getServerType().getServerLobby()).next(), 
/* 185 */         BungeeMain.getInstance().getServerManager().getBalancer(ServerType.LOBBY).next());
/*     */     
/* 187 */     if (server == null || server.getServerInfo() == null || server == kickedFrom) {
/* 188 */       player.disconnect(event.getKickReasonComponent());
/*     */       
/*     */       return;
/*     */     } 
/* 192 */     event.setCancelled(true);
/* 193 */     event.setCancelServer(server.getServerInfo());
/* 194 */     player.sendMessage(event.getKickReasonComponent());
/*     */   }
/*     */   
/*     */   @EventHandler(priority = 127)
/*     */   public void onProxyPing(final ProxyPingEvent event) {
/* 199 */     final ServerPing serverPing = event.getResponse();
/* 200 */     String serverIp = getServerIp(event.getConnection());
/* 201 */     ProxiedServer server = BungeeMain.getInstance().getServerManager().getServer(serverIp);
/*     */     
/* 203 */     serverPing.getPlayers().setMax(ProxyServer.getInstance().getOnlineCount() + 1);
/* 204 */     serverPing.getPlayers().setOnline(ProxyServer.getInstance().getOnlineCount());
/*     */     
/* 206 */     if (server == null) {
/* 207 */       serverPing.getPlayers().setSample(new ServerPing.PlayerInfo[] { new ServerPing.PlayerInfo("§e" + 
/* 208 */               CommonPlugin.getInstance().getPluginInfo().getWebsite(), 
/* 209 */               UUID.randomUUID()) });
/* 210 */       serverPing.setDescription(MOTD_HEADER + "\n" + (
/* 211 */           BungeeMain.getInstance().isMaintenance() ? MAINTENANCE_FOOTER : MOTD_FOOTER));
/*     */     } else {
/* 213 */       event.registerIntent((Plugin)BungeeMain.getInstance());
/* 214 */       server.getServerInfo().ping(new Callback<ServerPing>()
/*     */           {
/*     */             public void done(ServerPing realPing, Throwable throwable)
/*     */             {
/* 218 */               if (throwable == null) {
/* 219 */                 serverPing.getPlayers().setMax(realPing.getPlayers().getMax());
/* 220 */                 serverPing.getPlayers().setOnline(realPing.getPlayers().getOnline());
/* 221 */                 serverPing.setDescription(realPing.getDescription());
/*     */               } else {
/* 223 */                 serverPing.getPlayers()
/* 224 */                   .setSample(new ServerPing.PlayerInfo[] {
/* 225 */                       new ServerPing.PlayerInfo("§e" + CommonPlugin.getInstance().getPluginInfo().getWebsite(), 
/* 226 */                         UUID.randomUUID()) });
/* 227 */                 serverPing.setDescription(ServerListener.MOTD_HEADER + "\n" + ServerListener.SERVER_NOT_FOUND);
/*     */               } 
/*     */               
/* 230 */               event.completeIntent((Plugin)BungeeMain.getInstance());
/*     */             }
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private String getServerIp(PendingConnection con) {
/* 238 */     if (con == null || con.getVirtualHost() == null) {
/* 239 */       return "";
/*     */     }
/* 241 */     return con.getVirtualHost().getHostName().toLowerCase();
/*     */   }
/*     */   
/*     */   public <T> T getFirstIfNull(T first, T second) {
/* 245 */     return (second == null) ? first : second;
/*     */   }
/*     */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/listener/ServerListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */