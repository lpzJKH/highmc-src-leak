/*     */ package net.highmc.bungee.listener;
/*     */ 
/*     */ import com.google.common.io.ByteArrayDataInput;
/*     */ import com.google.common.io.ByteStreams;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParser;
/*     */ import com.google.gson.reflect.TypeToken;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.UUID;
/*     */ import java.util.logging.Level;
/*     */ import net.highmc.CommonConst;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.backend.data.DataServerMessage;
/*     */ import net.highmc.bungee.BungeeMain;
/*     */ import net.highmc.bungee.command.BungeeCommandSender;
/*     */ import net.highmc.bungee.event.RedisMessageEvent;
/*     */ import net.highmc.bungee.event.ServerUpdateEvent;
/*     */ import net.highmc.bungee.event.packet.PacketReceiveEvent;
/*     */ import net.highmc.bungee.event.player.PlayerFieldUpdateEvent;
/*     */ import net.highmc.bungee.event.player.PlayerPunishEvent;
/*     */ import net.highmc.bungee.member.BungeeMember;
/*     */ import net.highmc.command.CommandSender;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.packet.Packet;
/*     */ import net.highmc.packet.PacketType;
/*     */ import net.highmc.packet.types.PunishPlayerPacket;
/*     */ import net.highmc.packet.types.skin.SkinChange;
/*     */ import net.highmc.packet.types.staff.TeleportToTarget;
/*     */ import net.highmc.punish.Punish;
/*     */ import net.highmc.server.ServerType;
/*     */ import net.highmc.server.loadbalancer.server.MinigameServer;
/*     */ import net.highmc.server.loadbalancer.server.MinigameState;
/*     */ import net.highmc.server.loadbalancer.server.ProxiedServer;
/*     */ import net.highmc.utils.reflection.Reflection;
/*     */ import net.md_5.bungee.BungeeCord;
/*     */ import net.md_5.bungee.api.CommandSender;
/*     */ import net.md_5.bungee.api.ProxyServer;
/*     */ import net.md_5.bungee.api.connection.ProxiedPlayer;
/*     */ import net.md_5.bungee.api.event.PlayerDisconnectEvent;
/*     */ import net.md_5.bungee.api.event.PluginMessageEvent;
/*     */ import net.md_5.bungee.api.event.PostLoginEvent;
/*     */ import net.md_5.bungee.api.plugin.Event;
/*     */ import net.md_5.bungee.api.plugin.Listener;
/*     */ import net.md_5.bungee.event.EventHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataListener
/*     */   implements Listener
/*     */ {
/*     */   @EventHandler(priority = -128)
/*     */   public void onPluginMessage(PluginMessageEvent event) {
/*     */     String serverId, server;
/*     */     boolean silent;
/*     */     ProxiedServer proxiedServer;
/*  58 */     if (!event.getTag().equals("BungeeCord") || !(event.getSender() instanceof net.md_5.bungee.api.connection.Server) || 
/*  59 */       !(event.getReceiver() instanceof ProxiedPlayer)) {
/*     */       return;
/*     */     }
/*  62 */     ProxiedPlayer proxiedPlayer = (ProxiedPlayer)event.getReceiver();
/*  63 */     Member player = CommonPlugin.getInstance().getMemberManager().getMember(proxiedPlayer.getUniqueId());
/*  64 */     ByteArrayDataInput in = ByteStreams.newDataInput(event.getData());
/*  65 */     String subChannel = in.readUTF();
/*     */     
/*  67 */     switch (subChannel) {
/*     */       case "BungeeCommand":
/*  69 */         ProxyServer.getInstance().getPluginManager().dispatchCommand((CommandSender)proxiedPlayer, in.readUTF());
/*     */         break;
/*     */       
/*     */       case "PlayerConnect":
/*  73 */         serverId = in.readUTF();
/*  74 */         silent = in.readBoolean();
/*  75 */         proxiedServer = BungeeMain.getInstance().getServerManager().getServer(serverId);
/*     */         
/*  77 */         if (proxiedServer == null || proxiedServer.getServerInfo() == null) {
/*  78 */           if (!silent) {
/*  79 */             player.sendMessage(player.getLanguage().t("server-not-found", new String[] { "%server%", serverId }));
/*     */           }
/*     */           return;
/*     */         } 
/*  83 */         proxiedPlayer.connect(proxiedServer.getServerInfo());
/*     */         break;
/*     */       
/*     */       case "SearchServer":
/*  87 */         server = in.readUTF();
/*  88 */         silent = in.readBoolean();
/*     */         
/*  90 */         (new String[1])[0] = server; for (String s : server.contains("-") ? server.split("-") : new String[1]) {
/*     */           try {
/*  92 */             ServerType serverType = ServerType.valueOf(s);
/*     */             
/*  94 */             if (searchServer(player, proxiedPlayer, serverType, silent))
/*     */               return; 
/*  96 */           } catch (Exception exception) {}
/*     */         } 
/*     */ 
/*     */         
/* 100 */         if (!silent) {
/* 101 */           player.sendMessage(player.getLanguage().t("server.search-server.not-found", new String[0]));
/*     */         }
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean searchServer(Member player, ProxiedPlayer proxiedPlayer, ServerType serverType, boolean silent) {
/* 111 */     ProxiedServer server = (ProxiedServer)BungeeMain.getInstance().getServerManager().getBalancer(serverType).next();
/*     */     
/* 113 */     if (server == null || server.getServerInfo() == null) {
/* 114 */       return false;
/*     */     }
/*     */     
/* 117 */     if (server.isFull() && !player.hasPermission("server.full")) {
/* 118 */       if (!silent)
/* 119 */         proxiedPlayer.sendMessage(player.getLanguage().t("server-is-full", new String[0])); 
/* 120 */       return true;
/*     */     } 
/*     */     
/* 123 */     if (!server.canBeSelected() && !player.hasPermission("command.admin")) {
/* 124 */       if (!silent)
/* 125 */         proxiedPlayer.sendMessage(player.getLanguage().t("server-not-available", new String[0])); 
/* 126 */       return true;
/*     */     } 
/*     */     
/* 129 */     proxiedPlayer.connect(server.getServerInfo());
/* 130 */     return true;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPostLogin(PostLoginEvent event) {
/* 135 */     CommonPlugin.getInstance().getServerData().setTotalMembers(BungeeCord.getInstance().getOnlineCount());
/* 136 */     BungeeMain.getInstance().setPlayersRecord(
/* 137 */         Math.max(BungeeCord.getInstance().getOnlineCount(), BungeeMain.getInstance().getPlayersRecord()));
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerDisconnect(PlayerDisconnectEvent event) {
/* 142 */     CommonPlugin.getInstance().getServerData().setTotalMembers(BungeeCord.getInstance().getOnlineCount() - 1);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onRedisMessage(RedisMessageEvent event) {
/* 147 */     String message = event.getMessage();
/*     */     
/*     */     try {
/* 150 */       if (message.startsWith("{") && message.endsWith("}")) {
/* 151 */         handleMessageGson(event.getChannel(), JsonParser.parseString(message).getAsJsonObject());
/*     */         return;
/*     */       } 
/* 154 */     } catch (Exception ex) {
/* 155 */       CommonPlugin.getInstance().getLogger().log(Level.WARNING, "An error occured when reading json packet in redis!\n" + message, ex);
/*     */       
/* 157 */       System.out.println(ex.getLocalizedMessage());
/*     */     }  } @EventHandler public void onPacketReceive(PacketReceiveEvent event) { TeleportToTarget teleportToTarget; SkinChange skinChange; PunishPlayerPacket punishPlayer;
/*     */     ProxiedPlayer player;
/*     */     Member member;
/*     */     ProxiedPlayer target;
/*     */     Punish punish;
/* 163 */     switch (event.getPacketType()) {
/*     */       case JOIN:
/* 165 */         teleportToTarget = (TeleportToTarget)event.getPacket();
/*     */         
/* 167 */         player = ProxyServer.getInstance().getPlayer(teleportToTarget.getPlayerId());
/*     */         
/* 169 */         if (player == null) {
/*     */           return;
/*     */         }
/* 172 */         target = ProxyServer.getInstance().getPlayer(teleportToTarget.getTargetId());
/*     */         
/* 174 */         if (target == null) {
/* 175 */           player.sendMessage("§cO jogador " + teleportToTarget.getTargetName() + " não foi encontrado.");
/*     */           
/*     */           return;
/*     */         } 
/* 179 */         BungeeMain.getInstance().teleport(player, target);
/*     */         break;
/*     */       
/*     */       case LEAVE:
/* 183 */         skinChange = (SkinChange)event.getPacket();
/* 184 */         player = ProxyServer.getInstance().getPlayer(skinChange.getPlayerId());
/*     */         
/* 186 */         if (player == null) {
/*     */           return;
/*     */         }
/* 189 */         BungeeMain.getInstance().loadTexture(player.getPendingConnection(), skinChange.getSkin());
/*     */         break;
/*     */       
/*     */       case JOIN_ENABLE:
/* 193 */         punishPlayer = (PunishPlayerPacket)event.getPacket();
/* 194 */         member = CommonPlugin.getInstance().getMemberManager().getMember(punishPlayer.getPlayerId());
/* 195 */         punish = punishPlayer.getPunish();
/*     */         
/* 197 */         if (member == null) {
/* 198 */           member = CommonPlugin.getInstance().getMemberData().loadMember(punishPlayer.getPlayerId());
/*     */         }
/* 200 */         ProxyServer.getInstance().getPluginManager().callEvent((Event)new PlayerPunishEvent(member, punishPlayer.getPunish(), CommonConst.CONSOLE_ID.equals(punish.getPunisherId()) ? (CommandSender)new BungeeCommandSender(ProxyServer.getInstance().getConsole()) : 
/* 201 */               (CommandSender)CommonPlugin.getInstance().getMemberManager().getMember(punish.getPunisherId()))); break;
/*     */     }  } void handleMessageGson(String channel, JsonObject jsonObject) { PacketType packetType; UUID uuid; String source; Packet packet; ProxiedPlayer p; ServerType sourceType; Member player; DataServerMessage.Action action;
/*     */     DataServerMessage<DataServerMessage.JoinPayload> dataServerMessage4;
/*     */     DataServerMessage<DataServerMessage.LeavePayload> dataServerMessage3;
/*     */     DataServerMessage<DataServerMessage.JoinEnablePayload> dataServerMessage2;
/*     */     DataServerMessage<DataServerMessage.StartPayload> dataServerMessage1;
/*     */     DataServerMessage<DataServerMessage.StopPayload> dataServerMessage;
/*     */     DataServerMessage<DataServerMessage.UpdatePayload> payload;
/*     */     ProxiedServer server;
/* 210 */     if (CommonPlugin.getInstance().getPluginInfo().isRedisDebugEnabled()) {
/* 211 */       CommonPlugin.getInstance().debug("Redis message from channel " + channel + ": " + jsonObject);
/*     */     }
/* 213 */     switch (channel) {
/*     */       case "server_packet":
/* 215 */         packetType = PacketType.valueOf(jsonObject.get("packetType").getAsString());
/* 216 */         packet = (Packet)CommonConst.GSON.fromJson((JsonElement)jsonObject, packetType.getClassType());
/*     */         
/* 218 */         if (!packet.isExclusiveServers() || (packet.isExclusiveServers() && packet
/* 219 */           .getServerList().contains(CommonPlugin.getInstance().getServerId()))) {
/* 220 */           packet.receive();
/* 221 */           ProxyServer.getInstance().getPluginManager().callEvent((Event)new PacketReceiveEvent(packet));
/*     */         } 
/*     */         break;
/*     */       
/*     */       case "member_field":
/* 226 */         uuid = UUID.fromString(jsonObject.getAsJsonPrimitive("uniqueId").getAsString());
/* 227 */         p = ProxyServer.getInstance().getPlayer(uuid);
/*     */         
/* 229 */         if (p == null) {
/*     */           return;
/*     */         }
/* 232 */         player = CommonPlugin.getInstance().getMemberManager().getMember(uuid);
/*     */         
/* 234 */         if (player == null) {
/*     */           return;
/*     */         }
/*     */         try {
/* 238 */           Field f = Reflection.getField(Member.class, jsonObject.get("field").getAsString());
/* 239 */           Object object = CommonConst.GSON.fromJson(jsonObject.get("value"), f.getGenericType());
/* 240 */           f.setAccessible(true);
/* 241 */           f.set(player, object);
/* 242 */           ProxyServer.getInstance().getPluginManager().callEvent((Event)new PlayerFieldUpdateEvent((BungeeMember)player, jsonObject
/* 243 */                 .get("field").getAsString()));
/* 244 */         } catch (SecurityException|IllegalArgumentException|IllegalAccessException e) {
/* 245 */           e.printStackTrace();
/*     */         } 
/*     */         
/* 248 */         if (jsonObject.get("field").getAsString().toLowerCase().contains("configuration")) {
/*     */           try {
/* 250 */             Field field = Member.class.getDeclaredField(jsonObject.get("field").getAsString());
/* 251 */             field.setAccessible(true);
/* 252 */             Object object = field.get(player);
/*     */             
/* 254 */             Field memberField = object.getClass().getDeclaredField("member");
/* 255 */             memberField.setAccessible(true);
/* 256 */             memberField.set(field.get(player), player);
/* 257 */           } catch (Exception ex) {
/* 258 */             ex.printStackTrace();
/*     */           } 
/*     */         }
/*     */         break;
/*     */       
/*     */       case "server_info":
/* 264 */         source = jsonObject.get("source").getAsString();
/*     */         
/* 266 */         sourceType = ServerType.valueOf(jsonObject.get("serverType").getAsString());
/* 267 */         action = DataServerMessage.Action.valueOf(jsonObject.get("action").getAsString());
/*     */         
/* 269 */         if (sourceType == ServerType.BUNGEECORD) {
/*     */           break;
/*     */         }
/* 272 */         switch (action) {
/*     */           case JOIN:
/* 274 */             dataServerMessage4 = (DataServerMessage<DataServerMessage.JoinPayload>)CommonConst.GSON.fromJson((JsonElement)jsonObject, (new TypeToken<DataServerMessage<DataServerMessage.JoinPayload>>() {
/*     */                 
/* 276 */                 }).getType());
/* 277 */             server = BungeeMain.getInstance().getServerManager().getServer(source);
/*     */             
/* 279 */             if (server == null) {
/*     */               return;
/*     */             }
/* 282 */             server.joinPlayer(((DataServerMessage.JoinPayload)dataServerMessage4.getPayload()).getUniqueId());
/* 283 */             server.setMaxPlayers(((DataServerMessage.JoinPayload)dataServerMessage4.getPayload()).getMaxPlayers());
/*     */             break;
/*     */           
/*     */           case LEAVE:
/* 287 */             dataServerMessage3 = (DataServerMessage<DataServerMessage.LeavePayload>)CommonConst.GSON.fromJson((JsonElement)jsonObject, (new TypeToken<DataServerMessage<DataServerMessage.LeavePayload>>() {
/*     */                 
/* 289 */                 }).getType());
/* 290 */             server = BungeeMain.getInstance().getServerManager().getServer(source);
/*     */             
/* 292 */             if (server == null) {
/*     */               return;
/*     */             }
/* 295 */             server.leavePlayer(((DataServerMessage.LeavePayload)dataServerMessage3.getPayload()).getUniqueId());
/* 296 */             server.setMaxPlayers(((DataServerMessage.LeavePayload)dataServerMessage3.getPayload()).getMaxPlayers());
/*     */             break;
/*     */           
/*     */           case JOIN_ENABLE:
/* 300 */             dataServerMessage2 = (DataServerMessage<DataServerMessage.JoinEnablePayload>)CommonConst.GSON.fromJson((JsonElement)jsonObject, (new TypeToken<DataServerMessage<DataServerMessage.JoinEnablePayload>>() {
/*     */                 
/* 302 */                 }).getType());
/* 303 */             server = BungeeMain.getInstance().getServerManager().getServer(source);
/*     */             
/* 305 */             if (server == null) {
/*     */               return;
/*     */             }
/* 308 */             server.setJoinEnabled(((DataServerMessage.JoinEnablePayload)dataServerMessage2.getPayload()).isEnable());
/*     */             break;
/*     */           
/*     */           case START:
/* 312 */             dataServerMessage1 = (DataServerMessage<DataServerMessage.StartPayload>)CommonConst.GSON.fromJson((JsonElement)jsonObject, (new TypeToken<DataServerMessage<DataServerMessage.StartPayload>>() {
/*     */                 
/* 314 */                 }).getType());
/* 315 */             BungeeMain.getInstance().getServerManager().addActiveServer(((DataServerMessage.StartPayload)dataServerMessage1.getPayload()).getServerAddress(), ((DataServerMessage.StartPayload)dataServerMessage1
/* 316 */                 .getPayload()).getServer().getServerId(), sourceType, ((DataServerMessage.StartPayload)dataServerMessage1
/* 317 */                 .getPayload()).getServer().getMaxPlayers(), ((DataServerMessage.StartPayload)dataServerMessage1.getPayload()).getStartTime());
/*     */             break;
/*     */           
/*     */           case STOP:
/* 321 */             dataServerMessage = (DataServerMessage<DataServerMessage.StopPayload>)CommonConst.GSON.fromJson((JsonElement)jsonObject, (new TypeToken<DataServerMessage<DataServerMessage.StopPayload>>() {
/*     */                 
/* 323 */                 }).getType());
/*     */             
/* 325 */             if (sourceType != ServerType.BUNGEECORD) {
/* 326 */               BungeeMain.getInstance().getServerManager().removeActiveServer(((DataServerMessage.StopPayload)dataServerMessage.getPayload()).getServerId());
/*     */             }
/*     */             break;
/*     */           case UPDATE:
/* 330 */             payload = (DataServerMessage<DataServerMessage.UpdatePayload>)CommonConst.GSON.fromJson((JsonElement)jsonObject, (new TypeToken<DataServerMessage<DataServerMessage.UpdatePayload>>() {
/*     */                 
/* 332 */                 }).getType());
/* 333 */             server = BungeeMain.getInstance().getServerManager().getServer(source);
/*     */             
/* 335 */             if (server == null) {
/*     */               return;
/*     */             }
/* 338 */             if (server instanceof MinigameServer) {
/* 339 */               MinigameServer minigame = (MinigameServer)server;
/*     */               
/* 341 */               MinigameState lastState = minigame.getState();
/*     */               
/* 343 */               minigame.setState(((DataServerMessage.UpdatePayload)payload.getPayload()).getState());
/* 344 */               minigame.setTime(((DataServerMessage.UpdatePayload)payload.getPayload()).getTime());
/* 345 */               minigame.setMap(((DataServerMessage.UpdatePayload)payload.getPayload()).getMap());
/*     */               
/* 347 */               ProxyServer.getInstance().getPluginManager()
/* 348 */                 .callEvent((Event)new ServerUpdateEvent((ProxiedServer)minigame, ((DataServerMessage.UpdatePayload)payload.getPayload()).getMap(), ((DataServerMessage.UpdatePayload)payload
/* 349 */                     .getPayload()).getTime(), lastState, ((DataServerMessage.UpdatePayload)payload.getPayload()).getState()));
/*     */             } 
/*     */             break;
/*     */         } 
/*     */         break;
/*     */     }  }
/*     */ 
/*     */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/listener/DataListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */