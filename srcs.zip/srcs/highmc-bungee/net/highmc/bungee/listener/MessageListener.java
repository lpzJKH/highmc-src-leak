/*     */ package net.highmc.bungee.listener;
/*     */ import java.util.Arrays;
/*     */ import java.util.UUID;
/*     */ import net.highmc.CommonConst;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bungee.BungeeMain;
/*     */ import net.highmc.bungee.event.player.PlayerCommandEvent;
/*     */ import net.highmc.command.CommandSender;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.packet.Packet;
/*     */ import net.highmc.packet.types.StaffchatDiscordPacket;
/*     */ import net.highmc.punish.Punish;
/*     */ import net.highmc.punish.PunishType;
/*     */ import net.highmc.utils.DateUtils;
/*     */ import net.highmc.utils.mojang.UUIDParser;
/*     */ import net.highmc.utils.string.MessageBuilder;
/*     */ import net.md_5.bungee.api.ChatColor;
/*     */ import net.md_5.bungee.api.ProxyServer;
/*     */ import net.md_5.bungee.api.chat.BaseComponent;
/*     */ import net.md_5.bungee.api.connection.ProxiedPlayer;
/*     */ import net.md_5.bungee.api.event.ChatEvent;
/*     */ import net.md_5.bungee.api.plugin.Event;
/*     */ import net.md_5.bungee.api.plugin.Listener;
/*     */ import net.md_5.bungee.event.EventHandler;
/*     */ 
/*     */ public class MessageListener implements Listener {
/*     */   @EventHandler(priority = 127)
/*     */   public void onChatTeleport(ChatEvent event) {
/*  29 */     if (!(event.getSender() instanceof ProxiedPlayer)) {
/*     */       return;
/*     */     }
/*  32 */     if (event.isCancelled()) {
/*     */       return;
/*     */     }
/*  35 */     ProxiedPlayer proxiedPlayer = (ProxiedPlayer)event.getSender();
/*  36 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(proxiedPlayer.getUniqueId());
/*     */     
/*  38 */     if (member == null) {
/*  39 */       event.setCancelled(true);
/*  40 */       proxiedPlayer.disconnect("§cSua conta não foi carregada. [BungeeCord: 01]");
/*     */       
/*     */       return;
/*     */     } 
/*  44 */     boolean isCommand = event.isCommand();
/*  45 */     String message = event.getMessage();
/*     */     
/*  47 */     String[] split = message.trim().split(" ");
/*  48 */     String[] args = Arrays.<String>copyOfRange(split, isCommand ? 1 : 0, split.length);
/*  49 */     String command = split[0].replace("/", "").toLowerCase();
/*     */     
/*  51 */     if (isCommand) {
/*     */       
/*  53 */       PlayerCommandEvent callEvent = (PlayerCommandEvent)ProxyServer.getInstance().getPluginManager().callEvent((Event)new PlayerCommandEvent(proxiedPlayer, command, args));
/*  54 */       event.setCancelled(callEvent.isCancelled());
/*     */       
/*     */       return;
/*     */     } 
/*  58 */     if (member.getMemberConfiguration().isStaffChat()) {
/*     */       
/*  60 */       if (!member.getMemberConfiguration().isSeeingStaffChat()) {
/*  61 */         event.setCancelled(true);
/*  62 */         member.sendMessage("§cAtiva a visualização do staffchat para poder falar no staffchat.");
/*     */         
/*     */         return;
/*     */       } 
/*  66 */       String staffMessage = getStaffchatMessage(member, ChatColor.translateAlternateColorCodes('&', message));
/*     */       
/*  68 */       CommonPlugin.getInstance().getMemberManager().getMembers().stream().filter(m -> (m.isStaff() && m.getMemberConfiguration().isSeeingStaffChat()))
/*  69 */         .forEach(m -> m.sendMessage(staffMessage));
/*     */       
/*  71 */       CommonPlugin.getInstance().getServerData()
/*  72 */         .sendPacket((Packet)new StaffchatDiscordPacket(member.getUniqueId(), member.getServerGroup(), message));
/*  73 */       event.setCancelled(true);
/*     */       
/*     */       return;
/*     */     } 
/*  77 */     if (event.getMessage().length() > 1) {
/*  78 */       if (event.getMessage().startsWith("%") && member.hasPermission("command.staffchat")) {
/*  79 */         if (!member.getMemberConfiguration().isSeeingStaffChat()) {
/*  80 */           event.setCancelled(true);
/*  81 */           member.sendMessage("§cAtiva a visualização do staffchat para poder falar no staffchat.");
/*     */           
/*     */           return;
/*     */         } 
/*  85 */         String staffMessage = getStaffchatMessage(member, event.getMessage().substring(1));
/*     */         
/*  87 */         CommonPlugin.getInstance().getMemberManager().getMembers().stream().filter(m -> (m.isStaff() && m.getMemberConfiguration().isSeeingStaffChat()))
/*  88 */           .forEach(m -> m.sendMessage(staffMessage));
/*     */         
/*  90 */         CommonPlugin.getInstance().getServerData()
/*  91 */           .sendPacket((Packet)new StaffchatDiscordPacket(member.getUniqueId(), member.getServerGroup(), message));
/*  92 */         event.setCancelled(true);
/*  93 */       } else if (event.getMessage().startsWith("@") && member.getParty() != null) {
/*  94 */         Punish punish = member.getPunishConfiguration().getActualPunish(PunishType.MUTE);
/*     */         
/*  96 */         if (punish != null) {
/*  97 */           member.sendMessage((BaseComponent)(new MessageBuilder(punish.getMuteMessage(member.getLanguage())))
/*  98 */               .setHoverEvent("§fPunido em: §7" + CommonConst.DATE_FORMAT
/*  99 */                 .format(Long.valueOf(punish.getCreatedAt())) + "\n§fExpire em: §7" + (
/*     */                 
/* 101 */                 punish.isPermanent() ? "§cnunca" : 
/* 102 */                 DateUtils.getTime(member.getLanguage(), punish.getExpireAt())))
/* 103 */               .create());
/* 104 */           event.setCancelled(true);
/*     */           
/*     */           return;
/*     */         } 
/* 108 */         member.getParty().chat((CommandSender)member, event.getMessage().substring(1));
/* 109 */         event.setCancelled(true);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private String getStaffchatMessage(Member member, String message) {
/* 115 */     return "§e[STAFF] " + 
/* 116 */       CommonPlugin.getInstance().getPluginInfo().getTagByGroup(member.getServerGroup())
/* 117 */       .getStrippedColor() + " " + member
/* 118 */       .getPlayerName() + "§7: §f" + 
/* 119 */       ChatColor.translateAlternateColorCodes('&', message);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerCommand(PlayerCommandEvent event) {
/* 124 */     ProxiedPlayer player = event.getPlayer();
/* 125 */     String label = event.getCommand();
/* 126 */     String[] args = event.getArgs();
/*     */     
/* 128 */     if (label.startsWith("teleport") || label.startsWith("tp")) {
/* 129 */       if (args.length == 1) {
/* 130 */         UUID uniqueId = UUIDParser.parse(args[0]);
/*     */         
/* 132 */         ProxiedPlayer target = (uniqueId == null) ? ProxyServer.getInstance().getPlayer(args[0]) : ProxyServer.getInstance().getPlayer(uniqueId);
/*     */         
/* 134 */         if (target == null || target.getServer() == null || target.getServer().getInfo() == null || target
/* 135 */           .getServer().getInfo().getName().equals(player.getServer().getInfo().getName())) {
/*     */           return;
/*     */         }
/* 138 */         event.setCancelled(true);
/* 139 */         BungeeMain.getInstance().teleport(player, target);
/*     */         return;
/*     */       } 
/*     */     } else {
/* 143 */       Member member = CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId());
/*     */       
/* 145 */       if (!member.getLoginConfiguration().isLogged() && 
/* 146 */         !CommonConst.ALLOWED_COMMAND_LOGIN.contains(label)) {
/* 147 */         event.setCancelled(true);
/* 148 */         player.sendMessage(member.getLanguage().t("login.message.not-allowed", new String[0]));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/listener/MessageListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */