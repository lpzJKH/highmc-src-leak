/*     */ package net.highmc.bungee.listener;
/*     */ 
/*     */ import com.google.common.cache.Cache;
/*     */ import com.google.common.cache.CacheBuilder;
/*     */ import com.google.common.cache.CacheLoader;
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import com.google.common.collect.UnmodifiableIterator;
/*     */ import java.lang.reflect.Field;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.logging.Level;
/*     */ import net.highmc.CommonConst;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.PluginInfo;
/*     */ import net.highmc.bungee.BungeeConst;
/*     */ import net.highmc.bungee.BungeeMain;
/*     */ import net.highmc.bungee.event.player.PlayerFieldUpdateEvent;
/*     */ import net.highmc.bungee.event.player.PlayerPardonedEvent;
/*     */ import net.highmc.bungee.event.player.PlayerPunishEvent;
/*     */ import net.highmc.bungee.member.BungeeMember;
/*     */ import net.highmc.command.CommandSender;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.member.configuration.LoginConfiguration;
/*     */ import net.highmc.member.party.Party;
/*     */ import net.highmc.permission.Group;
/*     */ import net.highmc.punish.Punish;
/*     */ import net.highmc.punish.PunishType;
/*     */ import net.highmc.report.Report;
/*     */ import net.highmc.utils.DateUtils;
/*     */ import net.highmc.utils.skin.Skin;
/*     */ import net.md_5.bungee.api.CommandSender;
/*     */ import net.md_5.bungee.api.ProxyServer;
/*     */ import net.md_5.bungee.api.connection.ProxiedPlayer;
/*     */ import net.md_5.bungee.api.event.LoginEvent;
/*     */ import net.md_5.bungee.api.event.PermissionCheckEvent;
/*     */ import net.md_5.bungee.api.event.PlayerDisconnectEvent;
/*     */ import net.md_5.bungee.api.event.PostLoginEvent;
/*     */ import net.md_5.bungee.api.plugin.Event;
/*     */ import net.md_5.bungee.api.plugin.Listener;
/*     */ import net.md_5.bungee.api.plugin.Plugin;
/*     */ import net.md_5.bungee.connection.InitialHandler;
/*     */ import net.md_5.bungee.connection.LoginResult;
/*     */ import net.md_5.bungee.event.EventHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MemberListener
/*     */   implements Listener
/*     */ {
/*  53 */   private Cache<String, Punish> banCache = (Cache<String, Punish>)CacheBuilder.newBuilder().expireAfterWrite(30L, TimeUnit.MINUTES)
/*  54 */     .expireAfterAccess(30L, TimeUnit.MINUTES)
/*  55 */     .build(new CacheLoader<String, Punish>()
/*     */       {
/*     */         public Punish load(String name) throws Exception {
/*  58 */           return null;
/*     */         }
/*     */       });
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onLogin(LoginEvent event) {
/*  65 */     event.registerIntent((Plugin)BungeeMain.getInstance());
/*  66 */     CommonPlugin.getInstance().getPluginPlatform().runAsync(() -> {
/*     */           handleMemberLoad(event);
/*     */           event.completeIntent((Plugin)BungeeMain.getInstance());
/*     */         });
/*     */   }
/*     */   
/*     */   private void handleMemberLoad(LoginEvent event) {
/*  73 */     String playerName = event.getConnection().getName();
/*  74 */     UUID uniqueId = event.getConnection().getUniqueId();
/*     */     
/*  76 */     BungeeMember member = (BungeeMember)CommonPlugin.getInstance().getMemberData().loadMember(uniqueId, BungeeMember.class);
/*     */     
/*  78 */     if (member == null) {
/*  79 */       LoginConfiguration.AccountType accountType = event.getConnection().isOnlineMode() ? LoginConfiguration.AccountType.PREMIUM : LoginConfiguration.AccountType.CRACKED;
/*  80 */       BungeeMember memberByName = (BungeeMember)CommonPlugin.getInstance().getMemberData().loadMember(playerName, true, BungeeMember.class);
/*     */ 
/*     */       
/*  83 */       if (accountType == LoginConfiguration.AccountType.PREMIUM && memberByName != null && memberByName.getLoginConfiguration().getAccountType() == LoginConfiguration.AccountType.CRACKED) {
/*     */         try {
/*  85 */           InitialHandler initialHandler = (InitialHandler)event.getConnection();
/*     */           
/*  87 */           Field field = InitialHandler.class.getDeclaredField("uniqueId");
/*  88 */           field.setAccessible(true);
/*  89 */           field.set(initialHandler, memberByName.getUniqueId());
/*  90 */         } catch (Exception ex) {
/*  91 */           CommonPlugin.getInstance().getLogger().log(Level.SEVERE, "Failed to set unique id", ex);
/*  92 */           event.setCancelled(true);
/*  93 */           event.setCancelReason("§cSua conta não foi carregada.\nDetectamos que você está usando uma conta premium, mas já está registrado no servidor como cracked.\nFizemos as alterações necessárias mas está ocorrendo um erro.\nEntre em contato com um administrador.");
/*     */           
/*     */           return;
/*     */         } 
/*  97 */         event.getConnection().setOnlineMode(false);
/*     */       } else {
/*  99 */         if (memberByName != null) {
/* 100 */           if (!memberByName.getPlayerName().equals(playerName)) {
/* 101 */             event.setCancelled(true);
/* 102 */             event.setCancelReason("§cSua conta já está registrada no servidor com outro nick.");
/*     */             
/*     */             return;
/*     */           } 
/* 106 */           if (accountType != memberByName.getLoginConfiguration().getAccountType()) {
/* 107 */             event.setCancelled(true);
/* 108 */             event.setCancelReason("§cSua conta já está registrada no servidor como " + memberByName
/* 109 */                 .getLoginConfiguration().getAccountType().name() + ".");
/*     */           } 
/*     */         } 
/*     */         
/* 113 */         member = new BungeeMember(uniqueId, playerName, accountType);
/*     */         
/* 115 */         CommonPlugin.getInstance().getMemberData().createMember((Member)member);
/* 116 */         CommonPlugin.getInstance()
/* 117 */           .debug("The member " + member.getPlayerName() + "(" + member.getUniqueId() + ") has been created.");
/*     */       }
/*     */     
/* 120 */     } else if (member.getLoginConfiguration().getAccountType() == LoginConfiguration.AccountType.NONE) {
/* 121 */       member.getLoginConfiguration().setAccountType(
/* 122 */           event.getConnection().isOnlineMode() ? LoginConfiguration.AccountType.PREMIUM : LoginConfiguration.AccountType.CRACKED);
/* 123 */       member.saveConfig();
/*     */     } 
/*     */ 
/*     */     
/* 127 */     if (member.getSkin() == null || (!member.isCustomSkin() && member.getSkin().getCreatedAt() + 604800000L > System.currentTimeMillis())) {
/*     */       try {
/* 129 */         InitialHandler initialHandler = (InitialHandler)event.getConnection();
/* 130 */         LoginResult loginProfile = initialHandler.getLoginProfile();
/* 131 */         Skin skin = null;
/*     */         
/* 133 */         if (loginProfile != null && loginProfile.getProperties() != null) {
/* 134 */           for (LoginResult.Property property : loginProfile.getProperties()) {
/* 135 */             if (property.getName().equals("textures")) {
/* 136 */               skin = new Skin(member.getName(), property.getValue(), property.getSignature());
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         }
/* 142 */         if (skin == null)
/* 143 */         { member.setSkin(CommonConst.DEFAULT_SKIN); }
/*     */         else
/* 145 */         { member.setSkin(skin); } 
/* 146 */       } catch (Exception ex) {
/* 147 */         CommonPlugin.getInstance().getLogger().log(Level.WARNING, "Failed to load skin for " + member.getName(), ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 152 */     if (handleLogin(member, event))
/*     */       return; 
/* 154 */     if (handlePunish(member, event))
/*     */       return; 
/* 156 */     if (handleTimeout(member, event)) {
/*     */       return;
/*     */     }
/* 159 */     if (handleWhiteList(member, event)) {
/*     */       return;
/*     */     }
/* 162 */     if (!event.isCancelled()) {
/* 163 */       CommonPlugin.getInstance().getMemberManager().loadMember((Member)member);
/* 164 */       handleParty(member, event);
/*     */       
/* 166 */       if (!CommonPlugin.getInstance().getMemberData().checkCache(member.getUniqueId())) {
/* 167 */         CommonPlugin.getInstance().getMemberData().saveRedisMember((Member)member);
/*     */       }
/* 169 */       Report report = CommonPlugin.getInstance().getReportManager().getReportById(member.getUniqueId());
/*     */       
/* 171 */       if (report != null) {
/* 172 */         report.setOnline(true);
/*     */       }
/* 174 */       BungeeMain.getInstance().loadTexture(event.getConnection(), member.getSkin());
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPostLogin(PostLoginEvent event) {
/* 180 */     BungeeMember member = (BungeeMember)CommonPlugin.getInstance().getMemberManager().getMember(event.getPlayer().getUniqueId(), BungeeMember.class);
/*     */ 
/*     */     
/* 183 */     if (member == null) {
/* 184 */       event.getPlayer().disconnect(CommonPlugin.getInstance().getPluginInfo().translate("account-not-loaded"));
/*     */       
/*     */       return;
/*     */     } 
/* 188 */     member.setProxiedPlayer(event.getPlayer());
/* 189 */     handlePermissions(member);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerPunish(PlayerPunishEvent event) {
/* 194 */     if (event.getPunish().getPunishType() == PunishType.BAN && !event.getPunish().getPlayerName().equals("CONSOLE") && event
/* 195 */       .getPunish().isPermanent()) {
/* 196 */       Member member = event.getPunished();
/*     */       
/* 198 */       banIp(member.getLastIpAddress(), event.getPunish());
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerPardoned(PlayerPardonedEvent event) {
/* 204 */     if (event.getPunish().getPunishType() == PunishType.BAN && event.getPunish().isPermanent() && 
/* 205 */       isIpBanned(event.getPunished().getLastIpAddress())) {
/* 206 */       this.banCache.invalidate(event.getPunished().getLastIpAddress());
/*     */     }
/*     */   }
/*     */   
/*     */   public void handlePermissions(BungeeMember member) {
/* 211 */     ProxiedPlayer player = member.getProxiedPlayer();
/*     */     
/* 213 */     for (UnmodifiableIterator<String> unmodifiableIterator = ImmutableList.copyOf(player.getPermissions()).iterator(); unmodifiableIterator.hasNext(); ) { String permission = unmodifiableIterator.next();
/* 214 */       player.setPermission(permission, false); }
/*     */ 
/*     */     
/* 217 */     for (String string : member.getPermissions()) {
/* 218 */       player.setPermission(string.toLowerCase(), true);
/*     */     }
/*     */ 
/*     */     
/* 222 */     for (Group group : (Group[])member.getGroups().keySet().stream().map(name -> CommonPlugin.getInstance().getPluginInfo().getGroupByName(name)).toArray(x$0 -> new Group[x$0])) {
/* 223 */       for (String string : group.getPermissions()) {
/* 224 */         player.setPermission(string.toLowerCase(), true);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerFieldUpdate(PlayerFieldUpdateEvent event) {
/* 231 */     if (event.getFieldName().toLowerCase().contains("group"))
/* 232 */       handlePermissions(event.getPlayer()); 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPermissionCheck(PermissionCheckEvent event) {
/* 237 */     if (!(event.getSender() instanceof ProxiedPlayer) || event.hasPermission()) {
/*     */       return;
/*     */     }
/* 240 */     CommandSender sender = event.getSender();
/* 241 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(((ProxiedPlayer)sender).getUniqueId());
/*     */     
/* 243 */     if (member == null) {
/*     */       return;
/*     */     }
/*     */     
/* 247 */     String permission = sender.getPermissions().stream().filter(string -> string.equals("*")).findFirst().orElse(null);
/*     */     
/* 249 */     if (permission == null) {
/* 250 */       event.setHasPermission(member.hasSilentPermission(event.getPermission()));
/*     */     } else {
/* 252 */       event.setHasPermission(true);
/*     */     } 
/*     */   }
/*     */   @EventHandler
/*     */   public void onPlayerDisconnect(PlayerDisconnectEvent event) {
/* 257 */     BungeeMember member = (BungeeMember)CommonPlugin.getInstance().getMemberManager().getMember(event.getPlayer().getUniqueId(), BungeeMember.class);
/*     */ 
/*     */     
/* 260 */     if (member != null) {
/* 261 */       member.getLoginConfiguration().logOut();
/* 262 */       member.logOut();
/*     */       
/* 264 */       CommonPlugin.getInstance().getMemberManager().unloadMember((Member)member);
/*     */       
/* 266 */       CommonPlugin.getInstance().getMemberData().cacheConnection(event
/* 267 */           .getPlayer().getPendingConnection().getName(), 
/* 268 */           (member.getLoginConfiguration().getAccountType() == LoginConfiguration.AccountType.PREMIUM));
/* 269 */       CommonPlugin.getInstance().getMemberData().cacheMember(member.getUniqueId());
/*     */       
/* 271 */       Party party = member.getParty();
/*     */       
/* 273 */       if (party != null && 
/*     */ 
/*     */         
/* 276 */         !party.getMembers().stream().filter(id -> (CommonPlugin.getInstance().getMemberManager().getMember(id) != null)).findFirst().isPresent()) {
/* 277 */         member.setPartyId(null);
/* 278 */         CommonPlugin.getInstance().getPartyData().deleteParty(party);
/* 279 */         CommonPlugin.getInstance().getPartyManager().unloadParty(party.getPartyId());
/*     */       } 
/*     */ 
/*     */       
/* 283 */       Report report = CommonPlugin.getInstance().getReportManager().getReportById(member.getUniqueId());
/*     */       
/* 285 */       if (report != null) {
/* 286 */         report.setOnline(false);
/*     */       }
/* 288 */       CommonPlugin.getInstance().getPartyManager().getPartyInvitesMap().remove(member.getUniqueId());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void banIp(String ipAddress, Punish punish) {
/* 293 */     this.banCache.put(ipAddress, punish);
/*     */   }
/*     */   
/*     */   private boolean isIpBanned(String ipAddress) {
/* 297 */     return this.banCache.asMap().containsKey(ipAddress);
/*     */   }
/*     */   
/*     */   private boolean handleParty(BungeeMember member, LoginEvent event) {
/* 301 */     Party party = member.getParty();
/*     */     
/* 303 */     if (party != null) {
/* 304 */       return true;
/*     */     }
/* 306 */     if (member.getPartyId() != null) {
/* 307 */       member.setPartyId(null);
/*     */     }
/* 309 */     return true;
/*     */   }
/*     */   
/*     */   private boolean handleTimeout(BungeeMember member, LoginEvent event) {
/* 313 */     if (member.getLoginConfiguration().isTimeouted()) {
/* 314 */       event.setCancelled(true);
/* 315 */       event.setCancelReason(PluginInfo.t((CommandSender)member, "command.login.timeouted", new String[] { "%time%", 
/* 316 */               DateUtils.getTime(member.getLanguage(), member.getLoginConfiguration().getTimeoutTime()), "%website%", 
/* 317 */               CommonPlugin.getInstance().getPluginInfo().getWebsite() }));
/* 318 */       return true;
/*     */     } 
/* 320 */     return false;
/*     */   }
/*     */   
/*     */   private boolean handlePunish(BungeeMember member, LoginEvent event) {
/* 324 */     Punish punish = member.getPunishConfiguration().getActualPunish(PunishType.BAN);
/*     */     
/* 326 */     if (punish != null) {
/* 327 */       event.setCancelled(true);
/* 328 */       event.setCancelReason(PluginInfo.t((CommandSender)member, "ban-" + (
/* 329 */             punish.isPermanent() ? "permanent" : "temporary") + "-kick-message", new String[] { "%reason%", punish
/* 330 */               .getPunishReason(), "%expireAt%", 
/* 331 */               DateUtils.getTime(member.getLanguage(), punish.getExpireAt()), "%punisher%", punish
/* 332 */               .getPunisherName(), "%website%", CommonPlugin.getInstance().getPluginInfo().getWebsite(), "%store%", 
/* 333 */               CommonPlugin.getInstance().getPluginInfo().getStore(), "%discord%", 
/* 334 */               CommonPlugin.getInstance().getPluginInfo().getDiscord() }));
/* 335 */       return true;
/*     */     } 
/*     */     
/* 338 */     if (isIpBanned(member.getLastIpAddress())) {
/* 339 */       punish = new Punish((CommandSender)member, BungeeConst.CONSOLE_SENDER, "Conta alternativa", -1L, PunishType.BAN);
/*     */       
/* 341 */       member.getPunishConfiguration().punish(punish);
/* 342 */       member.saveConfig();
/*     */       
/* 344 */       ProxyServer.getInstance().getPluginManager()
/* 345 */         .callEvent((Event)new PlayerPunishEvent((Member)member, punish, BungeeConst.CONSOLE_SENDER));
/*     */       
/* 347 */       event.setCancelled(true);
/* 348 */       event.setCancelReason(PluginInfo.t((CommandSender)member, "ban-" + (
/* 349 */             punish.isPermanent() ? "permanent" : "temporary") + "-kick-message", new String[] { "%reason%", punish
/* 350 */               .getPunishReason(), "%expireAt%", 
/* 351 */               DateUtils.getTime(member.getLanguage(), punish.getExpireAt()), "%punisher%", punish
/* 352 */               .getPunisherName(), "%website%", CommonPlugin.getInstance().getPluginInfo().getWebsite(), "%store%", 
/* 353 */               CommonPlugin.getInstance().getPluginInfo().getStore(), "%discord%", 
/* 354 */               CommonPlugin.getInstance().getPluginInfo().getDiscord() }));
/* 355 */       return true;
/*     */     } 
/*     */     
/* 358 */     return false;
/*     */   }
/*     */   
/*     */   private boolean handleLogin(BungeeMember member, LoginEvent event) {
/* 362 */     SocketAddress socket = event.getConnection().getSocketAddress();
/*     */     
/* 364 */     if (!(socket instanceof InetSocketAddress)) {
/* 365 */       event.setCancelled(true);
/* 366 */       event.setCancelReason("§cWe cannot load your ip address.");
/* 367 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 371 */     String playerName = event.getConnection().getName();
/* 372 */     InetSocketAddress inetSocketAddress = (InetSocketAddress)socket;
/* 373 */     String ipAddress = inetSocketAddress.getHostString();
/*     */     
/*     */     try {
/* 376 */       member.logIn(playerName, ipAddress);
/* 377 */       return false;
/* 378 */     } catch (NullPointerException ex) {
/* 379 */       event.setCancelled(true);
/* 380 */       event.setCancelReason("§cWe cannot load your ip address.");
/* 381 */       ex.printStackTrace();
/* 382 */       return true;
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean handleWhiteList(BungeeMember bungeeMember, LoginEvent loginEvent) {
/* 387 */     if (BungeeMain.getInstance().isMaintenance() && !bungeeMember.hasPermission("command.admin") && 
/* 388 */       !BungeeMain.getInstance().isMemberInWhiteList(bungeeMember.getPlayerName())) {
/* 389 */       long maintenanceTime = BungeeMain.getInstance().getWhitelistExpires();
/*     */       
/* 391 */       loginEvent.setCancelled(true);
/*     */       
/* 393 */       loginEvent.setCancelReason("§c§lHIGHMC\n§4\n§cO servidor entrou em manutenção!\n§cPara melhorar sua jogabilidade estamos atualizando o servidor" + ((maintenanceTime == 0L) ? ", espere para entrar novamente!" : (".\n§cO servidor volta em " + 
/*     */ 
/*     */           
/* 396 */           DateUtils.getTime(
/* 397 */             CommonPlugin.getInstance().getPluginInfo().getDefaultLanguage(), maintenanceTime))) + "\n§f\n§ePara mais informações §b" + 
/* 398 */           CommonPlugin.getInstance().getPluginInfo().getDiscord());
/* 399 */       return true;
/*     */     } 
/*     */     
/* 402 */     return false;
/*     */   }
/*     */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/listener/MemberListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */