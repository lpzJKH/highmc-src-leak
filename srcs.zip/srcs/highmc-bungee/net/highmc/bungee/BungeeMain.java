/*     */ package net.highmc.bungee;
/*     */ import com.google.common.io.ByteArrayDataOutput;
/*     */ import com.google.common.io.ByteStreams;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import net.highmc.CommonConst;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.backend.redis.RedisConnection;
/*     */ import net.highmc.bungee.command.BungeeCommandFramework;
/*     */ import net.highmc.bungee.listener.DataListener;
/*     */ import net.highmc.bungee.listener.LoginListener;
/*     */ import net.highmc.bungee.listener.MemberListener;
/*     */ import net.highmc.bungee.listener.MessageListener;
/*     */ import net.highmc.bungee.listener.ServerListener;
/*     */ import net.highmc.bungee.manager.BungeeServerManager;
/*     */ import net.highmc.bungee.manager.LoginManager;
/*     */ import net.highmc.bungee.member.BungeeParty;
/*     */ import net.highmc.bungee.networking.BungeePubSubHandler;
/*     */ import net.highmc.report.Report;
/*     */ import net.highmc.server.ServerManager;
/*     */ import net.highmc.utils.skin.Skin;
/*     */ import net.md_5.bungee.api.ProxyServer;
/*     */ import net.md_5.bungee.api.connection.PendingConnection;
/*     */ import net.md_5.bungee.api.connection.ProxiedPlayer;
/*     */ import net.md_5.bungee.api.plugin.Listener;
/*     */ import net.md_5.bungee.api.plugin.Plugin;
/*     */ import net.md_5.bungee.config.Configuration;
/*     */ import net.md_5.bungee.config.ConfigurationProvider;
/*     */ import net.md_5.bungee.config.YamlConfiguration;
/*     */ import net.md_5.bungee.connection.InitialHandler;
/*     */ import net.md_5.bungee.connection.LoginResult;
/*     */ import redis.clients.jedis.JedisPubSub;
/*     */ 
/*     */ public class BungeeMain extends Plugin {
/*     */   private static BungeeMain instance;
/*     */   private CommonPlugin plugin;
/*     */   private ServerManager serverManager;
/*     */   private LoginManager loginManager;
/*     */   
/*     */   public static BungeeMain getInstance() {
/*  49 */     return instance;
/*     */   } private RedisConnection.PubSubListener pubSubListener; private Configuration config; private int playersRecord; private boolean whitelistEnabled; private long whitelistExpires;
/*     */   public CommonPlugin getPlugin() {
/*  52 */     return this.plugin;
/*     */   }
/*  54 */   public ServerManager getServerManager() { return this.serverManager; } public LoginManager getLoginManager() {
/*  55 */     return this.loginManager;
/*     */   } public RedisConnection.PubSubListener getPubSubListener() {
/*  57 */     return this.pubSubListener;
/*     */   } public Configuration getConfig() {
/*  59 */     return this.config;
/*     */   }
/*  61 */   public void setPlayersRecord(int playersRecord) { this.playersRecord = playersRecord; } public int getPlayersRecord() {
/*  62 */     return this.playersRecord;
/*     */   }
/*  64 */   public boolean isWhitelistEnabled() { return this.whitelistEnabled; } public long getWhitelistExpires() {
/*  65 */     return this.whitelistExpires;
/*  66 */   } private List<String> whiteList = new ArrayList<>(); private List<String> messages; public List<String> getWhiteList() { return this.whiteList; }
/*     */    public List<String> getMessages() {
/*  68 */     return this.messages;
/*     */   }
/*     */   
/*     */   public void onLoad() {
/*  72 */     instance = this;
/*  73 */     this.plugin = new CommonPlugin(new BungeePlatform());
/*  74 */     super.onLoad();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  79 */     loadConfiguration();
/*  80 */     this.serverManager = (ServerManager)new BungeeServerManager();
/*  81 */     this.loginManager = new LoginManager();
/*     */     
/*  83 */     getProxy().getPluginManager().registerListener(this, (Listener)new DataListener());
/*  84 */     getProxy().getPluginManager().registerListener(this, (Listener)new LoginListener());
/*  85 */     getProxy().getPluginManager().registerListener(this, (Listener)new LogListener());
/*  86 */     getProxy().getPluginManager().registerListener(this, (Listener)new MemberListener());
/*  87 */     getProxy().getPluginManager().registerListener(this, (Listener)new MessageListener());
/*  88 */     getProxy().getPluginManager().registerListener(this, (Listener)new ServerListener());
/*     */     
/*  90 */     ProxyServer.getInstance().getServers().remove("lobby");
/*  91 */     this.plugin.loadServers(this.serverManager);
/*  92 */     this.plugin.setServerId("bungeecord.highmc.net");
/*  93 */     this.plugin.getServerData().startServer(3000);
/*  94 */     this.plugin.getServerData().setJoinEnabled(!this.whitelistEnabled);
/*     */     
/*  96 */     this.plugin.getMemberData().reloadPlugins();
/*  97 */     this.plugin.setPartyClass(BungeeParty.class);
/*  98 */     this.plugin.getReportManager().getReports().stream().forEach(report -> report.setOnline(false));
/*     */     
/* 100 */     (new BungeeCommandFramework(this)).loadCommands("net.highmc");
/*     */     
/* 102 */     getProxy().getScheduler().runAsync(this, 
/* 103 */         (Runnable)(this.pubSubListener = new RedisConnection.PubSubListener(this.plugin.getRedisConnection(), (JedisPubSub)new BungeePubSubHandler(), new String[] { "member_field", "server_info", "server_packet" })));
/*     */ 
/*     */ 
/*     */     
/* 107 */     getProxy().getScheduler().schedule(this, () -> { if (!getMessages().isEmpty()) ProxyServer.getInstance().broadcast(getMessages().get(CommonConst.RANDOM.nextInt(getMessages().size())));  }2L, 2L, TimeUnit.MINUTES);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 113 */     super.onEnable();
/*     */   }
/*     */   
/*     */   public boolean isMaintenance() {
/* 117 */     if (this.whitelistEnabled) {
/* 118 */       if (this.whitelistExpires == -1L || this.whitelistExpires > System.currentTimeMillis()) {
/* 119 */         return true;
/*     */       }
/* 121 */       setWhitelistEnabled(false, -1L);
/*     */     } 
/*     */     
/* 124 */     return false;
/*     */   }
/*     */   
/*     */   public void addMemberToWhiteList(String playerName) {
/* 128 */     if (!this.whiteList.contains(playerName.toLowerCase())) {
/* 129 */       this.whiteList.add(playerName.toLowerCase());
/* 130 */       getConfig().set("whiteList", this.whiteList);
/* 131 */       saveConfig();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void removeMemberFromWhiteList(String playerName) {
/* 136 */     if (this.whiteList.contains(playerName.toLowerCase())) {
/* 137 */       this.whiteList.remove(playerName.toLowerCase());
/* 138 */       getConfig().set("whiteList", this.whiteList);
/* 139 */       saveConfig();
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isMemberInWhiteList(String playerName) {
/* 144 */     return this.whiteList.contains(playerName.toLowerCase());
/*     */   }
/*     */   
/*     */   public void setWhitelistEnabled(boolean whitelistEnabled, long time) {
/* 148 */     this.whitelistEnabled = whitelistEnabled;
/* 149 */     this.whitelistExpires = time;
/* 150 */     getConfig().set("whitelistEnabled", Boolean.valueOf(whitelistEnabled));
/* 151 */     getConfig().set("whitelistExpires", Long.valueOf(this.whitelistExpires));
/* 152 */     saveConfig();
/*     */     
/* 154 */     this.plugin.getServerData().setJoinEnabled(!whitelistEnabled);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/* 159 */     this.plugin.getServerData().stopServer();
/* 160 */     super.onDisable();
/*     */   }
/*     */   
/*     */   private void loadConfiguration() {
/*     */     try {
/* 165 */       if (!getDataFolder().exists()) {
/* 166 */         getDataFolder().mkdir();
/*     */       }
/*     */       
/* 169 */       File configFile = new File(getDataFolder(), "config.yml");
/*     */       
/* 171 */       if (!configFile.exists()) {
/*     */         try {
/* 173 */           configFile.createNewFile();
/* 174 */           try(InputStream is = getResourceAsStream("config.yml"); 
/* 175 */               OutputStream os = new FileOutputStream(configFile)) {
/* 176 */             ByteStreams.copy(is, os);
/*     */           } 
/* 178 */         } catch (IOException e) {
/* 179 */           throw new RuntimeException("Unable to create configuration file", e);
/*     */         } 
/*     */       }
/*     */       
/* 183 */       this.config = ConfigurationProvider.getProvider(YamlConfiguration.class).load(configFile);
/*     */       
/* 185 */       loadDefaultConfig(this.config);
/* 186 */     } catch (IOException ex) {
/* 187 */       ex.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void loadDefaultConfig(Configuration config2) {
/* 192 */     this.whitelistEnabled = this.config.getBoolean("whitelistEnabled", false);
/* 193 */     this.whitelistExpires = this.config.getLong("whitelistExpires", -1L);
/* 194 */     this.whiteList = new ArrayList<>(this.config.getStringList("whiteList"));
/*     */     
/* 196 */     this.messages = this.config.getStringList("messages.broadcast");
/*     */   }
/*     */   
/*     */   public void addMessage(String message) {
/* 200 */     this.messages.add(message);
/* 201 */     this.config.set("messages.broadcast", this.messages);
/* 202 */     saveConfig();
/*     */   }
/*     */   
/*     */   public void removeMessage(int index) {
/* 206 */     this.messages.remove(index);
/* 207 */     this.config.set("messages.broadcast", this.messages);
/* 208 */     saveConfig();
/*     */   }
/*     */   
/*     */   public void saveConfig() {
/*     */     try {
/* 213 */       ConfigurationProvider.getProvider(YamlConfiguration.class).save(this.config, new File(
/* 214 */             getDataFolder(), "config.yml"));
/* 215 */     } catch (IOException e) {
/* 216 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getAveragePing(Collection<ProxiedPlayer> players) {
/* 221 */     int averagePing = 0;
/* 222 */     for (ProxiedPlayer player : players)
/* 223 */       averagePing += player.getPing(); 
/* 224 */     return averagePing / Math.max(ProxyServer.getInstance().getPlayers().size(), 1);
/*     */   }
/*     */   
/*     */   public void teleport(ProxiedPlayer player, ProxiedPlayer target) {
/* 228 */     player.connect(target.getServer().getInfo());
/*     */     
/* 230 */     ProxyServer.getInstance().getScheduler().schedule(getInstance(), () -> { ByteArrayDataOutput out = ByteStreams.newDataOutput(); out.writeUTF("BungeeTeleport"); out.writeUTF(target.getUniqueId().toString()); player.getServer().sendData("BungeeCord", out.toByteArray()); }300L, TimeUnit.MILLISECONDS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadTexture(PendingConnection connection, Skin skin) {
/* 239 */     if (skin == null) {
/*     */       return;
/*     */     }
/* 242 */     InitialHandler initialHandler = (InitialHandler)connection;
/* 243 */     LoginResult loginProfile = initialHandler.getLoginProfile();
/*     */     
/* 245 */     LoginResult.Property property = new LoginResult.Property("textures", skin.getValue(), skin.getSignature());
/*     */     
/* 247 */     if (loginProfile == null || (loginProfile == null && property == null)) {
/*     */       
/* 249 */       (new LoginResult.Property[1])[0] = property; LoginResult loginResult = new LoginResult(connection.getUniqueId().toString().replace("-", ""), connection.getName(), (property == null) ? new LoginResult.Property[0] : new LoginResult.Property[1]);
/*     */ 
/*     */       
/*     */       try {
/* 253 */         Class<?> initialHandlerClass = connection.getClass();
/* 254 */         Field profileField = initialHandlerClass.getDeclaredField("loginProfile");
/* 255 */         profileField.setAccessible(true);
/* 256 */         profileField.set(connection, loginResult);
/* 257 */       } catch (Exception ex) {
/* 258 */         ex.printStackTrace();
/*     */       }
/*     */     
/* 261 */     } else if (property != null) {
/* 262 */       loginProfile.setProperties(new LoginResult.Property[] { property });
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/BungeeMain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */