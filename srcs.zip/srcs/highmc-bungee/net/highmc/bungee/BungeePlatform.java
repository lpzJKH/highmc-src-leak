/*    */ package net.highmc.bungee;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import java.util.logging.Logger;
/*    */ import net.highmc.PluginPlatform;
/*    */ import net.md_5.bungee.api.ProxyServer;
/*    */ import net.md_5.bungee.api.connection.ProxiedPlayer;
/*    */ 
/*    */ 
/*    */ public class BungeePlatform
/*    */   implements PluginPlatform
/*    */ {
/*    */   public UUID getUniqueId(String playerName) {
/* 15 */     ProxiedPlayer proxiedPlayer = ProxyServer.getInstance().getPlayer(playerName);
/* 16 */     return (proxiedPlayer == null) ? null : proxiedPlayer.getUniqueId();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName(UUID uuid) {
/* 21 */     ProxiedPlayer proxiedPlayer = ProxyServer.getInstance().getPlayer(uuid);
/* 22 */     return (proxiedPlayer == null) ? null : proxiedPlayer.getName();
/*    */   }
/*    */ 
/*    */   
/*    */   public void runAsync(Runnable runnable) {
/* 27 */     ProxyServer.getInstance().getScheduler().runAsync(BungeeMain.getInstance(), runnable);
/*    */   }
/*    */ 
/*    */   
/*    */   public void runAsync(Runnable runnable, long delay) {
/* 32 */     throw new UnsupportedOperationException("This operation is not implemented in BungeeCord");
/*    */   }
/*    */ 
/*    */   
/*    */   public void runAsync(Runnable runnable, long delay, long repeat) {
/* 37 */     throw new UnsupportedOperationException("This operation is not implemented in BungeeCord");
/*    */   }
/*    */ 
/*    */   
/*    */   public void run(Runnable runnable, long delay) {
/* 42 */     ProxyServer.getInstance().getScheduler().schedule(BungeeMain.getInstance(), runnable, delay / 20L, TimeUnit.SECONDS);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void run(Runnable runnable, long delay, long repeat) {
/* 48 */     ProxyServer.getInstance().getScheduler().schedule(BungeeMain.getInstance(), runnable, delay / 20L, repeat / 20L, TimeUnit.SECONDS);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void shutdown(String message) {
/* 54 */     System.out.println("§4" + message);
/*    */     
/* 56 */     ProxyServer.getInstance().getPlayers().forEach(player -> player.disconnect("§c" + message));
/* 57 */     ProxyServer.getInstance().stop(message);
/*    */   }
/*    */ 
/*    */   
/*    */   public Logger getLogger() {
/* 62 */     return BungeeMain.getInstance().getLogger();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void dispatchCommand(String command) {}
/*    */ 
/*    */   
/*    */   public void broadcast(String string) {
/* 71 */     ProxyServer.getInstance().broadcast(string);
/*    */   }
/*    */ 
/*    */   
/*    */   public void broadcast(String string, String permission) {
/* 76 */     ProxyServer.getInstance().broadcast(string);
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/BungeePlatform.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */