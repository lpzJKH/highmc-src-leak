/*    */ package net.highmc.bungee.member;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import net.highmc.member.Member;
/*    */ import net.highmc.member.party.Party;
/*    */ 
/*    */ public class BungeeParty
/*    */   extends Party
/*    */ {
/*    */   public BungeeParty(UUID partyId, Member member) {
/* 11 */     super(partyId, member);
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/member/BungeeParty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */