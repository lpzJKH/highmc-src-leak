/*    */ package net.highmc.bungee.member;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.member.Member;
/*    */ import net.highmc.member.configuration.LoginConfiguration;
/*    */ import net.highmc.packet.types.ActionBar;
/*    */ import net.md_5.bungee.BungeeTitle;
/*    */ import net.md_5.bungee.api.chat.BaseComponent;
/*    */ import net.md_5.bungee.api.chat.TextComponent;
/*    */ import net.md_5.bungee.api.connection.ProxiedPlayer;
/*    */ 
/*    */ public class BungeeMember
/*    */   extends Member
/*    */ {
/*    */   private transient ProxiedPlayer proxiedPlayer;
/*    */   
/*    */   public void setProxiedPlayer(ProxiedPlayer proxiedPlayer) {
/* 19 */     this.proxiedPlayer = proxiedPlayer; } public ProxiedPlayer getProxiedPlayer() {
/* 20 */     return this.proxiedPlayer;
/*    */   }
/*    */   public BungeeMember(UUID uniqueId, String playerName, LoginConfiguration.AccountType accountType) {
/* 23 */     super(uniqueId, playerName, accountType);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasPermission(String permission) {
/* 28 */     if (this.proxiedPlayer != null && this.proxiedPlayer.hasPermission(permission.toLowerCase())) {
/* 29 */       return true;
/*    */     }
/* 31 */     return super.hasPermission(permission);
/*    */   }
/*    */ 
/*    */   
/*    */   public void sendMessage(String message) {
/* 36 */     if (this.proxiedPlayer != null) {
/* 37 */       this.proxiedPlayer
/* 38 */         .sendMessage(CommonPlugin.getInstance().getPluginInfo().findAndTranslate(getLanguage(), message));
/*    */     }
/*    */   }
/*    */   
/*    */   public void sendMessage(BaseComponent str) {
/* 43 */     if (this.proxiedPlayer != null) {
/* 44 */       this.proxiedPlayer.sendMessage(str);
/*    */     }
/*    */   }
/*    */   
/*    */   public void sendMessage(BaseComponent... fromLegacyText) {
/* 49 */     if (this.proxiedPlayer != null) {
/* 50 */       this.proxiedPlayer.sendMessage(fromLegacyText);
/*    */     }
/*    */   }
/*    */   
/*    */   public void sendTitle(String title, String subTitle, int fadeIn, int stayIn, int fadeOut) {
/* 55 */     if (this.proxiedPlayer != null) {
/* 56 */       BungeeTitle packet = new BungeeTitle();
/*    */       
/* 58 */       packet.title(TextComponent.fromLegacyText(title));
/* 59 */       packet.subTitle(TextComponent.fromLegacyText(subTitle));
/* 60 */       packet.fadeIn(fadeIn);
/* 61 */       packet.fadeOut(fadeOut);
/* 62 */       packet.stay(stayIn);
/*    */       
/* 64 */       packet.send(this.proxiedPlayer);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void sendActionBar(String message) {
/* 70 */     if (this.proxiedPlayer != null) {
/* 71 */       CommonPlugin.getInstance().getServerData()
/* 72 */         .sendPacket((new ActionBar(getUniqueId(), message)).server(new String[] { getActualServerId() }));
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void saveConfig() {
/* 78 */     super.saveConfig();
/* 79 */     save(new String[] { "ipAddress", "lastIpAddress", "firstLogin", "lastLogin", "joinTime", "onlineTime", "online" });
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/member/BungeeMember.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */