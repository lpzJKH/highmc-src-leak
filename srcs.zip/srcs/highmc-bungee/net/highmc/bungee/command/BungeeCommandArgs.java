/*    */ package net.highmc.bungee.command;
/*    */ 
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.bungee.BungeeConst;
/*    */ import net.highmc.bungee.member.BungeeMember;
/*    */ import net.highmc.command.CommandArgs;
/*    */ import net.highmc.command.CommandSender;
/*    */ import net.md_5.bungee.api.CommandSender;
/*    */ import net.md_5.bungee.api.connection.ProxiedPlayer;
/*    */ 
/*    */ public class BungeeCommandArgs
/*    */   extends CommandArgs {
/*    */   protected BungeeCommandArgs(CommandSender sender, String label, String[] args, int subCommand) {
/* 14 */     super((sender instanceof ProxiedPlayer) ? 
/* 15 */         (CommandSender)CommonPlugin.getInstance().getMemberManager().getMember(((ProxiedPlayer)sender).getUniqueId()) : BungeeConst.CONSOLE_SENDER, label, args, subCommand);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isPlayer() {
/* 21 */     return getSender() instanceof net.highmc.member.Member;
/*    */   }
/*    */   
/*    */   public ProxiedPlayer getPlayer() {
/* 25 */     if (!isPlayer())
/* 26 */       return null; 
/* 27 */     return ((BungeeMember)getSender()).getProxiedPlayer();
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/command/BungeeCommandArgs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */