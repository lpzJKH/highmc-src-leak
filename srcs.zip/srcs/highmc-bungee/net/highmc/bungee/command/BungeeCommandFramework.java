/*     */ package net.highmc.bungee.command;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.command.CommandArgs;
/*     */ import net.highmc.command.CommandClass;
/*     */ import net.highmc.command.CommandFramework;
/*     */ import net.highmc.member.Member;
/*     */ import net.md_5.bungee.api.CommandSender;
/*     */ import net.md_5.bungee.api.chat.TextComponent;
/*     */ import net.md_5.bungee.api.connection.ProxiedPlayer;
/*     */ import net.md_5.bungee.api.event.TabCompleteEvent;
/*     */ import net.md_5.bungee.api.plugin.Command;
/*     */ import net.md_5.bungee.api.plugin.Listener;
/*     */ import net.md_5.bungee.api.plugin.Plugin;
/*     */ import net.md_5.bungee.event.EventHandler;
/*     */ 
/*     */ 
/*     */ public class BungeeCommandFramework
/*     */   implements CommandFramework
/*     */ {
/*  26 */   private final Map<String, Map.Entry<Method, Object>> commandMap = new HashMap<>();
/*  27 */   private final Map<String, Map.Entry<Method, Object>> completers = new HashMap<>();
/*     */   private final Plugin plugin;
/*     */   
/*     */   public BungeeCommandFramework(Plugin plugin) {
/*  31 */     this.plugin = plugin;
/*  32 */     this.plugin.getProxy().getPluginManager().registerListener(plugin, new BungeeCompleter());
/*     */   }
/*     */   
/*     */   public boolean handleCommand(final CommandSender sender, final String label, final String[] args) {
/*  36 */     for (int i = args.length; i >= 0; i--) {
/*  37 */       StringBuilder buffer = new StringBuilder();
/*  38 */       buffer.append(label.toLowerCase());
/*  39 */       for (int x = 0; x < i; x++) {
/*  40 */         buffer.append(".").append(args[x].toLowerCase());
/*     */       }
/*  42 */       final String cmdLabel = buffer.toString();
/*  43 */       if (this.commandMap.containsKey(cmdLabel)) {
/*  44 */         final Map.Entry<Method, Object> entry = this.commandMap.get(cmdLabel);
/*  45 */         CommandFramework.Command command = ((Method)entry.getKey()).<CommandFramework.Command>getAnnotation(CommandFramework.Command.class);
/*  46 */         if (sender instanceof ProxiedPlayer) {
/*  47 */           ProxiedPlayer p = (ProxiedPlayer)sender;
/*  48 */           Member member = CommonPlugin.getInstance().getMemberManager().getMember(p.getUniqueId());
/*     */           
/*  50 */           if (member == null) {
/*  51 */             p.disconnect(TextComponent.fromLegacyText("ERRO"));
/*  52 */             return true;
/*     */           } 
/*     */           
/*  55 */           if (!command.permission().isEmpty() && !member.hasPermission(command.permission())) {
/*  56 */             member.sendMessage(member.getLanguage().t("no-permission", new String[0]));
/*  57 */             return true;
/*     */           }
/*     */         
/*     */         }
/*  61 */         else if (!command.console()) {
/*  62 */           sender.sendMessage(
/*  63 */               CommonPlugin.getInstance().getPluginInfo().translate("command-only-for-player"));
/*  64 */           return true;
/*     */         } 
/*     */ 
/*     */         
/*  68 */         if (command.runAsync()) {
/*  69 */           this.plugin.getProxy().getScheduler().runAsync(this.plugin, new Runnable()
/*     */               {
/*     */                 public void run()
/*     */                 {
/*     */                   try {
/*  74 */                     ((Method)entry.getKey()).invoke(entry.getValue(), new Object[] { new BungeeCommandArgs(this.val$sender, this.val$label
/*  75 */                             .replace(".", " "), this.val$args, (this.val$cmdLabel.split("\\.")).length - 1) });
/*  76 */                   } catch (IllegalArgumentException|java.lang.reflect.InvocationTargetException|IllegalAccessException e) {
/*  77 */                     e.printStackTrace();
/*     */                   } 
/*     */                 }
/*     */               });
/*     */         } else {
/*     */           try {
/*  83 */             ((Method)entry.getKey()).invoke(entry.getValue(), new Object[] { new BungeeCommandArgs(sender, label, args, (cmdLabel
/*  84 */                     .split("\\.")).length - 1) });
/*  85 */           } catch (IllegalArgumentException|java.lang.reflect.InvocationTargetException|IllegalAccessException e) {
/*  86 */             e.printStackTrace();
/*     */           } 
/*     */         } 
/*  89 */         return true;
/*     */       } 
/*     */     } 
/*  92 */     defaultCommand(new BungeeCommandArgs(sender, label, args, 0));
/*  93 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerCommands(CommandClass cls) {
/*  98 */     for (Method m : cls.getClass().getMethods()) {
/*  99 */       if (m.getAnnotation(CommandFramework.Command.class) != null) {
/* 100 */         CommandFramework.Command command = m.<CommandFramework.Command>getAnnotation(CommandFramework.Command.class);
/* 101 */         if ((m.getParameterTypes()).length > 1 || (m.getParameterTypes()).length <= 0 || 
/* 102 */           !CommandArgs.class.isAssignableFrom(m.getParameterTypes()[0])) {
/* 103 */           System.out.println("Unable to register command " + m.getName() + ". Unexpected method arguments");
/*     */         } else {
/*     */           
/* 106 */           registerCommand(command, command.name(), m, cls);
/* 107 */           for (String alias : command.aliases())
/* 108 */             registerCommand(command, alias, m, cls); 
/*     */         } 
/* 110 */       } else if (m.getAnnotation(CommandFramework.Completer.class) != null) {
/* 111 */         CommandFramework.Completer comp = m.<CommandFramework.Completer>getAnnotation(CommandFramework.Completer.class);
/* 112 */         if ((m.getParameterTypes()).length > 1 || (m.getParameterTypes()).length <= 0 || 
/* 113 */           !CommandArgs.class.isAssignableFrom(m.getParameterTypes()[0])) {
/* 114 */           System.out.println("Unable to register tab completer " + m
/* 115 */               .getName() + ". Unexpected method arguments");
/*     */         
/*     */         }
/* 118 */         else if (m.getReturnType() != List.class) {
/* 119 */           System.out.println("Unable to register tab completer " + m.getName() + ". Unexpected return type");
/*     */         } else {
/*     */           
/* 122 */           registerCompleter(comp.name(), m, cls);
/* 123 */           for (String alias : comp.aliases()) {
/* 124 */             registerCompleter(alias, m, cls);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerCommand(CommandFramework.Command command, String label, Method m, Object obj) {
/* 135 */     Map.Entry<Method, Object> entry = new AbstractMap.SimpleEntry<>(m, obj);
/* 136 */     this.commandMap.put(label.toLowerCase(), entry);
/* 137 */     String cmdLabel = label.replace(".", ",").split(",")[0].toLowerCase();
/*     */     
/* 139 */     this.plugin.getProxy().getPluginManager().registerCommand(this.plugin, new BungeeCommand(cmdLabel));
/*     */   }
/*     */   
/*     */   private void registerCompleter(String label, Method m, Object obj) {
/* 143 */     this.completers.put(label, new AbstractMap.SimpleEntry<>(m, obj));
/*     */   }
/*     */   
/*     */   private void defaultCommand(CommandArgs args) {
/* 147 */     args.getSender().sendMessage("§cComando do bungeecord inacessível!");
/*     */   }
/*     */   
/*     */   class BungeeCommand
/*     */     extends Command {
/*     */     protected BungeeCommand(String label) {
/* 153 */       super(label);
/*     */     }
/*     */     
/*     */     protected BungeeCommand(String label, String permission) {
/* 157 */       super(label, permission, new String[0]);
/*     */     }
/*     */ 
/*     */     
/*     */     public void execute(CommandSender sender, String[] args) {
/* 162 */       BungeeCommandFramework.this.handleCommand(sender, getName(), args);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public class BungeeCompleter
/*     */     implements Listener
/*     */   {
/*     */     @EventHandler
/*     */     public void onTabComplete(TabCompleteEvent event) {
/* 172 */       if (!(event.getSender() instanceof ProxiedPlayer)) {
/*     */         return;
/*     */       }
/* 175 */       ProxiedPlayer player = (ProxiedPlayer)event.getSender();
/* 176 */       String[] split = event.getCursor().replaceAll("\\s+", " ").split(" ");
/*     */       
/* 178 */       if (split.length == 0) {
/*     */         return;
/*     */       }
/* 181 */       String[] args = new String[split.length - 1];
/*     */       
/* 183 */       for (int i = 1; i < split.length; i++) {
/* 184 */         args[i - 1] = split[i];
/*     */       }
/*     */       
/* 187 */       String label = split[0].substring(1);
/*     */       
/* 189 */       for (int j = args.length; j >= 0; j--) {
/* 190 */         StringBuilder buffer = new StringBuilder();
/* 191 */         buffer.append(label.toLowerCase());
/*     */         
/* 193 */         for (int x = 0; x < j; x++) {
/* 194 */           buffer.append(".").append(args[x].toLowerCase());
/*     */         }
/*     */         
/* 197 */         String cmdLabel = buffer.toString();
/*     */         
/* 199 */         if (BungeeCommandFramework.this.completers.containsKey(cmdLabel)) {
/* 200 */           Map.Entry<Method, Object> entry = (Map.Entry<Method, Object>)BungeeCommandFramework.this.completers.get(cmdLabel);
/*     */           try {
/* 202 */             event.getSuggestions().clear();
/*     */             
/* 204 */             List<String> list = (List<String>)((Method)entry.getKey()).invoke(entry.getValue(), new Object[] { new BungeeCommandArgs((CommandSender)player, label, args, (cmdLabel
/* 205 */                     .split("\\.")).length - 1) });
/*     */             
/* 207 */             event.getSuggestions().addAll(list);
/* 208 */           } catch (IllegalArgumentException|IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 209 */             e.printStackTrace();
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getJarClass() {
/* 218 */     return this.plugin.getClass();
/*     */   }
/*     */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/command/BungeeCommandFramework.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */