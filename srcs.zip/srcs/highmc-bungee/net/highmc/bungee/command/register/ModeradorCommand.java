/*     */ package net.highmc.bungee.command.register;
/*     */ 
/*     */ import com.google.common.base.Joiner;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.OptionalInt;
/*     */ import java.util.stream.Collectors;
/*     */ import net.highmc.CommonConst;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bungee.BungeeMain;
/*     */ import net.highmc.bungee.member.BungeeMember;
/*     */ import net.highmc.command.CommandArgs;
/*     */ import net.highmc.command.CommandClass;
/*     */ import net.highmc.command.CommandFramework.Command;
/*     */ import net.highmc.command.CommandFramework.Completer;
/*     */ import net.highmc.command.CommandSender;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.server.ServerType;
/*     */ import net.highmc.server.loadbalancer.server.ProxiedServer;
/*     */ import net.highmc.utils.DateUtils;
/*     */ import net.highmc.utils.ProtocolVersion;
/*     */ import net.highmc.utils.string.MessageBuilder;
/*     */ import net.highmc.utils.string.StringFormat;
/*     */ import net.md_5.bungee.BungeeCord;
/*     */ import net.md_5.bungee.api.CommandSender;
/*     */ import net.md_5.bungee.api.ProxyServer;
/*     */ import net.md_5.bungee.api.chat.BaseComponent;
/*     */ import net.md_5.bungee.api.chat.ClickEvent;
/*     */ import net.md_5.bungee.api.chat.HoverEvent;
/*     */ import net.md_5.bungee.api.chat.TextComponent;
/*     */ import net.md_5.bungee.api.connection.ProxiedPlayer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModeradorCommand
/*     */   implements CommandClass
/*     */ {
/*     */   @Command(name = "fakelist", aliases = {"nicklist"}, permission = "command.fakelist")
/*     */   public void fakelistCommand(CommandArgs cmdArgs) {
/*  47 */     List<Member> list = (List<Member>)CommonPlugin.getInstance().getMemberManager().getMembers().stream().filter(member -> member.isUsingFake()).collect(Collectors.toList());
/*     */     
/*  49 */     if (list.isEmpty()) {
/*  50 */       cmdArgs.getSender().sendMessage("§cNinguém está usando fake.");
/*     */     } else {
/*  52 */       list.forEach(member -> cmdArgs.getSender().sendMessage("§a" + member.getPlayerName() + " está usando o fake " + member.getFakeName() + "."));
/*     */     } 
/*     */   }
/*     */   
/*     */   @Command(name = "glist", aliases = {"globallist", "serverinfo"}, permission = "command.glist")
/*     */   public void glistChatCommand(CommandArgs cmdArgs) {
/*  58 */     String[] args = cmdArgs.getArgs();
/*  59 */     CommandSender sender = cmdArgs.getSender();
/*     */     
/*  61 */     if (args.length == 0) {
/*     */       
/*  63 */       ProxiedServer[] servers = (ProxiedServer[])BungeeMain.getInstance().getServerManager().getServers().stream().sorted((o1, o2) -> o1.getServerId().compareTo(o2.getServerId())).toArray(x$0 -> new ProxiedServer[x$0]);
/*     */       
/*  65 */       sender.sendMessage(" §aServidor global: ");
/*  66 */       handleInfo(sender, ProxyServer.getInstance().getPlayers(), 
/*  67 */           (int)((System.currentTimeMillis() - ManagementFactory.getRuntimeMXBean().getStartTime()) / 1000L), 
/*  68 */           BungeeMain.getInstance().getPlayersRecord(), ServerType.BUNGEECORD);
/*     */       
/*  70 */       MessageBuilder messageBuilder1 = new MessageBuilder("    §fServidores: §7");
/*     */       
/*  72 */       for (int j = 0; j < Math.max(servers.length, 24); j++) {
/*  73 */         ProxiedServer server = servers[j];
/*  74 */         messageBuilder1
/*  75 */           .extra((new MessageBuilder("§7" + server.getServerId() + ((j == servers.length - 1) ? "." : ", ")))
/*  76 */             .setHoverEvent("§a" + server.getServerId() + "\n\n  §fPlayers: §7" + server
/*  77 */               .getOnlinePlayers() + " jogadores\n  §fMáximo de players: §7" + server
/*  78 */               .getMaxPlayers() + " jogadores\n  §fRecord de players: §7" + server
/*  79 */               .getPlayersRecord() + " jogadores\n  §fTipo de servidor: §7" + server
/*  80 */               .getServerType().getName() + "\n  §fLigado há: §7" + 
/*  81 */               StringFormat.formatTime(
/*  82 */                 (int)((System.currentTimeMillis() - server.getStartTime()) / 1000L), StringFormat.TimeFormat.NORMAL) + "\n\n§eClique para saber mais.")
/*     */ 
/*     */             
/*  85 */             .setClickEvent("/glist " + server.getServerId()).create());
/*     */       } 
/*     */       
/*  88 */       sender.sendMessage((BaseComponent)messageBuilder1.create());
/*     */       
/*     */       return;
/*     */     } 
/*  92 */     ProxiedServer proxiedServer = BungeeMain.getInstance().getServerManager().getServerByName(args[0]);
/*     */     
/*  94 */     if (proxiedServer == null || proxiedServer.getServerInfo() == null) {
/*  95 */       sender.sendMessage(sender.getLanguage().t("server-not-found", new String[] { "%server%", args[0] }));
/*     */       
/*     */       return;
/*     */     } 
/*  99 */     sender.sendMessage((BaseComponent)(new MessageBuilder(" §aServidor " + proxiedServer.getServerId() + ":"))
/* 100 */         .setHoverEvent("§eClique para se conectar.")
/* 101 */         .setClickEvent(ClickEvent.Action.SUGGEST_COMMAND, "/connect " + proxiedServer.getServerId()).create());
/*     */ 
/*     */     
/* 104 */     MessageBuilder messageBuilder = new MessageBuilder("    §f" + proxiedServer.getServerInfo().getPlayers().size() + " players: §7");
/*     */     
/* 106 */     int max = proxiedServer.getServerInfo().getPlayers().size() * 2;
/* 107 */     int i = max - 1;
/*     */     
/* 109 */     for (ProxiedPlayer player : proxiedServer.getServerInfo().getPlayers()) {
/* 110 */       if (i < max - 1) {
/* 111 */         messageBuilder.extra(new TextComponent("§f, "));
/* 112 */         i--;
/*     */       } 
/*     */       
/* 115 */       messageBuilder.extra((new MessageBuilder("§7" + player.getName()))
/* 116 */           .setClickEvent(ClickEvent.Action.RUN_COMMAND, "/tp " + player.getName())
/* 117 */           .setHoverEvent(HoverEvent.Action.SHOW_TEXT, "§eClique para teletransportar").create());
/* 118 */       i--;
/*     */     } 
/*     */     
/* 121 */     handleInfo(sender, proxiedServer.getServerInfo().getPlayers(), 
/* 122 */         (int)((System.currentTimeMillis() - proxiedServer.getStartTime()) / 1000L), proxiedServer
/* 123 */         .getPlayersRecord(), proxiedServer.getServerType());
/*     */   }
/*     */   
/*     */   @Command(name = "messagebroadcast.remove", permission = "staff.super")
/*     */   public void messagebroadcastremove(CommandArgs cmdArgs) {
/* 128 */     CommandSender sender = cmdArgs.getSender();
/* 129 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 131 */     if (args.length == 0) {
/* 132 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " remove <index> §fpara remover.");
/*     */       
/*     */       return;
/*     */     } 
/* 136 */     OptionalInt integer = StringFormat.parseInt(args[0]);
/*     */     
/* 138 */     if (integer.isPresent())
/* 139 */     { if (integer.getAsInt() >= 0 && integer.getAsInt() < BungeeMain.getInstance().getMessages().size()) {
/* 140 */         BungeeMain.getInstance().removeMessage(integer.getAsInt());
/* 141 */         sender.sendMessage("§aRemovido com sucesso.");
/*     */       } else {
/* 143 */         sender.sendMessage("§cNão existe.");
/*     */       }  }
/* 145 */     else { sender.sendMessage(sender.getLanguage().t("invalid-format-integer", new String[] { "%value%", args[0] })); }
/*     */   
/*     */   }
/*     */   @Command(name = "messagebroadcast", permission = "staff.super")
/*     */   public void messagebroadcast(CommandArgs cmdArgs) {
/* 150 */     CommandSender sender = cmdArgs.getSender();
/* 151 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 153 */     if (args.length == 0) {
/* 154 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " <message>§f ");
/*     */       
/* 156 */       for (int i = 1; i <= BungeeMain.getInstance().getMessages().size(); i++) {
/* 157 */         sender.sendMessage("  §a" + i + "° §f" + (String)BungeeMain.getInstance().getMessages().get(i - 1));
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 162 */     String message = Joiner.on(' ').join((Object[])args);
/*     */     
/* 164 */     BungeeMain.getInstance().addMessage(message.replace('&', '§'));
/* 165 */     sender.sendMessage("§a" + message.replace('&', '§') + " §aadicionada com sucesso.");
/*     */   }
/*     */   
/*     */   @Command(name = "mojang", permission = "command.mojang")
/*     */   public void mojangCommand(CommandArgs cmdArgs) {
/* 170 */     CommandSender sender = cmdArgs.getSender();
/*     */     
/* 172 */     int pirateCount = 0;
/* 173 */     int premiumCount = 0;
/* 174 */     int onlineCount = BungeeCord.getInstance().getPlayers().size();
/*     */     
/* 176 */     for (ProxiedPlayer player : BungeeCord.getInstance().getPlayers()) {
/* 177 */       if (player.getPendingConnection().isOnlineMode()) {
/* 178 */         premiumCount++; continue;
/*     */       } 
/* 180 */       pirateCount++;
/*     */     } 
/*     */     
/* 183 */     sender.sendMessage("  §aEstatísticas dos jogadores:");
/* 184 */     sender.sendMessage("    §fOriginais: §7" + premiumCount + " jogadores.");
/* 185 */     sender.sendMessage("    §fPiratas: §7" + pirateCount + " jogadores.");
/* 186 */     sender.sendMessage("    §fTotal online: §7" + onlineCount + " jogadores.");
/*     */   }
/*     */   
/*     */   @Command(name = "staffchat", aliases = {"sc"}, permission = "command.staff", console = false)
/*     */   public void staffChatCommand(CommandArgs cmdArgs) {
/* 191 */     Member member = cmdArgs.getSenderAsMember();
/*     */     
/* 193 */     member.getMemberConfiguration().setStaffChat(!member.getMemberConfiguration().isStaffChat());
/* 194 */     member.sendMessage("§%command.staffchat." + (
/* 195 */         member.getMemberConfiguration().isStaffChat() ? "enabled" : "disabled") + "%§");
/*     */   }
/*     */ 
/*     */   
/*     */   @Command(name = "stafflist", runAsync = true, permission = "command.staff", usage = "/<command> <player> <server>")
/*     */   public void stafflistCommand(CommandArgs cmdArgs) {
/* 201 */     CommandSender sender = cmdArgs.getSender();
/* 202 */     int groupId = sender.isPlayer() ? cmdArgs.getSenderAsMember().getServerGroup().getId() : Integer.MAX_VALUE;
/*     */     
/* 204 */     int ping = 0;
/* 205 */     long time = 0L;
/* 206 */     Map<ProtocolVersion, Integer> map = new HashMap<>();
/*     */ 
/*     */ 
/*     */     
/* 210 */     BungeeMember[] array = (BungeeMember[])CommonPlugin.getInstance().getMemberManager().getMembers(BungeeMember.class).stream().sorted((o1, o2) -> (o1.getServerGroup().getId() - o2.getServerGroup().getId()) * -1).filter(member -> (member.getServerGroup().isStaff() && groupId >= member.getServerGroup().getId())).toArray(x$0 -> new BungeeMember[x$0]);
/*     */     
/* 212 */     for (BungeeMember member : array) {
/* 213 */       ping += member.getProxiedPlayer().getPing();
/* 214 */       time += member.getSessionTime();
/*     */ 
/*     */       
/* 217 */       ProtocolVersion version = ProtocolVersion.getById(member.getProxiedPlayer().getPendingConnection().getVersion());
/*     */       
/* 219 */       map.putIfAbsent(version, Integer.valueOf(0));
/* 220 */       map.put(version, Integer.valueOf(((Integer)map.get(version)).intValue() + 1));
/*     */     } 
/*     */     
/* 223 */     ping /= Math.max(array.length, 1);
/* 224 */     time /= Math.max(array.length, 1);
/*     */     
/* 226 */     sender.sendMessage("  §aEquipe online:");
/* 227 */     sender.sendMessage("    §fTempo médio: §7" + StringFormat.formatTime((int)(time / 1000L), StringFormat.TimeFormat.NORMAL));
/* 228 */     sender.sendMessage("    §fPing médio: §7" + ping + "ms");
/* 229 */     sender.sendMessage("    §fEquipe: §7" + array.length + " online");
/*     */     
/* 231 */     MessageBuilder messageBuilder = new MessageBuilder("    §fPlayers: §7");
/*     */     
/* 233 */     for (int i = 0; i < array.length; i++) {
/* 234 */       BungeeMember member = array[i];
/* 235 */       messageBuilder.extra((new MessageBuilder("§7" + member.getDefaultTag().getRealPrefix() + member
/* 236 */             .getPlayerName() + ((i == array.length - 1) ? "." : ", ")))
/* 237 */           .setHoverEvent("§fTempo online: §7" + 
/* 238 */             StringFormat.formatTime((int)(member.getSessionTime() / 1000L), StringFormat.TimeFormat.NORMAL) + "\n§fPing: §7" + member
/* 239 */             .getProxiedPlayer().getPing() + "ms\n§fServidor: §7" + member
/* 240 */             .getActualServerId() + "")
/* 241 */           .setClickEvent(ClickEvent.Action.SUGGEST_COMMAND, "/teleport " + member
/* 242 */             .getProxiedPlayer().getName())
/* 243 */           .create());
/*     */     } 
/*     */     
/* 246 */     sender.sendMessage((BaseComponent)messageBuilder.create());
/*     */   }
/*     */   
/*     */   @Command(name = "broadcast", aliases = {"bc"}, permission = "command.broadcast")
/*     */   public void broadcastCommand(CommandArgs cmdArgs) {
/* 251 */     CommandSender sender = cmdArgs.getSender();
/* 252 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 254 */     if (args.length == 0) {
/* 255 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs
/* 256 */           .getLabel() + " <message>§f para enviar uma mensagem no servidor.");
/*     */       
/*     */       return;
/*     */     } 
/* 260 */     String message = Joiner.on(' ').join((Object[])args).replace('&', '§');
/*     */     
/* 262 */     ProxyServer.getInstance().broadcast("");
/* 263 */     ProxyServer.getInstance().broadcast("§6§lHIGH §8» §f" + message);
/* 264 */     ProxyServer.getInstance().broadcast("");
/* 265 */     staffLog("O " + sender.getName() + " mandou uma mensagem global na proxy.");
/*     */   }
/*     */   @Command(name = "bungeewhitelist", aliases = {"globalwhitelist", "gwhitelist", "bwhitelist"}, permission = "command.globalwhitelist")
/*     */   public void whitelistCommand(CommandArgs cmdArgs) {
/*     */     boolean enabled;
/*     */     long time;
/* 271 */     CommandSender sender = cmdArgs.getSender();
/* 272 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 274 */     if (args.length == 0) {
/* 275 */       sender.sendMessage("§%command.bungeecord.whitelist.usage%§");
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 281 */     switch (args[0].toLowerCase()) {
/*     */       case "off":
/*     */       case "on":
/* 284 */         enabled = args[0].equalsIgnoreCase("on");
/* 285 */         time = -1L;
/*     */         
/* 287 */         if (args.length >= 2) {
/* 288 */           time = DateUtils.getTime(args[1]).longValue();
/*     */         }
/* 290 */         BungeeMain.getInstance().setWhitelistEnabled(enabled, time);
/* 291 */         sender.sendMessage(sender.getLanguage().t("command.bungeecord.whitelist." + (enabled ? ("enabled" + ((time == -1L) ? "" : "-temporary") + "-success") : "disabled-success"), new String[] { "%time%", 
/*     */                 
/* 293 */                 DateUtils.getTime(sender.getLanguage(), time) }));
/*     */         return;
/*     */       
/*     */       case "add":
/* 297 */         if (args.length >= 2) {
/* 298 */           String playerName = args[1];
/*     */           
/* 300 */           if (BungeeMain.getInstance().isMemberInWhiteList(playerName)) {
/* 301 */             sender.sendMessage("já está");
/*     */             
/*     */             return;
/*     */           } 
/* 305 */           BungeeMain.getInstance().addMemberToWhiteList(playerName);
/* 306 */           sender.sendMessage("adicionado");
/*     */         } 
/*     */         return;
/*     */       
/*     */       case "remove":
/* 311 */         if (args.length >= 2) {
/* 312 */           String playerName = args[1];
/*     */           
/* 314 */           if (!BungeeMain.getInstance().isMemberInWhiteList(playerName)) {
/* 315 */             sender.sendMessage("não está");
/*     */             
/*     */             return;
/*     */           } 
/* 319 */           BungeeMain.getInstance().addMemberToWhiteList(playerName);
/* 320 */           sender.sendMessage("removido");
/*     */         } 
/*     */         return;
/*     */     } 
/*     */     
/* 325 */     sender.sendMessage("§%command.bungeecord.whitelist.usage%§");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Command(name = "bungee", permission = "command.bungee")
/*     */   public void bungeeCommand(CommandArgs cmdArgs) {
/* 332 */     CommandSender sender = cmdArgs.getSender();
/* 333 */     Language language = sender.getLanguage();
/* 334 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 336 */     if (args.length == 0) {
/* 337 */       sender.sendMessage("§%command-server-usage%§");
/*     */       
/*     */       return;
/*     */     } 
/* 341 */     switch (args[0].toLowerCase()) {
/*     */       case "reload-config":
/*     */         try {
/* 344 */           CommonPlugin.getInstance().loadConfig();
/* 345 */           sender.sendMessage(language.t("command-server-reload-config-successfully", new String[0]));
/* 346 */         } catch (Exception ex) {
/* 347 */           sender.sendMessage(language.t("command-server-reload-config-error", new String[0]));
/* 348 */           sender.sendMessage("§c" + ex.getLocalizedMessage());
/* 349 */           ex.printStackTrace();
/*     */         } 
/*     */         return;
/*     */       
/*     */       case "save-config":
/*     */         try {
/* 355 */           CommonPlugin.getInstance().saveConfig();
/* 356 */           sender.sendMessage(language.t("command-server-save-config-successfully", new String[0]));
/* 357 */         } catch (Exception ex) {
/* 358 */           sender.sendMessage(language.t("command-server-save-config-error", new String[0]));
/* 359 */           sender.sendMessage("§c" + ex.getLocalizedMessage());
/* 360 */           ex.printStackTrace();
/*     */         } 
/*     */         return;
/*     */     } 
/*     */     
/* 365 */     sender.sendMessage("§%command-server-usage%§");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Command(name = "find", permission = "command.find")
/*     */   public void findCommand(CommandArgs cmdArgs) {
/* 373 */     CommandSender sender = cmdArgs.getSender();
/* 374 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 376 */     if (args.length == 0) {
/* 377 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " <player>§f para saber aonde um jogador está.");
/*     */       
/*     */       return;
/*     */     } 
/* 381 */     String playerName = args[0];
/* 382 */     ProxiedPlayer target = ProxyServer.getInstance().getPlayer(playerName);
/*     */     
/* 384 */     if (target == null) {
/* 385 */       sender.sendMessage(sender.getLanguage().t("player-not-found", new String[] { "%player%", playerName }));
/*     */       
/*     */       return;
/*     */     } 
/* 389 */     sender.sendMessage((BaseComponent)(new MessageBuilder("§aO jogador " + target
/* 390 */           .getName() + " está na sala " + target.getServer().getInfo().getName() + "."))
/* 391 */         .setHoverEvent("§aClique para se conectar.").setClickEvent("/tp " + target.getName()).create());
/*     */   }
/*     */   
/*     */   @Command(name = "go", permission = "command.go", console = false)
/*     */   public void goCommand(CommandArgs cmdArgs) {
/* 396 */     CommandSender sender = cmdArgs.getSender();
/* 397 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 399 */     if (args.length == 0) {
/* 400 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " <player>§f para ir até um jogador.");
/*     */       
/*     */       return;
/*     */     } 
/* 404 */     String playerName = args[0];
/* 405 */     ProxiedPlayer target = ProxyServer.getInstance().getPlayer(playerName);
/*     */     
/* 407 */     if (target == null) {
/* 408 */       sender.sendMessage(sender.getLanguage().t("player-not-found", new String[] { "%player%", playerName }));
/*     */       
/*     */       return;
/*     */     } 
/* 412 */     ((BungeeMember)cmdArgs.getSenderAsMember(BungeeMember.class)).getProxiedPlayer().connect(target.getServer().getInfo());
/*     */   }
/*     */   
/*     */   @Command(name = "top", permission = "command.top")
/*     */   public void topCommand(CommandArgs cmdArgs) {
/* 417 */     CommandSender sender = cmdArgs.getSender();
/*     */     
/* 419 */     if ((cmdArgs.getArgs()).length > 0 && cmdArgs.getArgs()[0].equalsIgnoreCase("gc")) {
/* 420 */       Runtime.getRuntime().gc();
/* 421 */       sender.sendMessage("§aVocê passou o Garbage Collector do java no BungeeCord.");
/*     */       
/*     */       return;
/*     */     } 
/* 425 */     long usedMemory = (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 2L / 1048576L;
/* 426 */     long allocatedMemory = Runtime.getRuntime().totalMemory() / 1048576L;
/*     */     
/* 428 */     sender.sendMessage(" ");
/* 429 */     sender.sendMessage("  §aBungeeCord Usage Info:");
/* 430 */     sender.sendMessage("    §fMemória usada: §7" + usedMemory + "MB (" + (usedMemory * 100L / allocatedMemory) + "%)");
/*     */     
/* 432 */     sender.sendMessage("    §fMemória livre: §7" + (allocatedMemory - usedMemory) + "MB (" + ((allocatedMemory - usedMemory) * 100L / allocatedMemory) + "%)");
/*     */     
/* 434 */     sender.sendMessage("    §fMemória máxima: §7" + allocatedMemory + "MB");
/* 435 */     sender.sendMessage("    §fCPU: §7" + CommonConst.DECIMAL_FORMAT.format(CommonConst.getCpuUse()) + "%");
/* 436 */     sender.sendMessage("    §fPing médio: §7" + 
/* 437 */         BungeeMain.getInstance().getAveragePing(ProxyServer.getInstance().getPlayers()) + "ms.");
/*     */   }
/*     */   
/*     */   @Command(name = "send", permission = "command.send")
/*     */   public void sendCommand(CommandArgs cmdArgs) {
/* 442 */     CommandSender sender = cmdArgs.getSender();
/* 443 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 445 */     if (args.length <= 1) {
/* 446 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " <player:current:all> <serverId:serverType>§f para enviar um jogador para uma sala.");
/*     */       
/*     */       return;
/*     */     } 
/* 450 */     List<ProxiedPlayer> playerList = new ArrayList<>();
/*     */     
/* 452 */     if (args[0].equalsIgnoreCase("all")) {
/* 453 */       playerList.addAll(ProxyServer.getInstance().getPlayers());
/* 454 */     } else if (args[0].equalsIgnoreCase("current")) {
/* 455 */       if (cmdArgs.isPlayer()) {
/* 456 */         playerList.addAll(((BungeeMember)cmdArgs.getSenderAsMember(BungeeMember.class)).getProxiedPlayer().getServer().getInfo()
/* 457 */             .getPlayers());
/*     */       } else {
/* 459 */         sender.sendMessage("§%command-only-for-players%§");
/*     */         
/*     */         return;
/*     */       } 
/* 463 */     } else if (args[0].contains(",")) {
/* 464 */       String[] split = args[0].split(",");
/*     */       
/* 466 */       for (String playerName : split) {
/* 467 */         ProxiedPlayer player = ProxyServer.getInstance().getPlayer(playerName);
/*     */         
/* 469 */         if (player == null) {
/* 470 */           sender.sendMessage(sender.getLanguage().t("player-not-found", new String[] { "%player%", playerName }));
/*     */           
/*     */           return;
/*     */         } 
/* 474 */         playerList.add(player);
/*     */       } 
/*     */     } else {
/* 477 */       ProxiedPlayer player = ProxyServer.getInstance().getPlayer(args[0]);
/*     */       
/* 479 */       if (player == null) {
/* 480 */         sender.sendMessage(sender.getLanguage().t("player-not-found", new String[] { "%player%", args[0] }));
/*     */         
/*     */         return;
/*     */       } 
/* 484 */       playerList.add(player);
/*     */     } 
/*     */ 
/*     */     
/* 488 */     ServerType serverType = null;
/*     */     
/*     */     try {
/* 491 */       serverType = ServerType.valueOf(args[1].toUpperCase());
/* 492 */     } catch (Exception ex) {
/* 493 */       serverType = null;
/*     */     } 
/*     */     
/* 496 */     if (serverType == null) {
/* 497 */       ProxiedServer proxiedServer = BungeeMain.getInstance().getServerManager().getServerByName(args[1]);
/*     */       
/* 499 */       if (proxiedServer == null || proxiedServer.getServerInfo() == null) {
/* 500 */         sender.sendMessage(sender.getLanguage().t("server-not-found", new String[] { "%server%", args[1] }));
/*     */         
/*     */         return;
/*     */       } 
/* 504 */       playerList.forEach(player -> player.connect(proxiedServer.getServerInfo()));
/*     */       
/* 506 */       if (args[0].equalsIgnoreCase("current")) {
/* 507 */         sender.sendMessage("§aTodos os jogadores da sala foram enviados para o servidor " + proxiedServer.getServerId() + ".");
/* 508 */       } else if (args[0].equalsIgnoreCase("all")) {
/* 509 */         sender.sendMessage("§aTodos os jogadores foram enviados para o servidor " + proxiedServer.getServerId() + ".");
/*     */       } else {
/* 511 */         sender.sendMessage("§aOs jogadores " + (String)playerList.stream().map(CommandSender::getName).collect(Collectors.joining(", ")) + " foram enviados para o servidor " + proxiedServer.getServerId() + ".");
/*     */       } 
/*     */     } else {
/* 514 */       ServerType type = serverType;
/*     */       
/* 516 */       List<ProxiedServer> servers = BungeeMain.getInstance().getServerManager().getBalancer(type).getList();
/*     */       
/* 518 */       if (servers.isEmpty()) {
/* 519 */         sender.sendMessage(sender.getLanguage().t("server-not-found", new String[] { "%server%", type.name() }));
/*     */         
/*     */         return;
/*     */       } 
/* 523 */       int index = 0;
/*     */       
/* 525 */       for (ProxiedPlayer player : playerList) {
/* 526 */         player.connect(((ProxiedServer)servers.get(index)).getServerInfo());
/*     */         
/* 528 */         index++;
/*     */         
/* 530 */         if (index >= servers.size()) {
/* 531 */           index = 0;
/*     */         }
/*     */       } 
/*     */       
/* 535 */       if (args[0].equalsIgnoreCase("current")) {
/* 536 */         sender.sendMessage("§aTodos os jogadores da sala foram enviados para o servidor " + type.name() + ".");
/* 537 */       } else if (args[0].equalsIgnoreCase("all")) {
/* 538 */         sender.sendMessage("§aTodos os jogadores foram enviados para o servidor " + type.name() + ".");
/*     */       } else {
/* 540 */         sender.sendMessage("§aOs jogadores " + (String)playerList.stream().map(CommandSender::getName).collect(Collectors.joining(", ")) + " foram enviados para o servidor " + type.name() + ".");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void handleInfo(CommandSender sender, Collection<ProxiedPlayer> players, int onlineTime, int playersRecord, ServerType serverType) {
/* 547 */     sender.sendMessage("    §fPlayers: §7" + players.size() + " jogadores");
/* 548 */     sender.sendMessage("    §fRecord de players: §7" + playersRecord);
/*     */     
/* 550 */     int ping = 0;
/* 551 */     Map<ProtocolVersion, Integer> map = new HashMap<>();
/*     */     
/* 553 */     for (ProxiedPlayer player : players) {
/* 554 */       ping += player.getPing();
/*     */       
/* 556 */       ProtocolVersion version = ProtocolVersion.getById(player.getPendingConnection().getVersion());
/*     */       
/* 558 */       map.putIfAbsent(version, Integer.valueOf(0));
/* 559 */       map.put(version, Integer.valueOf(((Integer)map.get(version)).intValue() + 1));
/*     */     } 
/*     */     
/* 562 */     ping /= Math.max(players.size(), 1);
/*     */     
/* 564 */     sender.sendMessage("    §fPing médio: §7" + ping + "ms");
/*     */     
/* 566 */     if (!players.isEmpty()) {
/* 567 */       sender.sendMessage("    §fVersão: §7");
/*     */       
/* 569 */       for (Map.Entry<ProtocolVersion, Integer> entry : map.entrySet()) {
/* 570 */         sender.sendMessage("      §f- " + ((ProtocolVersion)entry.getKey()).name().replace("MINECRAFT_", "").replace("_", ".") + ": §7" + entry
/* 571 */             .getValue() + " jogadores");
/*     */       }
/*     */     } 
/*     */     
/* 575 */     if (serverType == ServerType.BUNGEECORD)
/* 576 */       sender.sendMessage("    §fTipo de servidor: §7" + serverType.getName()); 
/* 577 */     sender.sendMessage("    §fLigado há: §7" + StringFormat.formatTime(onlineTime, StringFormat.TimeFormat.NORMAL));
/*     */   }
/*     */   
/*     */   @Completer(name = "teleport", aliases = {"tp"})
/*     */   public List<String> teleportCompleter(CommandArgs cmdArgs) {
/* 582 */     if ((cmdArgs.getArgs()).length == 1) {
/* 583 */       return (List<String>)ProxyServer.getInstance().getPlayers().stream()
/* 584 */         .filter(player -> player.getName().toLowerCase().startsWith(cmdArgs.getArgs()[0].toLowerCase()))
/* 585 */         .map(CommandSender::getName).collect(Collectors.toList());
/*     */     }
/*     */     
/* 588 */     return new ArrayList<>();
/*     */   }
/*     */   
/*     */   @Completer(name = "send")
/*     */   public List<String> serverCompleter(CommandArgs cmdArgs) {
/* 593 */     List<String> stringList = new ArrayList<>();
/*     */     
/* 595 */     if ((cmdArgs.getArgs()).length == 1) {
/* 596 */       for (String possibilities : Arrays.<String>asList(new String[] { "all", "current" })) {
/* 597 */         if (possibilities.startsWith(cmdArgs.getArgs()[0].toLowerCase()))
/* 598 */           stringList.add(possibilities); 
/*     */       } 
/* 600 */       stringList.addAll((Collection<? extends String>)ProxyServer.getInstance().getPlayers().stream()
/* 601 */           .filter(player -> player.getName().toLowerCase().startsWith(cmdArgs.getArgs()[0].toLowerCase()))
/* 602 */           .map(CommandSender::getName).collect(Collectors.toList()));
/* 603 */     } else if ((cmdArgs.getArgs()).length == 2) {
/* 604 */       stringList.addAll((Collection<? extends String>)BungeeMain.getInstance().getServerManager().getActiveServers().values().stream()
/* 605 */           .filter(server -> server.getServerId().toLowerCase().startsWith(cmdArgs.getArgs()[1].toLowerCase()))
/* 606 */           .map(ProxiedServer::getServerId).collect(Collectors.toList()));
/* 607 */       stringList.addAll((Collection<? extends String>)Arrays.<ServerType>asList(ServerType.values()).stream()
/* 608 */           .filter(server -> server.name().toLowerCase().startsWith(cmdArgs.getArgs()[1].toLowerCase()))
/* 609 */           .map(Enum::name).collect(Collectors.toList()));
/*     */     } 
/*     */     
/* 612 */     return stringList;
/*     */   }
/*     */   
/*     */   @Completer(name = "find")
/*     */   public List<String> findCompleter(CommandArgs cmdArgs) {
/* 617 */     if ((cmdArgs.getArgs()).length == 1) {
/* 618 */       return (List<String>)ProxyServer.getInstance().getPlayers().stream()
/* 619 */         .filter(player -> player.getName().toLowerCase().startsWith(cmdArgs.getArgs()[0].toLowerCase()))
/* 620 */         .map(CommandSender::getName).collect(Collectors.toList());
/*     */     }
/*     */     
/* 623 */     return new ArrayList<>();
/*     */   }
/*     */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/command/register/ModeradorCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */