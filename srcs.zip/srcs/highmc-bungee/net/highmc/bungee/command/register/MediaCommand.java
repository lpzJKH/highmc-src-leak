/*     */ package net.highmc.bungee.command.register;
/*     */ 
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.command.CommandArgs;
/*     */ import net.highmc.command.CommandClass;
/*     */ import net.highmc.command.CommandFramework.Command;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.permission.Tag;
/*     */ import net.highmc.utils.string.MessageBuilder;
/*     */ import net.md_5.bungee.api.ProxyServer;
/*     */ import net.md_5.bungee.api.chat.BaseComponent;
/*     */ import net.md_5.bungee.api.chat.ClickEvent;
/*     */ 
/*     */ public class MediaCommand
/*     */   implements CommandClass
/*     */ {
/*     */   @Command(name = "youtube")
/*     */   public void youtubeCommand(CommandArgs cmdArgs) {
/*  19 */     Member sender = cmdArgs.getSenderAsMember();
/*  20 */     String[] args = cmdArgs.getArgs();
/*     */     
/*  22 */     if (args.length == 0) {
/*  23 */       sender.sendMessage(" §e» §fUse §a/" + cmdArgs
/*  24 */           .getLabel() + " <youtube>§f para alterar seu link do youtube.");
/*     */       
/*     */       return;
/*     */     } 
/*  28 */     String youtubeLink = args[0];
/*     */ 
/*     */     
/*  31 */     sender.setYoutubeUrl(youtubeLink);
/*  32 */     sender.sendMessage(" §a» §fVocê alterou seu link do youtube para §b" + youtubeLink + "§f.");
/*     */   }
/*     */   
/*     */   @Command(name = "twitch")
/*     */   public void twitchCommand(CommandArgs cmdArgs) {
/*  37 */     Member sender = cmdArgs.getSenderAsMember();
/*  38 */     String[] args = cmdArgs.getArgs();
/*     */     
/*  40 */     if (args.length == 0) {
/*  41 */       sender.sendMessage(" §e» §fUse §a/" + cmdArgs.getLabel() + " <twitch>§f para alterar seu link da twitch.");
/*     */       
/*     */       return;
/*     */     } 
/*  45 */     String twitchUrl = args[0];
/*     */     
/*  47 */     if (!twitchUrl.toLowerCase().contains("twitch.tv")) {
/*  48 */       twitchUrl = "twitch.tv/" + twitchUrl;
/*     */     }
/*  50 */     sender.setTwitchUrl(twitchUrl.toLowerCase());
/*  51 */     sender.sendMessage(" §a» §fVocê alterou seu link da twitch para §d" + twitchUrl.toLowerCase() + "§f.");
/*     */   }
/*     */   
/*     */   @Command(name = "stream", permission = "command.stream")
/*     */   public void streamCommand(CommandArgs cmdArgs) {
/*  56 */     Member sender = cmdArgs.getSenderAsMember();
/*     */     
/*  58 */     if (sender.hasTwitch()) {
/*  59 */       if (sender.hasCooldown("command-stream") && !sender.hasPermission("staff.super")) {
/*  60 */         sender.sendMessage("§cVocê precisa esperar " + sender.getCooldownFormatted("command-stream") + " para usar esse comando novamente.");
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*  65 */       Tag tag = CommonPlugin.getInstance().getPluginInfo().getTagByName(sender.getServerGroup().getGroupName());
/*     */       
/*  67 */       if (tag == null) {
/*  68 */         sender.sendMessage("§cO servidor não encontrou a sua tag.");
/*     */         
/*     */         return;
/*     */       } 
/*  72 */       ProxyServer.getInstance().broadcast(" ");
/*  73 */       ProxyServer.getInstance()
/*  74 */         .broadcast((BaseComponent)(new MessageBuilder("§6§lHIGH §8» §fO nosso " + tag.getRealPrefix() + sender
/*  75 */             .getName() + "§f está em live agora! §bClique aqui para acompanhar."))
/*  76 */           .setHoverEvent("§eClique para abrir o link no navegador.")
/*  77 */           .setClickEvent(ClickEvent.Action.OPEN_URL, 
/*  78 */             sender.getTwitchUrl().toLowerCase().startsWith("http") ? sender.getTwitchUrl() : ("https://" + sender
/*  79 */             .getTwitchUrl()))
/*  80 */           .create());
/*  81 */       ProxyServer.getInstance().broadcast(" ");
/*  82 */       sender.putCooldown("command-stream", 300L);
/*     */     } else {
/*  84 */       sender.sendMessage("§cVocê ainda não registrou a sua Twitch. Use /twitch");
/*     */     } 
/*     */   }
/*     */   
/*     */   @Command(name = "record", aliases = {"record"}, permission = "command.record")
/*     */   public void recordCommand(CommandArgs cmdArgs) {
/*  90 */     Member sender = cmdArgs.getSenderAsMember();
/*     */     
/*  92 */     if (sender.hasCooldown("command-stream") && !sender.hasPermission("staff.super")) {
/*  93 */       sender.sendMessage("§cVocê precisa esperar " + sender.getCooldownFormatted("command-stream") + " para usar esse comando novamente.");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  98 */     Tag tag = CommonPlugin.getInstance().getPluginInfo().getTagByName(sender.getServerGroup().getGroupName());
/*     */     
/* 100 */     if (tag == null) {
/* 101 */       sender.sendMessage("§cO servidor não encontrou a sua tag.");
/*     */       
/*     */       return;
/*     */     } 
/* 105 */     ProxyServer.getInstance().broadcast(" ");
/* 106 */     ProxyServer.getInstance()
/* 107 */       .broadcast((BaseComponent)(new MessageBuilder("§6§lHIGH §8» §fO nosso " + tag.getRealPrefix() + sender
/* 108 */           .getName() + "§f está gravando no " + sender.getActualServerId() + "! §bClique aqui para se conectar."))
/* 109 */         .setHoverEvent("§eClique aqui para se conectar.")
/* 110 */         .setClickEvent(ClickEvent.Action.RUN_COMMAND, "/connect " + sender.getActualServerId())
/* 111 */         .create());
/* 112 */     ProxyServer.getInstance().broadcast(" ");
/* 113 */     sender.putCooldown("command-stream", 300L);
/*     */   }
/*     */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/command/register/MediaCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */