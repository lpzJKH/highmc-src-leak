/*     */ package net.highmc.bungee.command.register;
/*     */ 
/*     */ import com.google.common.base.Joiner;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.PluginInfo;
/*     */ import net.highmc.bungee.event.player.PlayerPardonedEvent;
/*     */ import net.highmc.bungee.event.player.PlayerPunishEvent;
/*     */ import net.highmc.bungee.member.BungeeMember;
/*     */ import net.highmc.command.CommandArgs;
/*     */ import net.highmc.command.CommandClass;
/*     */ import net.highmc.command.CommandFramework.Command;
/*     */ import net.highmc.command.CommandFramework.Completer;
/*     */ import net.highmc.command.CommandSender;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.punish.Punish;
/*     */ import net.highmc.punish.PunishType;
/*     */ import net.highmc.utils.DateUtils;
/*     */ import net.highmc.utils.string.StringFormat;
/*     */ import net.md_5.bungee.api.CommandSender;
/*     */ import net.md_5.bungee.api.ProxyServer;
/*     */ import net.md_5.bungee.api.connection.ProxiedPlayer;
/*     */ import net.md_5.bungee.api.plugin.Event;
/*     */ 
/*     */ public class PunishCommand
/*     */   implements CommandClass
/*     */ {
/*     */   @Command(name = "pardon", aliases = {"unpunish"}, permission = "command.pardon", runAsync = true)
/*     */   public void pardonCommand(CommandArgs cmdArgs) {
/*  33 */     CommandSender sender = cmdArgs.getSender();
/*  34 */     String[] args = cmdArgs.getArgs();
/*     */     
/*  36 */     if (args.length <= 1) {
/*  37 */       sender.sendMessage(PluginInfo.t(sender, "command.pardon.usage", new String[] { "%label%", cmdArgs.getLabel() }));
/*     */       
/*     */       return;
/*     */     } 
/*  41 */     pardon(sender, args, null);
/*     */   }
/*     */   
/*     */   @Command(name = "unban", permission = "command.pardon")
/*     */   public void unbanCommand(CommandArgs cmdArgs) {
/*  46 */     CommandSender sender = cmdArgs.getSender();
/*  47 */     String[] args = cmdArgs.getArgs();
/*     */     
/*  49 */     if (args.length == 0) {
/*  50 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " <player>§f para desbanir o jogador.");
/*     */       
/*     */       return;
/*     */     } 
/*  54 */     pardon(sender, args, PunishType.BAN);
/*     */   }
/*     */   
/*     */   @Command(name = "unmute", permission = "command.unmute")
/*     */   public void unmuteCommand(CommandArgs cmdArgs) {
/*  59 */     CommandSender sender = cmdArgs.getSender();
/*  60 */     String[] args = cmdArgs.getArgs();
/*     */     
/*  62 */     if (args.length == 0) {
/*  63 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " <player>§f para desmutar o jogador.");
/*     */       
/*     */       return;
/*     */     } 
/*  67 */     pardon(sender, args, PunishType.MUTE);
/*     */   }
/*     */   @Command(name = "punish", aliases = {"punir"}, permission = "command.punish", runAsync = true)
/*     */   public void punishCommand(CommandArgs cmdArgs) {
/*     */     String reason;
/*  72 */     CommandSender sender = cmdArgs.getSender();
/*  73 */     String[] args = cmdArgs.getArgs();
/*     */ 
/*     */ 
/*     */     
/*  77 */     if (args.length <= 2) {
/*  78 */       sender.sendMessage(PluginInfo.t(sender, "command.punish.usage", new String[] { "%label%", cmdArgs.getLabel() }));
/*     */       
/*     */       return;
/*     */     } 
/*  82 */     PunishType punishType = null;
/*     */     
/*     */     try {
/*  85 */       punishType = PunishType.valueOf(args[1].toUpperCase());
/*  86 */     } catch (Exception ex) {
/*  87 */       sender.sendMessage(PluginInfo.t(sender, "command.punish.type-not-exist", new String[] { "%type%", args[1] }));
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  93 */     if (args.length == 3) {
/*  94 */       reason = sender.getLanguage().t((punishType == PunishType.KICK) ? "no-reason" : "defaut-ban", new String[0]);
/*     */     } else {
/*  96 */       reason = Joiner.on(' ').join(Arrays.copyOfRange((Object[])args, 3, args.length));
/*     */     } 
/*  98 */     punish(sender, args[0], punishType, reason, (args[2]
/*  99 */         .equals("0") || args[2].equals("never")) ? -1L : DateUtils.getTime(args[2]).longValue());
/*     */   }
/*     */ 
/*     */   
/*     */   @Command(name = "mute", aliases = {"ban", "tempban", "tempmute", "kick"}, permission = "command.mute", runAsync = true)
/*     */   public void banMuteCommand(CommandArgs cmdArgs) {
/* 105 */     CommandSender sender = cmdArgs.getSender();
/* 106 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 108 */     boolean temp = cmdArgs.getLabel().toLowerCase().contains("temp");
/*     */     
/* 110 */     if (args.length <= (temp ? 1 : 0)) {
/* 111 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " <player> " + (temp ? "<tempo> " : "") + " <motivo>§f para punir alguém.");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 116 */     punish(sender, args[0], PunishType.valueOf(cmdArgs.getLabel().toUpperCase().replace("TEMP", "")), (args.length == (temp ? 2 : 1)) ? sender
/*     */         
/* 118 */         .getLanguage()
/* 119 */         .t(cmdArgs.getLabel().equalsIgnoreCase("kick") ? "no-reason" : "defaut-ban", new String[0]) : 
/* 120 */         Joiner.on(' ').join(Arrays.copyOfRange((Object[])args, temp ? 2 : 1, args.length)), temp ? 
/* 121 */         DateUtils.getTime(args[1]).longValue() : -1L);
/*     */   }
/*     */   
/*     */   public void punish(CommandSender sender, String playerName, PunishType punishType, String reason, long expireTime) {
/* 125 */     Member target = CommonPlugin.getInstance().getMemberManager().getMemberByName(playerName);
/*     */     
/* 127 */     if (target == null) {
/* 128 */       target = CommonPlugin.getInstance().getMemberData().loadMember(playerName, true);
/*     */       
/* 130 */       if (target == null) {
/* 131 */         sender.sendMessage(sender.getLanguage().t("player-not-found", new String[] { "%player%", playerName }));
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 136 */     if (target.getServerGroup().getId() >= sender.getServerGroup().getId() && sender.isPlayer()) {
/* 137 */       sender.sendMessage("§cVocê não pode banir cargo superior.");
/*     */       
/*     */       return;
/*     */     } 
/* 141 */     if (punishType != PunishType.KICK && target.getPunishConfiguration().getActualPunish(punishType) != null) {
/* 142 */       sender.sendMessage(PluginInfo.t(sender, "command.punish.already-punished", new String[] { "%type%", 
/* 143 */               StringFormat.formatString(punishType.name()), "%player%", target.getName() }));
/*     */       
/*     */       return;
/*     */     } 
/* 147 */     boolean permanent = (expireTime == -1L);
/* 148 */     Punish punish = new Punish((CommandSender)target, sender, reason, expireTime, punishType);
/*     */     
/* 150 */     switch (punish.getPunishType()) {
/*     */       case BAN:
/* 152 */         banPlayer(target, punish);
/*     */         break;
/*     */       
/*     */       case KICK:
/* 156 */         if (!target.isOnline()) {
/* 157 */           sender.sendMessage(PluginInfo.t(sender, "player-is-not-online", new String[] { "%player%", target.getPlayerName() }));
/*     */           
/*     */           return;
/*     */         } 
/* 161 */         kickPlayer(target, punish);
/*     */         break;
/*     */       
/*     */       case MUTE:
/* 165 */         target.sendMessage(PluginInfo.t(sender, "mute-message", new String[] { "%reason%", punish.getPunishReason(), "%expireAt%", 
/* 166 */                 DateUtils.getTime(target.getLanguage(), punish.getExpireAt()), "%punisher%", punish
/* 167 */                 .getPunisherName(), "%website%", CommonPlugin.getInstance().getPluginInfo().getWebsite(), "%store%", 
/* 168 */                 CommonPlugin.getInstance().getPluginInfo().getStore(), "%discord%", 
/* 169 */                 CommonPlugin.getInstance().getPluginInfo().getDiscord() }));
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 174 */     target.getPunishConfiguration().punish(punish);
/* 175 */     target.saveConfig();
/* 176 */     sender.sendMessage(PluginInfo.t(sender, "command.punish.success-" + punishType
/* 177 */           .name().toLowerCase() + "-" + (permanent ? "permanent" : "temporary"), new String[] { "%player%", target
/*     */             
/* 179 */             .getName(), "%reason%", reason, "%time%", 
/* 180 */             DateUtils.getTime(sender.getLanguage(), expireTime) }));
/* 181 */     ProxyServer.getInstance().getPluginManager().callEvent((Event)new PlayerPunishEvent(target, punish, sender));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Completer(name = "ban", aliases = {"mute", "tempban", "tempmute", "tempbanir", "tempmutar", "punish", "pardon", "punir", "perdoar"})
/*     */   public List<String> punishCompleter(CommandArgs cmdArgs) {
/* 188 */     switch ((cmdArgs.getArgs()).length) {
/*     */       case 1:
/* 190 */         return (List<String>)ProxyServer.getInstance().getPlayers().stream()
/* 191 */           .filter(player -> player.getName().toLowerCase().startsWith(cmdArgs.getArgs()[0].toLowerCase()))
/* 192 */           .map(CommandSender::getName).collect(Collectors.toList());
/*     */       case 2:
/* 194 */         if (cmdArgs.getLabel().equalsIgnoreCase("punish"))
/* 195 */           return (List<String>)Arrays.<PunishType>asList(PunishType.values()).stream()
/* 196 */             .filter(type -> type.name().toLowerCase().startsWith(cmdArgs.getArgs()[0].toLowerCase()))
/* 197 */             .map(Enum::name).collect(Collectors.toList());  break;
/*     */     } 
/* 199 */     return new ArrayList<>();
/*     */   }
/*     */ 
/*     */   
/*     */   private void kickPlayer(Member target, Punish punish) {
/* 204 */     if (!(target instanceof BungeeMember)) {
/*     */       return;
/*     */     }
/* 207 */     BungeeMember bungeeMember = (BungeeMember)target;
/* 208 */     ProxiedPlayer player = bungeeMember.getProxiedPlayer();
/*     */     
/* 210 */     if (player != null)
/* 211 */       player.disconnect(PluginInfo.t((CommandSender)bungeeMember, "kick-message", new String[] { "%reason%", punish.getPunishReason(), "%punisher%", punish
/* 212 */               .getPunisherName(), "%website%", CommonPlugin.getInstance().getPluginInfo().getWebsite(), "%store%", 
/* 213 */               CommonPlugin.getInstance().getPluginInfo().getStore(), "%discord%", 
/* 214 */               CommonPlugin.getInstance().getPluginInfo().getDiscord() })); 
/*     */   }
/*     */   
/*     */   public void banPlayer(Member target, Punish punish) {
/* 218 */     CommonPlugin.getInstance().getReportManager().notify(target.getUniqueId());
/*     */     
/* 220 */     if (!target.isOnline()) {
/*     */       return;
/*     */     }
/* 223 */     BungeeMember bungeeMember = (BungeeMember)target;
/* 224 */     ProxiedPlayer player = bungeeMember.getProxiedPlayer();
/*     */     
/* 226 */     if (player != null)
/* 227 */       player.disconnect(PluginInfo.t((CommandSender)bungeeMember, "ban-" + (
/* 228 */             punish.isPermanent() ? "permanent" : "temporary") + "-kick-message", new String[] { "%reason%", punish
/* 229 */               .getPunishReason(), "%expireAt%", 
/* 230 */               DateUtils.getTime(bungeeMember.getLanguage(), punish.getExpireAt()), "%punisher%", punish
/* 231 */               .getPunisherName(), "%website%", CommonPlugin.getInstance().getPluginInfo().getWebsite(), "%store%", 
/* 232 */               CommonPlugin.getInstance().getPluginInfo().getStore(), "%discord%", 
/* 233 */               CommonPlugin.getInstance().getPluginInfo().getDiscord() })); 
/*     */   }
/*     */   
/*     */   private void pardon(CommandSender sender, String[] args, PunishType punishType) {
/* 237 */     Member target = CommonPlugin.getInstance().getMemberManager().getMemberByName(args[0]);
/*     */     
/* 239 */     if (target == null) {
/* 240 */       target = CommonPlugin.getInstance().getMemberData().loadMember(args[0], true);
/*     */       
/* 242 */       if (target == null) {
/* 243 */         sender.sendMessage(sender.getLanguage().t("player-not-found", new String[] { "%player%", args[0] }));
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 248 */     if (punishType == null) {
/*     */       try {
/* 250 */         punishType = PunishType.valueOf(args[1].toUpperCase());
/* 251 */       } catch (Exception exception) {}
/*     */     }
/*     */ 
/*     */     
/* 255 */     if (punishType == null || punishType == PunishType.KICK) {
/* 256 */       sender.sendMessage(PluginInfo.t(sender, "command.punish.type-not-exist", new String[] { "%type%", args[1] }));
/*     */       
/*     */       return;
/*     */     } 
/* 260 */     Punish actualPunish = target.getPunishConfiguration().getActualPunish(punishType);
/*     */     
/* 262 */     if (actualPunish == null) {
/* 263 */       sender.sendMessage(PluginInfo.t(sender, "command.pardon.no-punish-found", new String[] { "%type%", 
/* 264 */               StringFormat.formatString(punishType.name()), "%player%", target.getName() }));
/*     */       
/*     */       return;
/*     */     } 
/* 268 */     if (target.getPunishConfiguration().pardon(actualPunish, sender)) {
/* 269 */       sender.sendMessage(PluginInfo.t(sender, "command.pardon.success", new String[] { "%type%", 
/* 270 */               StringFormat.formatString(punishType.name()), "%player%", target.getName() }));
/* 271 */       target.saveConfig();
/* 272 */       ProxyServer.getInstance().getPluginManager()
/* 273 */         .callEvent((Event)new PlayerPardonedEvent(target, actualPunish, sender));
/*     */       
/*     */       return;
/*     */     } 
/* 277 */     sender.sendMessage(PluginInfo.t(sender, "command.pardon.failed", new String[] { "%type%", StringFormat.formatString(punishType.name()), "%player%", target
/* 278 */             .getName() }));
/*     */   }
/*     */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/command/register/PunishCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */