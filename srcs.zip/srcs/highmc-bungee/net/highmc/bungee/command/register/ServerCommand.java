/*     */ package net.highmc.bungee.command.register;
/*     */ 
/*     */ import com.google.common.base.Joiner;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bungee.BungeeMain;
/*     */ import net.highmc.bungee.member.BungeeMember;
/*     */ import net.highmc.command.CommandArgs;
/*     */ import net.highmc.command.CommandClass;
/*     */ import net.highmc.command.CommandFramework.Command;
/*     */ import net.highmc.command.CommandFramework.Completer;
/*     */ import net.highmc.command.CommandSender;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.report.Report;
/*     */ import net.highmc.report.ReportInfo;
/*     */ import net.highmc.server.ServerType;
/*     */ import net.highmc.server.loadbalancer.server.ProxiedServer;
/*     */ import net.highmc.utils.DateUtils;
/*     */ import net.md_5.bungee.api.CommandSender;
/*     */ import net.md_5.bungee.api.ProxyServer;
/*     */ import net.md_5.bungee.api.connection.ProxiedPlayer;
/*     */ 
/*     */ public class ServerCommand
/*     */   implements CommandClass {
/*     */   @Command(name = "ping", aliases = {"latency"})
/*     */   public void pingCommand(CommandArgs cmdArgs) {
/*  31 */     CommandSender sender = cmdArgs.getSender();
/*  32 */     String[] args = cmdArgs.getArgs();
/*     */     
/*  34 */     if (args.length == 0)
/*  35 */     { if (sender.isPlayer()) {
/*  36 */         sender.sendMessage(sender.getLanguage().t("command-ping-your-latency", new String[] { "%ping%", 
/*  37 */                 String.valueOf(((BungeeMember)cmdArgs.getSenderAsMember(BungeeMember.class)).getProxiedPlayer().getPing()) }));
/*     */       } else {
/*  39 */         sender.sendMessage("§aO ping médio do servidor é de " + 
/*  40 */             BungeeMain.getInstance().getAveragePing(ProxyServer.getInstance().getPlayers()) + "ms.");
/*     */       }  }
/*  42 */     else { ProxiedPlayer player = ProxyServer.getInstance().getPlayer(args[0]);
/*     */       
/*  44 */       if (player == null) {
/*  45 */         sender.sendMessage(sender.getLanguage().t("player-not-found", new String[] { "%player%", args[0] }));
/*     */       } else {
/*  47 */         sender.sendMessage(sender.getLanguage().t("command-ping-player-latency", new String[] { "%player%", player.getName(), "%ping%", 
/*  48 */                 String.valueOf(player.getPing()) }));
/*     */       }  }
/*     */   
/*     */   }
/*     */   @Command(name = "report", aliases = {"rp"})
/*     */   public void reportCommand(CommandArgs cmdArgs) {
/*  54 */     CommandSender sender = cmdArgs.getSender();
/*  55 */     String[] args = cmdArgs.getArgs();
/*     */     
/*  57 */     if (args.length <= 1) {
/*  58 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs
/*  59 */           .getLabel() + " <player> <reason>§f para reportar um jogador.");
/*     */       
/*     */       return;
/*     */     } 
/*  63 */     Member target = CommonPlugin.getInstance().getMemberManager().getMemberByName(args[0]);
/*     */     
/*  65 */     if (target == null) {
/*  66 */       sender.sendMessage(sender.getLanguage().t("player-is-not-online", new String[] { "%player%", args[0] }));
/*     */       
/*     */       return;
/*     */     } 
/*  70 */     String reason = Joiner.on(' ').join(Arrays.copyOfRange((Object[])args, 1, args.length));
/*  71 */     Report report = CommonPlugin.getInstance().getReportManager().getReportById(target.getUniqueId());
/*     */     
/*  73 */     if (report == null) {
/*  74 */       report = new Report(target, sender, reason, target.isOnline());
/*  75 */       CommonPlugin.getInstance().getReportManager().createReport(report);
/*     */     } else {
/*  77 */       if (report.getReportMap().containsKey(sender.getUniqueId()) && ((ReportInfo)report
/*  78 */         .getReportMap().get(sender.getUniqueId())).getCreatedAt() + 300000L > 
/*  79 */         System.currentTimeMillis()) {
/*  80 */         sender.sendMessage("§cVocê precisa esperar para reportar esse usuário novamente.");
/*     */         
/*     */         return;
/*     */       } 
/*  84 */       report.addReport(sender, reason);
/*     */     } 
/*     */     
/*  87 */     sender.sendMessage("§aSua denúncia sobre o jogador " + target.getPlayerName() + " foi enviada ao servidor.");
/*  88 */     CommonPlugin.getInstance().getMemberManager().actionbar("§aUma nova denúncia foi registrada.", "command.report");
/*     */     
/*  90 */     CommonPlugin.getInstance().getMemberManager().getMembers().stream()
/*  91 */       .filter(m -> (m.isStaff() && m.getMemberConfiguration().isReportsEnabled()))
/*  92 */       .forEach(m -> m.sendMessage("§eO jogador " + sender.getName() + " denunciou o jogador " + target.getName() + " por " + reason));
/*     */   }
/*     */ 
/*     */   
/*     */   @Command(name = "server", aliases = {"connect"}, console = false)
/*     */   public void serverCommand(CommandArgs cmdArgs) {
/*  98 */     BungeeMember member = (BungeeMember)cmdArgs.getSenderAsMember(BungeeMember.class);
/*  99 */     ProxiedPlayer player = member.getProxiedPlayer();
/* 100 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 102 */     if (args.length == 0) {
/* 103 */       player.sendMessage(member.getLanguage().t("command-server-usage", new String[0]));
/*     */       
/*     */       return;
/*     */     } 
/* 107 */     String serverId = args[0];
/* 108 */     ProxiedServer server = BungeeMain.getInstance().getServerManager().getServerByName(serverId);
/*     */     
/* 110 */     if (server == null || server.getServerInfo() == null) {
/* 111 */       player.sendMessage(member.getLanguage().t("server-not-available", new String[0]));
/*     */       
/*     */       return;
/*     */     } 
/* 115 */     if (server.isFull() && !member.hasPermission("server.full")) {
/* 116 */       player.sendMessage(member.getLanguage().t("server-is-full", new String[0]));
/*     */       
/*     */       return;
/*     */     } 
/* 120 */     player.connect(server.getServerInfo());
/*     */   }
/*     */   
/*     */   @Command(name = "evento", console = false)
/*     */   public void eventoCommand(CommandArgs cmdArgs) {
/* 125 */     BungeeMember member = (BungeeMember)cmdArgs.getSenderAsMember(BungeeMember.class);
/* 126 */     ProxiedPlayer player = member.getProxiedPlayer();
/* 127 */     ProxiedServer server = (ProxiedServer)BungeeMain.getInstance().getServerManager().getBalancer(ServerType.EVENTO).next();
/*     */     
/* 129 */     if (server == null || server.getServerInfo() == null) {
/* 130 */       player.sendMessage(member.getLanguage().t("server-not-available", new String[0]));
/*     */       
/*     */       return;
/*     */     } 
/* 134 */     if (server.isFull() && !member.hasPermission("server.full")) {
/* 135 */       player.sendMessage(member.getLanguage().t("server-is-full", new String[0]));
/*     */       
/*     */       return;
/*     */     } 
/* 139 */     player.connect(server.getServerInfo());
/*     */   }
/*     */   
/*     */   @Command(name = "lobby", aliases = {"hub", "l"}, console = false)
/*     */   public void lobbyCommand(CommandArgs cmdArgs) {
/* 144 */     BungeeMember member = (BungeeMember)cmdArgs.getSenderAsMember(BungeeMember.class);
/* 145 */     ProxiedPlayer player = member.getProxiedPlayer();
/*     */ 
/*     */     
/* 148 */     ProxiedServer server = (ProxiedServer)BungeeMain.getInstance().getServerManager().getBalancer(BungeeMain.getInstance().getServerManager().getServer(player.getServer().getInfo().getName()).getServerType().getServerLobby()).next();
/*     */     
/* 150 */     if (server == null || server.getServerInfo() == null) {
/* 151 */       player.sendMessage(member.getLanguage().t("server-not-available", new String[0]));
/*     */       
/*     */       return;
/*     */     } 
/* 155 */     if (server.isFull() && !member.hasPermission("server.full")) {
/* 156 */       player.sendMessage(member.getLanguage().t("server-is-full", new String[0]));
/*     */       
/*     */       return;
/*     */     } 
/* 160 */     player.connect(server.getServerInfo());
/*     */   }
/*     */   
/*     */   @Command(name = "play", aliases = {"jogar"}, console = false)
/*     */   public void playCommand(CommandArgs cmdArgs) {
/* 165 */     ProxiedPlayer player = ((BungeeMember)cmdArgs.getSenderAsMember(BungeeMember.class)).getProxiedPlayer();
/* 166 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 168 */     if (args.length == 0) {
/* 169 */       player.sendMessage(cmdArgs.getSender().getLanguage().t("command.play.usage", new String[0]));
/*     */       
/*     */       return;
/*     */     } 
/* 173 */     ServerType serverType = ServerType.getTypeByName(Joiner.on(' ').join((Object[])args).replace(" ", "_"));
/*     */     
/* 175 */     if (serverType == null) {
/* 176 */       player.sendMessage("§cEsse servidor não existe.");
/*     */       
/*     */       return;
/*     */     } 
/* 180 */     ProxiedServer server = (ProxiedServer)BungeeMain.getInstance().getServerManager().getBalancer(serverType).next();
/* 181 */     Language language = cmdArgs.getSender().getLanguage();
/*     */     
/* 183 */     if (server == null || server.getServerInfo() == null) {
/* 184 */       player.sendMessage("§cNenhum servidor desse modo está disponível no momento.");
/*     */       
/*     */       return;
/*     */     } 
/* 188 */     if (server.isFull() && !player.hasPermission("server.full")) {
/* 189 */       player.sendMessage(language.t("server-is-full", new String[0]));
/*     */       
/*     */       return;
/*     */     } 
/* 193 */     player.connect(server.getServerInfo());
/*     */   }
/*     */   @Command(name = "bwhitelist", aliases = {"bungeewhitelist", "gwhitelist", "maintenance", "manutencao"}, permission = "command.whitelist")
/*     */   public void bwhitelistChatCommand(CommandArgs cmdArgs) {
/*     */     Long time;
/*     */     Member member;
/* 199 */     String[] args = cmdArgs.getArgs();
/* 200 */     CommandSender sender = cmdArgs.getSender();
/*     */     
/* 202 */     if (args.length == 0) {
/* 203 */       sender.sendMessage(" §e» §fUse /" + cmdArgs.getLabel() + " <on:off> <time> para ativar ou desativar a whitelist global.");
/*     */       
/* 205 */       sender.sendMessage(" §e» §fUse /" + cmdArgs
/* 206 */           .getLabel() + " add <player> para adicionar alguem a whitelist.");
/* 207 */       sender.sendMessage(" §e» §fUse /" + cmdArgs
/* 208 */           .getLabel() + " remove <player> para remover alguem da whitelist.");
/* 209 */       sender.sendMessage(" §e» §fUse /" + cmdArgs.getLabel() + " group <beta:staff:group> para definir qual grupo irá entrar no servidor.");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 214 */     switch (args[0].toLowerCase()) {
/*     */       case "on":
/* 216 */         time = Long.valueOf(0L);
/*     */         
/* 218 */         if (args.length > 1) {
/* 219 */           time = DateUtils.getTime(args[1]);
/*     */         }
/* 221 */         BungeeMain.getInstance().setWhitelistEnabled(true, time.longValue());
/* 222 */         sender.sendMessage(" §a» §fVocê §aativou§f a whitelist!");
/*     */         
/* 224 */         CommonPlugin.getInstance().getMemberManager().getMembers(BungeeMember.class).stream()
/* 225 */           .filter(bungee -> !bungee.hasPermission("command.admin"))
/* 226 */           .forEach(bungee -> bungee.getProxiedPlayer().disconnect("§cO servidor entrou em manutenção."));
/*     */         break;
/*     */       
/*     */       case "off":
/* 230 */         BungeeMain.getInstance().setWhitelistEnabled(false, 0L);
/* 231 */         sender.sendMessage(" §a» §fVocê §cdesativou§f a whitelist!");
/*     */         break;
/*     */       
/*     */       case "add":
/* 235 */         if (args.length == 1) {
/* 236 */           sender.sendMessage(" §e» §fUse /" + cmdArgs
/* 237 */               .getLabel() + " add <player> para adicionar alguem a whitelist.");
/*     */           
/*     */           break;
/*     */         } 
/* 241 */         member = CommonPlugin.getInstance().getMemberManager().getMemberByName(args[1]);
/*     */         
/* 243 */         if (member == null) {
/* 244 */           member = CommonPlugin.getInstance().getMemberData().loadMember(args[1], true);
/*     */           
/* 246 */           if (member == null) {
/* 247 */             sender.sendMessage(" §4» §fO jogador " + args[1] + " não existe!");
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 252 */         BungeeMain.getInstance().addMemberToWhiteList(member.getPlayerName());
/* 253 */         sender.sendMessage(" §a» §fO jogador §a" + member.getPlayerName() + "§f foi adicionado a whitelist!");
/*     */         break;
/*     */       
/*     */       case "remove":
/* 257 */         if (args.length == 1) {
/* 258 */           sender.sendMessage(" §e» §fUse /" + cmdArgs
/* 259 */               .getLabel() + " remove <player> para remover alguem da whitelist.");
/*     */           
/*     */           break;
/*     */         } 
/* 263 */         member = CommonPlugin.getInstance().getMemberManager().getMemberByName(args[1]);
/*     */         
/* 265 */         if (member == null) {
/* 266 */           member = CommonPlugin.getInstance().getMemberData().loadMember(args[1], true);
/*     */           
/* 268 */           if (member == null) {
/* 269 */             sender.sendMessage(" §4» §fO jogador " + args[1] + " não existe!");
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 274 */         BungeeMain.getInstance().removeMemberFromWhiteList(member.getPlayerName());
/* 275 */         sender.sendMessage(" §a» §fO jogador §a" + member.getPlayerName() + "§f foi removido da whitelist!");
/*     */         break;
/*     */       
/*     */       case "list":
/* 279 */         sender.sendMessage(" §a» §fLista de jogadores na whitelist: §a" + 
/* 280 */             Joiner.on(", ").join(BungeeMain.getInstance().getWhiteList()));
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Completer(name = "report", aliases = {"rp"})
/*     */   public List<String> teleportCompleter(CommandArgs cmdArgs) {
/* 288 */     if ((cmdArgs.getArgs()).length == 1) {
/* 289 */       return (List<String>)ProxyServer.getInstance().getPlayers().stream()
/* 290 */         .filter(player -> player.getName().toLowerCase().startsWith(cmdArgs.getArgs()[0].toLowerCase()))
/* 291 */         .map(CommandSender::getName).collect(Collectors.toList());
/*     */     }
/*     */     
/* 294 */     return new ArrayList<>();
/*     */   }
/*     */   
/*     */   @Completer(name = "server", aliases = {"connect"})
/*     */   public List<String> serverCompleter(CommandArgs cmdArgs) {
/* 299 */     if ((cmdArgs.getArgs()).length == 1) {
/* 300 */       return (List<String>)BungeeMain.getInstance().getServerManager().getActiveServers().values().stream()
/* 301 */         .filter(server -> server.getServerId().toLowerCase().startsWith(cmdArgs.getArgs()[0].toLowerCase()))
/* 302 */         .map(ProxiedServer::getServerId).collect(Collectors.toList());
/*     */     }
/*     */     
/* 305 */     return new ArrayList<>();
/*     */   }
/*     */   
/*     */   @Completer(name = "play", aliases = {"jogar"})
/*     */   public List<String> playCompleter(CommandArgs cmdArgs) {
/* 310 */     if ((cmdArgs.getArgs()).length == 1) {
/* 311 */       return (List<String>)Arrays.<ServerType>asList(ServerType.values()).stream()
/* 312 */         .filter(type -> type.name().toLowerCase().startsWith(cmdArgs.getArgs()[0].toLowerCase()))
/* 313 */         .map(Enum::name).collect(Collectors.toList());
/*     */     }
/*     */     
/* 316 */     return new ArrayList<>();
/*     */   }
/*     */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/command/register/ServerCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */