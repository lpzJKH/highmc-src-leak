/*     */ package net.highmc.bungee.command.register;
/*     */ 
/*     */ import com.google.common.base.Joiner;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.OptionalInt;
/*     */ import java.util.UUID;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bungee.member.BungeeMember;
/*     */ import net.highmc.bungee.member.BungeeParty;
/*     */ import net.highmc.command.CommandArgs;
/*     */ import net.highmc.command.CommandClass;
/*     */ import net.highmc.command.CommandFramework.Command;
/*     */ import net.highmc.command.CommandSender;
/*     */ import net.highmc.manager.PartyManager;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.member.Profile;
/*     */ import net.highmc.member.party.Party;
/*     */ import net.highmc.member.party.PartyRole;
/*     */ import net.highmc.utils.string.MessageBuilder;
/*     */ import net.highmc.utils.string.StringFormat;
/*     */ import net.md_5.bungee.api.ProxyServer;
/*     */ import net.md_5.bungee.api.chat.BaseComponent;
/*     */ import net.md_5.bungee.api.config.ServerInfo;
/*     */ import net.md_5.bungee.api.connection.ProxiedPlayer;
/*     */ 
/*     */ public class PartyCommand
/*     */   implements CommandClass {
/*     */   @Command(name = "partychat", aliases = {"pc", "partychat", "party.chat"}, console = false)
/*     */   public void partychatCommand(CommandArgs cmdArgs) {
/*  31 */     Member sender = (Member)cmdArgs.getSender();
/*  32 */     String[] args = cmdArgs.getArgs();
/*     */     
/*  34 */     if (args.length == 0) {
/*  35 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs
/*  36 */           .getLabel() + " <mensagem>§f para mandar uma mensagem na party.");
/*     */       
/*     */       return;
/*     */     } 
/*  40 */     if (sender.getParty() == null) {
/*  41 */       sender.sendMessage("§cVocê não está em uma party.");
/*     */       
/*     */       return;
/*     */     } 
/*  45 */     sender.getParty().chat((CommandSender)sender, Joiner.on(' ').join((Object[])args)); } @Command(name = "party", console = false) public void partyCommand(CommandArgs cmdArgs) { Party party1; int maxPlayers;
/*     */     Member member;
/*     */     Party party;
/*     */     PartyManager.InviteInfo inviteInfo;
/*     */     Party party2;
/*  50 */     Member sender = (Member)cmdArgs.getSender();
/*  51 */     String[] args = cmdArgs.getArgs();
/*     */     
/*  53 */     if (args.length == 0) {
/*  54 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs
/*  55 */           .getLabel() + " <disband/acabar>§f para acabar com sua party.");
/*  56 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " convidar <player>§f para convidar algum jogador para sua party.");
/*     */       
/*  58 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs
/*  59 */           .getLabel() + " expulsar <player>§f para expulsar alguém da sua party.");
/*  60 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " abrir <máximo de players>§f para abrir sua party para uma quantidade de pessoas.");
/*     */       
/*  62 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " fechar§f para fechar sua party.");
/*  63 */       sender.sendMessage("");
/*  64 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs
/*  65 */           .getLabel() + " aceitar <player>§f para aceitar um convite de party.");
/*  66 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs
/*  67 */           .getLabel() + " entrar <player>§f para entrar numa party pública.");
/*  68 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " sair§f para sair de uma party.");
/*     */       
/*     */       return;
/*     */     } 
/*  72 */     switch (args[0].toLowerCase()) {
/*     */       case "close":
/*     */       case "fechar":
/*  75 */         party1 = sender.getParty();
/*     */         
/*  77 */         if (party1 == null) {
/*  78 */           sender.sendMessage("§cVocê não tem uma party para fechar.");
/*     */           
/*     */           return;
/*     */         } 
/*  82 */         if (!party1.closeParty()) {
/*  83 */           sender.sendMessage("§cSua party não está aberta.");
/*     */         }
/*     */         return;
/*     */       
/*     */       case "abrir":
/*     */       case "open":
/*  89 */         maxPlayers = 6;
/*     */         
/*  91 */         if (args.length >= 2) {
/*  92 */           OptionalInt parseInt = StringFormat.parseInt(args[1]);
/*     */           
/*  94 */           if (!parseInt.isPresent()) {
/*  95 */             sender.sendMessage(sender.getLanguage().t("invalid-format-integer", new String[] { "%value%" }));
/*     */             
/*     */             return;
/*     */           } 
/*  99 */           maxPlayers = parseInt.getAsInt();
/*     */         } 
/*     */         
/* 102 */         if (maxPlayers > 10) {
/* 103 */           sender.sendMessage("§cVocê não pode abrir sua party para mais de 10 jogadores.");
/*     */           
/*     */           return;
/*     */         } 
/* 107 */         party2 = (sender.getParty() == null) ? createParty(sender) : sender.getParty();
/*     */         
/* 109 */         if (!party2.openParty(maxPlayers)) {
/* 110 */           sender.sendMessage("§cO valor inserido é menor que o número de membros da sua party.");
/*     */         }
/*     */         return;
/*     */       case "entrar":
/* 114 */         if (args.length < 2) {
/* 115 */           sender.sendMessage(" §a» §fUse §a/" + cmdArgs
/* 116 */               .getLabel() + " entrar <player>§f para entrar numa party pública.");
/*     */           
/*     */           return;
/*     */         } 
/* 120 */         if (sender.getParty() != null) {
/* 121 */           sender.sendMessage("§cVocê não pode entrar nessa party enquanto estiver em outra.");
/*     */           
/*     */           return;
/*     */         } 
/* 125 */         member = CommonPlugin.getInstance().getMemberManager().getMemberByName(args[1]);
/*     */         
/* 127 */         if (member == null) {
/* 128 */           sender.sendMessage(sender.getLanguage().t("player-is-not-online", new String[] { "%player%", args[1] }));
/*     */           
/*     */           return;
/*     */         } 
/* 132 */         if (member.getParty() == null) {
/* 133 */           sender.sendMessage("§cO jogador " + member.getPlayerName() + " não tem uma party.");
/*     */           
/*     */           return;
/*     */         } 
/* 137 */         if (member.getParty().getPartyPrivacy() == Party.PartyPrivacy.PRIVATE) {
/* 138 */           sender.sendMessage("§cEsta party é privada, somente jogadores convidados podem entrar.");
/*     */           
/*     */           return;
/*     */         } 
/* 142 */         member.getParty().addMember(Profile.from((CommandSender)sender));
/* 143 */         sender.setParty(member.getParty());
/*     */         return;
/*     */       
/*     */       case "teleportar":
/*     */       case "warp":
/* 148 */         if (sender.getParty() == null) {
/* 149 */           sender.sendMessage("§cVocê não tem party.");
/*     */           
/*     */           return;
/*     */         } 
/* 153 */         if (sender.getParty().hasRole(sender.getUniqueId(), PartyRole.OWNER)) {
/* 154 */           BungeeMember bungeeMember = (BungeeMember)sender;
/* 155 */           ServerInfo info = bungeeMember.getProxiedPlayer().getServer().getInfo();
/*     */           
/* 157 */           sender.getParty().getMembers().stream().map(id -> ProxyServer.getInstance().getPlayer(id))
/* 158 */             .forEach(player -> {
/*     */                 if (player != null)
/*     */                   player.connect(bungeeMember.getProxiedPlayer().getServer().getInfo()); 
/*     */               });
/* 162 */           sender.getParty().sendMessage("§aTodos os jogadores foram levados para a sala " + info.getName() + ".");
/*     */         } else {
/* 164 */           sender.sendMessage("§cSomente o líder da party pode fazer isso.");
/*     */         } 
/*     */         return;
/*     */       
/*     */       case "expulsar":
/* 169 */         party = sender.getParty();
/*     */         
/* 171 */         if (party == null) {
/* 172 */           sender.sendMessage("§cVocê não tem uma party.");
/*     */           
/*     */           return;
/*     */         } 
/* 176 */         if (!party.hasRole(sender.getUniqueId(), PartyRole.ADMIN)) {
/* 177 */           sender.sendMessage("§cVocê não tem permissão para expulsar alguém da sua party.");
/*     */           
/*     */           return;
/*     */         } 
/* 181 */         if (args.length == 2) {
/* 182 */           sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " expulsar <player>§f para expulsar alguém da sua party.");
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/* 187 */         member1 = CommonPlugin.getInstance().getMemberManager().getMemberByName(args[1]);
/*     */         
/* 189 */         if (member1 == null) {
/* 190 */           sender.sendMessage(sender.getLanguage().t("player-is-not-online", new String[] { "%player%", args[1] }));
/*     */           
/*     */           return;
/*     */         } 
/* 194 */         if (sender.getUniqueId().equals(member1.getUniqueId())) {
/* 195 */           sender.sendMessage("§cVocê não pode se expulsar da party.");
/*     */           
/*     */           return;
/*     */         } 
/* 199 */         if (party.hasRole(sender.getUniqueId(), PartyRole.OWNER)) {
/* 200 */           sender.sendMessage("§cVocê não pode expulsar esse jogador.");
/*     */           
/*     */           return;
/*     */         } 
/* 204 */         party.kickMember((CommandSender)sender, member1);
/*     */         return;
/*     */       
/*     */       case "acabar":
/*     */       case "disband":
/* 209 */         party = sender.getParty();
/*     */         
/* 211 */         if (party == null) {
/* 212 */           sender.sendMessage("§cVocê não está em uma party.");
/*     */           
/*     */           return;
/*     */         } 
/* 216 */         if (!party.hasRole(sender.getUniqueId(), PartyRole.OWNER)) {
/* 217 */           sender.sendMessage("§cVocê não pode acabar com essa party.");
/*     */           
/*     */           return;
/*     */         } 
/* 221 */         party.disband();
/*     */         return;
/*     */       
/*     */       case "sair":
/* 225 */         party = sender.getParty();
/*     */         
/* 227 */         if (party == null) {
/* 228 */           sender.sendMessage("§cVocê não está em uma party.");
/*     */           
/*     */           return;
/*     */         } 
/* 232 */         if (party.hasRole(sender.getUniqueId(), PartyRole.OWNER)) {
/* 233 */           sender.sendMessage("§cVocê não pode sair da party que você criou.");
/* 234 */           sender.sendMessage("§cUse /party disband para sair da party.");
/*     */           
/*     */           return;
/*     */         } 
/* 238 */         party.removeMember(Profile.from((CommandSender)sender));
/* 239 */         sender.setParty(null);
/*     */         return;
/*     */       
/*     */       case "accept":
/*     */       case "aceitar":
/* 244 */         if (sender.getParty() != null) {
/* 245 */           sender.sendMessage("§cSaia da sua party para entrar em outra.");
/*     */           
/*     */           return;
/*     */         } 
/* 249 */         if (!CommonPlugin.getInstance().getPartyManager().getPartyInvitesMap().containsKey(sender.getUniqueId()) || (
/* 250 */           (Map)CommonPlugin.getInstance().getPartyManager().getPartyInvitesMap().get(sender.getUniqueId()))
/* 251 */           .isEmpty()) {
/* 252 */           sender.sendMessage("§cVocê não tem nenhum convite de party para ser aceito.");
/*     */ 
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/* 258 */         if (args.length >= 2) {
/* 259 */           if (((Map)CommonPlugin.getInstance().getPartyManager().getPartyInvitesMap().get(sender.getUniqueId()))
/* 260 */             .size() > 1) {
/* 261 */             sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " aceitar <player>§f para aceitar um convite de party.");
/*     */ 
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/* 267 */           inviteInfo = ((Map)CommonPlugin.getInstance().getPartyManager().getPartyInvitesMap().get(sender.getUniqueId())).values().stream().findFirst().orElse(null);
/*     */         } else {
/*     */           
/* 270 */           member1 = CommonPlugin.getInstance().getMemberManager().getMemberByName(args[1]);
/*     */           
/* 272 */           if (member1 == null) {
/* 273 */             sender.sendMessage(sender.getLanguage().t("player-is-not-online", new String[] { "%player%", args[1] }));
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/* 278 */           inviteInfo = (PartyManager.InviteInfo)((Map)CommonPlugin.getInstance().getPartyManager().getPartyInvitesMap().get(sender.getUniqueId())).get(member1.getUniqueId());
/*     */           
/* 280 */           if (inviteInfo == null) {
/* 281 */             sender.sendMessage("§cO jogador " + member1.getPlayerName() + " não te convidou para party.");
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/* 286 */         CommonPlugin.getInstance().getPartyManager().getPartyInvitesMap().remove(sender.getUniqueId());
/*     */         
/* 288 */         if (inviteInfo.getCreatedAt() + 180000L > System.currentTimeMillis()) {
/* 289 */           Party party4 = CommonPlugin.getInstance().getPartyManager().getPartyById(inviteInfo.getPartyId());
/*     */           
/* 291 */           if (party4 == null) {
/* 292 */             sender.sendMessage("§cA party que convidou você não existe mais.");
/*     */             
/*     */             return;
/*     */           } 
/* 296 */           if (party4.addMember(Profile.from((CommandSender)sender))) {
/* 297 */             sender.setParty(party4);
/*     */           } else {
/* 299 */             sender.sendMessage("§cA party está cheia.");
/*     */           } 
/*     */           return;
/*     */         } 
/* 303 */         sender.sendMessage("§cO convite para entrar na party expirou!");
/*     */         return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 312 */     boolean inviteArg = (args[0].equalsIgnoreCase("convidar") || args[0].equalsIgnoreCase("invite"));
/*     */     
/* 314 */     if (inviteArg && 
/* 315 */       args.length <= 1) {
/* 316 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " convidar <player>§f para convidar algum jogador para sua party.");
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 322 */     Member member1 = CommonPlugin.getInstance().getMemberManager().getMemberByName(args[inviteArg ? 1 : 0]);
/*     */     
/* 324 */     if (member1 == null) {
/* 325 */       sender.sendMessage(sender.getLanguage().t("player-is-not-online", new String[] { "%player%", args[inviteArg ? 1 : 0] }));
/*     */       
/*     */       return;
/*     */     } 
/* 329 */     if (sender.getUniqueId().equals(member1.getUniqueId())) {
/* 330 */       sender.sendMessage("§cVocê não pode convidar este jogador.");
/*     */       
/*     */       return;
/*     */     } 
/* 334 */     if (!member1.getMemberConfiguration().isPartyInvites()) {
/* 335 */       sender.sendMessage("§cO jogador " + member1
/* 336 */           .getPlayerName() + " não está aceitando convites para party.");
/*     */       
/*     */       return;
/*     */     } 
/* 340 */     if (member1.getParty() != null) {
/* 341 */       sender.sendMessage("§cO jogador " + member1.getPlayerName() + " já está em uma party.");
/*     */       
/*     */       return;
/*     */     } 
/* 345 */     Party party3 = (sender.getParty() == null) ? createParty(sender) : sender.getParty();
/*     */     
/* 347 */     if (!party3.hasRole(sender.getUniqueId(), PartyRole.ADMIN)) {
/* 348 */       sender.sendMessage("§cVocê não tem permissão para convidar alguém para sua party.");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 353 */     Map<UUID, PartyManager.InviteInfo> partyInvites = CommonPlugin.getInstance().getPartyManager().getPartyInvitesMap().computeIfAbsent(member1.getUniqueId(), v -> new HashMap<>());
/*     */     
/* 355 */     if (partyInvites.containsKey(sender.getUniqueId())) {
/* 356 */       PartyManager.InviteInfo inviteInfo1 = partyInvites.get(sender.getUniqueId());
/*     */       
/* 358 */       if (inviteInfo1.getCreatedAt() + 180000L > System.currentTimeMillis()) {
/* 359 */         sender.sendMessage("§cVocê precisa esperar para enviar um novo invite para esse jogador.");
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 364 */     CommonPlugin.getInstance().getPartyManager().invite(sender.getUniqueId(), member1.getUniqueId(), party3);
/* 365 */     sender.sendMessage("§aO convite para party foi enviado para " + member1.getPlayerName() + ".");
/* 366 */     member1.sendMessage("§aVocê foi convidado para party de " + sender.getPlayerName() + ".");
/* 367 */     member1.sendMessage(new BaseComponent[] { (BaseComponent)(new MessageBuilder("§aClique ")).create(), (BaseComponent)(new MessageBuilder("§a§lAQUI"))
/* 368 */           .setHoverEvent("§aClique aqui para aceitar o convite.")
/* 369 */           .setClickEvent("/party aceitar " + sender.getPlayerName()).create(), (BaseComponent)(new MessageBuilder("§a para aceitar o convite da party."))
/* 370 */           .create() }); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Party createParty(Member member) {
/* 376 */     UUID partyId = CommonPlugin.getInstance().getPartyData().getPartyId();
/* 377 */     BungeeParty bungeeParty = new BungeeParty(partyId, member);
/*     */     
/* 379 */     member.setPartyId(partyId);
/* 380 */     member.sendMessage("§aSua party foi criada.");
/* 381 */     CommonPlugin.getInstance().getPartyData().createParty((Party)bungeeParty);
/* 382 */     CommonPlugin.getInstance().getPartyManager().loadParty((Party)bungeeParty);
/*     */     
/* 384 */     return (Party)bungeeParty;
/*     */   }
/*     */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/command/register/PartyCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */