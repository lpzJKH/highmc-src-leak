/*    */ package net.highmc.bungee.command;
/*    */ import java.util.UUID;
/*    */ import net.highmc.CommonConst;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.command.CommandSender;
/*    */ import net.highmc.language.Language;
/*    */ import net.highmc.member.Member;
/*    */ import net.highmc.member.Profile;
/*    */ import net.md_5.bungee.api.CommandSender;
/*    */ import net.md_5.bungee.api.chat.BaseComponent;
/*    */ import net.md_5.bungee.api.chat.TextComponent;
/*    */ import net.md_5.bungee.api.connection.ProxiedPlayer;
/*    */ 
/*    */ public class BungeeCommandSender implements CommandSender {
/*    */   private final CommandSender sender;
/*    */   
/*    */   public BungeeCommandSender(CommandSender sender) {
/* 18 */     this.sender = sender;
/*    */   }
/*    */   private UUID replyId; private boolean tellEnabled;
/*    */   public CommandSender getSender() {
/* 22 */     return this.sender;
/* 23 */   } public void setReplyId(UUID replyId) { this.replyId = replyId; }
/* 24 */   public UUID getReplyId() { return this.replyId; }
/* 25 */   public void setTellEnabled(boolean tellEnabled) { this.tellEnabled = tellEnabled; } public boolean isTellEnabled() {
/* 26 */     return this.tellEnabled;
/*    */   }
/*    */   
/*    */   public UUID getUniqueId() {
/* 30 */     if (this.sender instanceof ProxiedPlayer)
/* 31 */       return ((ProxiedPlayer)this.sender).getUniqueId(); 
/* 32 */     return CommonConst.CONSOLE_ID;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 37 */     if (this.sender instanceof ProxiedPlayer)
/* 38 */       return ((ProxiedPlayer)this.sender).getName(); 
/* 39 */     return "CONSOLE";
/*    */   }
/*    */ 
/*    */   
/*    */   public void sendMessage(String str) {
/* 44 */     this.sender.sendMessage(TextComponent.fromLegacyText(translate(getLanguage(), str)));
/*    */   }
/*    */ 
/*    */   
/*    */   public void sendMessage(BaseComponent baseComponent) {
/* 49 */     this.sender.sendMessage(baseComponent);
/*    */   }
/*    */ 
/*    */   
/*    */   public void sendMessage(BaseComponent... fromLegacyText) {
/* 54 */     this.sender.sendMessage(fromLegacyText);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPlayer() {
/* 59 */     return this.sender instanceof ProxiedPlayer;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getSenderName() {
/* 64 */     return this.sender.getName();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasPermission(String permission) {
/* 69 */     if (this.sender instanceof ProxiedPlayer) {
/* 70 */       return CommonPlugin.getInstance().getMemberManager().getMember(getUniqueId()).hasPermission(permission);
/*    */     }
/* 72 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Language getLanguage() {
/* 78 */     return isPlayer() ? ((Member)getSender()).getLanguage() : 
/* 79 */       CommonPlugin.getInstance().getPluginInfo().getDefaultLanguage();
/*    */   }
/*    */   
/*    */   public String translate(Language language, String string) {
/* 83 */     return CommonPlugin.getInstance().getPluginInfo().findAndTranslate(language, string);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isStaff() {
/* 88 */     if (this.sender instanceof ProxiedPlayer) {
/*    */       
/* 90 */       Member member = CommonPlugin.getInstance().getMemberManager().getMember(((ProxiedPlayer)this.sender).getUniqueId());
/* 91 */       return member.getServerGroup().isStaff();
/*    */     } 
/*    */     
/* 94 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isUserBlocked(Profile profile) {
/* 99 */     return isPlayer() ? ((Member)getSender()).isUserBlocked(profile) : false;
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/command/BungeeCommandSender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */