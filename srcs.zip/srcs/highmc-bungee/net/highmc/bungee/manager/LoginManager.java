/*    */ package net.highmc.bungee.manager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoginManager
/*    */ {
/*    */   public static void main(String[] args) throws InterruptedException {
/*  9 */     LoginManager loginManager = new LoginManager();
/*    */ 
/*    */     
/*    */     while (true) {
/* 13 */       for (int i = 0; i < Math.random() * 16.0D; i++) {
/* 14 */         loginManager.connection();
/*    */       }
/* 16 */       loginManager.print();
/* 17 */       System.out.println(loginManager.getAverage());
/* 18 */       Thread.sleep(1000L);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/* 23 */   private int[] average = new int[6];
/*    */   private int players;
/* 25 */   private long currentTime = System.currentTimeMillis(); public long getCurrentTime() { return this.currentTime; } public int getPlayers() {
/* 26 */     return this.players;
/*    */   }
/*    */   public void connection() {
/* 29 */     if (this.currentTime < System.currentTimeMillis()) {
/* 30 */       doAverage(this.players);
/* 31 */       this.players = 0;
/* 32 */       this.currentTime = System.currentTimeMillis();
/*    */     } 
/*    */     
/* 35 */     this.players++;
/*    */   }
/*    */   
/*    */   public void doAverage(int players) {
/* 39 */     for (int i = this.average.length - 1; i > 0; i--) {
/* 40 */       this.average[i] = this.average[i - 1];
/*    */     }
/*    */     
/* 43 */     this.average[0] = players;
/*    */   }
/*    */   
/*    */   public void print() {
/* 47 */     for (int i = 0; i < this.average.length; i++) {
/* 48 */       System.out.print(this.average[i] + " ");
/*    */     }
/* 50 */     System.out.println();
/*    */   }
/*    */   
/*    */   public int getLastSecondConnections() {
/* 54 */     return this.average[0];
/*    */   }
/*    */   
/*    */   public float getAverage() {
/* 58 */     float sum = 0.0F;
/*    */     
/* 60 */     for (int i = 0; i < this.average.length; i++) {
/* 61 */       sum += this.average[i];
/*    */     }
/*    */     
/* 64 */     return sum / this.average.length;
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/manager/LoginManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */