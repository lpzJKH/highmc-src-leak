/*    */ package net.highmc.bungee.manager;
/*    */ 
/*    */ import java.net.InetSocketAddress;
/*    */ import net.highmc.server.ServerManager;
/*    */ import net.highmc.server.ServerType;
/*    */ import net.highmc.server.loadbalancer.server.ProxiedServer;
/*    */ import net.md_5.bungee.api.ProxyServer;
/*    */ import net.md_5.bungee.api.config.ServerInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BungeeServerManager
/*    */   extends ServerManager
/*    */ {
/*    */   public ProxiedServer addActiveServer(String serverAddress, String serverIp, ServerType type, int maxPlayers, long startTime) {
/* 16 */     ProxiedServer server = super.addActiveServer(serverAddress, serverIp, type, maxPlayers, startTime);
/*    */     
/* 18 */     if (!ProxyServer.getInstance().getServers().containsKey(serverIp.toLowerCase())) {
/* 19 */       String ipAddress = serverAddress.split(":")[0];
/* 20 */       int port = Integer.valueOf(serverAddress.split(":")[1]).intValue();
/*    */       
/* 22 */       ServerInfo localServerInfo = ProxyServer.getInstance().constructServerInfo(serverIp.toLowerCase(), new InetSocketAddress(ipAddress, port), "Restarting", false);
/*    */ 
/*    */       
/* 25 */       ProxyServer.getInstance().getServers().put(serverIp.toLowerCase(), localServerInfo);
/*    */     } 
/*    */     
/* 28 */     return server;
/*    */   }
/*    */ 
/*    */   
/*    */   public void removeActiveServer(String str) {
/* 33 */     super.removeActiveServer(str);
/*    */     
/* 35 */     if (ProxyServer.getInstance().getServers().containsKey(str.toLowerCase()))
/* 36 */       ProxyServer.getInstance().getServers().remove(str.toLowerCase()); 
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/manager/BungeeServerManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */