/*    */ package net.highmc.bungee;
/*    */ 
/*    */ import net.highmc.bungee.command.BungeeCommandSender;
/*    */ import net.highmc.command.CommandSender;
/*    */ import net.md_5.bungee.api.ProxyServer;
/*    */ 
/*    */ public class BungeeConst
/*    */ {
/*    */   public static final int MAX_PLAYERS = 3000;
/* 10 */   public static final CommandSender CONSOLE_SENDER = (CommandSender)new BungeeCommandSender(
/* 11 */       ProxyServer.getInstance().getConsole());
/*    */   public static final String BROADCAST_PREFIX = "§6§lHIGH §8» ";
/*    */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/BungeeConst.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */