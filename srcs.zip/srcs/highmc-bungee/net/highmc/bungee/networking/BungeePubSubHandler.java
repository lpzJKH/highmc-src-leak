/*    */ package net.highmc.bungee.networking;
/*    */ 
/*    */ import net.highmc.bungee.event.RedisMessageEvent;
/*    */ import net.md_5.bungee.api.ProxyServer;
/*    */ import net.md_5.bungee.api.plugin.Event;
/*    */ import redis.clients.jedis.JedisPubSub;
/*    */ 
/*    */ public class BungeePubSubHandler
/*    */   extends JedisPubSub {
/*    */   public void onMessage(String channel, String message) {
/* 11 */     ProxyServer.getInstance().getPluginManager().callEvent((Event)new RedisMessageEvent(channel, message));
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/networking/BungeePubSubHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */