/*    */ package net.highmc.bungee.event.player;
/*    */ import net.md_5.bungee.api.connection.ProxiedPlayer;
/*    */ import net.md_5.bungee.api.plugin.Cancellable;
/*    */ import net.md_5.bungee.api.plugin.Event;
/*    */ 
/*    */ public class PlayerCommandEvent extends Event implements Cancellable {
/*    */   private final ProxiedPlayer player;
/*    */   private final String command;
/*    */   
/*    */   public ProxiedPlayer getPlayer() {
/* 11 */     return this.player;
/*    */   } private final String[] args; private boolean cancelled; public String getCommand() {
/* 13 */     return this.command;
/*    */   } public String[] getArgs() {
/* 15 */     return this.args;
/*    */   }
/*    */   
/* 18 */   public void setCancelled(boolean cancelled) { this.cancelled = cancelled; } public boolean isCancelled() {
/* 19 */     return this.cancelled;
/*    */   }
/*    */   
/*    */   public PlayerCommandEvent(ProxiedPlayer player, String command, String[] args) {
/* 23 */     this.player = player;
/* 24 */     this.command = command.toLowerCase();
/* 25 */     this.args = args;
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/event/player/PlayerCommandEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */