/*    */ package net.highmc.bungee.event.player;
/*    */ import net.highmc.command.CommandSender;
/*    */ import net.highmc.member.Member;
/*    */ import net.highmc.punish.Punish;
/*    */ import net.md_5.bungee.api.plugin.Event;
/*    */ 
/*    */ public class PlayerPardonedEvent extends Event {
/*    */   private Member punished;
/*    */   
/*    */   public PlayerPardonedEvent(Member punished, Punish punish, CommandSender sender) {
/* 11 */     this.punished = punished; this.punish = punish; this.sender = sender;
/*    */   } private Punish punish; private CommandSender sender;
/*    */   public Member getPunished() {
/* 14 */     return this.punished; }
/* 15 */   public Punish getPunish() { return this.punish; } public CommandSender getSender() {
/* 16 */     return this.sender;
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/event/player/PlayerPardonedEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */