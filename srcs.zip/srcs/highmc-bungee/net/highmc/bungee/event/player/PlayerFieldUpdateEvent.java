/*    */ package net.highmc.bungee.event.player;
/*    */ 
/*    */ import net.highmc.bungee.member.BungeeMember;
/*    */ import net.md_5.bungee.api.plugin.Event;
/*    */ 
/*    */ public class PlayerFieldUpdateEvent extends Event {
/*    */   private final BungeeMember player;
/*    */   private String fieldName;
/*    */   
/* 10 */   public BungeeMember getPlayer() { return this.player; } public String getFieldName() {
/* 11 */     return this.fieldName;
/*    */   }
/*    */   public PlayerFieldUpdateEvent(BungeeMember player, String fieldName) {
/* 14 */     this.player = player;
/* 15 */     this.fieldName = fieldName;
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/event/player/PlayerFieldUpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */