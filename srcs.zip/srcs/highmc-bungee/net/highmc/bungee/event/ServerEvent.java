/*    */ package net.highmc.bungee.event;
/*    */ 
/*    */ import net.highmc.server.loadbalancer.server.ProxiedServer;
/*    */ import net.md_5.bungee.api.plugin.Event;
/*    */ 
/*    */ public class ServerEvent
/*    */   extends Event {
/*    */   public ServerEvent(ProxiedServer proxiedServer) {
/*  9 */     this.proxiedServer = proxiedServer;
/*    */   } private ProxiedServer proxiedServer;
/*    */   public ProxiedServer getProxiedServer() {
/* 12 */     return this.proxiedServer;
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/event/ServerEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */