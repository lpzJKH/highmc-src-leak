/*    */ package net.highmc.bungee.event.packet;
/*    */ 
/*    */ import lombok.NonNull;
/*    */ import net.highmc.packet.Packet;
/*    */ import net.highmc.packet.PacketType;
/*    */ import net.md_5.bungee.api.plugin.Event;
/*    */ 
/*    */ public class PacketReceiveEvent extends Event {
/*    */   public PacketReceiveEvent(@NonNull Packet packet) {
/* 10 */     if (packet == null) throw new NullPointerException("packet is marked non-null but is null");  this.packet = packet;
/*    */   } @NonNull
/*    */   private final Packet packet;
/*    */   @NonNull
/*    */   public Packet getPacket() {
/* 15 */     return this.packet;
/*    */   }
/*    */   public PacketType getPacketType() {
/* 18 */     return this.packet.getPacketType();
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/event/packet/PacketReceiveEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */