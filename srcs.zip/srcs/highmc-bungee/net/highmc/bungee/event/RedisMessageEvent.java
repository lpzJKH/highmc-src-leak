/*    */ package net.highmc.bungee.event;
/*    */ import lombok.NonNull;
/*    */ import net.md_5.bungee.api.plugin.Cancellable;
/*    */ import net.md_5.bungee.api.plugin.Event;
/*    */ 
/*    */ public class RedisMessageEvent extends Event implements Cancellable {
/*    */   @NonNull
/*    */   private String channel;
/*    */   
/*    */   public RedisMessageEvent(@NonNull String channel, @NonNull String message) {
/* 11 */     if (channel == null) throw new NullPointerException("channel is marked non-null but is null");  if (message == null) throw new NullPointerException("message is marked non-null but is null");  this.channel = channel; this.message = message;
/*    */   } @NonNull
/*    */   private String message; private boolean cancelled; @NonNull
/*    */   public String getChannel() {
/* 15 */     return this.channel; } @NonNull
/*    */   public String getMessage() {
/* 17 */     return this.message;
/*    */   }
/* 19 */   public void setCancelled(boolean cancelled) { this.cancelled = cancelled; } public boolean isCancelled() {
/* 20 */     return this.cancelled;
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/event/RedisMessageEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */