/*    */ package net.highmc.bungee.event;
/*    */ 
/*    */ import net.highmc.server.loadbalancer.server.MinigameState;
/*    */ import net.highmc.server.loadbalancer.server.ProxiedServer;
/*    */ 
/*    */ public class ServerUpdateEvent extends ServerEvent {
/*    */   private String map;
/*    */   private int time;
/*    */   
/* 10 */   public String getMap() { return this.map; } private MinigameState lastState; private MinigameState state; public int getTime() {
/* 11 */     return this.time;
/*    */   }
/* 13 */   public MinigameState getLastState() { return this.lastState; } public MinigameState getState() {
/* 14 */     return this.state;
/*    */   }
/*    */   
/*    */   public ServerUpdateEvent(ProxiedServer proxiedServer, String map, int time, MinigameState lastState, MinigameState state) {
/* 18 */     super(proxiedServer);
/*    */     
/* 20 */     this.map = map;
/* 21 */     this.time = time;
/* 22 */     this.lastState = lastState;
/* 23 */     this.state = state;
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/BungeeCommon.jar!/net/highmc/bungee/event/ServerUpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */