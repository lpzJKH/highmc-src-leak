/*    */ package net.highmc.bukkit.listener;
/*    */ 
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.weather.WeatherChangeEvent;
/*    */ 
/*    */ public class WorldListener
/*    */   implements Listener {
/*    */   @EventHandler
/*    */   public void onWheater(WeatherChangeEvent event) {
/* 13 */     for (World w : Bukkit.getWorlds()) {
/* 14 */       w.setWeatherDuration(0);
/*    */     }
/* 16 */     event.setCancelled(true);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/listener/WorldListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */