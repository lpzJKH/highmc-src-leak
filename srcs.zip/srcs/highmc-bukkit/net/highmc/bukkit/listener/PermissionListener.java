/*     */ package net.highmc.bukkit.listener;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import java.util.stream.Collectors;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.bukkit.event.member.PlayerGroupChangeEvent;
/*     */ import net.highmc.bukkit.utils.permission.PermissionManager;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.permission.Group;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.player.PlayerKickEvent;
/*     */ import org.bukkit.event.player.PlayerLoginEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.permissions.Permission;
/*     */ import org.bukkit.permissions.PermissionAttachment;
/*     */ import org.bukkit.permissions.PermissionDefault;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ 
/*     */ 
/*     */ public class PermissionListener
/*     */   implements Listener
/*     */ {
/*     */   private final Map<UUID, PermissionAttachment> attachments;
/*     */   private PermissionManager manager;
/*     */   
/*     */   public PermissionListener() {
/*  34 */     this.attachments = new HashMap<>();
/*  35 */     this.manager = BukkitCommon.getInstance().getPermissionManager();
/*     */     
/*  37 */     (new BukkitRunnable()
/*     */       {
/*     */         public void run() {
/*  40 */           for (Player player : PermissionListener.this.manager.getServer().getOnlinePlayers()) {
/*  41 */             PermissionListener.this.updateAttachment(player);
/*     */           }
/*     */         }
/*  44 */       }).runTaskLater((Plugin)this.manager.getPlugin(), 10L);
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.LOW)
/*     */   public void onPlayerLogin(PlayerLoginEvent event) {
/*  49 */     updateAttachment(event.getPlayer());
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.MONITOR)
/*     */   public void onPlayerLoginMonitor(PlayerLoginEvent event) {
/*  54 */     if (event.getResult() != PlayerLoginEvent.Result.ALLOWED)
/*  55 */       removeAttachment(event.getPlayer()); 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerGroupChange(PlayerGroupChangeEvent event) {
/*  60 */     Player player = event.getPlayer();
/*     */     
/*  62 */     Group group = event.getGroup();
/*     */     
/*  64 */     if (group == null) {
/*  65 */       CommonPlugin.getInstance().debug("The server couldnt load group " + event.getGroupName() + " to change the permissions of " + player
/*  66 */           .getName());
/*     */       
/*     */       return;
/*     */     } 
/*  70 */     removeAttachment(player);
/*  71 */     updateAttachment(player);
/*  72 */     player.recalculatePermissions();
/*     */   }
/*     */   
/*     */   public void updateAttachment(Player player) {
/*  76 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId());
/*     */     
/*  78 */     if (member == null) {
/*     */       return;
/*     */     }
/*  81 */     PermissionAttachment attach = this.attachments.get(player.getUniqueId());
/*  82 */     Permission playerPerm = getCreateWrapper(player, player.getUniqueId().toString());
/*     */     
/*  84 */     if (attach == null) {
/*  85 */       attach = player.addAttachment((Plugin)this.manager.getPlugin());
/*  86 */       this.attachments.put(player.getUniqueId(), attach);
/*  87 */       attach.setPermission(playerPerm, true);
/*     */     } else {
/*  89 */       attach.getPermissions().clear();
/*  90 */       attach.setPermission(playerPerm, true);
/*     */     } 
/*     */     
/*  93 */     playerPerm.getChildren().clear();
/*     */ 
/*     */ 
/*     */     
/*  97 */     for (Group group : member.getGroups().keySet().stream().map(groupName -> CommonPlugin.getInstance().getPluginInfo().getGroupByName(groupName)).filter(group -> (group != null)).collect(Collectors.toList())) {
/*  98 */       for (String perm : group.getPermissions()) {
/*  99 */         if (!playerPerm.getChildren().containsKey(perm))
/* 100 */           playerPerm.getChildren().put(perm, Boolean.valueOf(true)); 
/*     */       } 
/* 102 */     }  for (String perm : member.getPermissions()) {
/* 103 */       if (!playerPerm.getChildren().containsKey(perm))
/* 104 */         playerPerm.getChildren().put(perm, Boolean.valueOf(true)); 
/*     */     } 
/* 106 */     player.recalculatePermissions();
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.MONITOR)
/*     */   public void onQuit(PlayerQuitEvent event) {
/* 111 */     removeAttachment(event.getPlayer());
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.MONITOR)
/*     */   public void onKick(PlayerKickEvent event) {
/* 116 */     removeAttachment(event.getPlayer());
/*     */   }
/*     */   
/*     */   protected void removeAttachment(Player player) {
/* 120 */     PermissionAttachment attach = this.attachments.remove(player.getUniqueId());
/* 121 */     if (attach != null) {
/* 122 */       attach.remove();
/*     */     }
/* 124 */     this.manager.getServer().getPluginManager().removePermission(player.getUniqueId().toString());
/*     */   }
/*     */   
/*     */   public void onDisable() {
/* 128 */     for (PermissionAttachment attach : this.attachments.values())
/* 129 */       attach.remove(); 
/* 130 */     this.attachments.clear();
/*     */   }
/*     */   
/*     */   private Permission getCreateWrapper(Player player, String name) {
/* 134 */     Permission perm = this.manager.getServer().getPluginManager().getPermission(name);
/*     */     
/* 136 */     if (perm == null) {
/* 137 */       perm = new Permission(name, "Interal Permission", PermissionDefault.FALSE);
/* 138 */       this.manager.getServer().getPluginManager().addPermission(perm);
/*     */     } 
/*     */     
/* 141 */     return perm;
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/listener/PermissionListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */