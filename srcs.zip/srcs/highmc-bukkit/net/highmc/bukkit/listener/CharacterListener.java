/*     */ package net.highmc.bukkit.listener;
/*     */ 
/*     */ import com.comphenix.protocol.PacketType;
/*     */ import com.comphenix.protocol.ProtocolLibrary;
/*     */ import com.comphenix.protocol.events.PacketAdapter;
/*     */ import com.comphenix.protocol.events.PacketEvent;
/*     */ import com.comphenix.protocol.events.PacketListener;
/*     */ import com.comphenix.protocol.wrappers.EnumWrappers;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.bukkit.BukkitMain;
/*     */ import net.highmc.bukkit.event.player.PlayerMoveUpdateEvent;
/*     */ import net.highmc.bukkit.utils.character.Character;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.event.player.PlayerRespawnEvent;
/*     */ import org.bukkit.event.player.PlayerTeleportEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ 
/*     */ public class CharacterListener
/*     */   implements Listener
/*     */ {
/*     */   private static final double MAX_DISTANCE = 128.0D;
/*     */   
/*     */   public CharacterListener() {
/*  30 */     ProtocolLibrary.getProtocolManager()
/*  31 */       .addPacketListener((PacketListener)new PacketAdapter((Plugin)BukkitCommon.getInstance(), new PacketType[] { PacketType.Play.Client.USE_ENTITY })
/*     */         {
/*     */           public void onPacketReceiving(PacketEvent event)
/*     */           {
/*  35 */             if (event.isCancelled()) {
/*     */               return;
/*     */             }
/*  38 */             Player player = event.getPlayer();
/*     */             
/*  40 */             if (event.getPacket().getEntityUseActions().read(0) == EnumWrappers.EntityUseAction.INTERACT || event
/*  41 */               .getPacket().getEntityUseActions().read(0) == EnumWrappers.EntityUseAction.ATTACK) {
/*  42 */               int entityId = ((Integer)event.getPacket().getIntegers().read(0)).intValue();
/*     */               
/*  44 */               Character character = Character.getCharacter(Integer.valueOf(entityId));
/*     */               
/*  46 */               if (character != null) {
/*  47 */                 character.getInteractHandler().onInteract(player, 
/*  48 */                     (event.getPacket().getEntityUseActions().read(0) == EnumWrappers.EntityUseAction.INTERACT));
/*     */               }
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerJoin(PlayerJoinEvent event) {
/*  58 */     Character.getCharacters().forEach(character -> {
/*     */           if (character.getNpc().getLocation().getWorld() == event.getPlayer().getLocation().getWorld() && character.getNpc().getLocation().distance(event.getPlayer().getLocation()) < 128.0D) {
/*     */             character.show(event.getPlayer());
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGHEST)
/*     */   public void onPlayerRespawn(final PlayerRespawnEvent event) {
/*  67 */     (new BukkitRunnable()
/*     */       {
/*     */         public void run()
/*     */         {
/*  71 */           Character.getCharacters().forEach(character -> {
/*     */                 if (character.getNpc().getLocation().getWorld() == event.getPlayer().getLocation().getWorld() && character.isShowing(event.getPlayer().getUniqueId()) && character.getNpc().getLocation().distance(event.getPlayer().getLocation()) < 128.0D) {
/*     */                   character.hide(event.getPlayer());
/*     */ 
/*     */                   
/*     */                   character.show(event.getPlayer());
/*     */                 } 
/*     */               });
/*     */         }
/*  80 */       }).runTaskLater((Plugin)BukkitMain.getInstance(), 5L);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerTeleport(PlayerTeleportEvent event) {
/*  85 */     Character.getCharacters().forEach(character -> {
/*     */           if (character.isShowing(event.getPlayer().getUniqueId())) {
/*     */             if (character.getNpc().getLocation().getWorld() != event.getPlayer().getLocation().getWorld()) {
/*     */               character.hide(event.getPlayer());
/*     */             } else if (character.getNpc().getLocation().distance(event.getPlayer().getLocation()) > 128.0D) {
/*     */               character.hide(event.getPlayer());
/*     */             } 
/*     */           } else if (character.getNpc().getLocation().getWorld() == event.getPlayer().getLocation().getWorld() && character.getNpc().getLocation().distance(event.getPlayer().getLocation()) < 128.0D) {
/*     */             character.show(event.getPlayer());
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerMoveUpdate(PlayerMoveUpdateEvent event) {
/* 101 */     Character.getCharacters().forEach(character -> {
/*     */           if (character.isShowing(event.getPlayer().getUniqueId())) {
/*     */             if (character.getNpc().getLocation().getWorld() != event.getPlayer().getLocation().getWorld()) {
/*     */               character.hide(event.getPlayer());
/*     */             } else if (character.getNpc().getLocation().distance(event.getPlayer().getLocation()) > 128.0D) {
/*     */               character.hide(event.getPlayer());
/*     */             } 
/*     */           } else if (character.getNpc().getLocation().getWorld() == event.getPlayer().getLocation().getWorld() && character.getNpc().getLocation().distance(event.getPlayer().getLocation()) < 128.0D) {
/*     */             character.show(event.getPlayer());
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerJoin(PlayerQuitEvent event) {
/* 117 */     Character.getCharacters().forEach(character -> character.hide(event.getPlayer()));
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/listener/CharacterListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */