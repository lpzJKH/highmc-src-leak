/*     */ package net.highmc.bukkit.listener;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.bukkit.event.UpdateEvent;
/*     */ import net.highmc.bukkit.event.player.PlayerOpenInventoryEvent;
/*     */ import net.highmc.bukkit.utils.menu.MenuHolder;
/*     */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*     */ import net.highmc.bukkit.utils.menu.MenuItem;
/*     */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.inventory.InventoryAction;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.InventoryHolder;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MenuListener
/*     */   implements Listener
/*     */ {
/*  32 */   private Map<Player, InventoryHolder> playerMap = new HashMap<>();
/*     */ 
/*     */   
/*     */   @EventHandler(priority = EventPriority.MONITOR)
/*     */   public void onInventoryClickListener(InventoryClickEvent event) {
/*  37 */     if (event.getInventory() == null) {
/*     */       return;
/*     */     }
/*  40 */     Inventory inv = event.getInventory();
/*     */     
/*  42 */     if (inv.getHolder() == null || !(inv.getHolder() instanceof MenuHolder)) {
/*     */       return;
/*     */     }
/*  45 */     event.setCancelled(true);
/*     */     
/*  47 */     if (event.getClickedInventory() != inv || !(event.getWhoClicked() instanceof Player) || event.getSlot() < 0) {
/*     */       return;
/*     */     }
/*  50 */     MenuHolder holder = (MenuHolder)inv.getHolder();
/*  51 */     MenuInventory menu = holder.getMenu();
/*     */     
/*  53 */     if (menu.hasItem(event.getSlot())) {
/*  54 */       Player p = (Player)event.getWhoClicked();
/*  55 */       MenuItem item = menu.getItem(event.getSlot());
/*  56 */       item.getHandler().onClick(p, inv, (event.getAction() == InventoryAction.PICKUP_HALF) ? ClickType.RIGHT : (
/*  57 */           (event.getAction() == InventoryAction.MOVE_TO_OTHER_INVENTORY) ? ClickType.SHIFT : ClickType.LEFT), event
/*  58 */           .getCurrentItem(), event.getSlot());
/*     */     } else {
/*  60 */       event.setCancelled(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.MONITOR)
/*     */   public void onMenuOpen(PlayerOpenInventoryEvent event) {
/*  66 */     if (event.getInventory() == null) {
/*     */       return;
/*     */     }
/*  69 */     Inventory inventory = event.getInventory();
/*     */     
/*  71 */     if (inventory.getHolder() instanceof MenuHolder) {
/*  72 */       MenuInventory menu = ((MenuHolder)inventory.getHolder()).getMenu();
/*     */       
/*  74 */       if (menu.getUpdateHandler() != null)
/*  75 */         this.playerMap.put(event.getPlayer(), inventory.getHolder()); 
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.MONITOR)
/*     */   public void onInventoryClose(final InventoryCloseEvent event) {
/*  81 */     if (event.getInventory() == null) {
/*     */       return;
/*     */     }
/*  84 */     Inventory inventory = event.getInventory();
/*     */     
/*  86 */     if (inventory.getHolder() instanceof MenuHolder) {
/*  87 */       final MenuHolder menuHolder = (MenuHolder)inventory.getHolder();
/*     */       
/*  89 */       final Player player = (Player)event.getPlayer();
/*     */       
/*  91 */       if (this.playerMap.containsKey(player)) {
/*  92 */         this.playerMap.remove(player);
/*     */       }
/*  94 */       if (menuHolder.getMenu().isReopenInventory()) {
/*  95 */         (new BukkitRunnable()
/*     */           {
/*     */             public void run()
/*     */             {
/*  99 */               if (player.isOnline())
/* 100 */                 menuHolder.getMenu().open((Player)event.getPlayer()); 
/*     */             }
/* 102 */           }).runTaskLater((Plugin)BukkitCommon.getInstance(), 10L);
/*     */       } else {
/* 104 */         menuHolder.onClose(player);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   @EventHandler(priority = EventPriority.MONITOR)
/*     */   public void onPlayerQuit(PlayerQuitEvent event) {
/* 110 */     this.playerMap.remove(event.getPlayer());
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.MONITOR)
/*     */   public void onUpdate(UpdateEvent event) {
/* 115 */     if (event.getType() != UpdateEvent.UpdateType.SECOND) {
/*     */       return;
/*     */     }
/* 118 */     for (Map.Entry<Player, InventoryHolder> entry : this.playerMap.entrySet()) {
/* 119 */       MenuInventory menu = ((MenuHolder)entry.getValue()).getMenu();
/*     */       
/* 121 */       if (menu.getUpdateHandler() != null)
/* 122 */         menu.getUpdateHandler().onUpdate(entry.getKey(), menu); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/listener/MenuListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */