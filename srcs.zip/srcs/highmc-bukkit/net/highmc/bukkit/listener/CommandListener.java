/*    */ package net.highmc.bukkit.listener;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import net.highmc.bukkit.event.player.PlayerCommandEvent;
/*    */ import net.highmc.language.Language;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandMap;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerCommandPreprocessEvent;
/*    */ 
/*    */ public class CommandListener
/*    */   implements Listener
/*    */ {
/*    */   private Map<String, Command> knownCommands;
/*    */   
/*    */   public CommandListener() {
/*    */     try {
/* 24 */       Field field = Bukkit.getServer().getClass().getDeclaredField("commandMap");
/* 25 */       field.setAccessible(true);
/*    */       
/* 27 */       CommandMap commandMap = (CommandMap)field.get(Bukkit.getServer());
/* 28 */       Field secondField = commandMap.getClass().getDeclaredField("knownCommands");
/*    */       
/* 30 */       secondField.setAccessible(true);
/* 31 */       this.knownCommands = (HashMap)secondField.get(commandMap);
/* 32 */     } catch (Exception e) {
/* 33 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */   
/*    */   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
/*    */   public void onPlayerCommandPreprocess(PlayerCommandPreprocessEvent event) {
/* 39 */     if (!event.getMessage().startsWith("/")) {
/*    */       return;
/*    */     }
/* 42 */     if (event.getMessage().startsWith("//")) {
/*    */       return;
/*    */     }
/* 45 */     String command = event.getMessage().split(" ")[0];
/* 46 */     String commandLabel = command.substring(1, command.length());
/*    */     
/* 48 */     PlayerCommandEvent playerCommandEvent = new PlayerCommandEvent(event.getPlayer(), commandLabel);
/* 49 */     Bukkit.getPluginManager().callEvent((Event)playerCommandEvent);
/* 50 */     event.setCancelled(playerCommandEvent.isCancelled());
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerCommand(PlayerCommandEvent event) {
/* 55 */     if (event.getCommandLabel().startsWith("//")) {
/*    */       return;
/*    */     }
/* 58 */     String command = event.getCommandLabel();
/*    */     
/* 60 */     if (command.contains(":")) {
/* 61 */       event.getPlayer().sendMessage(
/* 62 */           Language.getLanguage(event.getPlayer().getUniqueId()).t("command-not-found", new String[] { "%command%", command }));
/* 63 */       event.setCancelled(true);
/*    */       
/*    */       return;
/*    */     } 
/* 67 */     if (!this.knownCommands.containsKey(command.toLowerCase())) {
/* 68 */       event.getPlayer().sendMessage(
/* 69 */           Language.getLanguage(event.getPlayer().getUniqueId()).t("command-not-found", new String[] { "%command%", command }));
/* 70 */       event.setCancelled(true);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/listener/CommandListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */