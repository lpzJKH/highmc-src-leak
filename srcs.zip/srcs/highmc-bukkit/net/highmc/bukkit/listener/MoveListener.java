/*    */ package net.highmc.bukkit.listener;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import net.highmc.bukkit.event.UpdateEvent;
/*    */ import net.highmc.bukkit.event.player.PlayerMoveUpdateEvent;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MoveListener
/*    */   implements Listener
/*    */ {
/* 22 */   private Map<UUID, Location> locationMap = new HashMap<>();
/*    */ 
/*    */   
/*    */   @EventHandler(priority = EventPriority.LOWEST)
/*    */   public void onUpdate(UpdateEvent event) {
/* 27 */     if (event.getCurrentTick() % 5L == 0L)
/* 28 */       for (Player player : Bukkit.getOnlinePlayers()) {
/* 29 */         if (this.locationMap.containsKey(player.getUniqueId())) {
/* 30 */           Location location = this.locationMap.get(player.getUniqueId());
/*    */           
/* 32 */           if (location.getX() != player.getLocation().getX() || location.getZ() != player.getLocation().getZ() || location
/* 33 */             .getY() != player.getLocation().getY()) {
/*    */             
/* 35 */             PlayerMoveUpdateEvent playerMoveUpdateEvent = new PlayerMoveUpdateEvent(player, location, player.getLocation());
/* 36 */             Bukkit.getPluginManager().callEvent((Event)playerMoveUpdateEvent);
/*    */             
/* 38 */             if (playerMoveUpdateEvent.isCancelled()) {
/* 39 */               player.teleport(new Location(location
/* 40 */                     .getWorld(), location.getX(), player.getLocation().getY(), location
/* 41 */                     .getZ(), location.getYaw(), location.getPitch()));
/*    */             }
/*    */           } 
/*    */         } 
/* 45 */         this.locationMap.put(player.getUniqueId(), player.getLocation());
/*    */       }  
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/listener/MoveListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */