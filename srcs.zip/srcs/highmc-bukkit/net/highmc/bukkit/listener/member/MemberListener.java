/*     */ package net.highmc.bukkit.listener.member;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.bukkit.event.member.PlayerGroupChangeEvent;
/*     */ import net.highmc.bukkit.event.member.PlayerUpdatedFieldEvent;
/*     */ import net.highmc.bukkit.event.player.PlayerAdminEvent;
/*     */ import net.highmc.bukkit.member.BukkitMember;
/*     */ import net.highmc.bukkit.member.party.BukkitParty;
/*     */ import net.highmc.bukkit.utils.player.PlayerAPI;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.member.party.Party;
/*     */ import net.highmc.member.status.StatusType;
/*     */ import net.highmc.permission.Group;
/*     */ import net.highmc.permission.GroupInfo;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.event.player.PlayerLoginEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MemberListener
/*     */   implements Listener
/*     */ {
/*     */   @EventHandler(priority = EventPriority.LOW)
/*     */   public void onAsyncPlayerPreLogin(AsyncPlayerPreLoginEvent event) {
/*  39 */     if (event.getLoginResult() != AsyncPlayerPreLoginEvent.Result.ALLOWED) {
/*     */       return;
/*     */     }
/*  42 */     UUID uniqueId = event.getUniqueId();
/*  43 */     BukkitMember member = (BukkitMember)CommonPlugin.getInstance().getMemberData().loadMember(uniqueId, BukkitMember.class);
/*     */     
/*  45 */     if (member == null) {
/*  46 */       event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, 
/*  47 */           CommonPlugin.getInstance().getPluginInfo().translate("account-not-exists"));
/*     */       
/*     */       return;
/*     */     } 
/*  51 */     Party party = member.getParty();
/*     */     
/*  53 */     if (party == null && member.getPartyId() != null) {
/*  54 */       party = CommonPlugin.getInstance().getPartyData().loadParty(member.getPartyId(), BukkitParty.class);
/*     */       
/*  56 */       if (party == null) {
/*  57 */         CommonPlugin.getInstance().debug("The party " + member.getPartyId() + " didnt load.");
/*     */       } else {
/*  59 */         CommonPlugin.getInstance().getPartyManager().loadParty(party);
/*     */       } 
/*     */     } 
/*  62 */     member.connect();
/*  63 */     CommonPlugin.getInstance().getMemberManager().loadMember((Member)member);
/*     */     
/*  65 */     for (StatusType types : BukkitCommon.getInstance().getPreloadedStatus())
/*  66 */       CommonPlugin.getInstance().getStatusManager().loadStatus(uniqueId, types); 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.LOWEST)
/*     */   public void onPlayerLoginLW(PlayerLoginEvent event) {
/*  71 */     if (CommonPlugin.getInstance().getMemberManager().getMember(event.getPlayer().getUniqueId()) == null) {
/*  72 */       event.disallow(PlayerLoginEvent.Result.KICK_OTHER, 
/*  73 */           CommonPlugin.getInstance().getPluginInfo().translate("account-not-loaded"));
/*     */       
/*     */       return;
/*     */     } 
/*  77 */     BukkitMember member = (BukkitMember)CommonPlugin.getInstance().getMemberManager().getMember(event.getPlayer().getUniqueId(), BukkitMember.class);
/*     */ 
/*     */     
/*  80 */     Player player = event.getPlayer();
/*  81 */     member.setPlayer(player);
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGH)
/*     */   public void onPlayerLogin(final PlayerLoginEvent event) {
/*  86 */     if (CommonPlugin.getInstance().getMemberManager().getMember(event.getPlayer().getUniqueId()) == null) {
/*  87 */       event.disallow(PlayerLoginEvent.Result.KICK_OTHER, 
/*  88 */           CommonPlugin.getInstance().getPluginInfo().translate("account-not-loaded"));
/*     */       
/*     */       return;
/*     */     } 
/*  92 */     final BukkitMember member = (BukkitMember)CommonPlugin.getInstance().getMemberManager().getMember(event.getPlayer().getUniqueId(), BukkitMember.class);
/*     */ 
/*     */     
/*  95 */     int admins = BukkitCommon.getInstance().getVanishManager().getPlayersInAdmin().size();
/*     */     
/*  97 */     if (event.getResult() == PlayerLoginEvent.Result.KICK_FULL && Bukkit.getOnlinePlayers().size() - admins >= Bukkit.getMaxPlayers() && 
/*  98 */       !member.hasPermission("server.full")) {
/*  99 */       event.setKickMessage("§cO servidor está cheio.");
/*     */       
/*     */       return;
/*     */     } 
/* 103 */     if ((event.getResult() == PlayerLoginEvent.Result.KICK_WHITELIST || !CommonPlugin.getInstance().isJoinEnabled()) && 
/* 104 */       !member.hasPermission("command.admin")) {
/* 105 */       event.setKickMessage("§cSomente membros da equipe podem entrar no momento.");
/*     */       
/*     */       return;
/*     */     } 
/* 109 */     event.allow();
/*     */     
/* 111 */     if (member.isUsingFake()) {
/* 112 */       PlayerAPI.changePlayerName(event.getPlayer(), member.getFakeName(), false);
/*     */     }
/* 114 */     if (member.hasCustomSkin()) {
/* 115 */       (new BukkitRunnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 119 */             PlayerAPI.changePlayerSkin(event.getPlayer(), member.getSkin().getValue(), member.getSkin().getSignature(), false);
/*     */           }
/* 122 */         }).runTask((Plugin)BukkitCommon.getInstance());
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.MONITOR)
/*     */   public void onPlayerLoginM(PlayerLoginEvent event) {
/* 128 */     if (event.getResult() != PlayerLoginEvent.Result.ALLOWED) {
/* 129 */       CommonPlugin.getInstance().getMemberManager().unloadMember(event.getPlayer().getUniqueId());
/* 130 */       CommonPlugin.getInstance().getStatusManager().unloadStatus(event.getPlayer().getUniqueId());
/*     */       return;
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.LOWEST)
/*     */   public void onPlayerJoin(PlayerJoinEvent event) {
/* 137 */     if (CommonPlugin.getInstance().getMemberManager().getMember(event.getPlayer().getUniqueId()) == null) {
/* 138 */       event.getPlayer().kickPlayer(CommonPlugin.getInstance().getPluginInfo().translate("account-not-loaded"));
/*     */       
/*     */       return;
/*     */     } 
/* 142 */     CommonPlugin.getInstance().getPluginPlatform().runAsync(() -> CommonPlugin.getInstance().getServerData().joinPlayer(event.getPlayer().getUniqueId(), Bukkit.getMaxPlayers()));
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler(priority = EventPriority.MONITOR)
/*     */   public void onPlayerAdmin(PlayerAdminEvent event) {
/* 148 */     if (event.getAdminMode() == PlayerAdminEvent.AdminMode.ADMIN) {
/* 149 */       CommonPlugin.getInstance().getPluginPlatform().runAsync(() -> CommonPlugin.getInstance().getServerData().leavePlayer(event.getPlayer().getUniqueId(), Bukkit.getMaxPlayers()));
/*     */     } else {
/*     */       
/* 152 */       CommonPlugin.getInstance().getPluginPlatform().runAsync(() -> CommonPlugin.getInstance().getServerData().joinPlayer(event.getPlayer().getUniqueId(), Bukkit.getMaxPlayers()));
/*     */     } 
/*     */   }
/*     */   @EventHandler
/*     */   public void onPlayerUpdatedField(PlayerUpdatedFieldEvent event) {
/*     */     Map<String, GroupInfo> oldObject, newObject;
/* 158 */     Player player = event.getPlayer();
/* 159 */     BukkitMember member = event.getBukkitMember();
/*     */     
/* 161 */     switch (event.getField().toLowerCase()) {
/*     */       case "groups":
/* 163 */         oldObject = (Map<String, GroupInfo>)event.getOldObject();
/* 164 */         newObject = (Map<String, GroupInfo>)event.getObject();
/*     */         
/* 166 */         if (newObject.isEmpty()) {
/*     */ 
/*     */           
/* 169 */           Group highGroup = CommonPlugin.getInstance().getPluginInfo().getGroupMap().values().stream().filter(group -> oldObject.containsKey(group.getGroupName().toLowerCase())).sorted((o1, o2) -> Integer.compare(o1.getId(), o2.getId())).findFirst().orElse(null);
/*     */           
/* 171 */           if (highGroup == null) {
/* 172 */             Bukkit.getPluginManager()
/* 173 */               .callEvent((Event)new PlayerGroupChangeEvent(player, (Member)member, (String)null, 0L, PlayerGroupChangeEvent.Action.UNKNOWN));
/*     */           } else {
/* 175 */             Bukkit.getPluginManager()
/* 176 */               .callEvent((Event)new PlayerGroupChangeEvent(player, (Member)member, highGroup, 0L, PlayerGroupChangeEvent.Action.REMOVE));
/*     */           } 
/* 178 */         } else if (oldObject.isEmpty()) {
/*     */ 
/*     */           
/* 181 */           Group highGroup = CommonPlugin.getInstance().getPluginInfo().getGroupMap().values().stream().filter(group -> newObject.containsKey(group.getGroupName().toLowerCase())).sorted((o1, o2) -> Integer.compare(o1.getId(), o2.getId())).findFirst().orElse(null);
/*     */           
/* 183 */           if (highGroup == null) {
/* 184 */             Bukkit.getPluginManager()
/* 185 */               .callEvent((Event)new PlayerGroupChangeEvent(player, (Member)member, (String)null, 0L, PlayerGroupChangeEvent.Action.SET));
/*     */           } else {
/* 187 */             Bukkit.getPluginManager()
/* 188 */               .callEvent((Event)new PlayerGroupChangeEvent(player, (Member)member, highGroup, 0L, PlayerGroupChangeEvent.Action.SET));
/*     */           }
/*     */         
/* 191 */         } else if (newObject.size() == 1) {
/* 192 */           String groupName = newObject.keySet().stream().findFirst().orElse(null);
/*     */           
/* 194 */           if (groupName == null)
/* 195 */           { Bukkit.getPluginManager()
/* 196 */               .callEvent((Event)new PlayerGroupChangeEvent(player, (Member)member, (String)null, 0L, PlayerGroupChangeEvent.Action.SET)); }
/*     */           else
/* 198 */           { Bukkit.getPluginManager()
/* 199 */               .callEvent((Event)new PlayerGroupChangeEvent(player, (Member)member, groupName, 0L, PlayerGroupChangeEvent.Action.SET)); } 
/* 200 */         } else if (oldObject.size() < newObject.size()) {
/*     */           
/* 202 */           String groupName = oldObject.keySet().stream().filter(group -> newObject.containsKey(group)).findFirst().orElse(null);
/*     */           
/* 204 */           if (groupName == null) {
/* 205 */             Bukkit.getPluginManager()
/* 206 */               .callEvent((Event)new PlayerGroupChangeEvent(player, (Member)member, (String)null, 0L, PlayerGroupChangeEvent.Action.ADD));
/*     */           } else {
/* 208 */             Bukkit.getPluginManager()
/* 209 */               .callEvent((Event)new PlayerGroupChangeEvent(player, (Member)member, groupName, 0L, PlayerGroupChangeEvent.Action.ADD));
/*     */           } 
/* 211 */         } else if (oldObject.size() > newObject.size()) {
/*     */           
/* 213 */           String groupName = newObject.keySet().stream().filter(group -> !oldObject.containsKey(group)).findFirst().orElse(null);
/*     */           
/* 215 */           if (groupName == null) {
/* 216 */             Bukkit.getPluginManager()
/* 217 */               .callEvent((Event)new PlayerGroupChangeEvent(player, (Member)member, (String)null, 0L, PlayerGroupChangeEvent.Action.REMOVE));
/*     */           } else {
/* 219 */             Bukkit.getPluginManager()
/* 220 */               .callEvent((Event)new PlayerGroupChangeEvent(player, (Member)member, groupName, 0L, PlayerGroupChangeEvent.Action.REMOVE));
/*     */           } 
/*     */         } else {
/* 223 */           Bukkit.getPluginManager().callEvent((Event)new PlayerGroupChangeEvent(player, (Member)member, newObject
/* 224 */                 .keySet().stream().findFirst().orElse(null), 0L, PlayerGroupChangeEvent.Action.UNKNOWN));
/*     */         } 
/*     */ 
/*     */         
/* 228 */         member.updateGroup();
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler(priority = EventPriority.LOWEST)
/*     */   public void onPlayerQuit(PlayerQuitEvent event) {
/* 238 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(event.getPlayer().getUniqueId());
/*     */     
/* 240 */     if (member != null)
/* 241 */       CommonPlugin.getInstance().getPluginPlatform().runAsync(() -> {
/*     */             CommonPlugin.getInstance().getMemberManager().unloadMember(member);
/*     */             CommonPlugin.getInstance().getServerData().leavePlayer(event.getPlayer().getUniqueId(), Bukkit.getMaxPlayers());
/*     */             CommonPlugin.getInstance().getStatusManager().unloadStatus(member.getUniqueId());
/*     */             Party party = member.getParty();
/*     */             if (party != null && !party.getMembers().stream().filter(()).findFirst().isPresent()) {
/*     */               CommonPlugin.getInstance().getPartyData().deleteParty(party);
/*     */               CommonPlugin.getInstance().getPartyManager().unloadParty(party.getPartyId());
/*     */             } 
/*     */           }); 
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/listener/member/MemberListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */