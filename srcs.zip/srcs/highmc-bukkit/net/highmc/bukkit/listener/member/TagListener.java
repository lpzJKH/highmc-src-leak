/*     */ package net.highmc.bukkit.listener.member;
/*     */ 
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.bukkit.event.member.PlayerChangedTagEvent;
/*     */ import net.highmc.bukkit.event.member.PlayerLanguageChangeEvent;
/*     */ import net.highmc.bukkit.member.BukkitMember;
/*     */ import net.highmc.bukkit.utils.player.PlayerHelper;
/*     */ import net.highmc.bukkit.utils.scoreboard.ScoreboardAPI;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.permission.Tag;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.event.server.PluginDisableEvent;
/*     */ 
/*     */ public class TagListener
/*     */   implements Listener
/*     */ {
/*  25 */   private static char[] chars = "abcdefghijklmnopqrstuv".toCharArray();
/*     */   
/*     */   @EventHandler
/*     */   public void onPluginDisable(PluginDisableEvent event) {
/*  29 */     if (BukkitCommon.getInstance().isTagControl())
/*  30 */       for (Player p : Bukkit.getServer().getOnlinePlayers()) {
/*  31 */         ScoreboardAPI.leaveCurrentTeamForOnlinePlayers(p);
/*     */       } 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.MONITOR)
/*     */   public void onPlayerQuit(PlayerQuitEvent event) {
/*  37 */     ScoreboardAPI.leaveCurrentTeamForOnlinePlayers(event.getPlayer());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerLanguageChange(PlayerLanguageChangeEvent event) {
/*  42 */     if (!BukkitCommon.getInstance().isTagControl()) {
/*     */       return;
/*     */     }
/*  45 */     Player player = event.getPlayer();
/*     */     
/*  47 */     for (Player o : Bukkit.getOnlinePlayers()) {
/*  48 */       Member bp = CommonPlugin.getInstance().getMemberManager().getMember(o.getUniqueId());
/*     */       
/*  50 */       Tag tag = bp.getTag();
/*  51 */       String id = getTeamName(tag);
/*     */       
/*  53 */       String prefix = PlayerHelper.translate(Language.getLanguage(player.getUniqueId()), tag.getRealPrefix());
/*     */       
/*  55 */       ScoreboardAPI.setTeamPrefixAndSuffix(ScoreboardAPI.createTeamIfNotExistsToPlayer(player, id, prefix, ""), prefix, "");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
/*     */   public void onPlayerChangeTag(PlayerChangedTagEvent event) {
/*  62 */     if (!BukkitCommon.getInstance().isTagControl()) {
/*     */       return;
/*     */     }
/*  65 */     Player p = event.getPlayer();
/*  66 */     BukkitMember bukkitMember = (BukkitMember)event.getMember();
/*     */     
/*  68 */     if (bukkitMember == null) {
/*     */       return;
/*     */     }
/*  71 */     String id = getTeamName(event.getNewTag());
/*  72 */     String oldId = getTeamName(event.getOldTag());
/*     */     
/*  74 */     String tag = PlayerHelper.translate(Language.getLanguage(bukkitMember.getUniqueId()), event
/*  75 */         .getNewTag().getRealPrefix());
/*     */     
/*  77 */     for (Player o : Bukkit.getOnlinePlayers()) {
/*  78 */       ScoreboardAPI.leaveTeamToPlayer(o, oldId, p);
/*  79 */       ScoreboardAPI.joinTeam(ScoreboardAPI.createTeamIfNotExistsToPlayer(o, id, tag, ""), p);
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.MONITOR)
/*     */   public void onPlayerJoin(PlayerJoinEvent e) {
/*  85 */     if (!BukkitCommon.getInstance().isTagControl()) {
/*     */       return;
/*     */     }
/*  88 */     Player p = e.getPlayer();
/*     */     
/*  90 */     Member player = CommonPlugin.getInstance().getMemberManager().getMember(e.getPlayer().getUniqueId(), BukkitMember.class);
/*     */     
/*  92 */     Tag tag = player.getTag();
/*  93 */     String id = getTeamName(tag);
/*     */     
/*  95 */     for (Player o : Bukkit.getOnlinePlayers()) {
/*  96 */       ScoreboardAPI.joinTeam(ScoreboardAPI.createTeamIfNotExistsToPlayer(o, id, 
/*  97 */             PlayerHelper.translate(Language.getLanguage(o.getUniqueId()), tag.getRealPrefix()), ""), p);
/*     */     }
/*     */     
/* 100 */     for (Player o : Bukkit.getOnlinePlayers()) {
/* 101 */       if (!o.getUniqueId().equals(p.getUniqueId())) {
/*     */         
/* 103 */         BukkitMember bp = (BukkitMember)CommonPlugin.getInstance().getMemberManager().getMember(o.getUniqueId());
/*     */         
/* 105 */         if (bp == null) {
/* 106 */           o.kickPlayer("§cSua conta não foi carregada.");
/*     */           
/*     */           return;
/*     */         } 
/* 110 */         tag = bp.getTag();
/* 111 */         id = getTeamName(tag);
/*     */         
/* 113 */         ScoreboardAPI.joinTeam(ScoreboardAPI.createTeamIfNotExistsToPlayer(p, id, 
/* 114 */               PlayerHelper.translate(player.getLanguage(), tag.getRealPrefix()), ""), o);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String getTeamName(Tag tag) {
/* 120 */     String p = chars[tag.getTagId()] + "";
/* 121 */     return p;
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/listener/member/TagListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */