/*     */ package net.highmc.bukkit.listener;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import net.highmc.BukkitConst;
/*     */ import net.highmc.CommonConst;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.command.CommandSender;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.medal.Medal;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.member.Profile;
/*     */ import net.highmc.punish.Punish;
/*     */ import net.highmc.punish.PunishType;
/*     */ import net.highmc.utils.DateUtils;
/*     */ import net.highmc.utils.string.MessageBuilder;
/*     */ import net.highmc.utils.string.StringFormat;
/*     */ import net.md_5.bungee.api.chat.BaseComponent;
/*     */ import net.md_5.bungee.api.chat.ClickEvent;
/*     */ import net.md_5.bungee.api.chat.HoverEvent;
/*     */ import net.md_5.bungee.api.chat.TextComponent;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.player.AsyncPlayerChatEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ 
/*     */ public class ChatListener
/*     */   implements Listener {
/*  36 */   public static final Pattern PATTERN = Pattern.compile("(§%question-(\\d+)%§)");
/*     */   
/*     */   @EventHandler(priority = EventPriority.LOWEST)
/*     */   public void onAsyncPlayerChatLW(AsyncPlayerChatEvent event) {
/*  40 */     if (BukkitCommon.getInstance().getChatManager().containsChat(event.getPlayer().getUniqueId())) {
/*  41 */       event.setCancelled(true);
/*     */       
/*  43 */       Player player = event.getPlayer();
/*  44 */       String message = event.getMessage();
/*     */       
/*  46 */       boolean cancel = (message.contains("cancel") || Language.getLanguage(player.getUniqueId()).t("cancel", new String[0]).equalsIgnoreCase(message));
/*     */       
/*  48 */       boolean validate = BukkitCommon.getInstance().getChatManager().validate(player.getUniqueId(), message);
/*     */       
/*  50 */       if (validate || cancel) {
/*  51 */         String nextQuestion = BukkitCommon.getInstance().getChatManager().callback(player.getUniqueId(), event
/*  52 */             .getMessage(), cancel);
/*     */         
/*  54 */         if (nextQuestion != null) {
/*  55 */           Matcher matcher = PATTERN.matcher(nextQuestion);
/*     */           
/*  57 */           while (matcher.find()) {
/*  58 */             String replace = matcher.group(), id = matcher.group(2).toLowerCase();
/*  59 */             nextQuestion = nextQuestion.replace(replace, BukkitCommon.getInstance().getChatManager()
/*  60 */                 .getAnswers(player.getUniqueId(), StringFormat.parseInt(id).getAsInt() - 1));
/*     */           } 
/*     */           
/*  63 */           if (BukkitCommon.getInstance().getChatManager().isClearChat(player.getUniqueId()))
/*  64 */             for (int i = 0; i < 100; i++) {
/*  65 */               player.sendMessage(" ");
/*     */             } 
/*  67 */           player.sendMessage(nextQuestion);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
/*     */   public void onAsyncPlayerChatL(AsyncPlayerChatEvent event) {
/*  75 */     Player player = event.getPlayer();
/*  76 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId());
/*     */     
/*  78 */     if (member == null) {
/*  79 */       event.setCancelled(true);
/*     */       
/*     */       return;
/*     */     } 
/*  83 */     Punish punish = member.getPunishConfiguration().getActualPunish(PunishType.MUTE);
/*     */     
/*  85 */     if (punish != null) {
/*  86 */       member.sendMessage((BaseComponent)(new MessageBuilder(punish.getMuteMessage(member.getLanguage())))
/*  87 */           .setHoverEvent("§fPunido em: §7" + CommonConst.DATE_FORMAT.format(Long.valueOf(punish.getCreatedAt())) + "\n§fExpire em: §7" + (
/*     */             
/*  89 */             punish.isPermanent() ? "§cnunca" : 
/*  90 */             DateUtils.formatDifference(member.getLanguage(), punish.getExpireAt() / 1000L)))
/*  91 */           .create());
/*  92 */       event.setCancelled(true);
/*     */       
/*     */       return;
/*     */     } 
/*  96 */     switch (BukkitCommon.getInstance().getChatState()) {
/*     */ 
/*     */ 
/*     */       
/*     */       case DISABLED:
/* 101 */         if (!member.hasPermission("chat.disabled-say")) {
/* 102 */           member.sendMessage("§cVocê não pode falar no chat no momento, somente membros da equipe.");
/* 103 */           event.setCancelled(true);
/*     */           return;
/*     */         } 
/*     */         break;
/*     */       
/*     */       case YOUTUBER:
/* 109 */         if (!member.hasPermission("chat.youtuber-say")) {
/* 110 */           member.sendMessage("§cVocê não pode falar no chat no momento, somente celebridades do servidor.");
/* 111 */           event.setCancelled(true);
/*     */           return;
/*     */         } 
/*     */         break;
/*     */       
/*     */       case PAYMENT:
/* 117 */         if (!member.hasPermission("chat.payment-say")) {
/* 118 */           member.sendMessage("§cVocê não pode falar no chat no momento, somente jogadores pagantes.");
/* 119 */           event.setCancelled(true);
/*     */           return;
/*     */         } 
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 126 */     if (member.hasCooldown("chat-cooldown") && !member.hasPermission("command.admin")) {
/* 127 */       member.sendActionBar("§cVocê precisa esperar " + member.getCooldownFormatted("chat-cooldown") + " para falar no chat novamente.");
/*     */       
/* 129 */       event.setCancelled(true);
/*     */       
/*     */       return;
/*     */     } 
/* 133 */     member.putCooldown("chat-cooldown", 3.5D);
/*     */     
/* 135 */     if (!member.hasPermission("command.admin"))
/* 136 */       for (String string : event.getMessage().split(" ")) {
/* 137 */         if (BukkitConst.SWEAR_WORDS.contains(string.toLowerCase())) {
/* 138 */           StringBuilder stringBuilder = new StringBuilder();
/*     */           
/* 140 */           for (int x = 0; x < string.length(); x++) {
/* 141 */             stringBuilder.append('*');
/*     */           }
/* 143 */           event.setMessage(event.getMessage().replace(string, stringBuilder.toString().trim()));
/*     */         } 
/*     */       }  
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
/*     */   public void onAsyncPlayerChatN(AsyncPlayerChatEvent event) {
/* 150 */     event.setCancelled(true);
/* 151 */     Player player = event.getPlayer();
/* 152 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId());
/* 153 */     String message = event.getMessage();
/* 154 */     MessageBuilder messageBuilder = new MessageBuilder("");
/*     */     
/* 156 */     Medal medal = member.getMedal();
/*     */     
/* 158 */     if (medal != null) {
/* 159 */       messageBuilder.extra((new MessageBuilder(medal.getChatColor() + medal.getSymbol() + " "))
/* 160 */           .setHoverEvent("§aMedalha: " + medal.getChatColor() + medal.getMedalName()).create());
/*     */     }
/*     */     
/* 163 */     messageBuilder.extra((new MessageBuilder(member.getTag().getRealPrefix() + player.getName()))
/* 164 */         .setHoverEvent("§a" + player.getName() + "\n\n§fMedalha: " + ((medal == null) ? "§7Nenhuma" : (medal
/* 165 */           .getChatColor() + medal.getSymbol())) + "\n§fTempo de sessão atual: §7" + 
/*     */           
/* 167 */           DateUtils.formatDifference(member.getLanguage(), member.getSessionTime() / 1000L) + "\n\n§eMensagem enviada às " + CommonConst.TIME_FORMAT
/* 168 */           .format(Long.valueOf(System.currentTimeMillis())) + ".")
/* 169 */         .create());
/* 170 */     messageBuilder.extra(" §7» §f");
/*     */     
/* 172 */     String[] split = event.getMessage().split(" ");
/* 173 */     String currentColor = "§f";
/*     */     
/* 175 */     for (int x = 0; x < split.length; x++) {
/* 176 */       String msg = ((x > 0) ? " " : "") + currentColor + split[x];
/*     */       
/* 178 */       List<String> links = extractUrls(msg);
/*     */       
/* 180 */       if (links.isEmpty()) {
/* 181 */         messageBuilder.extra((new MessageBuilder(msg)).create());
/*     */       } else {
/* 183 */         String url = ((String)links.stream().findFirst().orElse(null)).toLowerCase();
/*     */         
/* 185 */         if (!url.contains("you") && !url.contains("twitch") && 
/* 186 */           !member.hasPermission("command.admin")) {
/* 187 */           member.sendMessage("§cNão é permitido enviar links.");
/* 188 */           event.setCancelled(true);
/*     */           
/*     */           return;
/*     */         } 
/* 192 */         messageBuilder
/* 193 */           .extra((new MessageBuilder(msg)).setClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, url))
/* 194 */             .setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, 
/* 195 */                 TextComponent.fromLegacyText(url)))
/* 196 */             .create());
/*     */       } 
/*     */       
/* 199 */       currentColor = ChatColor.getLastColors(msg);
/*     */     } 
/*     */     
/* 202 */     TextComponent textComponent = messageBuilder.create();
/*     */     
/* 204 */     event.getRecipients().removeIf(recipient -> {
/*     */           Member memberRecipient = CommonPlugin.getInstance().getMemberManager().getMember(recipient.getUniqueId());
/*     */           
/* 207 */           return (memberRecipient == null || memberRecipient.getUniqueId().equals(member.getUniqueId())) ? false : (
/*     */ 
/*     */             
/* 210 */             (!memberRecipient.getMemberConfiguration().isSeeingChat() && !member.hasPermission("staff.seechat-ignore")) ? true : (
/*     */ 
/*     */ 
/*     */             
/* 214 */             (memberRecipient.isUserBlocked(Profile.from((CommandSender)member)) && !member.hasPermission("staff.seechat-ignore"))));
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 221 */     event.getRecipients().forEach(recipient -> recipient.spigot().sendMessage((BaseComponent)textComponent));
/*     */     
/* 223 */     Bukkit.getConsoleSender().sendMessage(member.getPlayerName() + ": " + message);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerQuit(PlayerQuitEvent event) {
/* 228 */     BukkitCommon.getInstance().getChatManager().remove(event.getPlayer().getUniqueId());
/*     */   }
/*     */ 
/*     */   
/* 232 */   private static Pattern urlFinderPattern = Pattern.compile("((https?):((//)|(\\\\))+[\\w\\d:#@%/;$()~_?\\+-=\\\\\\.&]*)", 2);
/*     */   
/*     */   public static List<String> extractUrls(String text) {
/* 235 */     List<String> containedUrls = new ArrayList<>();
/* 236 */     Matcher urlMatcher = urlFinderPattern.matcher(text);
/*     */     
/* 238 */     while (urlMatcher.find()) {
/* 239 */       containedUrls.add(urlMatcher.group(1));
/*     */     }
/*     */     
/* 242 */     return containedUrls;
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/listener/ChatListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */