/*     */ package net.highmc.bukkit.listener;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import net.highmc.bukkit.event.player.PlayerDamagePlayerEvent;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.enchantments.Enchantment;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.entity.Projectile;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*     */ import org.bukkit.event.entity.EntityDamageEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.metadata.MetadataValue;
/*     */ import org.bukkit.potion.PotionEffect;
/*     */ import org.bukkit.potion.PotionEffectType;
/*     */ 
/*     */ 
/*     */ public class CombatListener
/*     */   implements Listener
/*     */ {
/*  27 */   private static final Map<Material, Double> DAMAGE = new HashMap<>();
/*     */   
/*     */   static {
/*  30 */     DAMAGE.put(Material.WOOD_SWORD, Double.valueOf(2.0D));
/*  31 */     DAMAGE.put(Material.STONE_SWORD, Double.valueOf(4.0D));
/*  32 */     DAMAGE.put(Material.IRON_SWORD, Double.valueOf(6.0D));
/*  33 */     DAMAGE.put(Material.DIAMOND_SWORD, Double.valueOf(8.0D));
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGHEST)
/*     */   public void onEntityDamage(EntityDamageEvent event) {
/*  38 */     if (!(event.getEntity() instanceof Player)) {
/*     */       return;
/*     */     }
/*     */     
/*  42 */     Player player = (Player)event.getEntity();
/*     */     
/*  44 */     if (event.getCause() == EntityDamageEvent.DamageCause.FALL && 
/*  45 */       player.hasMetadata("nofall")) {
/*  46 */       MetadataValue metadata = player.getMetadata("nofall").stream().findFirst().orElse(null);
/*     */       
/*  48 */       if (metadata.asLong() > System.currentTimeMillis()) {
/*  49 */         event.setCancelled(true);
/*     */       }
/*  51 */       metadata.invalidate();
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGHEST)
/*     */   public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
/*  57 */     if (!(event.getEntity() instanceof Player)) {
/*     */       return;
/*     */     }
/*  60 */     Player player = (Player)event.getEntity();
/*  61 */     Player damager = null;
/*     */     
/*  63 */     if (event.getDamager() instanceof Player) {
/*  64 */       damager = (Player)event.getDamager();
/*  65 */     } else if (event.getDamager() instanceof Projectile) {
/*  66 */       Projectile projectile = (Projectile)event.getDamager();
/*     */       
/*  68 */       if (projectile.getShooter() instanceof Player) {
/*  69 */         damager = (Player)projectile.getShooter();
/*     */       }
/*     */     } 
/*     */     
/*  73 */     if (!(damager instanceof Player)) {
/*     */       return;
/*     */     }
/*     */     
/*  77 */     PlayerDamagePlayerEvent playerDamagePlayerEvent = new PlayerDamagePlayerEvent(player, damager, event.isCancelled(), event.getDamage(), event.getFinalDamage());
/*     */     
/*  79 */     Bukkit.getPluginManager().callEvent((Event)playerDamagePlayerEvent);
/*     */     
/*  81 */     event.setCancelled(playerDamagePlayerEvent.isCancelled());
/*  82 */     event.setDamage(playerDamagePlayerEvent.getDamage());
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.LOWEST)
/*     */   public void onEntityDamageEvent(EntityDamageByEntityEvent event) {
/*  87 */     if (!(event.getDamager() instanceof Player)) {
/*     */       return;
/*     */     }
/*  90 */     Player p = (Player)event.getDamager();
/*  91 */     ItemStack sword = p.getItemInHand();
/*  92 */     double damage = event.getDamage();
/*  93 */     double danoEspada = getDamage(sword.getType());
/*  94 */     boolean isMore = false;
/*     */     
/*  96 */     if (damage > 1.0D) {
/*  97 */       isMore = true;
/*     */     }
/*  99 */     if (p.hasPotionEffect(PotionEffectType.INCREASE_DAMAGE)) {
/* 100 */       for (PotionEffect effect : p.getActivePotionEffects()) {
/* 101 */         if (effect.getType().equals(PotionEffectType.INCREASE_DAMAGE)) {
/*     */           double minus;
/* 103 */           if (isCrital(p)) {
/* 104 */             minus = (danoEspada + danoEspada / 2.0D) * 1.3D * (effect.getAmplifier() + 1);
/*     */           } else {
/* 106 */             minus = danoEspada * 1.3D * (effect.getAmplifier() + 1);
/*     */           } 
/* 108 */           damage -= minus;
/* 109 */           damage += (2 * (effect.getAmplifier() + 1));
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/* 115 */     if (!sword.getEnchantments().isEmpty()) {
/* 116 */       if (sword.containsEnchantment(Enchantment.DAMAGE_ARTHROPODS) && isArthropod(event.getEntityType())) {
/* 117 */         damage -= 1.5D * sword.getEnchantmentLevel(Enchantment.DAMAGE_ARTHROPODS);
/* 118 */         damage += (1 * sword.getEnchantmentLevel(Enchantment.DAMAGE_ARTHROPODS));
/*     */       } 
/* 120 */       if (sword.containsEnchantment(Enchantment.DAMAGE_UNDEAD) && isUndead(event.getEntityType())) {
/* 121 */         damage -= 1.5D * sword.getEnchantmentLevel(Enchantment.DAMAGE_UNDEAD);
/* 122 */         damage += (1 * sword.getEnchantmentLevel(Enchantment.DAMAGE_UNDEAD));
/*     */       } 
/* 124 */       if (sword.containsEnchantment(Enchantment.DAMAGE_ALL)) {
/* 125 */         damage -= 1.25D * sword.getEnchantmentLevel(Enchantment.DAMAGE_ALL);
/* 126 */         damage += (1 * sword.getEnchantmentLevel(Enchantment.DAMAGE_ALL));
/*     */       } 
/*     */     } 
/*     */     
/* 130 */     if (isCrital(p)) {
/* 131 */       damage += 0.5D;
/*     */     }
/* 133 */     if (isMore) {
/* 134 */       damage -= 2.0D;
/*     */     }
/* 136 */     event.setDamage(damage);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isCrital(Player p) {
/* 141 */     return (p.getFallDistance() > 0.0F && !p.isOnGround() && !p.hasPotionEffect(PotionEffectType.BLINDNESS));
/*     */   }
/*     */   
/*     */   private boolean isArthropod(EntityType type) {
/* 145 */     switch (type) {
/*     */       case CAVE_SPIDER:
/* 147 */         return true;
/*     */       case SPIDER:
/* 149 */         return true;
/*     */       case SILVERFISH:
/* 151 */         return true;
/*     */     } 
/*     */ 
/*     */     
/* 155 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isUndead(EntityType type) {
/* 159 */     switch (type) {
/*     */       case SKELETON:
/* 161 */         return true;
/*     */       case ZOMBIE:
/* 163 */         return true;
/*     */       case WITHER_SKULL:
/* 165 */         return true;
/*     */       case PIG_ZOMBIE:
/* 167 */         return true;
/*     */     } 
/*     */ 
/*     */     
/* 171 */     return false;
/*     */   }
/*     */   
/*     */   private double getDamage(Material type) {
/* 175 */     double damage = 1.0D;
/* 176 */     if (type.toString().contains("DIAMOND_")) {
/* 177 */       damage = 7.0D;
/* 178 */     } else if (type.toString().contains("IRON_")) {
/* 179 */       damage = 5.0D;
/* 180 */     } else if (type.toString().contains("STONE_")) {
/* 181 */       damage = 4.0D;
/* 182 */     } else if (type.toString().contains("WOOD_")) {
/* 183 */       damage = 3.0D;
/* 184 */     } else if (type.toString().contains("GOLD_")) {
/* 185 */       damage = 3.0D;
/*     */     } 
/* 187 */     if (!type.toString().contains("_SWORD")) {
/* 188 */       damage--;
/* 189 */       if (!type.toString().contains("_AXE")) {
/* 190 */         damage--;
/* 191 */         if (!type.toString().contains("_PICKAXE")) {
/* 192 */           damage--;
/* 193 */           if (!type.toString().contains("_SPADE")) {
/* 194 */             damage = 1.0D;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 199 */     return damage;
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/listener/CombatListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */