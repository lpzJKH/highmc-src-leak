/*    */ package net.highmc.bukkit.listener;
/*    */ 
/*    */ import java.util.stream.Collectors;
/*    */ import net.highmc.bukkit.BukkitCommon;
/*    */ import net.highmc.bukkit.utils.hologram.Hologram;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.entity.ArmorStand;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.EntityType;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
/*    */ import org.bukkit.event.server.PluginDisableEvent;
/*    */ import org.bukkit.event.world.ChunkLoadEvent;
/*    */ import org.bukkit.event.world.ChunkUnloadEvent;
/*    */ import org.bukkit.event.world.WorldLoadEvent;
/*    */ 
/*    */ 
/*    */ public class HologramListener
/*    */   implements Listener
/*    */ {
/*    */   public HologramListener() {
/* 24 */     for (World world : Bukkit.getWorlds()) {
/*    */       
/* 26 */       for (Entity armorStand : world.getEntities().stream().filter(entity -> (entity.getType() == EntityType.ARMOR_STAND)).collect(Collectors.toList())) {
/* 27 */         armorStand.remove();
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerArmorStandManipulate(PlayerArmorStandManipulateEvent e) {
/* 48 */     ArmorStand armorStand = e.getRightClicked();
/* 49 */     if (!armorStand.isVisible()) {
/* 50 */       e.setCancelled(true);
/*    */     }
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onWorldLoad(WorldLoadEvent event) {
/* 56 */     for (Entity armorStand : event.getWorld().getEntities().stream().filter(entity -> (entity.getType() == EntityType.ARMOR_STAND)).collect(Collectors.toList()))
/* 57 */       armorStand.remove(); 
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onChunkLoad(ChunkLoadEvent event) {
/* 62 */     for (Hologram hologram : BukkitCommon.getInstance().getHologramManager().getHologramList()) {
/* 63 */       if (hologram.getLocation().getChunk().equals(event.getChunk()) && 
/* 64 */         !hologram.isSpawned())
/* 65 */         hologram.spawn(); 
/*    */     } 
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onChunkUnload(ChunkUnloadEvent event) {
/* 71 */     for (Hologram hologram : BukkitCommon.getInstance().getHologramManager().getHologramList()) {
/* 72 */       if (hologram.isSpawned() && 
/* 73 */         hologram.getLocation().getChunk().equals(event.getChunk()))
/* 74 */         event.setCancelled(true); 
/*    */     } 
/*    */   }
/*    */   @EventHandler
/*    */   public void onPluginDisable(PluginDisableEvent event) {
/* 79 */     for (Hologram hologram : BukkitCommon.getInstance().getHologramManager().getHologramList())
/* 80 */       hologram.remove(); 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/listener/HologramListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */