/*    */ package net.highmc.bukkit.listener;
/*    */ 
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.bukkit.BukkitCommon;
/*    */ import net.highmc.bukkit.event.player.PlayerAdminEvent;
/*    */ import net.highmc.bukkit.event.player.PlayerShowToPlayerEvent;
/*    */ import net.highmc.member.Member;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerInteractEntityEvent;
/*    */ import org.bukkit.event.player.PlayerJoinEvent;
/*    */ import org.bukkit.event.player.PlayerPickupItemEvent;
/*    */ import org.bukkit.event.player.PlayerQuitEvent;
/*    */ 
/*    */ 
/*    */ public class VanishListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler(priority = EventPriority.LOWEST)
/*    */   public void onPlayerJoinL(PlayerJoinEvent event) {
/* 25 */     Player player = event.getPlayer();
/*    */     
/* 27 */     BukkitCommon.getInstance().getVanishManager().updateVanishToPlayer(player);
/* 28 */     Bukkit.getOnlinePlayers().forEach(online -> {
/*    */           if (online.getUniqueId().equals(player.getUniqueId())) {
/*    */             return;
/*    */           }
/*    */           PlayerShowToPlayerEvent eventCall = new PlayerShowToPlayerEvent(player, online);
/*    */           Bukkit.getPluginManager().callEvent((Event)eventCall);
/*    */           if (eventCall.isCancelled()) {
/*    */             if (online.canSee(player))
/*    */               online.hidePlayer(player); 
/*    */           } else if (!online.canSee(player)) {
/*    */             online.showPlayer(player);
/*    */           } 
/*    */         });
/*    */   }
/*    */   
/*    */   @EventHandler(priority = EventPriority.HIGH)
/*    */   public void onPlayerJoin(PlayerJoinEvent event) {
/* 45 */     Player player = event.getPlayer();
/* 46 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId());
/*    */     
/* 48 */     if (player.hasPermission("command.admin") && member.getMemberConfiguration().isAdminOnJoin())
/* 49 */       BukkitCommon.getInstance().getVanishManager().setPlayerInAdmin(player); 
/*    */   }
/*    */   
/*    */   @EventHandler(priority = EventPriority.HIGHEST)
/*    */   public void onPlayerPickupItem(PlayerPickupItemEvent event) {
/* 54 */     if (isPlayerInAdmin(event.getPlayer()))
/* 55 */       event.setCancelled(true); 
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerInteractEntity(PlayerInteractEntityEvent event) {
/* 60 */     if (event.getRightClicked() instanceof Player && 
/* 61 */       isPlayerInAdmin(event.getPlayer()))
/* 62 */       event.getPlayer().performCommand("invsee " + event.getRightClicked().getName()); 
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerAdmin(PlayerAdminEvent event) {
/* 67 */     CommonPlugin.getInstance().getMemberManager().getMember(event.getPlayer().getUniqueId())
/* 68 */       .getMemberConfiguration().setAdminMode((event.getAdminMode() == PlayerAdminEvent.AdminMode.ADMIN));
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerQuit(PlayerQuitEvent event) {
/* 73 */     BukkitCommon.getInstance().getVanishManager().resetPlayer(event.getPlayer());
/*    */   }
/*    */   
/*    */   private boolean isPlayerInAdmin(Player player) {
/* 77 */     return BukkitCommon.getInstance().getVanishManager().isPlayerInAdmin(player);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/listener/VanishListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */