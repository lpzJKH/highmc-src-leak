/*     */ package net.highmc.bukkit.listener;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.UUID;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.bukkit.event.member.PlayerGroupChangeEvent;
/*     */ import net.highmc.bukkit.event.server.ServerPacketReceiveEvent;
/*     */ import net.highmc.bukkit.utils.player.PlayerHelper;
/*     */ import net.highmc.bukkit.utils.scoreboard.ScoreHelper;
/*     */ import net.highmc.packet.types.ActionBar;
/*     */ import net.highmc.permission.Group;
/*     */ import org.bukkit.Achievement;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.scoreboard.Objective;
/*     */ import org.bukkit.scoreboard.Scoreboard;
/*     */ import org.bukkit.scoreboard.Team;
/*     */ 
/*     */ public class PlayerListener
/*     */   implements Listener
/*     */ {
/*     */   @EventHandler(priority = EventPriority.LOWEST)
/*     */   public void onPlayerJoin(PlayerJoinEvent event) {
/*  32 */     event.setJoinMessage(null);
/*  33 */     event.getPlayer().awardAchievement(Achievement.OPEN_INVENTORY);
/*     */     
/*  35 */     event.getPlayer().setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onServerPacket(ServerPacketReceiveEvent event) {
/*  40 */     if (event.getPacket() instanceof ActionBar) {
/*  41 */       ActionBar actionBar = (ActionBar)event.getPacket();
/*  42 */       Player player = Bukkit.getPlayer(actionBar.getUniqueId());
/*     */       
/*  44 */       if (player != null)
/*  45 */         PlayerHelper.actionbar(player, actionBar.getText()); 
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerGroupChange(PlayerGroupChangeEvent event) {
/*  51 */     Group group = event.getGroup();
/*     */     
/*  53 */     if (group == null) {
/*  54 */       PlayerHelper.title(event.getPlayer(), event.getMember().getDefaultTag().getRealPrefix(), "§fseu grupo foi atualizado.", 15, 60, 15);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  59 */     String strippedColor = CommonPlugin.getInstance().getPluginInfo().getTagByGroup(group).getStrippedColor();
/*     */     
/*  61 */     switch (event.getAction()) {
/*     */       case ADD:
/*  63 */         PlayerHelper.title(event.getPlayer(), strippedColor, "§ffoi adicionado a você.", 15, 60, 15);
/*     */         return;
/*     */       case REMOVE:
/*  66 */         PlayerHelper.title(event.getPlayer(), strippedColor, "§ffoi removido de você.", 15, 60, 15);
/*     */         return;
/*     */       case SET:
/*  69 */         PlayerHelper.title(event.getPlayer(), strippedColor, "§fvocê se tornou.", 15, 60, 15);
/*     */         return;
/*     */     } 
/*  72 */     PlayerHelper.title(event.getPlayer(), strippedColor, "§fseu grupo foi atualizado", 15, 60, 15);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGHEST)
/*     */   public void onPlayerQuitListener(PlayerQuitEvent event) {
/*  79 */     event.setQuitMessage(null);
/*  80 */     ScoreHelper.getInstance().removeScoreboard(event.getPlayer());
/*  81 */     Scoreboard board = event.getPlayer().getScoreboard();
/*     */     
/*  83 */     if (board != null) {
/*  84 */       for (Team t : board.getTeams()) {
/*  85 */         t.unregister();
/*     */       }
/*     */       
/*  88 */       for (Objective ob : board.getObjectives()) {
/*  89 */         ob.unregister();
/*     */       }
/*     */     } 
/*     */     
/*  93 */     event.getPlayer().setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
/*  94 */     removePlayerFile(event.getPlayer().getUniqueId());
/*     */   }
/*     */   
/*     */   private void removePlayerFile(UUID uuid) {
/*  98 */     if (BukkitCommon.getInstance().isRemovePlayerDat()) {
/*  99 */       World world = Bukkit.getWorlds().get(0);
/* 100 */       File folder = new File(world.getWorldFolder(), "playerdata");
/*     */       
/* 102 */       if (folder.exists() && folder.isDirectory()) {
/* 103 */         File file = new File(folder, uuid.toString() + ".dat");
/* 104 */         Bukkit.getScheduler().runTaskLaterAsynchronously((Plugin)BukkitCommon.getInstance(), () -> { if (file.exists() && !file.delete()) removePlayerFile(uuid);  }2L);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/listener/PlayerListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */