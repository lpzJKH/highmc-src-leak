/*    */ package net.highmc.bukkit.anticheat.listener;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.bukkit.anticheat.StormCore;
/*    */ import net.highmc.bukkit.anticheat.gamer.UserData;
/*    */ import net.highmc.bukkit.member.BukkitMember;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.entity.PlayerDeathEvent;
/*    */ import org.bukkit.event.player.PlayerJoinEvent;
/*    */ import org.bukkit.event.player.PlayerLoginEvent;
/*    */ import org.bukkit.event.player.PlayerMoveEvent;
/*    */ import org.bukkit.event.player.PlayerPortalEvent;
/*    */ import org.bukkit.event.player.PlayerRespawnEvent;
/*    */ import org.bukkit.event.player.PlayerTeleportEvent;
/*    */ 
/*    */ public class PlayerListener implements Listener {
/*    */   @EventHandler(priority = EventPriority.LOWEST)
/*    */   public void onPlayerDeath(PlayerDeathEvent event) {
/* 21 */     StormCore.getInstance().ignore(event.getEntity(), 4.0D);
/*    */   }
/*    */   
/*    */   @EventHandler(priority = EventPriority.LOWEST)
/*    */   public void onPlayerLogin(PlayerLoginEvent event) {
/* 26 */     StormCore.getInstance().ignore(event.getPlayer(), 4.0D);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerRespawn(PlayerRespawnEvent event) {
/* 31 */     StormCore.getInstance().ignore(event.getPlayer(), 4.0D);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerVelocity(Player event) {
/* 36 */     StormCore.getInstance().ignore(event.getPlayer(), 0.5D);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerTeleport(PlayerTeleportEvent event) {
/* 41 */     StormCore.getInstance().ignore(event.getPlayer(), 4.0D);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerPortal(PlayerPortalEvent event) {
/* 46 */     StormCore.getInstance().ignore(event.getPlayer(), 4.0D);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerJoin(PlayerJoinEvent event) {
/* 51 */     StormCore.getInstance().ignore(event.getPlayer(), 4.0D);
/*    */   }
/*    */   
/*    */   @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
/*    */   public void onPlayerMove(PlayerMoveEvent event) {
/* 56 */     UserData userData = getUserData(event.getPlayer());
/* 57 */     Location lastLocation = (userData.getLastLocation() == null) ? event.getFrom() : userData.getLastLocation();
/*    */     
/* 59 */     userData.setDistanceY(lastLocation.getY() - event.getTo().getY());
/*    */     
/* 61 */     if (userData.getDistanceY() > 0.05D) {
/* 62 */       userData.setGoingUp(true);
/* 63 */       userData.setFalling(false);
/* 64 */     } else if (userData.getDistanceY() < -0.05D) {
/* 65 */       userData.setGoingUp(false);
/* 66 */       userData.setFalling(true);
/*    */     } else {
/* 68 */       userData.setGoingUp(false);
/* 69 */       userData.setFalling(false);
/*    */     } 
/*    */     
/* 72 */     userData.setPing((((CraftPlayer)event.getPlayer()).getHandle()).ping);
/* 73 */     userData.setLastLocation(event.getTo().clone());
/*    */   }
/*    */   
/*    */   public UserData getUserData(Player player) {
/* 77 */     return ((BukkitMember)CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId(), BukkitMember.class)).getUserData();
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/anticheat/listener/PlayerListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */