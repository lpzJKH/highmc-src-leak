/*    */ package net.highmc.bukkit.anticheat.gamer;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.bukkit.anticheat.StormCore;
/*    */ import net.highmc.bukkit.anticheat.hack.HackData;
/*    */ import net.highmc.bukkit.anticheat.hack.HackType;
/*    */ import net.highmc.member.Member;
/*    */ import net.highmc.utils.string.MessageBuilder;
/*    */ import net.md_5.bungee.api.chat.BaseComponent;
/*    */ import net.md_5.bungee.api.chat.ClickEvent;
/*    */ import org.bukkit.Location;
/*    */ 
/*    */ public class UserData {
/*    */   private final UUID playerId;
/*    */   private String playerName;
/*    */   private Map<HackType, HackData> hackMap;
/*    */   private Location lastLocation;
/*    */   
/* 22 */   public UUID getPlayerId() { return this.playerId; } private double distanceY; private boolean isFalling; private boolean isGoingUp; private int ping; public String getPlayerName() {
/* 23 */     return this.playerName;
/*    */   } public Map<HackType, HackData> getHackMap() {
/* 25 */     return this.hackMap;
/*    */   }
/* 27 */   public void setLastLocation(Location lastLocation) { this.lastLocation = lastLocation; }
/* 28 */   public Location getLastLocation() { return this.lastLocation; }
/* 29 */   public void setDistanceY(double distanceY) { this.distanceY = distanceY; } public double getDistanceY() {
/* 30 */     return this.distanceY;
/*    */   }
/* 32 */   public void setFalling(boolean isFalling) { this.isFalling = isFalling; }
/* 33 */   public boolean isFalling() { return this.isFalling; }
/* 34 */   public void setGoingUp(boolean isGoingUp) { this.isGoingUp = isGoingUp; } public boolean isGoingUp() {
/* 35 */     return this.isGoingUp;
/*    */   }
/* 37 */   public void setPing(int ping) { this.ping = ping; } public int getPing() {
/* 38 */     return this.ping;
/*    */   }
/*    */   
/*    */   public UserData(UUID playerId, String playerName) {
/* 42 */     this.playerId = playerId;
/* 43 */     this.playerName = playerName;
/*    */     
/* 45 */     this.hackMap = new HashMap<>();
/*    */   }
/*    */   
/*    */   public void pulse(HackType hackType) {
/* 49 */     pulse(hackType, "");
/*    */   }
/*    */   
/*    */   public void pulse(HackType hackType, String message) {
/* 53 */     HackData hackData = this.hackMap.computeIfAbsent(hackType, v -> new HackData(hackType, this));
/*    */     
/* 55 */     hackData.addTimes();
/* 56 */     int times = hackData.getTimes();
/*    */     
/* 58 */     boolean important = (times / hackType.getMaxAlerts() > 0.7D);
/*    */     
/* 60 */     String string = "§c" + getPlayerName() + " pode está usando " + hackType.name().toLowerCase() + (important ? (" no servidor " + CommonPlugin.getInstance().getServerId()) : "") + ((times > hackType.getMaxAlerts()) ? (" (" + times + ")") : (" (" + times + "/" + hackType.getMaxAlerts() + ")"));
/* 61 */     String hover = "§fServidor: §a" + CommonPlugin.getInstance().getServerId() + (message.isEmpty() ? "" : ("\n§7" + message.replace("(", "").replace(")", "")));
/*    */     
/* 63 */     if (important) {
/* 64 */       CommonPlugin.getInstance().getServerData().sendPacket((new Stafflog((new MessageBuilder(string)).setHoverEvent(hover).setClickEvent(ClickEvent.Action.SUGGEST_COMMAND, "/teleport " + getPlayerName()).create())).anticheat().bungeecord());
/*    */     } else {
/* 66 */       CommonPlugin.getInstance().getMemberManager().getMembers().stream().filter(member -> (member.isStaff() && member.getMemberConfiguration().isAnticheatEnabled())).forEach(member -> member.sendMessage((BaseComponent)(new MessageBuilder(string)).setHoverEvent(hover).setClickEvent(ClickEvent.Action.SUGGEST_COMMAND, "/teleport " + getPlayerName()).create()));
/*    */     } 
/* 68 */     Bukkit.getConsoleSender().sendMessage("§c" + getPlayerName() + " está usando " + hackType.name().toLowerCase() + " " + message + " (" + times + "/" + hackType.getMaxAlerts() + ")");
/*    */     
/* 70 */     if (times > hackType.getMaxAlerts() && !StormCore.getInstance().getBanPlayerMap().containsKey(this.playerId))
/* 71 */       StormCore.getInstance().autoban(this.playerId); 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/anticheat/gamer/UserData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */