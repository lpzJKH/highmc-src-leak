/*    */ package net.highmc.bukkit.anticheat.hack;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Clicks
/*    */ {
/*    */   private int clicks;
/*    */   
/*    */   public int getClicks() {
/* 10 */     return this.clicks;
/* 11 */   } private long expireTime = System.currentTimeMillis() + 1000L; public long getExpireTime() { return this.expireTime; }
/*    */   
/*    */   public void addClick() {
/* 14 */     this.clicks++;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/anticheat/hack/Clicks.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */