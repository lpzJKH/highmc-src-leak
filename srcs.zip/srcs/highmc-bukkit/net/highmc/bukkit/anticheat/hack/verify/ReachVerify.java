/*    */ package net.highmc.bukkit.anticheat.hack.verify;
/*    */ 
/*    */ import net.highmc.bukkit.anticheat.gamer.UserData;
/*    */ import net.highmc.bukkit.anticheat.hack.HackType;
/*    */ import net.highmc.bukkit.anticheat.hack.Verify;
/*    */ import net.minecraft.server.v1_8_R3.MinecraftServer;
/*    */ import org.bukkit.GameMode;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*    */ 
/*    */ public class ReachVerify
/*    */   implements Verify {
/*    */   @EventHandler(priority = EventPriority.LOWEST)
/*    */   public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
/* 17 */     if (!(event.getDamager() instanceof Player))
/*    */       return; 
/* 19 */     if ((MinecraftServer.getServer()).recentTps[0] <= 19.98D)
/*    */       return; 
/* 21 */     Player player = (Player)event.getDamager();
/* 22 */     UserData userData = getUserData(player);
/*    */     
/* 24 */     if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR)
/*    */       return; 
/* 26 */     if (player.getAllowFlight())
/*    */       return; 
/* 28 */     double distance = Math.sqrt(player.getLocation().distanceSquared(event.getEntity().getLocation())) - 0.55D;
/* 29 */     double maxDistance = 5.5D;
/*    */ 
/*    */     
/* 32 */     if (player.isSprinting()) distance -= 0.25D;
/*    */     
/* 34 */     int ping = userData.getPing();
/*    */     
/* 36 */     if (ping >= 25) distance -= (ping / 500);
/*    */     
/* 38 */     if (distance >= maxDistance) alert(player, "distance: " + distance + ", max: " + maxDistance + ", ping: " + ping);
/*    */   
/*    */   }
/*    */   
/*    */   public HackType getHackType() {
/* 43 */     return HackType.REACH;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/anticheat/hack/verify/ReachVerify.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */