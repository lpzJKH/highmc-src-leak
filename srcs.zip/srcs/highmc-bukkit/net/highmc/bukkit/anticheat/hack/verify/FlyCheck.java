/*    */ package net.highmc.bukkit.anticheat.hack.verify;
/*    */ 
/*    */ import net.highmc.bukkit.anticheat.gamer.UserData;
/*    */ import net.highmc.bukkit.anticheat.hack.HackType;
/*    */ import net.highmc.bukkit.anticheat.hack.Verify;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.block.Block;
/*    */ import org.bukkit.block.BlockFace;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.player.PlayerMoveEvent;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ 
/*    */ public class FlyCheck
/*    */   implements Verify
/*    */ {
/*    */   @EventHandler(priority = EventPriority.LOW)
/*    */   public void onPlayerMove(PlayerMoveEvent event) {
/* 21 */     Player player = event.getPlayer();
/*    */     
/* 23 */     if (isIgnore(player))
/*    */       return; 
/* 25 */     UserData userData = getUserData(event.getPlayer());
/* 26 */     Location lastLocation = userData.getLastLocation();
/* 27 */     double distance = Math.pow(event.getFrom().getX() - lastLocation.getX(), 2.0D) + Math.pow(event.getFrom().getZ() - lastLocation.getZ(), 2.0D);
/*    */     
/* 29 */     if (player.getAllowFlight() || userData.getPing() > 150) {
/*    */       return;
/*    */     }
/* 32 */     if (userData.isFalling()) {
/*    */       return;
/*    */     }
/* 35 */     Block feetBlock = lastLocation.clone().subtract(0.0D, 1.0D, 0.0D).getBlock();
/*    */     
/* 37 */     for (Block block : new Block[] { feetBlock, feetBlock.getRelative(BlockFace.NORTH), feetBlock.getRelative(BlockFace.SOUTH), feetBlock.getRelative(BlockFace.EAST), feetBlock.getRelative(BlockFace.WEST) }) {
/*    */       
/* 39 */       if (block.getType() != Material.AIR) {
/*    */         return;
/*    */       }
/*    */     } 
/*    */     
/* 44 */     feetBlock = event.getTo().clone().subtract(0.0D, 1.0D, 0.0D).getBlock();
/*    */     
/* 46 */     for (Block block : new Block[] { feetBlock, feetBlock.getRelative(BlockFace.NORTH), feetBlock.getRelative(BlockFace.SOUTH), feetBlock.getRelative(BlockFace.EAST), feetBlock.getRelative(BlockFace.WEST) }) {
/*    */       
/* 48 */       if (block.getType() != Material.AIR) {
/*    */         return;
/*    */       }
/*    */     } 
/*    */     
/* 53 */     double maxJump = 2.5D;
/*    */     
/* 55 */     PotionEffect potion = player.getActivePotionEffects().stream().filter(potionEffect -> potionEffect.getType().getName().equals("JUMP")).findFirst().orElse(null);
/*    */     
/* 57 */     if (potion != null) {
/* 58 */       maxJump += potion.getAmplifier() * 0.75D;
/*    */     }
/* 60 */     if (userData.isGoingUp() && userData.getDistanceY() < maxJump) {
/*    */       return;
/*    */     }
/*    */     
/* 64 */     alert(player);
/* 65 */     ignore(player, 0.5D);
/*    */   }
/*    */ 
/*    */   
/*    */   public HackType getHackType() {
/* 70 */     return HackType.FLY;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/anticheat/hack/verify/FlyCheck.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */