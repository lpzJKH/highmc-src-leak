/*    */ package net.highmc.bukkit.anticheat.hack;
/*    */ 
/*    */ import net.highmc.bukkit.anticheat.gamer.UserData;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HackData
/*    */ {
/*    */   private HackType hackType;
/*    */   private long lastNotify;
/*    */   private int times;
/*    */   
/*    */   public HackType getHackType() {
/* 14 */     return this.hackType;
/*    */   }
/* 16 */   public long getLastNotify() { return this.lastNotify; } public int getTimes() {
/* 17 */     return this.times;
/*    */   }
/*    */   
/*    */   public HackData(HackType hackType, UserData userData) {
/* 21 */     this.hackType = hackType;
/* 22 */     this.lastNotify = System.currentTimeMillis();
/*    */   }
/*    */   
/*    */   public void addTimes() {
/* 26 */     this.times++;
/* 27 */     this.lastNotify = System.currentTimeMillis();
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/anticheat/hack/HackData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */