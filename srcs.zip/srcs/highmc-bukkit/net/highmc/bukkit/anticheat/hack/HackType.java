/*    */ package net.highmc.bukkit.anticheat.hack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum HackType
/*    */ {
/* 10 */   AUTOSOUP(10), KILLAURA(15), FLY(10), SPEED(10), AUTOCLICK(20), MACRO(30), REACH(100);
/*    */   public int getMaxAlerts() {
/* 12 */     return this.maxAlerts;
/*    */   }
/*    */   
/*    */   private int maxAlerts;
/*    */   
/*    */   HackType(int maxAlerts) {
/*    */     this.maxAlerts = maxAlerts;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/anticheat/hack/HackType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */