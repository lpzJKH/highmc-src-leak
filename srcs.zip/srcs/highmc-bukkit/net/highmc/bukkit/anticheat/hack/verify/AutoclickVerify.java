/*    */ package net.highmc.bukkit.anticheat.hack.verify;
/*    */ 
/*    */ import com.comphenix.protocol.PacketType;
/*    */ import com.comphenix.protocol.ProtocolLibrary;
/*    */ import com.comphenix.protocol.events.PacketAdapter;
/*    */ import com.comphenix.protocol.events.PacketEvent;
/*    */ import com.comphenix.protocol.events.PacketListener;
/*    */ import com.google.common.collect.ImmutableList;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import net.highmc.bukkit.BukkitMain;
/*    */ import net.highmc.bukkit.anticheat.hack.Clicks;
/*    */ import net.highmc.bukkit.anticheat.hack.HackType;
/*    */ import net.highmc.bukkit.anticheat.hack.Verify;
/*    */ import net.highmc.bukkit.event.UpdateEvent;
/*    */ import org.bukkit.GameMode;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.block.BlockDamageEvent;
/*    */ import org.bukkit.event.player.PlayerQuitEvent;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public class AutoclickVerify implements Verify {
/*    */   private Map<Player, Clicks> clicksPerSecond;
/*    */   private Map<Player, Long> cooldownMap;
/*    */   
/*    */   public AutoclickVerify() {
/* 31 */     this.clicksPerSecond = new HashMap<>();
/* 32 */     this.cooldownMap = new HashMap<>();
/*    */     
/* 34 */     ProtocolLibrary.getProtocolManager()
/* 35 */       .addPacketListener((PacketListener)new PacketAdapter((Plugin)BukkitMain.getInstance(), new PacketType[] { PacketType.Play.Client.ARM_ANIMATION })
/*    */         {
/*    */           public void onPacketReceiving(PacketEvent event)
/*    */           {
/* 39 */             Player player = event.getPlayer();
/*    */             
/* 41 */             if (player == null) {
/*    */               return;
/*    */             }
/* 44 */             if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.ADVENTURE) {
/*    */               return;
/*    */             }
/* 47 */             if (AutoclickVerify.this.cooldownMap.containsKey(player) && ((Long)AutoclickVerify.this.cooldownMap.get(player)).longValue() > System.currentTimeMillis()) {
/*    */               return;
/*    */             }
/*    */             try {
/* 51 */               if (player.getTargetBlock((Set)null, 4).getType() != Material.AIR)
/*    */                 return; 
/* 53 */             } catch (IllegalStateException ex) {
/*    */               return;
/*    */             } 
/*    */             
/* 57 */             AutoclickVerify.this.handle(player);
/*    */           }
/*    */         });
/*    */   }
/*    */ 
/*    */   
/*    */   @EventHandler(priority = EventPriority.LOWEST)
/*    */   public void onPlayerInteract(BlockDamageEvent event) {
/* 65 */     this.clicksPerSecond.remove(event.getPlayer());
/* 66 */     this.cooldownMap.put(event.getPlayer(), Long.valueOf(System.currentTimeMillis() + 1000L));
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerQuit(PlayerQuitEvent event) {
/* 71 */     this.clicksPerSecond.remove(event.getPlayer());
/* 72 */     this.cooldownMap.remove(event.getPlayer());
/*    */   }
/*    */   
/*    */   public void handle(Player player) {
/* 76 */     ((Clicks)this.clicksPerSecond.computeIfAbsent(player, v -> new Clicks())).addClick();
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onUpdate(UpdateEvent event) {
/* 81 */     ImmutableList.copyOf(this.clicksPerSecond.entrySet()).stream()
/* 82 */       .filter(entry -> (((Clicks)entry.getValue()).getExpireTime() < System.currentTimeMillis())).forEach(entry -> {
/*    */           if (((Clicks)entry.getValue()).getClicks() >= 25) {
/*    */             alert((Player)entry.getKey(), "(" + ((Clicks)entry.getValue()).getClicks() + " cps)");
/*    */           }
/*    */           this.clicksPerSecond.remove(entry.getKey());
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public HackType getHackType() {
/* 93 */     return HackType.AUTOCLICK;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/anticheat/hack/verify/AutoclickVerify.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */