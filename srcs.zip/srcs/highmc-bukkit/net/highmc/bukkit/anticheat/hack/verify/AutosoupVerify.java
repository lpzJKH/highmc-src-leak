/*    */ package net.highmc.bukkit.anticheat.hack.verify;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import net.highmc.bukkit.anticheat.hack.HackType;
/*    */ import net.highmc.bukkit.anticheat.hack.Verify;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.inventory.InventoryAction;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AutosoupVerify
/*    */   implements Verify
/*    */ {
/* 22 */   private Map<UUID, Long> time = new HashMap<>();
/*    */ 
/*    */   
/*    */   @EventHandler
/*    */   private void onClick(InventoryClickEvent event) {
/* 27 */     if (!event.getAction().equals(InventoryAction.MOVE_TO_OTHER_INVENTORY) || event.getCurrentItem() == null || 
/* 28 */       !event.getCurrentItem().getType().equals(Material.MUSHROOM_SOUP)) {
/*    */       return;
/*    */     }
/* 31 */     this.time.put(event.getWhoClicked().getUniqueId(), Long.valueOf(System.currentTimeMillis()));
/*    */   }
/*    */   
/*    */   @EventHandler(priority = EventPriority.LOWEST)
/*    */   private void onPlayerInteract(PlayerInteractEvent event) {
/* 36 */     if (!event.hasItem() || !event.getItem().getType().equals(Material.MUSHROOM_SOUP)) {
/*    */       return;
/*    */     }
/* 39 */     Player player = event.getPlayer();
/* 40 */     UUID uniqueId = player.getUniqueId();
/*    */     
/* 42 */     if (this.time.containsKey(uniqueId)) {
/* 43 */       Long spentTime = Long.valueOf(System.currentTimeMillis() - ((Long)this.time.get(uniqueId)).longValue());
/*    */       
/* 45 */       if (spentTime.longValue() <= 10L) {
/* 46 */         alert(player);
/*    */       }
/*    */       
/* 49 */       this.time.remove(uniqueId);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public HackType getHackType() {
/* 55 */     return HackType.AUTOSOUP;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/anticheat/hack/verify/AutosoupVerify.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */