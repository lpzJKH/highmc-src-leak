/*   */ package net.highmc.bukkit.anticheat.hack.verify;
/*   */ 
/*   */ import net.highmc.bukkit.anticheat.hack.HackType;
/*   */ import net.highmc.bukkit.anticheat.hack.Verify;
/*   */ 
/*   */ public class KillauraCheck
/*   */   implements Verify {
/*   */   public HackType getHackType() {
/* 9 */     return HackType.KILLAURA;
/*   */   }
/*   */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/anticheat/hack/verify/KillauraCheck.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */