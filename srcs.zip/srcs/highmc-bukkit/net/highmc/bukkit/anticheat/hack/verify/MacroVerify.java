/*    */ package net.highmc.bukkit.anticheat.hack.verify;
/*    */ 
/*    */ import com.google.common.collect.ImmutableList;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import net.highmc.bukkit.anticheat.hack.Clicks;
/*    */ import net.highmc.bukkit.anticheat.hack.HackType;
/*    */ import net.highmc.bukkit.anticheat.hack.Verify;
/*    */ import net.highmc.bukkit.event.UpdateEvent;
/*    */ import org.bukkit.GameMode;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.inventory.InventoryAction;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MacroVerify
/*    */   implements Verify
/*    */ {
/* 23 */   private Map<Player, Clicks> clicksPerSecond = new HashMap<>();
/*    */ 
/*    */   
/*    */   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
/*    */   private void onInventoryClick(InventoryClickEvent event) {
/* 28 */     Player player = (Player)event.getWhoClicked();
/*    */     
/* 30 */     if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.ADVENTURE) {
/*    */       return;
/*    */     }
/* 33 */     if (event.isShiftClick() && 
/* 34 */       event.getAction() == InventoryAction.MOVE_TO_OTHER_INVENTORY) {
/*    */       return;
/*    */     }
/* 37 */     Clicks click = this.clicksPerSecond.computeIfAbsent(player, v -> new Clicks());
/*    */     
/* 39 */     if (click.getExpireTime() < System.currentTimeMillis()) {
/* 40 */       if (click.getClicks() >= 25) {
/* 41 */         alert(player);
/*    */       }
/*    */       
/* 44 */       this.clicksPerSecond.remove(player);
/*    */       
/*    */       return;
/*    */     } 
/* 48 */     click.addClick();
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onUpdate(UpdateEvent event) {
/* 53 */     ImmutableList.copyOf(this.clicksPerSecond.entrySet()).stream()
/* 54 */       .filter(entry -> (((Clicks)entry.getValue()).getExpireTime() < System.currentTimeMillis())).forEach(entry -> {
/*    */           if (((Clicks)entry.getValue()).getClicks() >= 20) {
/*    */             alert((Player)entry.getKey(), "( " + ((Clicks)entry.getValue()).getClicks() + " cps)");
/*    */           }
/*    */           this.clicksPerSecond.remove(entry.getKey());
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public HackType getHackType() {
/* 65 */     return HackType.MACRO;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/anticheat/hack/verify/MacroVerify.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */