/*    */ package net.highmc.bukkit.anticheat.hack;
/*    */ 
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.bukkit.BukkitCommon;
/*    */ import net.highmc.bukkit.anticheat.StormCore;
/*    */ import net.highmc.bukkit.anticheat.gamer.UserData;
/*    */ import net.highmc.bukkit.member.BukkitMember;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.metadata.MetadataValue;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public interface Verify
/*    */   extends Listener
/*    */ {
/*    */   HackType getHackType();
/*    */   
/*    */   default boolean isPlayerBypass(Player player) {
/* 19 */     return ((BukkitMember)CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId(), BukkitMember.class)).isAnticheatBypass();
/*    */   }
/*    */   
/*    */   default boolean isIgnore(Player player) {
/* 23 */     if (player.hasMetadata("anticheat-ignore")) {
/* 24 */       MetadataValue metadataValue = player.getMetadata("anticheat-ignore").stream().findFirst().orElse(null);
/*    */       
/* 26 */       if (metadataValue.asLong() > System.currentTimeMillis()) {
/* 27 */         return true;
/*    */       }
/*    */       
/* 30 */       player.removeMetadata("anticheat-ignore", (Plugin)BukkitCommon.getInstance());
/*    */     } 
/*    */     
/* 33 */     return false;
/*    */   }
/*    */   
/*    */   default boolean ignore(Player player, double seconds) {
/* 37 */     StormCore.getInstance().ignore(player, seconds);
/* 38 */     return true;
/*    */   }
/*    */   
/*    */   default UserData getUserData(Player player) {
/* 42 */     return ((BukkitMember)CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId(), BukkitMember.class)).getUserData();
/*    */   }
/*    */   
/*    */   default void alert(Player player) {
/* 46 */     getUserData(player).pulse(getHackType());
/*    */   }
/*    */   
/*    */   default void alert(Player player, String message) {
/* 50 */     getUserData(player).pulse(getHackType(), message);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/anticheat/hack/Verify.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */