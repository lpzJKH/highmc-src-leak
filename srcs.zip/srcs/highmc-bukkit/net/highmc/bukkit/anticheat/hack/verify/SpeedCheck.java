/*    */ package net.highmc.bukkit.anticheat.hack.verify;
/*    */ 
/*    */ import net.highmc.bukkit.anticheat.gamer.UserData;
/*    */ import net.highmc.bukkit.anticheat.hack.HackType;
/*    */ import net.highmc.bukkit.anticheat.hack.Verify;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.player.PlayerMoveEvent;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpeedCheck
/*    */   implements Verify
/*    */ {
/*    */   @EventHandler(priority = EventPriority.LOW)
/*    */   public void onPlayerMove(PlayerMoveEvent event) {
/* 21 */     Player player = event.getPlayer();
/*    */     
/* 23 */     if (isIgnore(player))
/*    */       return; 
/* 25 */     UserData userData = getUserData(event.getPlayer());
/* 26 */     Location lastLocation = (userData.getLastLocation() == null) ? event.getFrom() : userData.getLastLocation();
/*    */     
/* 28 */     double distance = Math.pow(event.getFrom().getX() - lastLocation.getX(), 2.0D) + Math.pow(event.getFrom().getZ() - lastLocation.getZ(), 2.0D);
/*    */     
/* 30 */     if (player.getAllowFlight() || userData.getPing() > 150 || distance < Math.pow(2.5D, 2.0D)) {
/*    */       return;
/*    */     }
/*    */     
/* 34 */     float maxWalkSpeed = player.getWalkSpeed() * 1.2F;
/*    */     
/* 36 */     PotionEffect potion = player.getActivePotionEffects().stream().filter(potionEffect -> potionEffect.getType().getName().equals("SPEED")).findFirst().orElse(null);
/*    */     
/* 38 */     if (potion != null) {
/*    */       return;
/*    */     }
/*    */ 
/*    */     
/* 43 */     if (distance > Math.pow(maxWalkSpeed, 2.0D)) {
/* 44 */       alert(player, "(distance " + distance + ", maxSpeed: " + maxWalkSpeed + ")");
/* 45 */       ignore(player, 0.5D);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public HackType getHackType() {
/* 51 */     return HackType.SPEED;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/anticheat/hack/verify/SpeedCheck.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */