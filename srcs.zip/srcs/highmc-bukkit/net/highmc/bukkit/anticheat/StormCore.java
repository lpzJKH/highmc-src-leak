/*    */ package net.highmc.bukkit.anticheat;
/*    */ import com.google.common.collect.ImmutableList;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import net.highmc.CommonConst;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.bukkit.anticheat.hack.HackData;
/*    */ import net.highmc.bukkit.anticheat.hack.HackType;
/*    */ import net.highmc.bukkit.anticheat.hack.verify.AutoclickVerify;
/*    */ import net.highmc.bukkit.anticheat.hack.verify.AutosoupVerify;
/*    */ import net.highmc.bukkit.event.UpdateEvent;
/*    */ import net.highmc.bukkit.member.BukkitMember;
/*    */ import net.highmc.command.CommandSender;
/*    */ import net.highmc.member.Member;
/*    */ import net.highmc.packet.Packet;
/*    */ import net.highmc.packet.types.PunishPlayerPacket;
/*    */ import net.highmc.punish.Punish;
/*    */ import net.highmc.punish.PunishType;
/*    */ import net.highmc.utils.string.StringFormat;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public class StormCore {
/*    */   private static StormCore instance;
/*    */   
/*    */   public static StormCore getInstance() {
/* 31 */     return instance;
/*    */   } private final Plugin plugin;
/*    */   public Plugin getPlugin() {
/* 34 */     return this.plugin;
/*    */   }
/* 36 */   private Map<UUID, Long> banPlayerMap = new HashMap<>(); public Map<UUID, Long> getBanPlayerMap() { return this.banPlayerMap; }
/*    */   
/*    */   public StormCore(Plugin plugin) {
/* 39 */     this.plugin = plugin;
/* 40 */     instance = this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onLoad() {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 50 */     Bukkit.getPluginManager().registerEvents((Listener)new AutoclickVerify(), this.plugin);
/* 51 */     Bukkit.getPluginManager().registerEvents((Listener)new AutosoupVerify(), this.plugin);
/*    */ 
/*    */     
/* 54 */     Bukkit.getPluginManager().registerEvents((Listener)new KillauraCheck(), this.plugin);
/* 55 */     Bukkit.getPluginManager().registerEvents((Listener)new MacroVerify(), this.plugin);
/* 56 */     Bukkit.getPluginManager().registerEvents((Listener)new ReachVerify(), this.plugin);
/*    */     
/* 58 */     Bukkit.getPluginManager().registerEvents((Listener)new PlayerListener(), this.plugin);
/*    */     
/* 60 */     Bukkit.getPluginManager().registerEvents(new Listener() {
/*    */           @EventHandler
/*    */           public void onUpdate(UpdateEvent event) {
/* 63 */             if (event.getType() == UpdateEvent.UpdateType.SECOND) {
/* 64 */               ImmutableList.copyOf(StormCore.this.banPlayerMap.entrySet()).forEach(entry -> {
/*    */                     Player player = Bukkit.getPlayer((UUID)entry.getKey());
/*    */                     BukkitMember member = (BukkitMember)CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId(), BukkitMember.class);
/*    */                     if (player == null || member == null) {
/*    */                       StormCore.this.banPlayerMap.remove(entry.getKey());
/*    */                       return;
/*    */                     } 
/*    */                     int seconds = (int)((((Long)entry.getValue()).longValue() - System.currentTimeMillis()) / 1000L);
/*    */                     HackType hackType = (HackType)((Map.Entry)member.getUserData().getHackMap().entrySet().stream().sorted(()).findFirst().orElse(null)).getKey();
/*    */                     if (seconds <= 0) {
/*    */                       CommonPlugin.getInstance().getServerData().sendPacket((Packet)new PunishPlayerPacket(player.getUniqueId(), new Punish((CommandSender)member, CommonConst.CONSOLE_ID, "STORM", "Uso de " + StringFormat.formatString(hackType.name()), -1L, PunishType.BAN)));
/*    */                       StormCore.this.banPlayerMap.remove(entry.getKey());
/*    */                       return;
/*    */                     } 
/*    */                     if ((seconds <= 30 && seconds % 10 == 0) || seconds % 15 == 0) {
/*    */                       CommonPlugin.getInstance().getMemberManager().getMembers().stream().filter(()).forEach(());
/*    */                     }
/*    */                   });
/*    */             }
/*    */           }
/*    */         }this.plugin);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onDisable() {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void ignore(Player player, double seconds) {
/* 95 */     player.setMetadata("anticheat-ignore", BukkitCommon.getInstance().createMeta(Long.valueOf(System.currentTimeMillis() + (long)(seconds * 1000.0D))));
/*    */   }
/*    */   
/*    */   public void autoban(UUID playerId) {
/* 99 */     this.banPlayerMap.put(playerId, Long.valueOf(System.currentTimeMillis() + 61000L));
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/anticheat/StormCore.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */