/*    */ package net.highmc.bukkit;
/*    */ 
/*    */ import net.highmc.bukkit.utils.character.handler.ActionHandler;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class BukkitMain
/*    */   extends BukkitCommon
/*    */ {
/*    */   public void onEnable() {
/* 13 */     super.onEnable();
/* 14 */     createCharacter(new Location(Bukkit.getWorlds().stream().findFirst().orElse(null), 0.0D, 120.0D, 0.0D), "Kotcka", new ActionHandler()
/*    */         {
/*    */           
/*    */           public boolean onInteract(Player player, boolean right)
/*    */           {
/* 19 */             player.sendMessage("viado");
/* 20 */             return false;
/*    */           }
/*    */         });
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/BukkitMain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */