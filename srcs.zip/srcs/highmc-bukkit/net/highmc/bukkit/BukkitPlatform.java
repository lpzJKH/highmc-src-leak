/*    */ package net.highmc.bukkit;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import java.util.logging.Logger;
/*    */ import net.highmc.PluginPlatform;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public class BukkitPlatform
/*    */   implements PluginPlatform
/*    */ {
/*    */   public UUID getUniqueId(String playerName) {
/* 15 */     Player player = Bukkit.getPlayerExact(playerName);
/* 16 */     return (player == null) ? null : player.getUniqueId();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName(UUID uuid) {
/* 21 */     Player player = Bukkit.getPlayer(uuid);
/* 22 */     return (player == null) ? null : player.getName();
/*    */   }
/*    */   
/*    */   public void runAsync(Runnable runnable) {
/* 26 */     Bukkit.getScheduler().runTaskAsynchronously((Plugin)BukkitCommon.getPlugin(BukkitCommon.class), runnable);
/*    */   }
/*    */   
/*    */   public void runAsync(Runnable runnable, long delay) {
/* 30 */     Bukkit.getScheduler().runTaskLaterAsynchronously((Plugin)BukkitCommon.getPlugin(BukkitCommon.class), runnable, delay);
/*    */   }
/*    */   
/*    */   public void runAsync(Runnable runnable, long delay, long repeat) {
/* 34 */     Bukkit.getScheduler().runTaskTimerAsynchronously((Plugin)BukkitCommon.getPlugin(BukkitCommon.class), runnable, delay, repeat);
/*    */   }
/*    */ 
/*    */   
/*    */   public void run(Runnable runnable, long delay) {
/* 39 */     Bukkit.getScheduler().runTaskLater((Plugin)BukkitCommon.getPlugin(BukkitCommon.class), runnable, delay);
/*    */   }
/*    */   
/*    */   public void run(Runnable runnable, long delay, long repeat) {
/* 43 */     Bukkit.getScheduler().runTaskTimer((Plugin)BukkitCommon.getPlugin(BukkitCommon.class), runnable, delay, repeat);
/*    */   }
/*    */   
/*    */   public void shutdown(String message) {
/* 47 */     Bukkit.getConsoleSender().sendMessage("§4" + message);
/*    */     
/* 49 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 50 */       player.kickPlayer("§cO servidor foi fechado!");
/*    */     }
/* 52 */     Bukkit.shutdown();
/*    */   }
/*    */ 
/*    */   
/*    */   public Logger getLogger() {
/* 57 */     return Bukkit.getLogger();
/*    */   }
/*    */ 
/*    */   
/*    */   public void dispatchCommand(String command) {
/* 62 */     Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), command);
/*    */   }
/*    */ 
/*    */   
/*    */   public void broadcast(String string) {
/* 67 */     Bukkit.broadcastMessage(string);
/*    */   }
/*    */ 
/*    */   
/*    */   public void broadcast(String string, String permission) {
/* 72 */     Bukkit.broadcast(string, permission);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/BukkitPlatform.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */