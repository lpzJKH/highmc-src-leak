/*     */ package net.highmc.bukkit.protocol.impl;
/*     */ 
/*     */ import com.comphenix.protocol.PacketType;
/*     */ import com.comphenix.protocol.ProtocolLibrary;
/*     */ import com.comphenix.protocol.events.ListenerPriority;
/*     */ import com.comphenix.protocol.events.PacketAdapter;
/*     */ import com.comphenix.protocol.events.PacketContainer;
/*     */ import com.comphenix.protocol.events.PacketEvent;
/*     */ import com.comphenix.protocol.events.PacketListener;
/*     */ import com.comphenix.protocol.wrappers.WrappedChatComponent;
/*     */ import com.comphenix.protocol.wrappers.WrappedDataWatcher;
/*     */ import com.comphenix.protocol.wrappers.WrappedWatchableObject;
/*     */ import com.google.common.base.Splitter;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParser;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import net.highmc.CommonConst;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.protocol.PacketInjector;
/*     */ import net.highmc.bukkit.utils.player.PlayerHelper;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.member.Member;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TranslationInjector
/*     */   implements PacketInjector
/*     */ {
/*     */   public void inject(Plugin plugin) {
/*  37 */     ProtocolLibrary.getProtocolManager()
/*  38 */       .addPacketListener((PacketListener)new PacketAdapter(plugin, ListenerPriority.NORMAL, new PacketType[] { 
/*     */             PacketType.Play.Server.CHAT, PacketType.Play.Server.WINDOW_ITEMS, PacketType.Play.Server.SET_SLOT, PacketType.Play.Server.OPEN_WINDOW, PacketType.Play.Server.UPDATE_SIGN, PacketType.Play.Server.SCOREBOARD_OBJECTIVE, PacketType.Play.Server.SCOREBOARD_TEAM, PacketType.Play.Server.SCOREBOARD_SCORE, PacketType.Play.Server.PLAYER_LIST_HEADER_FOOTER, PacketType.Play.Server.SPAWN_ENTITY_LIVING, 
/*     */             PacketType.Play.Server.ENTITY_METADATA, PacketType.Play.Server.TITLE })
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void onPacketSending(PacketEvent event)
/*     */           {
/*  48 */             if (event.getPlayer() == null) {
/*     */               return;
/*     */             }
/*  51 */             if (event.getPlayer().getUniqueId() == null) {
/*     */               return;
/*     */             }
/*  54 */             if (event.getPacket() == null) {
/*     */               return;
/*     */             }
/*  57 */             if (event.isReadOnly()) {
/*     */               return;
/*     */             }
/*  60 */             Language lang = Member.getLanguage(event.getPlayer().getUniqueId());
/*     */             
/*  62 */             if (event.getPacketType() == PacketType.Play.Server.CHAT) {
/*  63 */               PacketContainer packet = event.getPacket().deepClone();
/*     */               
/*  65 */               for (int i = 0; i < packet.getChatComponents().size(); i++) {
/*  66 */                 WrappedChatComponent chatComponent = (WrappedChatComponent)packet.getChatComponents().read(i);
/*     */                 
/*  68 */                 if (chatComponent != null) {
/*  69 */                   packet.getChatComponents().write(i, 
/*  70 */                       WrappedChatComponent.fromJson(PlayerHelper.translate(lang, chatComponent.getJson())));
/*     */                 }
/*     */               } 
/*     */ 
/*     */               
/*  75 */               event.setPacket(packet);
/*  76 */             } else if (event.getPacketType() == PacketType.Play.Server.WINDOW_ITEMS) {
/*  77 */               PacketContainer packet = event.getPacket().deepClone();
/*     */               
/*  79 */               for (ItemStack item : (ItemStack[])packet.getItemArrayModifier().read(0)) {
/*  80 */                 if (item != null)
/*     */                 {
/*     */                   
/*  83 */                   PlayerHelper.translate(lang, item);
/*     */                 }
/*     */               } 
/*  86 */               event.setPacket(packet);
/*  87 */             } else if (event.getPacketType() == PacketType.Play.Server.SET_SLOT) {
/*  88 */               PacketContainer packet = event.getPacket().deepClone();
/*  89 */               ItemStack item = (ItemStack)packet.getItemModifier().read(0);
/*     */               
/*  91 */               packet.getItemModifier().write(0, PlayerHelper.translate(lang, item));
/*     */               
/*  93 */               event.setPacket(packet);
/*  94 */             } else if (event.getPacketType() == PacketType.Play.Server.TITLE) {
/*  95 */               PacketContainer packet = event.getPacket().deepClone();
/*  96 */               WrappedChatComponent component = (WrappedChatComponent)event.getPacket().getChatComponents().read(0);
/*     */               
/*  98 */               if (component == null) {
/*     */                 return;
/*     */               }
/* 101 */               packet.getChatComponents().write(0, 
/* 102 */                   WrappedChatComponent.fromJson(PlayerHelper.translate(lang, component.getJson())));
/* 103 */               event.setPacket(packet);
/* 104 */             } else if (event.getPacketType() == PacketType.Play.Server.SCOREBOARD_SCORE) {
/* 105 */               PacketContainer packet = event.getPacket().deepClone();
/* 106 */               String message = (String)event.getPacket().getStrings().read(0);
/*     */               
/* 108 */               packet.getStrings().write(0, PlayerHelper.translate(lang, message));
/*     */               
/* 110 */               event.setPacket(packet);
/* 111 */             } else if (event.getPacketType() == PacketType.Play.Server.OPEN_WINDOW) {
/* 112 */               PacketContainer packet = event.getPacket().deepClone();
/* 113 */               WrappedChatComponent component = (WrappedChatComponent)event.getPacket().getChatComponents().read(0);
/* 114 */               JsonElement element = JsonParser.parseString(component.getJson());
/*     */               
/* 116 */               if (!(element instanceof JsonObject) || !((JsonObject)element).has("translate")) {
/* 117 */                 String message = PlayerHelper.translate(lang, element.getAsString());
/* 118 */                 message = message.substring(0, (message.length() > 32) ? 32 : message.length());
/* 119 */                 packet.getChatComponents().write(0, WrappedChatComponent.fromText(message));
/*     */                 
/* 121 */                 event.setPacket(packet);
/*     */               } 
/* 123 */             } else if (event.getPacketType() == PacketType.Play.Server.SCOREBOARD_OBJECTIVE) {
/* 124 */               PacketContainer packet = event.getPacket().deepClone();
/* 125 */               String message = (String)event.getPacket().getStrings().read(1);
/*     */               
/* 127 */               packet.getStrings().write(1, PlayerHelper.translate(lang, message));
/*     */               
/* 129 */               event.setPacket(packet);
/* 130 */             } else if (event.getPacketType() == PacketType.Play.Server.SCOREBOARD_TEAM) {
/* 131 */               String prefix, suffix; PacketContainer packet = event.getPacket().deepClone();
/*     */               
/* 133 */               String pre = (String)packet.getStrings().read(2);
/* 134 */               String su = (String)packet.getStrings().read(3);
/* 135 */               boolean matched = false;
/* 136 */               Matcher matcher = CommonConst.TRANSLATE_PATTERN.matcher(pre);
/*     */               
/* 138 */               while (matcher.find()) {
/* 139 */                 pre = pre.replace(matcher.group(), 
/* 140 */                     CommonPlugin.getInstance().getPluginInfo().translate(lang, matcher.group(2), new String[0]));
/* 141 */                 matched = true;
/*     */               } 
/*     */               
/* 144 */               matcher = CommonConst.TRANSLATE_PATTERN.matcher(su);
/*     */               
/* 146 */               while (matcher.find()) {
/* 147 */                 su = su.replace(matcher.group(), 
/* 148 */                     CommonPlugin.getInstance().getPluginInfo().translate(lang, matcher.group(2), new String[0]));
/* 149 */                 matched = true;
/*     */               } 
/*     */               
/* 152 */               if (matched && 
/* 153 */                 pre.length() <= 16 && su.length() <= 16) {
/* 154 */                 packet.getStrings().write(2, pre);
/* 155 */                 packet.getStrings().write(3, su);
/* 156 */                 event.setPacket(packet);
/*     */ 
/*     */                 
/*     */                 return;
/*     */               } 
/*     */ 
/*     */               
/* 163 */               String text = (String)packet.getStrings().read(2) + (String)packet.getStrings().read(3);
/* 164 */               matcher = CommonConst.TRANSLATE_PATTERN.matcher(text);
/* 165 */               matched = false;
/*     */               
/* 167 */               while (matcher.find()) {
/* 168 */                 text = text.replace(matcher.group(), 
/* 169 */                     CommonPlugin.getInstance().getPluginInfo().translate(lang, matcher.group(2), new String[0]));
/* 170 */                 matched = true;
/*     */               } 
/*     */               
/* 173 */               if (!matched) {
/*     */                 return;
/*     */               }
/*     */               
/* 177 */               Iterator<String> iterator = Splitter.fixedLength(16).split(text).iterator();
/* 178 */               String str = iterator.next();
/*     */               
/* 180 */               if (str.endsWith("§")) {
/* 181 */                 str = str.substring(0, str.length() - 1);
/* 182 */                 prefix = str;
/*     */                 
/* 184 */                 if (iterator.hasNext()) {
/* 185 */                   String next = iterator.next();
/*     */                   
/* 187 */                   if (!next.startsWith("§")) {
/* 188 */                     String str2 = "§" + next;
/*     */                     
/* 190 */                     if (str2.length() > 16) {
/* 191 */                       str2 = str2.substring(0, 16);
/*     */                     }
/* 193 */                     suffix = str2;
/*     */                   } else {
/* 195 */                     suffix = next;
/*     */                   } 
/*     */                 } else {
/*     */                   
/* 199 */                   suffix = "";
/*     */                 }
/*     */               
/* 202 */               } else if (iterator.hasNext()) {
/* 203 */                 String next = iterator.next();
/*     */                 
/* 205 */                 if (!next.startsWith("§")) {
/* 206 */                   String colors = ChatColor.getLastColors(str);
/* 207 */                   String str3 = colors + next;
/*     */                   
/* 209 */                   if (str3.length() > 16) {
/* 210 */                     str3 = str3.substring(0, 16);
/*     */                   }
/* 212 */                   prefix = str;
/* 213 */                   suffix = str3;
/*     */                 } else {
/* 215 */                   prefix = str;
/* 216 */                   suffix = next;
/*     */                 } 
/*     */               } else {
/* 219 */                 prefix = str;
/* 220 */                 suffix = "";
/*     */               } 
/*     */               
/* 223 */               packet.getStrings().write(2, prefix);
/* 224 */               packet.getStrings().write(3, suffix);
/*     */               
/* 226 */               event.setPacket(packet);
/* 227 */             } else if (event.getPacketType() == PacketType.Play.Server.PLAYER_LIST_HEADER_FOOTER) {
/* 228 */               PacketContainer packet = event.getPacket().deepClone();
/* 229 */               WrappedChatComponent header = (WrappedChatComponent)packet.getChatComponents().read(0);
/* 230 */               WrappedChatComponent footer = (WrappedChatComponent)packet.getChatComponents().read(1);
/*     */               
/* 232 */               if (header != null) {
/* 233 */                 packet.getChatComponents().write(0, 
/* 234 */                     WrappedChatComponent.fromJson(PlayerHelper.translate(lang, header.getJson())));
/*     */               }
/* 236 */               if (footer != null) {
/* 237 */                 packet.getChatComponents().write(1, 
/* 238 */                     WrappedChatComponent.fromJson(PlayerHelper.translate(lang, footer.getJson())));
/*     */               }
/* 240 */               event.setPacket(packet);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             }
/* 253 */             else if (event.getPacketType() == PacketType.Play.Server.ENTITY_METADATA) {
/* 254 */               PacketContainer packet = event.getPacket().deepClone();
/* 255 */               List<WrappedWatchableObject> objects = (List<WrappedWatchableObject>)packet.getWatchableCollectionModifier().read(0);
/*     */               
/* 257 */               for (WrappedWatchableObject obj : objects) {
/* 258 */                 if (obj.getIndex() == 2) {
/* 259 */                   String str = (String)obj.getRawValue();
/* 260 */                   str = PlayerHelper.translate(lang, str);
/* 261 */                   obj.setValue(str);
/*     */                   
/*     */                   break;
/*     */                 } 
/*     */               } 
/* 266 */               event.setPacket(packet);
/* 267 */             } else if (event.getPacketType() == PacketType.Play.Server.SPAWN_ENTITY_LIVING) {
/* 268 */               PacketContainer packet = event.getPacket();
/* 269 */               int type = ((Integer)packet.getIntegers().read(1)).intValue();
/*     */               
/* 271 */               if (type != EntityType.ARMOR_STAND.getTypeId()) {
/*     */                 return;
/*     */               }
/*     */               
/* 275 */               PacketContainer packetClone = event.getPacket().deepClone();
/*     */               
/* 277 */               List<WrappedWatchableObject> objects = ((WrappedDataWatcher)packetClone.getDataWatcherModifier().read(0)).getWatchableObjects();
/*     */               
/* 279 */               for (WrappedWatchableObject obj : objects) {
/* 280 */                 if (obj.getIndex() == 2) {
/* 281 */                   String str = (String)obj.getRawValue();
/* 282 */                   str = PlayerHelper.translate(lang, str);
/* 283 */                   obj.setValue(str);
/*     */                   
/*     */                   break;
/*     */                 } 
/*     */               } 
/* 288 */               event.setPacket(packetClone);
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/protocol/impl/TranslationInjector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */