/*     */ package net.highmc.bukkit.protocol.impl;
/*     */ 
/*     */ import com.comphenix.protocol.PacketType;
/*     */ import com.comphenix.protocol.ProtocolLibrary;
/*     */ import com.comphenix.protocol.events.ListenerPriority;
/*     */ import com.comphenix.protocol.events.PacketAdapter;
/*     */ import com.comphenix.protocol.events.PacketContainer;
/*     */ import com.comphenix.protocol.events.PacketEvent;
/*     */ import com.comphenix.protocol.events.PacketListener;
/*     */ import com.comphenix.protocol.wrappers.WrappedChatComponent;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import java.util.Locale;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.BukkitMain;
/*     */ import net.highmc.bukkit.protocol.PacketInjector;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ public class LimiterInjector
/*     */   implements PacketInjector
/*     */ {
/*  25 */   private final Pattern pattern = Pattern.compile(".*\\$\\{[^}]*\\}.*");
/*     */ 
/*     */ 
/*     */   
/*     */   public void inject(Plugin plugin) {
/*  30 */     ProtocolLibrary.getProtocolManager().addPacketListener((PacketListener)new PacketAdapter((Plugin)BukkitMain.getInstance(), ListenerPriority.LOWEST, new PacketType[] { PacketType.Play.Client.WINDOW_CLICK, PacketType.Play.Client.CUSTOM_PAYLOAD })
/*     */         {
/*     */           public void onPacketReceiving(PacketEvent event)
/*     */           {
/*  34 */             if (event.getPlayer() == null)
/*     */               return; 
/*  36 */             if (event.getPacketType() == PacketType.Play.Client.WINDOW_CLICK) {
/*     */               
/*  38 */               if (((Integer)event.getPacket().getModifier().getValues().get(1)).intValue() >= 100) {
/*  39 */                 event.setCancelled(true);
/*  40 */                 LimiterInjector.this.disconnect(event.getPlayer(), "§cYou are sending too many packets.");
/*  41 */                 CommonPlugin.getInstance().debug("The player " + event.getPlayer().getName() + " is trying to crash the server (WindowClick)");
/*     */               } 
/*     */             } else {
/*     */               
/*  45 */               String packetName = event.getPacket().getStrings().getValues().get(0);
/*     */               
/*  47 */               if ((packetName.equals("MC|BEdit") || packetName.equals("MC|BSign")) && (
/*  48 */                 (ByteBuf)event.getPacket().getModifier().getValues().get(1)).capacity() > 7500) {
/*  49 */                 event.setCancelled(true);
/*  50 */                 LimiterInjector.this.disconnect(event.getPlayer(), "§cYou are sending too many packets.");
/*  51 */                 CommonPlugin.getInstance().debug("The player " + event.getPlayer().getName() + " is trying to crash the server (CustomPayload)");
/*     */               } 
/*     */             } 
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */     
/*  59 */     ProtocolLibrary.getProtocolManager()
/*  60 */       .addPacketListener((PacketListener)new PacketAdapter((Plugin)BukkitMain.getInstance(), ListenerPriority.LOWEST, new PacketType[] { PacketType.Play.Server.CHAT, PacketType.Play.Client.CHAT, PacketType.Play.Client.WINDOW_CLICK })
/*     */         {
/*     */ 
/*     */           
/*     */           public void onPacketSending(PacketEvent event)
/*     */           {
/*  66 */             if (event.getPacketType() == PacketType.Play.Server.CHAT) {
/*  67 */               PacketContainer packetContainer = event.getPacket();
/*     */ 
/*     */               
/*  70 */               WrappedChatComponent wrappedChatComponent = packetContainer.getChatComponents().getValues().get(0);
/*     */               
/*  72 */               if (wrappedChatComponent == null) {
/*     */                 return;
/*     */               }
/*  75 */               String jsonMessage = wrappedChatComponent.getJson();
/*     */               
/*  77 */               if (jsonMessage.indexOf('$') == -1) {
/*     */                 return;
/*     */               }
/*  80 */               if (LimiterInjector.this.matches(jsonMessage)) {
/*  81 */                 event.setCancelled(true);
/*  82 */                 packetContainer.getChatComponents().write(0, WrappedChatComponent.fromText(""));
/*     */               } 
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/*     */           public void onPacketReceiving(PacketEvent event) {
/*  89 */             if (event.getPacketType() == PacketType.Play.Client.CHAT) {
/*  90 */               PacketContainer packetContainer = event.getPacket();
/*     */               
/*  92 */               String message = (String)packetContainer.getStrings().read(0);
/*     */               
/*  94 */               if (message.indexOf('$') == -1) {
/*     */                 return;
/*     */               }
/*  97 */               if (LimiterInjector.this.matches(message)) {
/*  98 */                 event.setCancelled(true);
/*  99 */                 packetContainer.getStrings().write(0, "");
/* 100 */                 CommonPlugin.getInstance().debug("The player " + event.getPlayer().getName() + " is trying to crash the server (Chat)");
/*     */               } 
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void disconnect(Player player, String string) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean matches(String message) {
/* 116 */     Matcher matcher = this.pattern.matcher(message.replaceAll("[^\\x00-\\x7F]", "").toLowerCase(Locale.ROOT));
/* 117 */     return matcher.find();
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/protocol/impl/LimiterInjector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */