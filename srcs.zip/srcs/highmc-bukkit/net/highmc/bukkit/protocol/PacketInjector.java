package net.highmc.bukkit.protocol;

import org.bukkit.plugin.Plugin;

public interface PacketInjector {
  void inject(Plugin paramPlugin);
}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/protocol/PacketInjector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */