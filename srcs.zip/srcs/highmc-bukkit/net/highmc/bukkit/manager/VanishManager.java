/*     */ package net.highmc.bukkit.manager;
/*     */ 
/*     */ import com.google.common.collect.ImmutableSet;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.event.player.PlayerAdminEvent;
/*     */ import net.highmc.bukkit.event.player.PlayerHideToPlayerEvent;
/*     */ import net.highmc.bukkit.event.player.PlayerShowToPlayerEvent;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.permission.Group;
/*     */ import net.highmc.utils.string.StringFormat;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VanishManager
/*     */ {
/*  36 */   private Map<UUID, Group> vanishMap = new HashMap<>();
/*  37 */   private Set<UUID> adminSet = new HashSet<>();
/*  38 */   private Map<UUID, PlayerState> playerStateMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setPlayerInAdmin(Player player) {
/*  50 */     if (this.adminSet.contains(player.getUniqueId())) {
/*  51 */       return false;
/*     */     }
/*  53 */     PlayerAdminEvent playerAdminEvent = new PlayerAdminEvent(player, PlayerAdminEvent.AdminMode.ADMIN, GameMode.CREATIVE);
/*     */     
/*  55 */     Bukkit.getPluginManager().callEvent((Event)playerAdminEvent);
/*     */     
/*  57 */     if (playerAdminEvent.isCancelled()) {
/*  58 */       return false;
/*     */     }
/*  60 */     if (CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId()).getMemberConfiguration()
/*  61 */       .isAdminRemoveItems()) {
/*  62 */       ItemStack[] contents = new ItemStack[(player.getInventory().getContents()).length + 4];
/*     */       int i;
/*  64 */       for (i = 0; i < (player.getInventory().getContents()).length; i++) {
/*  65 */         contents[i] = player.getInventory().getContents()[i];
/*     */       }
/*     */       
/*  68 */       for (i = 0; i < (player.getInventory().getArmorContents()).length; i++) {
/*  69 */         contents[(player.getInventory().getContents()).length + i] = player.getInventory().getArmorContents()[i];
/*     */       }
/*     */       
/*  72 */       this.playerStateMap.put(player.getUniqueId(), new PlayerState(contents, player.getGameMode()));
/*  73 */       player.getInventory().clear();
/*  74 */       player.getInventory().setArmorContents(new ItemStack[4]);
/*     */     } 
/*     */     
/*  77 */     this.adminSet.add(player.getUniqueId());
/*     */     
/*  79 */     Group group = hidePlayer(player);
/*  80 */     player.sendMessage("§dVocê entrou no modo admin.");
/*  81 */     player.sendMessage(Language.getLanguage(player.getUniqueId()).t("vanish.player-group-hided", new String[] { "%group%", 
/*  82 */             StringFormat.formatString(group.getGroupName()) }));
/*  83 */     player.setGameMode(playerAdminEvent.getGameMode());
/*     */     
/*  85 */     if (playerAdminEvent.getGameMode() == GameMode.CREATIVE)
/*  86 */       player.setFlying(true); 
/*  87 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setPlayer(Player player) {
/*  99 */     if (this.adminSet.contains(player.getUniqueId())) {
/*     */ 
/*     */ 
/*     */       
/* 103 */       PlayerAdminEvent playerAdminEvent = new PlayerAdminEvent(player, PlayerAdminEvent.AdminMode.PLAYER, this.playerStateMap.containsKey(player.getUniqueId()) ? ((PlayerState)this.playerStateMap.get(player.getUniqueId())).getGameMode() : GameMode.SURVIVAL);
/*     */       
/* 105 */       Bukkit.getPluginManager().callEvent((Event)playerAdminEvent);
/*     */       
/* 107 */       if (playerAdminEvent.isCancelled()) {
/* 108 */         return false;
/*     */       }
/* 110 */       this.adminSet.remove(player.getUniqueId());
/*     */       
/* 112 */       showPlayer(player);
/* 113 */       player.sendMessage("§dVocê saiu no modo admin.");
/* 114 */       player.sendMessage("§dVocê está visível para todos os jogadores.");
/* 115 */       player.setGameMode(playerAdminEvent.getGameMode());
/*     */       
/* 117 */       if (this.playerStateMap.containsKey(player.getUniqueId())) {
/* 118 */         ItemStack[] contents = ((PlayerState)this.playerStateMap.get(player.getUniqueId())).getContents();
/*     */         
/* 120 */         player.getInventory()
/* 121 */           .setContents(Arrays.<ItemStack>copyOfRange(contents, 0, (player.getInventory().getContents()).length));
/* 122 */         player.getInventory().setArmorContents(
/* 123 */             Arrays.<ItemStack>copyOfRange(contents, (player.getInventory().getContents()).length, contents.length));
/* 124 */         this.playerStateMap.remove(player.getUniqueId());
/*     */       } 
/*     */       
/* 127 */       return false;
/*     */     } 
/*     */     
/* 130 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetPlayer(Player player) {
/* 141 */     this.adminSet.remove(player.getUniqueId());
/* 142 */     this.vanishMap.remove(player.getUniqueId());
/* 143 */     this.playerStateMap.remove(player.getUniqueId());
/*     */   }
/*     */   
/*     */   public void showPlayer(Player player) {
/* 147 */     setPlayerVanishToGroup(player, null);
/*     */   }
/*     */   
/*     */   public Group setPlayerVanishToGroup(Player player, Group group) {
/* 151 */     if (group == null) {
/* 152 */       this.vanishMap.remove(player.getUniqueId());
/*     */     } else {
/* 154 */       this.vanishMap.put(player.getUniqueId(), group);
/*     */     } 
/* 156 */     for (Player online : Bukkit.getOnlinePlayers()) {
/* 157 */       if (online.getUniqueId().equals(player.getUniqueId())) {
/*     */         continue;
/*     */       }
/* 160 */       Member onlineP = CommonPlugin.getInstance().getMemberManager().getMember(online.getUniqueId());
/*     */       
/* 162 */       if (onlineP == null) {
/*     */         continue;
/*     */       }
/* 165 */       if (group != null && (onlineP.getServerGroup().getId() <= group.getId() || 
/* 166 */         !onlineP.getMemberConfiguration().isSpectatorsEnabled())) {
/* 167 */         PlayerHideToPlayerEvent playerHideToPlayerEvent = new PlayerHideToPlayerEvent(player, online);
/*     */         
/* 169 */         Bukkit.getPluginManager().callEvent((Event)playerHideToPlayerEvent);
/*     */         
/* 171 */         if (playerHideToPlayerEvent.isCancelled()) {
/* 172 */           if (!online.canSee(player))
/* 173 */             online.showPlayer(player);  continue;
/* 174 */         }  if (online.canSee(player)) {
/* 175 */           online.hidePlayer(player);
/*     */         }
/*     */         
/*     */         continue;
/*     */       } 
/* 180 */       PlayerShowToPlayerEvent event = new PlayerShowToPlayerEvent(player, online);
/* 181 */       Bukkit.getPluginManager().callEvent((Event)event);
/*     */       
/* 183 */       if (event.isCancelled()) {
/* 184 */         if (online.canSee(player))
/* 185 */           online.hidePlayer(player);  continue;
/* 186 */       }  if (!online.canSee(player))
/* 187 */         online.showPlayer(player); 
/*     */     } 
/* 189 */     return group;
/*     */   }
/*     */   
/*     */   public void updateVanishToPlayer(Player player) {
/* 193 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId());
/* 194 */     for (Player online : Bukkit.getOnlinePlayers()) {
/* 195 */       if (online.getUniqueId().equals(player.getUniqueId())) {
/*     */         continue;
/*     */       }
/* 198 */       Group group = this.vanishMap.get(online.getUniqueId());
/*     */       
/* 200 */       if (group != null && (
/* 201 */         member.getServerGroup().getId() <= group.getId() || 
/* 202 */         !member.getMemberConfiguration().isSpectatorsEnabled())) {
/* 203 */         PlayerHideToPlayerEvent playerHideToPlayerEvent = new PlayerHideToPlayerEvent(online, player);
/* 204 */         Bukkit.getPluginManager().callEvent((Event)playerHideToPlayerEvent);
/*     */         
/* 206 */         if (playerHideToPlayerEvent.isCancelled()) {
/* 207 */           if (!player.canSee(online))
/* 208 */             player.showPlayer(online);  continue;
/* 209 */         }  if (player.canSee(online)) {
/* 210 */           player.hidePlayer(online);
/*     */         }
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 216 */       PlayerShowToPlayerEvent event = new PlayerShowToPlayerEvent(online, player);
/*     */       
/* 218 */       Bukkit.getPluginManager().callEvent((Event)event);
/*     */       
/* 220 */       if (event.isCancelled()) {
/* 221 */         if (player.canSee(online))
/* 222 */           player.hidePlayer(online);  continue;
/* 223 */       }  if (!player.canSee(online))
/* 224 */         player.showPlayer(online); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Group hidePlayer(Player player) {
/* 229 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId());
/*     */     
/* 231 */     Group serverGroup = member.getServerGroup();
/*     */     
/* 233 */     Group group = (serverGroup.getId() - 1 >= 0) ? CommonPlugin.getInstance().getPluginInfo().filterGroup(g -> 
/* 234 */         (g.getId() < serverGroup.getId() && g.isStaff()), 
/* 235 */         CommonPlugin.getInstance().getPluginInfo().getFirstLowerGroup(serverGroup.getId())) : serverGroup;
/*     */ 
/*     */     
/* 238 */     return setPlayerVanishToGroup(player, group);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Group getVanishedToGroup(Player player) {
/* 250 */     return this.vanishMap.get(player.getUniqueId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPlayerInAdmin(UUID playerId) {
/* 262 */     return this.adminSet.contains(playerId);
/*     */   }
/*     */   
/*     */   public boolean isPlayerInAdmin(Player player) {
/* 266 */     return this.adminSet.contains(player.getUniqueId());
/*     */   }
/*     */   
/*     */   public Set<UUID> getPlayersInAdmin() {
/* 270 */     return (Set<UUID>)ImmutableSet.copyOf(this.adminSet);
/*     */   } public class PlayerState { private ItemStack[] contents;
/*     */     public PlayerState(ItemStack[] contents, GameMode gameMode) {
/* 273 */       this.contents = contents; this.gameMode = gameMode;
/*     */     }
/*     */     private GameMode gameMode;
/*     */     public ItemStack[] getContents() {
/* 277 */       return this.contents; } public GameMode getGameMode() {
/* 278 */       return this.gameMode;
/*     */     } }
/*     */ 
/*     */   
/*     */   public boolean isPlayerVanished(UUID uniqueId) {
/* 283 */     return this.vanishMap.containsKey(uniqueId);
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/manager/VanishManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */