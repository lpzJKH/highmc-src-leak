/*     */ package net.highmc.bukkit.manager;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import net.highmc.command.CommandSender;
/*     */ import net.highmc.utils.string.Line;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChatManager
/*     */ {
/*  20 */   private Map<UUID, Info> chatMap = new HashMap<>();
/*     */ 
/*     */   
/*     */   public String callback(UUID uniqueId, String message, boolean cancel) {
/*  24 */     if (this.chatMap.containsKey(uniqueId)) {
/*  25 */       Info info = this.chatMap.get(uniqueId);
/*     */       
/*  27 */       if (cancel) {
/*  28 */         info.callback.callback(true, (String[])info.answers.stream().toArray(x$0 -> new String[x$0]));
/*     */       } else {
/*  30 */         info.answer(message);
/*     */         
/*  32 */         if (info.hasNextQuestion()) {
/*  33 */           return info.question();
/*     */         }
/*     */         
/*  36 */         info.callback.callback(false, (String[])info.answers.stream().toArray(x$0 -> new String[x$0]));
/*  37 */         this.chatMap.remove(uniqueId);
/*     */       } 
/*     */     } 
/*     */     
/*  41 */     return null;
/*     */   }
/*     */   
/*     */   public boolean validate(UUID uniqueId, String message) {
/*  45 */     if (this.chatMap.containsKey(uniqueId)) {
/*  46 */       Info info = this.chatMap.get(uniqueId);
/*     */       
/*  48 */       if (info.validator != null) {
/*  49 */         return info.validator.validate(message, info.index);
/*     */       }
/*     */     } 
/*  52 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isClearChat(UUID uniqueId) {
/*  56 */     return this.chatMap.containsKey(uniqueId) ? ((Info)this.chatMap.get(uniqueId)).isClearChat() : false;
/*     */   }
/*     */   
/*     */   public Info loadChat(CommandSender sender, Callback callback, String... questions) {
/*  60 */     return loadChat(sender, callback, (Validator)null, questions);
/*     */   }
/*     */   
/*     */   public Info loadChat(CommandSender sender, Callback callback, Line... questions) {
/*  64 */     return loadChat(sender, callback, (Validator)null, 
/*  65 */         (String[])Arrays.<Line>asList(questions).stream().map(Line::toString).toArray(x$0 -> new String[x$0]));
/*     */   }
/*     */   
/*     */   public Info loadChat(CommandSender sender, Callback callback, Validator validator, String... questions) {
/*  69 */     sender.sendMessage(questions[0]);
/*  70 */     Info info = new Info(callback, validator, questions);
/*  71 */     this.chatMap.put(sender.getUniqueId(), info);
/*  72 */     return info;
/*     */   }
/*     */   
/*     */   public Info loadChat(CommandSender sender, Callback callback, Validator validator, Line... questions) {
/*  76 */     return loadChat(sender, callback, validator, 
/*  77 */         (String[])Arrays.<Line>asList(questions).stream().map(Line::toString).toArray(x$0 -> new String[x$0]));
/*     */   }
/*     */   
/*     */   public String getAnswers(UUID uniqueId, int index) {
/*  81 */     return ((Info)this.chatMap.get(uniqueId)).getAnswers().get(index);
/*     */   }
/*     */   
/*     */   public boolean containsChat(UUID uniqueId) {
/*  85 */     return this.chatMap.containsKey(uniqueId);
/*     */   }
/*     */   
/*     */   public void remove(UUID uniqueId) {
/*  89 */     this.chatMap.remove(uniqueId);
/*     */   }
/*     */   public class Info {
/*     */     private final ChatManager.Callback callback; private final ChatManager.Validator validator; private final String[] questions; private List<String> answers; private int index;
/*     */     private boolean clearChat;
/*     */     private boolean stopChat;
/*     */     
/*     */     public ChatManager.Callback getCallback() {
/*     */       return this.callback;
/*     */     }
/*     */     
/*     */     public ChatManager.Validator getValidator() {
/*     */       return this.validator;
/*     */     }
/*     */     
/*     */     public String[] getQuestions() {
/*     */       return this.questions;
/*     */     }
/*     */     
/*     */     public List<String> getAnswers() {
/*     */       return this.answers;
/*     */     }
/*     */     
/* 112 */     public Info(ChatManager.Callback callback, ChatManager.Validator validator, String[] questions) { this.answers = new ArrayList<>();
/*     */       
/* 114 */       this.index = 0; this.callback = callback; this.validator = validator; this.questions = questions; } public int getIndex() { return this.index; }
/* 115 */     public boolean isClearChat() { return this.clearChat; } public boolean isStopChat() {
/* 116 */       return this.stopChat;
/*     */     }
/*     */     public boolean hasNextQuestion() {
/* 119 */       return (this.index < this.questions.length);
/*     */     }
/*     */     
/*     */     public String question() {
/* 123 */       return this.questions[this.index];
/*     */     }
/*     */     
/*     */     public void answer(String answer) {
/* 127 */       this.answers.add(answer);
/* 128 */       this.index++;
/*     */     }
/*     */     
/*     */     public Info clearChat() {
/* 132 */       this.clearChat = !this.clearChat;
/* 133 */       return this;
/*     */     }
/*     */     
/*     */     public Info stopChat() {
/* 137 */       this.stopChat = !this.stopChat;
/* 138 */       return this;
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface Validator {
/*     */     boolean validate(String param1String, int param1Int);
/*     */   }
/*     */   
/*     */   public static interface Callback {
/*     */     void callback(boolean param1Boolean, String... param1VarArgs);
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/manager/ChatManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */