/*    */ package net.highmc.bukkit.manager;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CombatlogManager
/*    */ {
/* 15 */   private Map<UUID, Combat> playerMap = new HashMap<>();
/*    */ 
/*    */   
/*    */   public long getRemaining(UUID playerId) {
/* 19 */     return this.playerMap.containsKey(playerId) ? (((Combat)this.playerMap
/* 20 */       .get(playerId)).getLastHit() + 30000L - System.currentTimeMillis()) : 0L;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isInCombatlog(UUID playerId) {
/* 25 */     return (this.playerMap.containsKey(playerId) && ((Combat)this.playerMap
/* 26 */       .get(playerId)).getLastHit() + 30000L > System.currentTimeMillis());
/*    */   }
/*    */   
/*    */   public void putCombatlog(UUID playerId, UUID hittedId) {
/* 30 */     this.playerMap.put(hittedId, new Combat(playerId, System.currentTimeMillis()));
/* 31 */     this.playerMap.put(playerId, new Combat(hittedId, System.currentTimeMillis()));
/*    */   }
/*    */   public class Combat { private UUID lastId;
/*    */     public Combat(UUID lastId, long lastHit) {
/* 35 */       this.lastId = lastId; this.lastHit = lastHit;
/*    */     } private long lastHit;
/*    */     public UUID getLastId() {
/* 38 */       return this.lastId; } public long getLastHit() {
/* 39 */       return this.lastHit;
/*    */     } }
/*    */ 
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/manager/CombatlogManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */