/*     */ package net.highmc.bukkit.manager;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.bukkit.event.UpdateEvent;
/*     */ import net.highmc.bukkit.utils.item.ActionItemStack;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.bukkit.utils.worldedit.FutureBlock;
/*     */ import net.highmc.bukkit.utils.worldedit.schematic.Schematic;
/*     */ import net.minecraft.server.v1_8_R3.Block;
/*     */ import net.minecraft.server.v1_8_R3.BlockPosition;
/*     */ import net.minecraft.server.v1_8_R3.Chunk;
/*     */ import net.minecraft.server.v1_8_R3.IBlockData;
/*     */ import net.minecraft.server.v1_8_R3.WorldServer;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.block.BlockState;
/*     */ import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockManager
/*     */ {
/*     */   private Map<UUID, Position> positionMap;
/*     */   private ActionItemStack wand;
/*     */   private Map<Location, Place> blocksForUpdate;
/*     */   
/*     */   public BlockManager() {
/*  50 */     this.positionMap = new HashMap<>();
/*     */     
/*  52 */     this.wand = new ActionItemStack((new ItemBuilder()).name("§dWand").type(Material.WOOD_AXE).build(), new ActionItemStack.Interact()
/*     */         {
/*     */           
/*     */           public boolean onInteract(Player player, Entity entity, Block block, ItemStack item, ActionItemStack.ActionType action)
/*     */           {
/*  57 */             if (block != null) {
/*  58 */               if (action == ActionItemStack.ActionType.LEFT) {
/*  59 */                 BlockManager.this.setFirstPosition(player, block.getLocation());
/*  60 */                 player.sendMessage("§dO local da primeira posição é " + block.getX() + ", " + block.getY() + ", " + block
/*  61 */                     .getZ());
/*     */               } else {
/*  63 */                 BlockManager.this.setSecondPosition(player, block.getLocation());
/*  64 */                 player.sendMessage("§dO local da segunda posição é " + block.getX() + ", " + block.getY() + ", " + block
/*  65 */                     .getZ());
/*     */               } 
/*     */             }
/*     */             
/*  69 */             return true;
/*     */           }
/*     */         });
/*     */ 
/*     */     
/*  74 */     this.blocksForUpdate = new HashMap<>();
/*     */     
/*  76 */     Bukkit.getPluginManager().registerEvents(new Listener()
/*     */         {
/*     */           @EventHandler
/*     */           public void onUpdate(UpdateEvent event) {
/*  80 */             if (!BlockManager.this.blocksForUpdate.isEmpty()) {
/*  81 */               for (Map.Entry<Location, BlockManager.Place> entry : (Iterable<Map.Entry<Location, BlockManager.Place>>)BlockManager.this.blocksForUpdate.entrySet()) {
/*  82 */                 Location location = entry.getKey();
/*  83 */                 WorldServer worldServer = ((CraftWorld)location.getWorld()).getHandle();
/*  84 */                 worldServer.notify(new BlockPosition(location
/*  85 */                       .getBlockX(), location.getBlockY(), location.getBlockZ()));
/*     */                 
/*  87 */                 if (entry.getValue() != null) {
/*  88 */                   ((BlockManager.Place)entry.getValue()).place(location);
/*     */                 }
/*     */               } 
/*  91 */               BlockManager.this.blocksForUpdate.clear();
/*     */             }
/*     */           
/*     */           }
/*  95 */         }(Plugin)BukkitCommon.getInstance());
/*     */   }
/*     */   
/*     */   public void setBlockFast(World world, int x, int y, int z, int blockId, byte data) {
/*  99 */     WorldServer worldServer = ((CraftWorld)world).getHandle();
/* 100 */     Chunk chunk = worldServer.getChunkAt(x >> 4, z >> 4);
/* 101 */     BlockPosition bp = new BlockPosition(x, y, z);
/* 102 */     int i = blockId + (data << 12);
/* 103 */     IBlockData ibd = Block.getByCombinedId(i);
/* 104 */     chunk.a(bp, ibd);
/* 105 */     addBlockUpdate(new Location(world, x, y, z));
/*     */   }
/*     */   
/*     */   public void setBlockFast(World world, int x, int y, int z, int blockId, byte data, Place place) {
/* 109 */     WorldServer worldServer = ((CraftWorld)world).getHandle();
/* 110 */     Chunk chunk = worldServer.getChunkAt(x >> 4, z >> 4);
/* 111 */     BlockPosition bp = new BlockPosition(x, y, z);
/* 112 */     int i = blockId + (data << 12);
/* 113 */     IBlockData ibd = Block.getByCombinedId(i);
/* 114 */     chunk.a(bp, ibd);
/* 115 */     addBlockUpdate(new Location(world, x, y, z), place);
/*     */   }
/*     */   
/*     */   public void setBlockFast(Location location, int blockId) {
/* 119 */     setBlockFast(location.getWorld(), location, blockId, (byte)0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBlockFast(Location location, Material material) {
/* 124 */     setBlockFast(location.getWorld(), location, material.getId(), (byte)0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBlockFast(Location location, Material material, byte data) {
/* 129 */     setBlockFast(location.getWorld(), location, material.getId(), data);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBlockFast(Location location, Material material, byte data, Place place) {
/* 134 */     setBlockFast(location.getWorld(), location, material.getId(), data, place);
/*     */   }
/*     */   
/*     */   public void setBlockFast(Location location, int blockId, byte data) {
/* 138 */     setBlockFast(location.getWorld(), location, blockId, data);
/*     */   }
/*     */   
/*     */   public void setBlockFast(World world, Location location, int blockId) {
/* 142 */     setBlockFast(world, location, blockId, (byte)0);
/*     */   }
/*     */   
/*     */   public void setBlockFast(World world, Location location, int blockId, byte data) {
/* 146 */     setBlockFast(world, location.getBlockX(), location.getBlockY(), location.getBlockZ(), blockId, data);
/*     */   }
/*     */   
/*     */   public void setBlockFast(Location location, int blockId, Place place) {
/* 150 */     setBlockFast(location.getWorld(), location, blockId, (byte)0, place);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBlockFast(Location location, Material material, Place place) {
/* 155 */     setBlockFast(location.getWorld(), location, material.getId(), (byte)0, place);
/*     */   }
/*     */   
/*     */   public void setBlockFast(Location location, int blockId, byte data, Place place) {
/* 159 */     setBlockFast(location.getWorld(), location, blockId, data, place);
/*     */   }
/*     */   
/*     */   public void setBlockFast(World world, Location location, int blockId, Place place) {
/* 163 */     setBlockFast(world, location, blockId, (byte)0, place);
/*     */   }
/*     */   
/*     */   public void setBlockFast(World world, Location location, int blockId, byte data, Place place) {
/* 167 */     setBlockFast(world, location.getBlockX(), location.getBlockY(), location.getBlockZ(), blockId, data, place);
/*     */   }
/*     */   
/*     */   public void addBlockUpdate(Location location) {
/* 171 */     addBlockUpdate(location, null);
/*     */   }
/*     */   
/*     */   public void addBlockUpdate(Location location, Place place) {
/* 175 */     this.blocksForUpdate.put(location, place);
/*     */   }
/*     */   
/*     */   public void addUndo(Player player, Map<Location, BlockState> map) {
/* 179 */     ((Position)this.positionMap.computeIfAbsent(player.getUniqueId(), v -> new Position())).addUndo(map);
/*     */   }
/*     */   
/*     */   public void removeUndo(Player player, Map<Location, BlockState> map) {
/* 183 */     ((Position)this.positionMap.computeIfAbsent(player.getUniqueId(), v -> new Position())).removeUndo(map);
/*     */   }
/*     */   
/*     */   public void giveWand(Player player) {
/* 187 */     player.getInventory().addItem(new ItemStack[] { this.wand.getItemStack() });
/*     */   }
/*     */   
/*     */   public void setFirstPosition(Player player, Location location) {
/* 191 */     ((Position)this.positionMap.computeIfAbsent(player.getUniqueId(), v -> new Position())).setFirstLocation(location);
/*     */   }
/*     */   
/*     */   public void setSecondPosition(Player player, Location location) {
/* 195 */     ((Position)this.positionMap.computeIfAbsent(player.getUniqueId(), v -> new Position())).setSecondLocation(location);
/*     */   }
/*     */   
/*     */   public boolean hasFirstPosition(Player player) {
/* 199 */     return ((Position)this.positionMap.computeIfAbsent(player.getUniqueId(), v -> new Position())).hasFirstLocation();
/*     */   }
/*     */   
/*     */   public boolean hasSecondPosition(Player player) {
/* 203 */     return ((Position)this.positionMap.computeIfAbsent(player.getUniqueId(), v -> new Position())).hasSecondLocation();
/*     */   }
/*     */   
/*     */   public boolean hasUndoList(Player player) {
/* 207 */     return !((Position)this.positionMap.computeIfAbsent(player.getUniqueId(), v -> new Position())).getUndoList().isEmpty();
/*     */   }
/*     */   
/*     */   public Location getFirstPosition(Player player) {
/* 211 */     return ((Position)this.positionMap.computeIfAbsent(player.getUniqueId(), v -> new Position())).getFirstLocation();
/*     */   }
/*     */   
/*     */   public Location getSecondPosition(Player player) {
/* 215 */     return ((Position)this.positionMap.computeIfAbsent(player.getUniqueId(), v -> new Position())).getSecondLocation();
/*     */   }
/*     */   
/*     */   public List<Map<Location, BlockState>> getUndoList(Player player) {
/* 219 */     return ((Position)this.positionMap.computeIfAbsent(player.getUniqueId(), v -> new Position())).getUndoList();
/*     */   }
/*     */   
/*     */   public List<Location> getLocationsFromTwoPoints(Location location1, Location location2) {
/* 223 */     List<Location> locations = new ArrayList<>();
/*     */     
/* 225 */     int topBlockX = (location1.getBlockX() < location2.getBlockX()) ? location2.getBlockX() : location1.getBlockX();
/*     */     
/* 227 */     int bottomBlockX = (location1.getBlockX() > location2.getBlockX()) ? location2.getBlockX() : location1.getBlockX();
/*     */     
/* 229 */     int topBlockY = (location1.getBlockY() < location2.getBlockY()) ? location2.getBlockY() : location1.getBlockY();
/*     */     
/* 231 */     int bottomBlockY = (location1.getBlockY() > location2.getBlockY()) ? location2.getBlockY() : location1.getBlockY();
/*     */     
/* 233 */     int topBlockZ = (location1.getBlockZ() < location2.getBlockZ()) ? location2.getBlockZ() : location1.getBlockZ();
/*     */     
/* 235 */     int bottomBlockZ = (location1.getBlockZ() > location2.getBlockZ()) ? location2.getBlockZ() : location1.getBlockZ();
/*     */     
/* 237 */     for (int x = bottomBlockX; x <= topBlockX; x++) {
/* 238 */       for (int z = bottomBlockZ; z <= topBlockZ; z++) {
/* 239 */         for (int y = bottomBlockY; y <= topBlockY; y++)
/* 240 */           locations.add(new Location(location1.getWorld(), x, y, z)); 
/*     */       } 
/* 242 */     }  return locations;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<FutureBlock> load(Location location, File file) {
/* 247 */     List<FutureBlock> blocks = new ArrayList<>();
/*     */     
/*     */     try {
/* 250 */       BufferedReader reader = new BufferedReader(new FileReader(file));
/* 251 */       String line = null;
/*     */       
/* 253 */       while ((line = reader.readLine()) != null) {
/* 254 */         if (!line.contains(",") || !line.contains(":")) {
/*     */           continue;
/*     */         }
/*     */         
/* 258 */         String[] parts = line.split(":");
/* 259 */         String[] coordinates = parts[0].split(",");
/* 260 */         String[] blockData = parts[1].split("\\.");
/* 261 */         blocks.add(new FutureBlock(location
/* 262 */               .clone().add(Integer.valueOf(coordinates[0]).intValue(), Integer.valueOf(coordinates[2]).intValue(), 
/* 263 */                 Integer.valueOf(coordinates[1]).intValue()), 
/* 264 */               Material.values()[Integer.valueOf(blockData[0]).intValue()], (blockData.length > 1) ? 
/* 265 */               Byte.valueOf(blockData[1]).byteValue() : 0));
/*     */       } 
/*     */       
/* 268 */       reader.close();
/* 269 */     } catch (Exception e) {
/* 270 */       CommonPlugin.getInstance()
/* 271 */         .debug("Error to load the bo2file " + file.getName() + " in the location " + location.toString());
/*     */     } 
/*     */     
/* 274 */     return blocks;
/*     */   }
/*     */   
/*     */   public List<FutureBlock> spawn(Location location, File file, Place place) {
/* 278 */     List<FutureBlock> load = load(location, file);
/*     */     
/* 280 */     for (FutureBlock futureBlock : load) {
/* 281 */       BukkitCommon.getInstance().getBlockManager().setBlockFast(futureBlock.getLocation(), futureBlock.getType(), futureBlock
/* 282 */           .getData(), place);
/*     */     }
/*     */     
/* 285 */     return load;
/*     */   }
/*     */   
/*     */   public List<FutureBlock> spawn(Location location, File file) {
/* 289 */     return spawn(location, file, null);
/*     */   }
/*     */   
/*     */   public List<FutureBlock> spawn(Location location, Schematic schematic) {
/* 293 */     return spawn(location, schematic, false, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<FutureBlock> spawn(Location location, Schematic schematic, boolean air, Place place) {
/* 298 */     List<FutureBlock> list = new ArrayList<>();
/*     */     
/* 300 */     short length = schematic.getLenght();
/* 301 */     short width = schematic.getWidth();
/* 302 */     short height = schematic.getHeight();
/*     */     
/* 304 */     for (int x = 0; x < width; x++) {
/* 305 */       for (int y = 0; y < height; y++) {
/* 306 */         for (int z = 0; z < length; z++) {
/* 307 */           int index = y * width * length + z * width + x;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 312 */           FutureBlock futureBlock = new FutureBlock(new Location(location.getWorld(), x + location.getX(), y + location.getY(), z + location.getZ()), Material.getMaterial(schematic.getBlocks()[index]), schematic.getData()[index]);
/*     */           
/* 314 */           if (air || futureBlock.getType() != Material.AIR) {
/* 315 */             list.add(new FutureBlock(new Location(location
/* 316 */                     .getWorld(), x + location.getX(), y + location.getY(), z + location
/* 317 */                     .getZ()), 
/* 318 */                   Material.getMaterial(schematic.getBlocks()[index]), schematic.getData()[index]));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 324 */     for (FutureBlock futureBlock : list) {
/* 325 */       BukkitCommon.getInstance().getBlockManager().setBlockFast(futureBlock.getLocation(), futureBlock.getType(), futureBlock
/* 326 */           .getData(), place);
/*     */     }
/*     */     
/* 329 */     return list;
/*     */   }
/*     */   public class Position {
/*     */     private Location firstLocation;
/*     */     private Location secondLocation;
/*     */     
/* 335 */     public void setFirstLocation(Location firstLocation) { this.firstLocation = firstLocation; }
/* 336 */     public Location getFirstLocation() { return this.firstLocation; }
/* 337 */     public void setSecondLocation(Location secondLocation) { this.secondLocation = secondLocation; } public Location getSecondLocation() {
/* 338 */       return this.secondLocation;
/*     */     } public List<Map<Location, BlockState>> getUndoList() {
/* 340 */       return this.undoList;
/*     */     }
/*     */     
/* 343 */     private List<Map<Location, BlockState>> undoList = new ArrayList<>();
/*     */ 
/*     */     
/*     */     public void addUndo(Map<Location, BlockState> map) {
/* 347 */       this.undoList.add(map);
/*     */     }
/*     */     
/*     */     public void removeUndo(Map<Location, BlockState> map) {
/* 351 */       this.undoList.remove(map);
/*     */     }
/*     */     
/*     */     public boolean hasFirstLocation() {
/* 355 */       return (this.firstLocation != null);
/*     */     }
/*     */     
/*     */     public boolean hasSecondLocation() {
/* 359 */       return (this.firstLocation != null);
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface Place {
/*     */     void place(Location param1Location);
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/manager/BlockManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */