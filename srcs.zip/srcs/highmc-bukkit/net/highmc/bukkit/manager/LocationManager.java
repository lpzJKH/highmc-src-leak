/*    */ package net.highmc.bukkit.manager;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import net.highmc.bukkit.BukkitCommon;
/*    */ import net.highmc.bukkit.event.server.LocationChangeEvent;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.WorldCreator;
/*    */ import org.bukkit.event.Event;
/*    */ 
/*    */ 
/*    */ public class LocationManager
/*    */ {
/*    */   public Map<String, Location> getLocationMap() {
/* 17 */     return this.locationMap;
/*    */   }
/*    */ 
/*    */   
/* 21 */   private Map<String, Location> locationMap = new HashMap<>();
/*    */ 
/*    */   
/*    */   public boolean hasLocation(String locationName) {
/* 25 */     return this.locationMap.containsKey(locationName.toLowerCase());
/*    */   }
/*    */   
/*    */   public void loadLocation(String locationName, Location location) {
/* 29 */     this.locationMap.put(locationName.toLowerCase(), location);
/*    */   }
/*    */   
/*    */   public void saveLocation(String locationName, Location location) {
/* 33 */     BukkitCommon.getInstance().getConfig().set("location." + locationName + ".world", location
/* 34 */         .getWorld().getName());
/* 35 */     BukkitCommon.getInstance().getConfig().set("location." + locationName + ".x", Double.valueOf(location.getX()));
/* 36 */     BukkitCommon.getInstance().getConfig().set("location." + locationName + ".y", Double.valueOf(location.getY()));
/* 37 */     BukkitCommon.getInstance().getConfig().set("location." + locationName + ".z", Double.valueOf(location.getZ()));
/* 38 */     BukkitCommon.getInstance().getConfig().set("location." + locationName + ".pitch", Float.valueOf(location.getPitch()));
/* 39 */     BukkitCommon.getInstance().getConfig().set("location." + locationName + ".yaw", Float.valueOf(location.getYaw()));
/* 40 */     BukkitCommon.getInstance().saveConfig();
/* 41 */     Bukkit.getPluginManager().callEvent((Event)new LocationChangeEvent(locationName, location, null));
/*    */   }
/*    */   
/*    */   public void saveAndLoadLocation(String locationName, Location location) {
/* 45 */     this.locationMap.put(locationName.toLowerCase(), location);
/* 46 */     saveLocation(locationName, location);
/*    */   }
/*    */   
/*    */   public Location getLocation(String locationName) {
/* 50 */     return this.locationMap.computeIfAbsent(locationName.toLowerCase(), v -> getLocationFromConfig(locationName));
/*    */   }
/*    */   
/*    */   public Location getLocationFromConfig(String locationName) {
/* 54 */     if (!BukkitCommon.getInstance().getConfig().contains("location." + locationName)) {
/* 55 */       return new Location(Bukkit.getWorlds().stream().findFirst().orElse(null), 0.0D, 120.0D, 0.0D);
/*    */     }
/* 57 */     World world = Bukkit.getWorld(
/* 58 */         BukkitCommon.getInstance().getConfig().getString("location." + locationName + ".world").toLowerCase());
/*    */     
/* 60 */     if (world == null) {
/* 61 */       world = Bukkit.createWorld(new WorldCreator(BukkitCommon.getInstance().getConfig()
/* 62 */             .getString("location." + locationName + ".world").toLowerCase()));
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 69 */     Location location = new Location(world, BukkitCommon.getInstance().getConfig().getDouble("location." + locationName + ".x"), BukkitCommon.getInstance().getConfig().getDouble("location." + locationName + ".y"), BukkitCommon.getInstance().getConfig().getDouble("location." + locationName + ".z"), (float)BukkitCommon.getInstance().getConfig().getDouble("location." + locationName + ".yaw"), (float)BukkitCommon.getInstance().getConfig().getDouble("location." + locationName + ".pitch"));
/*    */     
/* 71 */     return location;
/*    */   }
/*    */   
/*    */   public void removeLocationInConfig(String locationName) {
/* 75 */     this.locationMap.remove(locationName.toLowerCase());
/* 76 */     BukkitCommon.getInstance().getConfig().set("location." + locationName, null);
/* 77 */     BukkitCommon.getInstance().saveConfig();
/*    */   }
/*    */   
/*    */   public String[] getLocations() {
/* 81 */     return (String[])this.locationMap.keySet().stream().toArray(x$0 -> new String[x$0]);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/manager/LocationManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */