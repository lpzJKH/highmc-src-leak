/*     */ package net.highmc.bukkit.manager;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.bukkit.event.UpdateEvent;
/*     */ import net.highmc.bukkit.event.cooldown.CooldownFinishEvent;
/*     */ import net.highmc.bukkit.event.cooldown.CooldownStartEvent;
/*     */ import net.highmc.bukkit.event.cooldown.CooldownStopEvent;
/*     */ import net.highmc.bukkit.utils.cooldown.Cooldown;
/*     */ import net.highmc.bukkit.utils.cooldown.ItemCooldown;
/*     */ import net.highmc.bukkit.utils.player.PlayerHelper;
/*     */ import net.highmc.utils.string.StringFormat;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.HandlerList;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CooldownManager
/*     */   implements Listener
/*     */ {
/*     */   private static final char CHAR = '|';
/*  47 */   private Map<UUID, List<Cooldown>> map = new ConcurrentHashMap<>();
/*  48 */   private Listener listener = new CooldownListener();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCooldown(Player player, Cooldown cooldown) {
/*  59 */     CooldownStartEvent event = new CooldownStartEvent(player, cooldown);
/*  60 */     Bukkit.getServer().getPluginManager().callEvent((Event)event);
/*     */     
/*  62 */     if (!event.isCancelled()) {
/*  63 */       List<Cooldown> list = this.map.computeIfAbsent(player.getUniqueId(), v -> new ArrayList());
/*     */       
/*  65 */       boolean add = true;
/*     */       
/*  67 */       for (Cooldown cool : list) {
/*  68 */         if (cool.getName().equals(cooldown.getName())) {
/*  69 */           cool.update(cooldown.getDuration(), cooldown.getStartTime());
/*  70 */           add = false;
/*     */         } 
/*     */       } 
/*     */       
/*  74 */       if (add) {
/*  75 */         list.add(cooldown);
/*     */       }
/*  77 */       if (!this.map.isEmpty()) {
/*  78 */         registerListener();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCooldown(UUID uuid, String name, long duration) {
/*  90 */     Player player = Bukkit.getPlayer(uuid);
/*     */     
/*  92 */     if (player == null) {
/*     */       return;
/*     */     }
/*  95 */     Cooldown cooldown = new Cooldown(name, duration);
/*     */     
/*  97 */     CooldownStartEvent event = new CooldownStartEvent(player, cooldown);
/*  98 */     Bukkit.getServer().getPluginManager().callEvent((Event)event);
/*     */     
/* 100 */     if (!event.isCancelled()) {
/* 101 */       List<Cooldown> list = this.map.computeIfAbsent(player.getUniqueId(), v -> new ArrayList());
/*     */       
/* 103 */       boolean add = true;
/*     */       
/* 105 */       for (Cooldown cool : list) {
/* 106 */         if (cool.getName().equals(cooldown.getName())) {
/* 107 */           cool.update(cooldown.getDuration(), cooldown.getStartTime());
/* 108 */           add = false;
/*     */         } 
/*     */       } 
/*     */       
/* 112 */       if (add) {
/* 113 */         list.add(cooldown);
/*     */       }
/* 115 */       if (!this.map.isEmpty())
/* 116 */         registerListener(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void registerListener() {
/* 121 */     if (this.listener == null) {
/* 122 */       this.listener = new CooldownListener();
/* 123 */       Bukkit.getPluginManager().registerEvents(this.listener, (Plugin)BukkitCommon.getInstance());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeCooldown(Player player, String name) {
/* 135 */     if (this.map.containsKey(player.getUniqueId())) {
/* 136 */       List<Cooldown> list = this.map.get(player.getUniqueId());
/* 137 */       Iterator<Cooldown> it = list.iterator();
/* 138 */       while (it.hasNext()) {
/* 139 */         Cooldown cooldown = it.next();
/*     */         
/* 141 */         if (cooldown.getName().equals(name)) {
/* 142 */           it.remove();
/* 143 */           Bukkit.getPluginManager().callEvent((Event)new CooldownStopEvent(player, cooldown));
/* 144 */           return true;
/*     */         } 
/*     */       } 
/*     */     } 
/* 148 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasCooldown(Player player, String name) {
/* 161 */     if (this.map.containsKey(player.getUniqueId())) {
/* 162 */       List<Cooldown> list = this.map.get(player.getUniqueId());
/* 163 */       for (Cooldown cooldown : list) {
/* 164 */         if (cooldown.getName().equals(name))
/* 165 */           return true; 
/*     */       } 
/* 167 */     }  return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasCooldown(UUID uniqueId, String name) {
/* 180 */     if (this.map.containsKey(uniqueId)) {
/* 181 */       List<Cooldown> list = this.map.get(uniqueId);
/* 182 */       for (Cooldown cooldown : list) {
/* 183 */         if (cooldown.getName().equals(name))
/* 184 */           return true; 
/*     */       } 
/* 186 */     }  return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cooldown getCooldown(UUID uniqueId, String name) {
/* 200 */     if (this.map.containsKey(uniqueId)) {
/* 201 */       List<Cooldown> list = this.map.get(uniqueId);
/*     */       
/* 203 */       for (Cooldown cooldown : list) {
/* 204 */         if (cooldown.getName().equals(name))
/* 205 */           return cooldown; 
/*     */       } 
/* 207 */     }  return null;
/*     */   }
/*     */   
/*     */   public void clearCooldown(Player player) {
/* 211 */     if (this.map.containsKey(player.getUniqueId()))
/* 212 */       this.map.remove(player.getUniqueId()); 
/*     */   }
/*     */   
/*     */   public class CooldownListener
/*     */     implements Listener {
/*     */     @EventHandler
/*     */     public void onUpdate(UpdateEvent event) {
/* 219 */       if (event.getType() != UpdateEvent.UpdateType.TICK) {
/*     */         return;
/*     */       }
/* 222 */       if (event.getCurrentTick() % 5L == 0L) {
/*     */         return;
/*     */       }
/* 225 */       for (UUID uuid : CooldownManager.this.map.keySet()) {
/* 226 */         Player player = Bukkit.getPlayer(uuid);
/*     */         
/* 228 */         if (player != null) {
/* 229 */           List<Cooldown> list = (List<Cooldown>)CooldownManager.this.map.get(uuid);
/* 230 */           Iterator<Cooldown> it = list.iterator();
/*     */ 
/*     */           
/* 233 */           Cooldown found = null;
/* 234 */           while (it.hasNext()) {
/* 235 */             Cooldown cooldown1 = it.next();
/*     */             
/* 237 */             if (!cooldown1.expired()) {
/* 238 */               if (cooldown1 instanceof ItemCooldown) {
/* 239 */                 ItemStack hand = player.getItemInHand();
/* 240 */                 if (hand != null && hand.getType() != Material.AIR) {
/* 241 */                   ItemCooldown item = (ItemCooldown)cooldown1;
/* 242 */                   if (hand.equals(item.getItem())) {
/* 243 */                     item.setSelected(true);
/* 244 */                     ItemCooldown itemCooldown = item;
/*     */                     
/*     */                     break;
/*     */                   } 
/*     */                 } 
/*     */                 continue;
/*     */               } 
/* 251 */               found = cooldown1;
/*     */               
/*     */               continue;
/*     */             } 
/* 255 */             it.remove();
/*     */             
/* 257 */             CooldownFinishEvent e = new CooldownFinishEvent(player, cooldown1);
/* 258 */             Bukkit.getServer().getPluginManager().callEvent((Event)e);
/*     */           } 
/*     */ 
/*     */           
/* 262 */           if (found != null) {
/* 263 */             display(player, found); continue;
/* 264 */           }  if (list.isEmpty()) {
/* 265 */             PlayerHelper.actionbar(player, " ");
/* 266 */             CooldownManager.this.map.remove(uuid); continue;
/*     */           } 
/* 268 */           Cooldown cooldown = list.get(0);
/*     */           
/* 270 */           if (cooldown instanceof ItemCooldown) {
/* 271 */             ItemCooldown item = (ItemCooldown)cooldown;
/*     */             
/* 273 */             if (item.isSelected()) {
/* 274 */               item.setSelected(false);
/* 275 */               PlayerHelper.actionbar(player, " ");
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     @EventHandler
/*     */     public void onCooldown(CooldownStopEvent event) {
/* 285 */       if (CooldownManager.this.map.isEmpty()) {
/* 286 */         HandlerList.unregisterAll(CooldownManager.this.listener);
/* 287 */         CooldownManager.this.listener = null;
/*     */       } 
/*     */     }
/*     */     
/*     */     private void display(Player player, Cooldown cooldown) {
/* 292 */       StringBuilder bar = new StringBuilder();
/* 293 */       double percentage = cooldown.getPercentage();
/* 294 */       double count = 20.0D - Math.max((percentage > 0.0D) ? 1.0D : 0.0D, percentage / 5.0D);
/*     */       int a;
/* 296 */       for (a = 0; a < count; a++)
/* 297 */         bar.append("§a|"); 
/* 298 */       for (a = 0; a < 20.0D - count; a++) {
/* 299 */         bar.append("§c|");
/*     */       }
/* 301 */       PlayerHelper.actionbar(player, "§f" + cooldown.getName() + " " + bar.toString() + " §f" + 
/* 302 */           StringFormat.formatTime((int)cooldown.getRemaining(), StringFormat.TimeFormat.NORMAL));
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/manager/CooldownManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */