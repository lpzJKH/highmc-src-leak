/*     */ package net.highmc.bukkit.manager;
/*     */ 
/*     */ import com.comphenix.protocol.PacketType;
/*     */ import com.comphenix.protocol.ProtocolLibrary;
/*     */ import com.comphenix.protocol.events.ListenerPriority;
/*     */ import com.comphenix.protocol.events.PacketAdapter;
/*     */ import com.comphenix.protocol.events.PacketContainer;
/*     */ import com.comphenix.protocol.events.PacketEvent;
/*     */ import com.comphenix.protocol.events.PacketListener;
/*     */ import com.comphenix.protocol.wrappers.WrappedWatchableObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.bukkit.utils.hologram.Hologram;
/*     */ import net.highmc.bukkit.utils.hologram.HologramBuilder;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ public class HologramManager {
/*     */   private JavaPlugin javaPlugin;
/*     */   private List<Hologram> hologramList;
/*     */   
/*     */   public JavaPlugin getJavaPlugin() {
/*  30 */     return this.javaPlugin; } public List<Hologram> getHologramList() {
/*  31 */     return this.hologramList;
/*     */   }
/*     */   public HologramManager() {
/*  34 */     this.hologramList = new ArrayList<>();
/*     */     
/*  36 */     ProtocolLibrary.getProtocolManager().addPacketListener((PacketListener)new PacketAdapter(
/*  37 */           (Plugin)BukkitCommon.getInstance(), ListenerPriority.HIGHEST, new PacketType[] { PacketType.Play.Server.SPAWN_ENTITY_LIVING, PacketType.Play.Server.ENTITY_METADATA })
/*     */         {
/*     */           public void onPacketSending(PacketEvent event)
/*     */           {
/*  41 */             Entity entity = (Entity)event.getPacket().getEntityModifier(event.getPlayer().getWorld()).read(0);
/*  42 */             Player player = event.getPlayer();
/*  43 */             if (entity != null && entity.getType() == EntityType.ARMOR_STAND) {
/*     */               
/*  45 */               Hologram hologram = HologramManager.this.hologramList.stream().filter(h -> h.isEntityOrLine(entity.getEntityId())).findFirst().orElse(null);
/*  46 */               if (hologram == null)
/*     */                 return; 
/*  48 */               if (event.getPacketType() == PacketType.Play.Server.ENTITY_METADATA) {
/*  49 */                 if (hologram.hasViewHandler()) {
/*  50 */                   PacketContainer packet = event.getPacket().deepClone();
/*     */                   
/*  52 */                   List<WrappedWatchableObject> objects = (List<WrappedWatchableObject>)packet.getWatchableCollectionModifier().read(0);
/*  53 */                   for (WrappedWatchableObject obj : objects) {
/*  54 */                     if (obj.getIndex() == 2) {
/*  55 */                       obj.setValue(hologram.getViewHandler().onView(hologram, player, (String)obj
/*  56 */                             .getRawValue()));
/*     */                       break;
/*     */                     } 
/*     */                   } 
/*  60 */                   event.setPacket(packet);
/*     */                 } 
/*  62 */               } else if (!hologram.isVisibleTo(player)) {
/*  63 */                 event.setCancelled(true);
/*     */               } 
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/*  69 */     Bukkit.getWorlds().forEach(world -> world.getEntities().forEach(()));
/*     */   }
/*     */   
/*     */   public void registerHologram(Hologram hologram) {
/*  73 */     if (!this.hologramList.contains(hologram))
/*  74 */       this.hologramList.add(hologram); 
/*     */   }
/*     */   
/*     */   public void unregisterHologram(Hologram hologram) {
/*  78 */     if (this.hologramList.contains(hologram))
/*  79 */       this.hologramList.remove(hologram); 
/*     */   }
/*     */   
/*     */   public Hologram createHologram(String displayName, Location location, Class<? extends Hologram> clazz) {
/*  83 */     Hologram hologram = null;
/*     */     
/*     */     try {
/*  86 */       hologram = clazz.getConstructor(new Class[] { String.class, Location.class }).newInstance(new Object[] { displayName, location });
/*  87 */       hologram.spawn();
/*  88 */       registerHologram(hologram);
/*  89 */     } catch (InstantiationException|IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException|NoSuchMethodException|SecurityException e) {
/*     */       
/*  91 */       e.printStackTrace();
/*     */     } 
/*     */     
/*  94 */     return hologram;
/*     */   }
/*     */   
/*     */   public Hologram createHologram(HologramBuilder hologramBuilder) {
/*  98 */     Hologram hologram = hologramBuilder.build();
/*     */     
/* 100 */     hologram.spawn();
/* 101 */     registerHologram(hologram);
/*     */     
/* 103 */     return hologram;
/*     */   }
/*     */   
/*     */   public Hologram createHologram(Hologram hologram) {
/* 107 */     hologram.spawn();
/* 108 */     registerHologram(hologram);
/*     */     
/* 110 */     return hologram;
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/manager/HologramManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */