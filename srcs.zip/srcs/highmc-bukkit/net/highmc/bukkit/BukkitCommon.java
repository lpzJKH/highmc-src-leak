/*     */ package net.highmc.bukkit;
/*     */ import com.google.common.base.Joiner;
/*     */ import com.google.common.io.ByteArrayDataInput;
/*     */ import com.google.common.io.ByteArrayDataOutput;
/*     */ import com.google.common.io.ByteStreams;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.HashSet;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.backend.redis.RedisConnection;
/*     */ import net.highmc.bukkit.anticheat.StormCore;
/*     */ import net.highmc.bukkit.command.BukkitCommandFramework;
/*     */ import net.highmc.bukkit.event.UpdateEvent;
/*     */ import net.highmc.bukkit.listener.CharacterListener;
/*     */ import net.highmc.bukkit.listener.ChatListener;
/*     */ import net.highmc.bukkit.listener.CombatListener;
/*     */ import net.highmc.bukkit.listener.CommandListener;
/*     */ import net.highmc.bukkit.listener.HologramListener;
/*     */ import net.highmc.bukkit.listener.MenuListener;
/*     */ import net.highmc.bukkit.listener.MoveListener;
/*     */ import net.highmc.bukkit.listener.PlayerListener;
/*     */ import net.highmc.bukkit.listener.VanishListener;
/*     */ import net.highmc.bukkit.listener.WorldListener;
/*     */ import net.highmc.bukkit.listener.member.MemberListener;
/*     */ import net.highmc.bukkit.listener.member.TagListener;
/*     */ import net.highmc.bukkit.manager.BlockManager;
/*     */ import net.highmc.bukkit.manager.ChatManager;
/*     */ import net.highmc.bukkit.manager.CombatlogManager;
/*     */ import net.highmc.bukkit.manager.CooldownManager;
/*     */ import net.highmc.bukkit.manager.HologramManager;
/*     */ import net.highmc.bukkit.manager.LocationManager;
/*     */ import net.highmc.bukkit.manager.VanishManager;
/*     */ import net.highmc.bukkit.member.party.BukkitParty;
/*     */ import net.highmc.bukkit.networking.BukkitPubSubHandler;
/*     */ import net.highmc.bukkit.protocol.impl.LimiterInjector;
/*     */ import net.highmc.bukkit.protocol.impl.TranslationInjector;
/*     */ import net.highmc.bukkit.utils.character.Character;
/*     */ import net.highmc.bukkit.utils.character.handler.ActionHandler;
/*     */ import net.highmc.bukkit.utils.hologram.Hologram;
/*     */ import net.highmc.bukkit.utils.hologram.impl.SimpleHologram;
/*     */ import net.highmc.bukkit.utils.permission.PermissionManager;
/*     */ import net.highmc.bukkit.utils.player.PlayerHelper;
/*     */ import net.highmc.member.status.StatusType;
/*     */ import net.highmc.server.ServerManager;
/*     */ import net.highmc.server.ServerType;
/*     */ import net.minecraft.server.v1_8_R3.DedicatedPlayerList;
/*     */ import net.minecraft.server.v1_8_R3.PlayerList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.craftbukkit.v1_8_R3.CraftServer;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.HandlerList;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
/*     */ import org.bukkit.metadata.FixedMetadataValue;
/*     */ import org.bukkit.metadata.MetadataValue;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ import redis.clients.jedis.JedisPubSub;
/*     */ 
/*     */ public abstract class BukkitCommon extends JavaPlugin {
/*     */   private static BukkitCommon instance;
/*     */   private CommonPlugin plugin;
/*     */   private BlockManager blockManager;
/*     */   private ChatManager chatManager;
/*     */   private CombatlogManager combatlogManager;
/*     */   private CooldownManager cooldownManager;
/*     */   
/*     */   public static BukkitCommon getInstance() {
/*  78 */     return instance;
/*     */   } private HologramManager hologramManager; private LocationManager locationManager; private VanishManager vanishManager; private PermissionManager permissionManager; private ServerManager serverManager; private StormCore stormCore; private boolean serverLog;
/*     */   public CommonPlugin getPlugin() {
/*  81 */     return this.plugin;
/*     */   }
/*  83 */   public BlockManager getBlockManager() { return this.blockManager; }
/*  84 */   public ChatManager getChatManager() { return this.chatManager; }
/*  85 */   public CombatlogManager getCombatlogManager() { return this.combatlogManager; }
/*  86 */   public CooldownManager getCooldownManager() { return this.cooldownManager; }
/*  87 */   public HologramManager getHologramManager() { return this.hologramManager; }
/*  88 */   public LocationManager getLocationManager() { return this.locationManager; } public VanishManager getVanishManager() {
/*  89 */     return this.vanishManager;
/*     */   }
/*  91 */   public PermissionManager getPermissionManager() { return this.permissionManager; } public ServerManager getServerManager() {
/*  92 */     return this.serverManager;
/*     */   } public StormCore getStormCore() {
/*  94 */     return this.stormCore;
/*     */   }
/*  96 */   public void setServerLog(boolean serverLog) { this.serverLog = serverLog; }
/*  97 */   public boolean isServerLog() { return this.serverLog; } private boolean tagControl = true;
/*  98 */   public void setTagControl(boolean tagControl) { this.tagControl = tagControl; }
/*  99 */   public boolean isTagControl() { return this.tagControl; } private boolean removePlayerDat = true;
/* 100 */   public void setRemovePlayerDat(boolean removePlayerDat) { this.removePlayerDat = removePlayerDat; } public boolean isRemovePlayerDat() {
/* 101 */     return this.removePlayerDat;
/* 102 */   } private ChatState chatState = ChatState.ENABLED; public void setChatState(ChatState chatState) { this.chatState = chatState; } public ChatState getChatState() {
/* 103 */     return this.chatState;
/*     */   } private boolean blockCommands = true;
/* 105 */   public void setBlockCommands(boolean blockCommands) { this.blockCommands = blockCommands; }
/* 106 */   public boolean isBlockCommands() { return this.blockCommands; } private boolean permissionControl = true;
/* 107 */   public void setPermissionControl(boolean permissionControl) { this.permissionControl = permissionControl; }
/* 108 */   public boolean isPermissionControl() { return this.permissionControl; } private boolean registerCommands = true;
/* 109 */   public void setRegisterCommands(boolean registerCommands) { this.registerCommands = registerCommands; } public boolean isRegisterCommands() {
/* 110 */     return this.registerCommands;
/*     */   }
/* 112 */   private Set<StatusType> preloadedStatus = new HashSet<>(); public Set<StatusType> getPreloadedStatus() { return this.preloadedStatus; }
/*     */ 
/*     */   
/*     */   public void onLoad() {
/* 116 */     instance = this;
/*     */     
/* 118 */     this.plugin = new CommonPlugin(new BukkitPlatform());
/* 119 */     this.stormCore = new StormCore((Plugin)this);
/* 120 */     this.stormCore.onLoad();
/* 121 */     saveDefaultConfig();
/* 122 */     super.onLoad();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*     */     try {
/* 128 */       Listener listener = new Listener()
/*     */         {
/*     */           @EventHandler(priority = EventPriority.LOWEST)
/*     */           public void onAsyncPlayerPreLogin(AsyncPlayerPreLoginEvent event) {
/* 132 */             event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, "§cO servidor está carregando.");
/*     */           }
/*     */         };
/*     */ 
/*     */       
/* 137 */       Bukkit.getPluginManager().registerEvents(listener, (Plugin)this);
/*     */       
/* 139 */       loadManagers();
/* 140 */       loadListeners();
/* 141 */       loadPacketInjectors();
/* 142 */       this.stormCore.onEnable();
/*     */       
/* 144 */       getServer().getScheduler().runTaskTimer((Plugin)this, new UpdateScheduler(), 1L, 1L);
/*     */       
/* 146 */       getServer().getScheduler().runTaskAsynchronously((Plugin)getInstance(), (Runnable)new RedisConnection.PubSubListener(this.plugin
/* 147 */             .getRedisConnection(), (JedisPubSub)new BukkitPubSubHandler(), new String[] { "member_field", "clan_field", "server_info", "server_packet", "server_members" }));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 152 */       (new BukkitRunnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 156 */             if (BukkitCommon.this.isBlockCommands()) {
/* 157 */               BukkitCommandFramework.INSTANCE.unregisterCommands(new String[] { "icanhasbukkit", "plugins", "pl", "ver", "version", "?", "about", "help", "ban", "ban-ip", "banlist", "kick", "deop", "teleport", "gamemode", "op", "list", "me", "say", "scoreboard", "seed", "spawnpoint", "spreadplayers", "summon", "tell", "tellraw", "testfor", "testforblocks", "tp", "weather", "reload", "rl", "worldborder", "achievement", "blockdata", "clone", "debug", "defaultgamemode", "entitydata", "execute", "fill", "pardon", "pardon-ip", "replaceitem", "setidletimeout", "stats", "testforblock", "title", "trigger", "viaver", "ps", "holograms", "hd", "holo", "hologram", "restart", "filter", "packetlog", "?", "tps", "viaversion", "vvbukkit", "stop" });
/*     */             }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 167 */             if (BukkitCommon.this.isRegisterCommands())
/* 168 */               BukkitCommandFramework.INSTANCE.loadCommands("net.highmc"); 
/*     */           }
/* 170 */         }).runTaskLater((Plugin)this, 7L);
/*     */       
/* 172 */       loadServerInfo();
/* 173 */       loadBungeeConfig();
/*     */       
/* 175 */       HandlerList.unregisterAll(listener);
/* 176 */       super.onEnable();
/* 177 */     } catch (Exception ex) {
/* 178 */       Bukkit.shutdown();
/* 179 */       ex.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/* 185 */     this.plugin.getServerData().stopServer();
/* 186 */     super.onDisable();
/*     */   }
/*     */   
/*     */   public void addStatus(StatusType statusType) {
/* 190 */     this.preloadedStatus.add(statusType);
/*     */   }
/*     */   
/*     */   public Hologram createCharacter(Location location, String playerName, ActionHandler interact) {
/* 194 */     Character character = new Character(playerName, location, interact);
/* 195 */     SimpleHologram simpleHologram = new SimpleHologram("", location);
/*     */     
/* 197 */     this.hologramManager.registerHologram((Hologram)simpleHologram);
/* 198 */     simpleHologram.spawn();
/*     */     
/* 200 */     Bukkit.getOnlinePlayers().forEach(player -> character.show(player));
/* 201 */     return (Hologram)simpleHologram;
/*     */   }
/*     */ 
/*     */   
/*     */   public void loadServerInfo() {
/* 206 */     ServerType serverType = ServerType.valueOf(getConfig().getString("serverType", ServerType.BUNGEECORD.name()).toUpperCase());
/* 207 */     String serverId = getConfig().getString("serverId").toLowerCase();
/* 208 */     boolean joinEnabled = getConfig().getBoolean("joinEnabled", true);
/*     */     
/* 210 */     if (serverType.name().contains("LOBBY")) {
/* 211 */       setServerLog(true);
/*     */     }
/* 213 */     this.plugin.setServerAddress(Bukkit.getIp() + ":" + Bukkit.getPort());
/* 214 */     this.plugin.setServerType(serverType);
/* 215 */     this.plugin.setServerId(serverId);
/* 216 */     this.plugin.setJoinEnabled(joinEnabled);
/*     */     
/* 218 */     this.plugin.debug("The server id is " + serverId);
/* 219 */     this.plugin.debug("The server type is " + serverType);
/*     */     
/* 221 */     this.plugin.getServerData().startServer(Bukkit.getMaxPlayers());
/*     */     
/* 223 */     if (isServerLog()) {
/* 224 */       this.plugin.loadServers(this.serverManager);
/*     */     }
/* 226 */     this.plugin.debug("The server has been started!");
/*     */     
/* 228 */     this.plugin.setPartyClass(BukkitParty.class);
/* 229 */     this.plugin.getReportManager().loadReports();
/*     */   }
/*     */   
/*     */   public void loadManagers() {
/* 233 */     this.blockManager = new BlockManager();
/* 234 */     this.chatManager = new ChatManager();
/* 235 */     this.combatlogManager = new CombatlogManager();
/* 236 */     this.cooldownManager = new CooldownManager();
/*     */     
/* 238 */     this.hologramManager = new HologramManager();
/*     */     
/* 240 */     this.locationManager = new LocationManager();
/*     */     
/* 242 */     if (isPermissionControl()) {
/* 243 */       this.permissionManager = new PermissionManager(this);
/*     */     }
/* 245 */     this.serverManager = new ServerManager();
/* 246 */     this.vanishManager = new VanishManager();
/*     */   }
/*     */   
/*     */   public void loadBungeeConfig() {
/* 250 */     getServer().getMessenger().registerOutgoingPluginChannel((Plugin)this, "BungeeCord");
/* 251 */     getServer().getMessenger().registerIncomingPluginChannel((Plugin)this, "BungeeCord", (channel, player, message) -> {
/*     */           ByteArrayDataInput in = ByteStreams.newDataInput(message);
/*     */           String subchannel = in.readUTF();
/*     */           if (subchannel.equalsIgnoreCase("BungeeTeleport")) {
/*     */             String uniqueId = in.readUTF();
/*     */             Player p = BukkitMain.getInstance().getServer().getPlayer(UUID.fromString(uniqueId));
/*     */             if (p != null) {
/*     */               player.chat("/tp " + p.getName());
/*     */               getVanishManager().setPlayerInAdmin(player);
/*     */             } 
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadPacketInjectors() {
/* 270 */     (new LimiterInjector()).inject((Plugin)this);
/* 271 */     (new TranslationInjector()).inject((Plugin)this);
/*     */   }
/*     */   
/*     */   public void loadListeners() {
/* 275 */     Bukkit.getPluginManager().registerEvents((Listener)new MemberListener(), (Plugin)this);
/* 276 */     Bukkit.getPluginManager().registerEvents((Listener)new TagListener(), (Plugin)this);
/*     */     
/* 278 */     Bukkit.getPluginManager().registerEvents((Listener)new CharacterListener(), (Plugin)this);
/* 279 */     Bukkit.getPluginManager().registerEvents((Listener)new ChatListener(), (Plugin)this);
/* 280 */     Bukkit.getPluginManager().registerEvents((Listener)new CombatListener(), (Plugin)this);
/* 281 */     Bukkit.getPluginManager().registerEvents((Listener)new CommandListener(), (Plugin)this);
/* 282 */     Bukkit.getPluginManager().registerEvents((Listener)new HologramListener(), (Plugin)this);
/* 283 */     Bukkit.getPluginManager().registerEvents((Listener)new MenuListener(), (Plugin)this);
/* 284 */     Bukkit.getPluginManager().registerEvents((Listener)new MoveListener(), (Plugin)this);
/*     */     
/* 286 */     Bukkit.getPluginManager().registerEvents((Listener)new PlayerListener(), (Plugin)this);
/* 287 */     Bukkit.getPluginManager().registerEvents((Listener)new VanishListener(), (Plugin)this);
/* 288 */     Bukkit.getPluginManager().registerEvents((Listener)new WorldListener(), (Plugin)this);
/*     */     
/* 290 */     if (isPermissionControl())
/* 291 */       Bukkit.getPluginManager().registerEvents((Listener)new PermissionListener(), (Plugin)this); 
/*     */   }
/*     */   
/*     */   public void setMaxPlayers(int maxPlayers) {
/*     */     try {
/* 296 */       DedicatedPlayerList dedicatedPlayerList = ((CraftServer)getServer()).getHandle();
/*     */       
/* 298 */       Field fieldMaxPlayers = PlayerList.class.getDeclaredField("maxPlayers");
/* 299 */       fieldMaxPlayers.setAccessible(true);
/* 300 */       fieldMaxPlayers.set(dedicatedPlayerList, Integer.valueOf(maxPlayers));
/*     */       
/* 302 */       if (!Bukkit.getOnlinePlayers().isEmpty()) {
/* 303 */         Player player = Bukkit.getOnlinePlayers().stream().findFirst().orElse(null);
/* 304 */         this.plugin.getServerData().leavePlayer(player.getUniqueId(), maxPlayers);
/* 305 */         this.plugin.getServerData().joinPlayer(player.getUniqueId(), maxPlayers);
/*     */       } 
/* 307 */     } catch (SecurityException|IllegalAccessException|IllegalArgumentException|NoSuchFieldException e) {
/* 308 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void sendPlayerToServer(Player player, String server) {
/* 313 */     ByteArrayOutputStream b = new ByteArrayOutputStream();
/* 314 */     DataOutputStream out = new DataOutputStream(b);
/*     */     
/*     */     try {
/* 317 */       out.writeUTF("Connect");
/* 318 */       out.writeUTF(server);
/* 319 */     } catch (Exception e) {
/* 320 */       e.printStackTrace(System.out);
/*     */     } 
/*     */     
/* 323 */     player.sendPluginMessage((Plugin)this, "BungeeCord", b.toByteArray());
/*     */   }
/*     */   
/*     */   public void sendPlayerToServer(Player player, boolean silent, String server) {
/* 327 */     ByteArrayOutputStream b = new ByteArrayOutputStream();
/* 328 */     DataOutputStream out = new DataOutputStream(b);
/*     */     
/*     */     try {
/* 331 */       out.writeUTF("PlayerConnect");
/* 332 */       out.writeUTF(server);
/* 333 */       out.writeBoolean(silent);
/* 334 */     } catch (Exception e) {
/* 335 */       e.printStackTrace(System.out);
/*     */     } 
/*     */     
/* 338 */     player.sendPluginMessage((Plugin)this, "BungeeCord", b.toByteArray());
/*     */   }
/*     */   
/*     */   public void sendPlayerToServer(Player player, ServerType... serverType) {
/* 342 */     sendPlayerToServer(player, false, serverType);
/*     */   }
/*     */   
/*     */   public void sendPlayerToServer(Player player, boolean silent, ServerType... serverType) {
/* 346 */     ByteArrayDataOutput out = ByteStreams.newDataOutput();
/* 347 */     out.writeUTF("SearchServer");
/* 348 */     out.writeUTF(Joiner.on('-').join((Object[])serverType));
/* 349 */     out.writeBoolean(silent);
/* 350 */     player.sendPluginMessage((Plugin)this, "BungeeCord", out.toByteArray());
/*     */   }
/*     */   
/*     */   public void performCommand(Player player, String command) {
/* 354 */     ByteArrayDataOutput out = ByteStreams.newDataOutput();
/* 355 */     out.writeUTF("BungeeCommand");
/* 356 */     out.writeUTF(command);
/* 357 */     player.sendPluginMessage((Plugin)this, "BungeeCord", out.toByteArray());
/*     */   }
/*     */   
/*     */   public void debug(String string) {
/* 361 */     this.plugin.debug(string);
/*     */     
/* 363 */     Player player = Bukkit.getPlayer("yandv");
/*     */     
/* 365 */     if (player != null)
/* 366 */       PlayerHelper.actionbar(player, "§c" + string); 
/*     */   }
/*     */   
/*     */   public class UpdateScheduler
/*     */     implements Runnable
/*     */   {
/*     */     private long currentTick;
/*     */     
/*     */     public void run() {
/* 375 */       this.currentTick++;
/* 376 */       Bukkit.getPluginManager().callEvent((Event)new UpdateEvent(UpdateEvent.UpdateType.TICK, this.currentTick));
/*     */       
/* 378 */       if (this.currentTick % 20.0D == 0.0D) {
/* 379 */         Bukkit.getPluginManager().callEvent((Event)new UpdateEvent(UpdateEvent.UpdateType.SECOND, this.currentTick));
/*     */       }
/*     */       
/* 382 */       if (this.currentTick % 1200.0D == 0.0D) {
/* 383 */         Bukkit.getPluginManager().callEvent((Event)new UpdateEvent(UpdateEvent.UpdateType.MINUTE, this.currentTick));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String getColorByLevel(int level) {
/* 390 */     if (level >= 0 && level < 10)
/* 391 */       return "§7" + level + "✫"; 
/* 392 */     if (level >= 10 && level < 20)
/* 393 */       return "§a" + level + "✶"; 
/* 394 */     if (level >= 20 && level < 30)
/* 395 */       return "§b" + level + "✻"; 
/* 396 */     if (level >= 30 && level < 40)
/* 397 */       return "§d" + level + "❃"; 
/* 398 */     if (level >= 40 && level < 50)
/* 399 */       return "§e" + level + "✷"; 
/* 400 */     if (level >= 50 && level < 60)
/* 401 */       return "§6" + level + "✫"; 
/* 402 */     if (level >= 60 && level < 70)
/* 403 */       return "§5" + level + "✹"; 
/* 404 */     if (level >= 70 && level < 80)
/* 405 */       return "§2" + level + "✦"; 
/* 406 */     if (level >= 80 && level < 90)
/* 407 */       return "§1" + level + "✵"; 
/* 408 */     if (level >= 90 && level < 100) {
/* 409 */       return "§c" + level + "✱";
/*     */     }
/* 411 */     return "§4" + level + "♥";
/*     */   }
/*     */   
/*     */   public int getMaxPoints(int level) {
/* 415 */     return 500 * level / 9 + ((level % 9 == 9) ? 0 : 500);
/*     */   }
/*     */   
/*     */   public String createProgressBar(char character, char has, char need, int amount, double current, double max) {
/* 419 */     StringBuilder bar = new StringBuilder();
/* 420 */     double percentage = current / max;
/* 421 */     double count = amount * percentage;
/*     */     
/* 423 */     if (count > 0.0D) {
/* 424 */       bar.append("§" + has);
/*     */       
/* 426 */       for (int a = 0; a < count; a++) {
/* 427 */         bar.append(character);
/*     */       }
/*     */     } 
/* 430 */     if (amount - count > 0.0D) {
/* 431 */       bar.append("§" + need);
/*     */       
/* 433 */       for (int a = 0; a < amount - count; a++) {
/* 434 */         bar.append(character);
/*     */       }
/*     */     } 
/* 437 */     return bar.toString();
/*     */   }
/*     */   
/*     */   public String createProgressBar(char character, char need, int amount, double current, double max) {
/* 441 */     return createProgressBar(character, 'a', need, amount, current, max);
/*     */   }
/*     */   
/*     */   public String createProgressBar(char character, int amount, double current, double max) {
/* 445 */     return createProgressBar(character, 'a', 'c', amount, current, max);
/*     */   }
/*     */   
/*     */   public <T> MetadataValue createMeta(T object) {
/* 449 */     return (MetadataValue)new FixedMetadataValue((Plugin)this, object);
/*     */   }
/*     */   
/*     */   public static Optional<Player> getPlayer(UUID uniqueId) {
/* 453 */     Player player = Bukkit.getPlayer(uniqueId);
/* 454 */     return (player == null) ? Optional.<Player>empty() : Optional.<Player>of(player);
/*     */   }
/*     */   
/*     */   public static Optional<Player> getPlayer(String playerName, boolean exact) {
/* 458 */     Player player = exact ? Bukkit.getPlayer(playerName) : Bukkit.getPlayerExact(playerName);
/* 459 */     return (player == null) ? Optional.<Player>empty() : Optional.<Player>of(player);
/*     */   }
/*     */   
/*     */   public enum ChatState
/*     */   {
/* 464 */     DISABLED, PAYMENT, YOUTUBER, ENABLED;
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/BukkitCommon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */