/*    */ package net.highmc.bukkit.menu.staff.server;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import net.highmc.server.loadbalancer.server.ProxiedServer;
/*    */ 
/*    */ public enum ServerOrdenator
/*    */   implements Comparator<ProxiedServer>
/*    */ {
/*  9 */   ALPHABETIC
/*    */   {
/*    */     public int compare(ProxiedServer o1, ProxiedServer o2)
/*    */     {
/* 13 */       return o1.getServerId().compareTo(o2.getServerId());
/*    */     }
/*    */   },
/*    */   
/* 17 */   ONLINE_TIME
/*    */   {
/*    */     public int compare(ProxiedServer o1, ProxiedServer o2)
/*    */     {
/* 21 */       return Long.compare(o1.getStartTime(), o2.getStartTime());
/*    */     }
/*    */   },
/*    */   
/* 25 */   TYPE
/*    */   {
/*    */     public int compare(ProxiedServer o1, ProxiedServer o2)
/*    */     {
/* 29 */       return Integer.compare(o1.getServerType().ordinal(), o2.getServerType().ordinal());
/*    */     }
/*    */   };
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/menu/staff/server/ServerOrdenator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */