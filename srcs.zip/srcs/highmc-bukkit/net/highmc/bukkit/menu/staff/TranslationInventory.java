/*    */ package net.highmc.bukkit.menu.staff;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.stream.Collectors;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*    */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*    */ import net.highmc.bukkit.utils.menu.MenuItem;
/*    */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*    */ import net.highmc.language.Language;
/*    */ import net.highmc.member.Member;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class TranslationInventory {
/* 20 */   private int itemsPerPage = 21;
/*    */ 
/*    */   
/*    */   public TranslationInventory(Player player, Language language, int page) {
/* 24 */     MenuInventory menuInventory = new MenuInventory(Member.getLanguage(player.getUniqueId()).t("staff.inventory-translation", new String[] { "%page%", page + "", "%language%", language.getLanguageName() }), 5);
/*    */     
/* 26 */     List<MenuItem> items = new ArrayList<>();
/*    */     
/* 28 */     for (Map.Entry<String, String> skin : (Iterable<Map.Entry<String, String>>)((Map)CommonPlugin.getInstance().getPluginInfo().getLanguageMap().get(language))
/* 29 */       .entrySet().stream().sorted((o1, o2) -> ((String)o1.getKey()).compareTo((String)o2.getKey()))
/* 30 */       .collect(Collectors.toList())) {
/* 31 */       items.add(new MenuItem((new ItemBuilder()).name("§a" + (String)skin.getKey())
/* 32 */             .lore("\n§7" + (String)skin.getValue() + "\n§a\n§aClique para alterar.").type(Material.PAPER).build(), (p, inv, type, stack, s) -> {
/*    */               p.closeInventory();
/*    */               
/*    */               p.sendMessage("teste");
/*    */             }));
/*    */     } 
/*    */     
/* 39 */     int pageStart = 0;
/* 40 */     int pageEnd = this.itemsPerPage;
/*    */     
/* 42 */     if (page > 1) {
/* 43 */       pageStart = (page - 1) * this.itemsPerPage;
/* 44 */       pageEnd = page * this.itemsPerPage;
/*    */     } 
/*    */     
/* 47 */     if (pageEnd > items.size()) {
/* 48 */       pageEnd = items.size();
/*    */     }
/*    */     
/* 51 */     int w = 10;
/*    */     
/* 53 */     for (int i = pageStart; i < pageEnd; i++) {
/* 54 */       MenuItem item = items.get(i);
/* 55 */       menuInventory.setItem(item, w);
/*    */       
/* 57 */       if (w % 9 == 7) {
/* 58 */         w += 3;
/*    */       }
/*    */       else {
/*    */         
/* 62 */         w++;
/*    */       } 
/*    */     } 
/* 65 */     if (page == 1) {
/* 66 */       menuInventory.setItem(39, (new ItemBuilder()).name("§a§%back%§").type(Material.ARROW).build(), (p, inv, type, stack, slot) -> new LanguageInventory(player));
/*    */     } else {
/*    */       
/* 69 */       menuInventory
/* 70 */         .setItem(new MenuItem((new ItemBuilder())
/* 71 */             .type(Material.ARROW).name("§a§%page%§ " + (page - 1)).build(), (p, inv, type, stack, s) -> new TranslationInventory(player, language, page - 1)), 39);
/*    */     } 
/*    */ 
/*    */     
/* 75 */     if (Math.ceil((items.size() / this.itemsPerPage)) + 1.0D > page) {
/* 76 */       menuInventory.setItem(new MenuItem((new ItemBuilder())
/* 77 */             .type(Material.ARROW).name("§a§%page%§ " + (page + 1)).build(), (p, inventory, clickType, item, slot) -> new TranslationInventory(player, language, page + 1)), 41);
/*    */     }
/*    */ 
/*    */ 
/*    */     
/* 82 */     menuInventory.open(player);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/menu/staff/TranslationInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */