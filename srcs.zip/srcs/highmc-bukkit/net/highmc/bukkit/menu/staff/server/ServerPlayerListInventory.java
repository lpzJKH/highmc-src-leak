/*     */ package net.highmc.bukkit.menu.staff.server;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*     */ import net.highmc.bukkit.utils.menu.MenuItem;
/*     */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.server.loadbalancer.server.ProxiedServer;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ public class ServerPlayerListInventory
/*     */   extends MenuInventory
/*     */ {
/*     */   public ServerPlayerListInventory(Player player, ProxiedServer server, int page, MenuInventory backInventory) {
/*  23 */     super("§7Lista de jogadores", 5);
/*  24 */     List<PlayerInfo> items = new ArrayList<>();
/*     */     
/*  26 */     for (UUID playerId : server.getPlayers()) {
/*  27 */       items.add(new PlayerInfo(playerId, CommonPlugin.getInstance().getMemberManager().getMember(playerId)));
/*     */     }
/*     */     
/*  30 */     int pageStart = 0;
/*  31 */     int pageEnd = 21;
/*     */     
/*  33 */     if (page > 1) {
/*  34 */       pageStart = (page - 1) * 21;
/*  35 */       pageEnd = page * 21;
/*     */     } 
/*     */     
/*  38 */     if (pageEnd > items.size()) {
/*  39 */       pageEnd = items.size();
/*     */     }
/*     */     
/*  42 */     int w = 10;
/*     */     
/*  44 */     for (int i = pageStart; i < pageEnd; i++) {
/*  45 */       PlayerInfo playerInfo = items.get(i);
/*     */       
/*  47 */       playerInfo.setSlot(w);
/*  48 */       setItem(w, createItem(playerInfo));
/*     */       
/*  50 */       if (w % 9 == 7) {
/*  51 */         w += 3;
/*     */       }
/*     */       else {
/*     */         
/*  55 */         w++;
/*     */       } 
/*     */     } 
/*  58 */     if (page == 1) {
/*  59 */       setItem(new MenuItem((new ItemBuilder()).type(Material.ARROW).name("§aVoltar").build(), (p, inv, type, stack, s) -> backInventory.open(p)), 39);
/*     */     } else {
/*     */       
/*  62 */       setItem(new MenuItem((new ItemBuilder()).type(Material.ARROW).name("§a§%page%§ " + (page - 1)).build(), (p, inv, type, stack, s) -> new ServerPlayerListInventory(player, server, page - 1, backInventory)), 39);
/*     */     } 
/*     */ 
/*     */     
/*  66 */     if (Math.ceil((items.size() / 21)) + 1.0D > page) {
/*  67 */       setItem(new MenuItem((new ItemBuilder()).type(Material.ARROW).name("§a§%page%§ " + (page + 1)).build(), (p, inventory, clickType, item, slot) -> new ServerPlayerListInventory(player, server, page + 1, backInventory)), 41);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/*  72 */       removeItem(41);
/*     */     } 
/*  74 */     open(player);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ItemStack createItem(PlayerInfo playerInfo) {
/*  81 */     ItemBuilder itemBuilder = (new ItemBuilder()).name((playerInfo.getMember() == null) ? ("§e" + playerInfo.getPlayerId()) : ("§a" + playerInfo.getMember().getName())).type(Material.SKULL_ITEM).durability(3);
/*     */     
/*  83 */     if (playerInfo.getMember() != null) {
/*  84 */       itemBuilder.skin(playerInfo.getMember().getName());
/*     */     }
/*  86 */     return itemBuilder.build();
/*     */   }
/*     */   public class PlayerInfo {
/*     */     private UUID playerId;
/*     */     private Member member;
/*     */     
/*  92 */     public UUID getPlayerId() { return this.playerId; } private int slot; private boolean has; public Member getMember() {
/*  93 */       return this.member;
/*     */     }
/*  95 */     public int getSlot() { return this.slot; } public boolean isHas() {
/*  96 */       return this.has;
/*     */     }
/*     */     public PlayerInfo(UUID playerId, Member member) {
/*  99 */       this.playerId = playerId;
/* 100 */       this.member = member;
/*     */     }
/*     */     
/*     */     public void setSlot(int slot) {
/* 104 */       this.slot = slot;
/* 105 */       this.has = true;
/*     */     }
/*     */     
/*     */     public void load() {
/* 109 */       if (this.has)
/* 110 */         ServerPlayerListInventory.this.setItem(this.slot, ServerPlayerListInventory.this.createItem(this)); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/menu/staff/server/ServerPlayerListInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */