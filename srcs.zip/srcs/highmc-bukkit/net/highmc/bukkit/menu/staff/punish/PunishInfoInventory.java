/*    */ package net.highmc.bukkit.menu.staff.punish;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*    */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*    */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*    */ import net.highmc.member.Member;
/*    */ import net.highmc.punish.PunishType;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class PunishInfoInventory extends MenuInventory {
/*    */   public PunishInfoInventory(Player player, Member target) {
/* 16 */     super("§7Punições " + target.getName(), 3);
/*    */     
/* 18 */     setItem(10, (new ItemBuilder()).name("§a" + target.getName())
/* 19 */         .lore("§7Total de punições: §a" + target
/* 20 */           .getPunishConfiguration().getPunishMap().values().stream().mapToInt(List::size).sum())
/* 21 */         .type(Material.SKULL_ITEM).durability(3).skin(target.getName()).build());
/* 22 */     setItem(11, (new ItemBuilder())
/* 23 */         .name("§aTodos os banimentos").lore("§7Clique para Listar banimentos")
/* 24 */         .type(Material.BOOK).build(), (p, inv, type, stack, slot) -> new PunishInfoListInventory(player, target, PunishType.BAN, 1, this));
/*    */     
/* 26 */     setItem(12, (new ItemBuilder())
/* 27 */         .name("§aTodos os mutes").lore("§7Clique para Listar mutes").type(Material.BOOK)
/* 28 */         .build(), (p, inv, type, stack, slot) -> new PunishInfoListInventory(player, target, PunishType.MUTE, 1, this));
/*    */     
/* 30 */     setItem(13, (new ItemBuilder())
/* 31 */         .name("§aTodos os kicks").lore("§7Clique para Listar kicks").type(Material.BOOK)
/* 32 */         .build(), (p, inv, type, stack, slot) -> new PunishInfoListInventory(player, target, PunishType.KICK, 1, this));
/*    */     
/* 34 */     open(player);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/menu/staff/punish/PunishInfoInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */