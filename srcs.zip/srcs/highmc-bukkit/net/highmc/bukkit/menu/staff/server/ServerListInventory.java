/*     */ package net.highmc.bukkit.menu.staff.server;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*     */ import net.highmc.bukkit.utils.menu.MenuItem;
/*     */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.server.loadbalancer.server.ProxiedServer;
/*     */ import net.highmc.utils.DateUtils;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerListInventory
/*     */   extends MenuInventory
/*     */ {
/*     */   private Player player;
/*     */   private int page;
/*  27 */   private List<ProxiedServer> serverList = new ArrayList<>();
/*     */   
/*     */   private boolean loading;
/*  30 */   private ServerOrdenator ordenator = ServerOrdenator.ALPHABETIC;
/*     */   
/*     */   private boolean asc;
/*     */   private long wait;
/*     */   
/*     */   public ServerListInventory(Player player, int page) {
/*  36 */     super("§7Lista de servidores", 5);
/*     */     
/*  38 */     this.player = player;
/*  39 */     this.page = page;
/*     */     
/*  41 */     if (!BukkitCommon.getInstance().isServerLog()) {
/*  42 */       this.loading = true;
/*     */     }
/*     */     
/*  45 */     handleItems();
/*  46 */     open(player);
/*     */   }
/*     */   
/*     */   private void handleItems() {
/*  50 */     if (this.loading) {
/*  51 */       setItem(13, (new ItemBuilder()).name("§aCarregando...").type(Material.BARRIER)
/*  52 */           .lore("§7Estamos carregando as informações do servidores, aguarde...").build());
/*     */       
/*     */       return;
/*     */     } 
/*  56 */     removeItem(13);
/*     */     
/*  58 */     List<MenuItem> items = new ArrayList<>();
/*     */     
/*  60 */     for (ProxiedServer server : getServerList().stream()
/*  61 */       .sorted((o1, o2) -> this.ordenator.compare(o1, o2) * (this.asc ? 1 : -1)).collect(Collectors.toList())) {
/*  62 */       items.add(new MenuItem((new ItemBuilder())
/*  63 */             .name("§a" + server.getServerId()).type(Material.BOOK).lore(new String[] { "", "§fTipo: §7" + server
/*  64 */                 .getServerType().name(), "", "§fPlayers: §7" + server
/*  65 */                 .getOnlinePlayers(), "§fMáximo de players: §7" + server
/*  66 */                 .getPlayersRecord(), "§fPing médio: §70ms", "§fLigado há: §7" + 
/*  67 */                 DateUtils.formatDifference(Language.getLanguage(this.player.getUniqueId()), (
/*  68 */                   System.currentTimeMillis() - server.getStartTime()) / 1000L), "", "§aClique para executar ações."
/*  69 */               }).build(), (p, inv, type, stack, slot) -> new ServerInfoInventory(this.player, server, this)));
/*     */     } 
/*     */ 
/*     */     
/*  73 */     int pageStart = 0;
/*  74 */     int pageEnd = 21;
/*     */     
/*  76 */     if (this.page > 1) {
/*  77 */       pageStart = (this.page - 1) * 21;
/*  78 */       pageEnd = this.page * 21;
/*     */     } 
/*     */     
/*  81 */     if (pageEnd > items.size()) {
/*  82 */       pageEnd = items.size();
/*     */     }
/*     */     
/*  85 */     int w = 10;
/*     */     
/*  87 */     for (int i = pageStart; i < pageEnd; i++) {
/*  88 */       MenuItem item = items.get(i);
/*  89 */       setItem(item, w);
/*     */       
/*  91 */       if (w % 9 == 7) {
/*  92 */         w += 3;
/*     */       }
/*     */       else {
/*     */         
/*  96 */         w++;
/*     */       } 
/*     */     } 
/*  99 */     setItem(40, (new ItemBuilder())
/*     */         
/* 101 */         .name("§a§%server.order." + this.ordenator.name().toLowerCase().replace("_", "-") + "-name%§")
/* 102 */         .type(Material.ITEM_FRAME)
/* 103 */         .lore(new String[] { "§7§%server.order." + this.ordenator.name().toLowerCase().replace("_", "-") + "-description%§", this.asc ? "§7Ordem crescente." : "§7Ordem decrescente."
/*     */           
/* 105 */           }).build(), (p, inv, type, stack, s) -> {
/*     */           if (this.wait > System.currentTimeMillis()) {
/*     */             p.sendMessage("§cAguarde para mudar a ordenação novamente.");
/*     */ 
/*     */             
/*     */             return;
/*     */           } 
/*     */ 
/*     */           
/*     */           this.wait = System.currentTimeMillis() + 500L;
/*     */           
/*     */           if (type == ClickType.RIGHT || type == ClickType.SHIFT) {
/*     */             this.asc = !this.asc;
/*     */           } else {
/*     */             this.ordenator = ServerOrdenator.values()[(this.ordenator.ordinal() == (ServerOrdenator.values()).length - 1) ? 0 : (this.ordenator.ordinal() + 1)];
/*     */           } 
/*     */           
/*     */           handleItems();
/*     */         });
/*     */     
/* 125 */     if (this.page == 1) {
/* 126 */       removeItem(39);
/*     */     } else {
/* 128 */       setItem(new MenuItem((new ItemBuilder()).type(Material.ARROW).name("§a§%page%§ " + (this.page - 1)).build(), (p, inv, type, stack, s) -> { this.page--; handleItems(); }), 39);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     if (Math.ceil((items.size() / 21)) + 1.0D > this.page) {
/* 135 */       setItem(new MenuItem((new ItemBuilder()).type(Material.ARROW).name("§a§%page%§ " + (this.page + 1)).build(), (p, inventory, clickType, item, slot) -> { this.page++; handleItems(); }), 41);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 141 */       removeItem(41);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Collection<ProxiedServer> getServerList() {
/* 146 */     return BukkitCommon.getInstance().isServerLog() ? 
/* 147 */       BukkitCommon.getInstance().getServerManager().getActiveServers().values() : this.serverList;
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/menu/staff/server/ServerListInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */