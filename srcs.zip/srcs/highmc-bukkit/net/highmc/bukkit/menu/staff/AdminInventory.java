/*     */ package net.highmc.bukkit.menu.staff;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*     */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*     */ import net.highmc.bukkit.utils.menu.click.MenuClickHandler;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.member.configuration.MemberConfiguration;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ public class AdminInventory {
/*     */   public AdminInventory(Player player) {
/*  17 */     this(player, 0L);
/*     */   }
/*     */   
/*     */   public AdminInventory(Player player, long wait) {
/*  21 */     MenuInventory menuInventory = new MenuInventory("§7Admin Config", 4);
/*  22 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId());
/*     */ 
/*     */     
/*  25 */     MenuClickHandler handler = (p, inv, type, stack, s) -> {
/*     */         if (wait > System.currentTimeMillis()) {
/*     */           player.sendMessage("§cAguarde para alterar outra configuração.");
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/*     */         int code = member.getMemberConfiguration().getAdminModeJoin();
/*     */         if (code == 2) {
/*     */           code = 0;
/*     */         } else {
/*     */           code++;
/*     */         } 
/*     */         member.getMemberConfiguration().setAdminModeJoin(code);
/*     */         new AdminInventory(player, System.currentTimeMillis() + 500L);
/*     */         p.updateInventory();
/*     */       };
/*  42 */     String color = (member.getMemberConfiguration().getAdminModeJoin() == 0) ? "§c" : ((member.getMemberConfiguration().getAdminModeJoin() == 1) ? "§a" : "§e");
/*     */     
/*  44 */     menuInventory.setItem(10, (new ItemBuilder()).name(color + "Entrar no admin").type(Material.PAPER).lore("§7Entre automaticamente no modo admin ao entrar no servidor.").build(), handler);
/*  45 */     menuInventory.setItem(19, (new ItemBuilder()).name(color + "Entrar no admin").type(Material.INK_SACK).durability((member.getMemberConfiguration().getAdminModeJoin() == 0) ? 8 : ((member.getMemberConfiguration().getAdminModeJoin() == 1) ? 10 : 11)).lore((member.getMemberConfiguration().getAdminModeJoin() == 0) ? "§7Clique para ativar" : ((member.getMemberConfiguration().getAdminModeJoin() == 1) ? "§7Clique para mudar para o modo alternado" : "§7Clique para desativar")).build(), handler);
/*     */ 
/*     */     
/*  48 */     create(player, "Items do admin", "Remover items ao entrar no modo admin.", Material.PAPER, Boolean.valueOf(member.getMemberConfiguration().isAdminRemoveItems()), 11, menuInventory, (p, inv, type, stack, s) -> {
/*     */           if (wait > System.currentTimeMillis()) {
/*     */             player.sendMessage("§cAguarde para alterar outra configuração.");
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/*     */           member.getMemberConfiguration().setAdminRemoveItems(!member.getMemberConfiguration().isAdminRemoveItems());
/*     */           new AdminInventory(player, System.currentTimeMillis() + 500L);
/*     */         });
/*  58 */     create(player, "Staffchat", "Visualizar mensagens do staffchat.", Material.PAPER, Boolean.valueOf(member.getMemberConfiguration().isSeeingStaffChat()), 12, menuInventory, (p, inv, type, stack, s) -> {
/*     */           if (wait > System.currentTimeMillis()) {
/*     */             player.sendMessage("§cAguarde para alterar outra configuração.");
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/*     */           member.getMemberConfiguration().setSeeingStaffChat(!member.getMemberConfiguration().isSeeingStaffChat());
/*     */           new AdminInventory(player, System.currentTimeMillis() + 500L);
/*     */         });
/*  68 */     create(player, "Stafflog", "Visualizar as logs da staff e monitorar o que estão fazendo no servidor", Material.PAPER, Boolean.valueOf(member.getMemberConfiguration().isSeeingLogs()), 13, menuInventory, (p, inv, type, stack, s) -> {
/*     */           if (wait > System.currentTimeMillis()) {
/*     */             player.sendMessage("§cAguarde para alterar outra configuração.");
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/*     */           member.getMemberConfiguration().setSeeingLogs(!member.getMemberConfiguration().isSeeingLogs());
/*     */           new AdminInventory(player, System.currentTimeMillis() + 500L);
/*     */         });
/*  78 */     create(player, "Espectadores", "Ver os espectadores das partidas", Material.PAPER, Boolean.valueOf(member.getMemberConfiguration().isSpectatorsEnabled()), 14, menuInventory, (p, inv, type, stack, s) -> {
/*     */           if (wait > System.currentTimeMillis()) {
/*     */             player.sendMessage("§cAguarde para alterar outra configuração.");
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/*     */           member.getMemberConfiguration().setSpectatorsEnabled(!member.getMemberConfiguration().isSpectatorsEnabled());
/*     */           BukkitCommon.getInstance().getVanishManager().updateVanishToPlayer(p);
/*     */           new AdminInventory(player, System.currentTimeMillis() + 500L);
/*     */         });
/*  89 */     create(player, "Reports", "Receba um aviso no chat sempre que um report for feito", Material.PAPER, Boolean.valueOf(member.getMemberConfiguration().isReportsEnabled()), 15, menuInventory, (p, inv, type, stack, s) -> {
/*     */           if (wait > System.currentTimeMillis()) {
/*     */             player.sendMessage("§cAguarde para alterar outra configuração.");
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/*     */           member.getMemberConfiguration().setReportsEnabled(!member.getMemberConfiguration().isReportsEnabled());
/*     */           new AdminInventory(player, System.currentTimeMillis() + 500L);
/*     */         });
/*  99 */     create(player, "Anticheat", "Receba um aviso no chat sempre que um report for feito", Material.PAPER, Boolean.valueOf(member.getMemberConfiguration().isAnticheatEnabled()), 16, menuInventory, (p, inv, type, stack, s) -> {
/*     */           if (wait > System.currentTimeMillis()) {
/*     */             player.sendMessage("§cAguarde para alterar outra configuração.");
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/*     */           member.getMemberConfiguration().setCheatState(member.getMemberConfiguration().isAnticheatEnabled() ? MemberConfiguration.CheatState.DISABLED : MemberConfiguration.CheatState.ENABLED);
/*     */           new AdminInventory(player, System.currentTimeMillis() + 500L);
/*     */         });
/* 109 */     menuInventory.open(player);
/*     */   }
/*     */   
/*     */   public void create(Player player, String name, String description, Material material, Boolean active, int slot, MenuInventory menuInventory, MenuClickHandler handler) {
/* 113 */     menuInventory.setItem(slot, (new ItemBuilder()).name((active.booleanValue() ? "§a" : "§c") + name).type(material).lore("§7" + description).build(), handler);
/* 114 */     menuInventory.setItem(slot + 9, (new ItemBuilder()).name((active.booleanValue() ? "§a" : "§c") + name).type(Material.INK_SACK).durability(active.booleanValue() ? 10 : 8).lore(active.booleanValue() ? "§7Clique para desativar." : "§7Clique para ativar.").build(), handler);
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/menu/staff/AdminInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */