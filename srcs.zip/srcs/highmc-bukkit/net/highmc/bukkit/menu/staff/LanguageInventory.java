/*    */ package net.highmc.bukkit.menu.staff;
/*    */ 
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.bukkit.utils.helper.SkullHelper;
/*    */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*    */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*    */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*    */ import net.highmc.bukkit.utils.menu.click.MenuClickHandler;
/*    */ import net.highmc.language.Language;
/*    */ import net.highmc.member.Member;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ public class LanguageInventory
/*    */ {
/*    */   public LanguageInventory(final Player player) {
/* 20 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId());
/* 21 */     MenuInventory menuInventory = new MenuInventory("§7§%staff.inventory-language%§", 3);
/*    */     
/* 23 */     for (int i = 1; i <= (Language.values()).length; i++) {
/* 24 */       final Language language = Language.values()[i - 1];
/* 25 */       menuInventory.setItem(9 + i, (new ItemBuilder())
/* 26 */           .type(Material.SKULL_ITEM).durability(3).skin(SkullHelper.getLanguageSkin(language), "")
/* 27 */           .name("§a" + language.getLanguageName())
/* 28 */           .lore("§7" + member
/* 29 */             .getLanguage()
/* 30 */             .t("staff.inventory-language-" + language.name().toLowerCase() + "-description", new String[0]) + "\n\n§e" + member
/*    */             
/* 32 */             .getLanguage().t("staff.inventory-language-click-to-modify", new String[0]))
/* 33 */           .build(), new MenuClickHandler()
/*    */           {
/*    */             
/*    */             public void onClick(Player p, Inventory inv, ClickType type, ItemStack stack, int slot)
/*    */             {
/* 38 */               new TranslationInventory(player, language, 1);
/*    */             }
/*    */           });
/*    */     } 
/*    */     
/* 43 */     menuInventory.open(player);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/menu/staff/LanguageInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */