/*     */ package net.highmc.bukkit.menu.staff.punish;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import net.highmc.CommonConst;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*     */ import net.highmc.bukkit.utils.menu.MenuItem;
/*     */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.punish.Punish;
/*     */ import net.highmc.punish.PunishType;
/*     */ import net.highmc.utils.DateUtils;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PunishInfoListInventory
/*     */   extends MenuInventory
/*     */ {
/*     */   private Player player;
/*     */   private Member target;
/*     */   private PunishType punishType;
/*     */   private int page;
/*  30 */   private PunishOrdenator ordenator = PunishOrdenator.ALPHABETIC;
/*     */   
/*     */   private boolean asc = true;
/*     */   
/*     */   private long wait;
/*     */   private MenuInventory backInventory;
/*     */   
/*     */   public PunishInfoListInventory(Player player, Member target, PunishType punishType, int page, MenuInventory backInventory) {
/*  38 */     super("§7Listando " + punishType.name().toLowerCase() + "s", 5);
/*  39 */     this.player = player;
/*  40 */     this.target = target;
/*  41 */     this.punishType = punishType;
/*  42 */     this.page = page;
/*  43 */     this.backInventory = backInventory;
/*  44 */     handleItems();
/*  45 */     open(player);
/*     */   }
/*     */   
/*     */   private void handleItems() {
/*  49 */     List<MenuItem> items = new ArrayList<>();
/*     */ 
/*     */     
/*  52 */     for (Punish punish : this.target.getPunishConfiguration().getPunish(this.punishType).stream().sorted((o1, o2) -> this.ordenator.compare(o1, o2) * (this.asc ? 1 : -1)).collect(Collectors.toList())) {
/*  53 */       items.add(new MenuItem((new ItemBuilder()).name("§a" + punish.getPunisherName()).lore("§fAutor: §7" + punish
/*  54 */               .getPunisherName() + "\n§fMotivo: §7" + punish.getPunishReason() + "\n§fCriado às: §7" + CommonConst.DATE_FORMAT
/*  55 */               .format(Long.valueOf(punish.getCreatedAt())) + "\n" + (
/*  56 */               (punish.getPunishType() == PunishType.KICK) ? "" : (
/*  57 */               punish.isPermanent() ? "§cEssa punição não tem prazo de expiração." : ("§fExpira em: §7" + 
/*  58 */               DateUtils.formatDifference(
/*  59 */                 Language.getLanguage(this.player.getUniqueId()), punish.getExpireAt() / 1000L)))))
/*  60 */             .type(Material.SKULL_ITEM).durability(3).skin(punish.getPunisherName()).build(), (p, inv, type, stack, s) -> p.sendMessage("§eEm breve opções de interação.")));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     int pageStart = 0;
/*  67 */     int pageEnd = 21;
/*     */     
/*  69 */     if (this.page > 1) {
/*  70 */       pageStart = (this.page - 1) * 21;
/*  71 */       pageEnd = this.page * 21;
/*     */     } 
/*     */     
/*  74 */     if (pageEnd > items.size()) {
/*  75 */       pageEnd = items.size();
/*     */     }
/*     */     
/*  78 */     int w = 10;
/*     */     
/*  80 */     for (int i = pageStart; i < pageEnd; i++) {
/*  81 */       MenuItem item = items.get(i);
/*  82 */       setItem(item, w);
/*     */       
/*  84 */       if (w % 9 == 7) {
/*  85 */         w += 3;
/*     */       }
/*     */       else {
/*     */         
/*  89 */         w++;
/*     */       } 
/*     */     } 
/*  92 */     setItem(40, (new ItemBuilder())
/*     */         
/*  94 */         .name("§a§%punish.order." + this.ordenator.name().toLowerCase().replace("_", "-") + "-name%§")
/*  95 */         .type(Material.ITEM_FRAME)
/*  96 */         .lore(new String[] { "§7§%punish.order." + this.ordenator.name().toLowerCase().replace("_", "-") + "-description%§", this.asc ? "§7Ordem crescente." : "§7Ordem decrescente."
/*     */           
/*  98 */           }).build(), (p, inv, type, stack, s) -> {
/*     */           if (this.wait > System.currentTimeMillis()) {
/*     */             p.sendMessage("§cAguarde para mudar a ordenação novamente.");
/*     */ 
/*     */             
/*     */             return;
/*     */           } 
/*     */ 
/*     */           
/*     */           this.wait = System.currentTimeMillis() + 500L;
/*     */           
/*     */           if (type == ClickType.RIGHT || type == ClickType.SHIFT) {
/*     */             this.asc = !this.asc;
/*     */           } else {
/*     */             this.ordenator = PunishOrdenator.values()[(this.ordenator.ordinal() == (PunishOrdenator.values()).length - 1) ? 0 : (this.ordenator.ordinal() + 1)];
/*     */           } 
/*     */           
/*     */           handleItems();
/*     */         });
/*     */     
/* 118 */     if (this.page == 1) {
/* 119 */       if (this.backInventory == null) {
/* 120 */         removeItem(39);
/*     */       } else {
/* 122 */         setItem(new MenuItem((new ItemBuilder())
/* 123 */               .type(Material.ARROW).name("§a§%back%§")
/* 124 */               .lore("§7Voltar para " + this.backInventory.getTitle()).build(), (p, inv, type, stack, s) -> this.backInventory.open(p)), 39);
/*     */       } 
/*     */     } else {
/* 127 */       setItem(new MenuItem((new ItemBuilder()).type(Material.ARROW).name("§a§%page%§ " + (this.page - 1)).build(), (p, inv, type, stack, s) -> { this.page--; handleItems(); }), 39);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     if (Math.ceil((items.size() / 21)) + 1.0D > this.page) {
/* 134 */       setItem(new MenuItem((new ItemBuilder()).type(Material.ARROW).name("§a§%page%§ " + (this.page + 1)).build(), (p, inventory, clickType, item, slot) -> { this.page++; handleItems(); }), 41);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 140 */       removeItem(41);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/menu/staff/punish/PunishInfoListInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */