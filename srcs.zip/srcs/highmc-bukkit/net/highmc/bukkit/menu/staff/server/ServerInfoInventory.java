/*    */ package net.highmc.bukkit.menu.staff.server;
/*    */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*    */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*    */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*    */ import net.highmc.server.loadbalancer.server.ProxiedServer;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class ServerInfoInventory extends MenuInventory {
/*    */   public ServerInfoInventory(Player player, ProxiedServer server, MenuInventory backInventory) {
/* 13 */     super("§7" + server.getServerId(), 3);
/*    */     
/* 15 */     setItem(10, (new ItemBuilder()).name("§a" + server.getServerId()).type(Material.BOOK).build());
/* 16 */     setItem(11, (new ItemBuilder()).name("§aAlterar detalhes").type(Material.PAPER).build(), (p, inv, type, stack, slot) -> new ServerDetailsInventory(player, server, this));
/*    */     
/* 18 */     setItem(12, (new ItemBuilder()).name("§aExecutar ação").type(Material.IRON_CHESTPLATE).build(), (p, inv, type, stack, slot) -> new ServerActionsInventory(player, server, this));
/*    */     
/* 20 */     setItem(13, (new ItemBuilder()).name("§aListar jogadores").type(Material.NAME_TAG).build(), (p, inv, type, stack, slot) -> new ServerPlayerListInventory(player, server, 1, this));
/*    */ 
/*    */     
/* 23 */     setItem(16, (new ItemBuilder()).name("§aVoltar").lore("§7Voltar para " + backInventory.getTitle())
/* 24 */         .type(Material.ARROW).build(), (p, inv, type, stack, slot) -> backInventory.open(player));
/*    */     
/* 26 */     open(player);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/menu/staff/server/ServerInfoInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */