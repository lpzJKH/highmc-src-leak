/*    */ package net.highmc.bukkit.menu.staff.punish;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import net.highmc.punish.Punish;
/*    */ 
/*    */ public enum PunishOrdenator
/*    */   implements Comparator<Punish>
/*    */ {
/*  9 */   ALPHABETIC
/*    */   {
/*    */     public int compare(Punish o1, Punish o2)
/*    */     {
/* 13 */       return o1.getPlayerName().compareTo(o2.getPlayerName());
/*    */     }
/*    */   },
/*    */   
/* 17 */   EXPIRE_TIME
/*    */   {
/*    */     public int compare(Punish o1, Punish o2)
/*    */     {
/* 21 */       return Long.compare(o1.getExpireAt(), o2.getExpireAt()) * -1;
/*    */     }
/*    */   },
/*    */   
/* 25 */   CREATION_TIME
/*    */   {
/*    */     public int compare(Punish o1, Punish o2)
/*    */     {
/* 29 */       return Long.compare(o1.getCreatedAt(), o2.getCreatedAt());
/*    */     }
/*    */   };
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/menu/staff/punish/PunishOrdenator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */