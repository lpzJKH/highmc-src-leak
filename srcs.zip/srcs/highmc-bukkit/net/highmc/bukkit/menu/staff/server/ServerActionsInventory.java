/*    */ package net.highmc.bukkit.menu.staff.server;
/*    */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*    */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*    */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*    */ import net.highmc.server.loadbalancer.server.ProxiedServer;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class ServerActionsInventory extends MenuInventory {
/*    */   public ServerActionsInventory(Player player, ProxiedServer server, MenuInventory backInventory) {
/* 13 */     super(server.getServerId(), 6);
/*    */     
/* 15 */     setItem(10, (new ItemBuilder()).type(Material.PAPER).name("§aDesligar servidor.").build());
/* 16 */     setItem(11, (new ItemBuilder()).type(Material.PAPER).name("§aVerificar atualização.").build());
/* 17 */     setItem(12, (new ItemBuilder()).type(Material.PAPER)
/* 18 */         .name(server.isJoinEnabled() ? "§cDesativar jogadores." : "§aAtivar jogadores.").build());
/* 19 */     setItem(13, (new ItemBuilder()).type(Material.PAPER).name("§aExecutar comando.").build());
/* 20 */     setItem(14, (new ItemBuilder()).type(Material.PAPER).name("§aListar jogadores.").build());
/*    */     
/* 22 */     setItem(48, (new ItemBuilder())
/* 23 */         .name("§aVoltar").type(Material.ARROW)
/* 24 */         .lore("§7Voltar para " + backInventory.getTitle()).build(), (p, inv, type, stack, slot) -> backInventory.open(player));
/*    */ 
/*    */     
/* 27 */     open(player);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/menu/staff/server/ServerActionsInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */