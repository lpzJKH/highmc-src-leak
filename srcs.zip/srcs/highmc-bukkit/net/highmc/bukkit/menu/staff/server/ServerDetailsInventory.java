/*    */ package net.highmc.bukkit.menu.staff.server;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.bukkit.BukkitCommon;
/*    */ import net.highmc.bukkit.manager.ChatManager;
/*    */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*    */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*    */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*    */ import net.highmc.server.loadbalancer.server.ProxiedServer;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class ServerDetailsInventory extends MenuInventory {
/*    */   public ServerDetailsInventory(final Player player, final ProxiedServer server, final MenuInventory backInventory) {
/* 16 */     super("§7Detalhes", 3);
/*    */     
/* 18 */     setItem(10, (new ItemBuilder()).name("§a" + server.getServerId()).type(Material.BOOK).build());
/* 19 */     setItem(11, (new ItemBuilder()).name("§eAlterar nome").lore("§7Clique para alterar o nome do servidor.")
/* 20 */         .type(Material.BOOK).build(), (p, inv, type, stack, slot) -> {
/*    */           p.closeInventory();
/*    */ 
/*    */ 
/*    */           
/*    */           BukkitCommon.getInstance().getChatManager().loadChat((CommandSender)CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId()), new ChatManager.Callback()
/*    */               {
/*    */                 public void callback(boolean cancel, String... asks)
/*    */                 {
/* 29 */                   if (cancel) {
/* 30 */                     ServerDetailsInventory.this.open(player);
/*    */                   } else {
/* 32 */                     player.sendMessage("§aNome do servidor alterado de " + server.getServerId() + " para " + asks[0] + ".");
/*    */                     
/* 34 */                     new ServerDetailsInventory(player, server, backInventory);
/*    */                   } 
/*    */                 }
/*    */               }new String[] { "§aDigite o novo nome do servidor para altera-ló." });
/*    */         });
/*    */     
/* 40 */     setItem(12, (new ItemBuilder()).name("§eAlterar tipo").lore("§7Clique para alterar o tipo do servidor.")
/* 41 */         .type(Material.BOOK).build(), (p, inv, type, stack, slot) -> {
/*    */           player.sendMessage("§aO tipo do servidor foi alterado para " + server.getServerType().name() + ".");
/*    */           
/*    */           new ServerDetailsInventory(player, server, backInventory);
/*    */         });
/* 46 */     setItem(16, (new ItemBuilder())
/* 47 */         .name("§aVoltar").type(Material.ARROW)
/* 48 */         .lore("§7Voltar para " + backInventory.getTitle()).build(), (p, inv, type, stack, slot) -> backInventory.open(player));
/*    */ 
/*    */     
/* 51 */     open(player);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/menu/staff/server/ServerDetailsInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */