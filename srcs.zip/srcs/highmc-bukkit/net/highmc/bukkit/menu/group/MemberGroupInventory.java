/*    */ package net.highmc.bukkit.menu.group;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*    */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*    */ import net.highmc.bukkit.utils.menu.MenuItem;
/*    */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*    */ import net.highmc.member.Member;
/*    */ import net.highmc.permission.Group;
/*    */ import net.highmc.utils.string.StringFormat;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class MemberGroupInventory {
/*    */   public MemberGroupInventory(Player player, Member target, Group group, List<MenuItem> items, int page) {
/* 18 */     MenuInventory menuInventory = new MenuInventory("§7" + target.getName(), 3);
/*    */     
/* 20 */     menuInventory.setItem(10, (new ItemBuilder()).name("§a" + target.getName()).type(Material.SKULL_ITEM)
/* 21 */         .durability(3).skin(target.getName()).build());
/* 22 */     menuInventory.setItem(11, (new ItemBuilder()).name("§eTodos os grupos")
/* 23 */         .lore("§7Clique para ver todos os grupos desse jogador.").type(Material.PAPER).build());
/* 24 */     menuInventory.setItem(12, (new ItemBuilder()).name("§eTodos os grupos")
/* 25 */         .lore("§7Clique para ver todas as permissões desse jogador.").type(Material.BOOK).build());
/*    */     
/* 27 */     if (group.isDefaultGroup()) {
/* 28 */       menuInventory.setItem(15, (new ItemBuilder())
/* 29 */           .name("§cRemover " + StringFormat.formatString(group.getGroupName()))
/* 30 */           .lore("§7Remova o grupo da conta desse jogador.").type(Material.BARRIER).build(), (p, inv, type, stack, slot) -> p.sendMessage("§cO grupo não pode ser removido!"));
/*    */     } else {
/*    */       
/* 33 */       menuInventory.setItem(15, (new ItemBuilder())
/* 34 */           .name("§cRemover " + StringFormat.formatString(group.getGroupName()))
/* 35 */           .lore("§7Remova o grupo da conta desse jogador.").type(Material.BARRIER).build(), (p, inv, type, stack, slot) -> p.sendMessage("§cUse /group " + target.getName() + " remove " + group.getGroupName() + " para remover esse cargo."));
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 40 */     menuInventory.setItem(16, (new ItemBuilder()).name("§7Voltar").type(Material.ARROW).build(), (p, inv, type, stack, slot) -> new MemberGroupListInventory(player, group, items, page));
/*    */ 
/*    */     
/* 43 */     menuInventory.open(player);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/menu/group/MemberGroupInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */