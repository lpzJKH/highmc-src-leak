/*     */ package net.highmc.bukkit.menu.group;
/*     */ 
/*     */ import java.util.AbstractMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Collectors;
/*     */ import net.highmc.CommonConst;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*     */ import net.highmc.bukkit.utils.menu.MenuItem;
/*     */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.permission.Group;
/*     */ import net.highmc.permission.GroupInfo;
/*     */ import net.highmc.utils.DateUtils;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ public class MemberGroupListInventory
/*     */ {
/*     */   private Player player;
/*     */   private Group group;
/*     */   private List<MenuItem> items;
/*  28 */   private int page = 1;
/*     */   
/*     */   public MemberGroupListInventory(Player player, Group group, List<Member> memberList) {
/*  31 */     this.player = player;
/*  32 */     this.group = group;
/*     */     
/*  34 */     boolean skipMember = (group != CommonPlugin.getInstance().getPluginInfo().getDefaultGroup());
/*     */     
/*  36 */     this
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  71 */       .items = (List<MenuItem>)memberList.stream().sorted((o1, o2) -> o1.getPlayerName().compareTo(o2.getPlayerName())).map(member -> { ItemBuilder itemBuilder = (new ItemBuilder()).name(member.getDefaultTag().getRealPrefix() + member.getPlayerName()).type(Material.SKULL_ITEM).durability(3).skin(member.getName()).lore(""); for (Map.Entry<Group, GroupInfo> entry : (Iterable<Map.Entry<Group, GroupInfo>>)member.getGroups().entrySet().stream().map(()).sorted(()).collect(Collectors.toList())) { if (skipMember && entry.getKey() == CommonPlugin.getInstance().getPluginInfo().getDefaultGroup()) continue;  itemBuilder.lore(new String[] { "§7Grupo: " + CommonPlugin.getInstance().getPluginInfo().getTagByName(((Group)entry.getKey()).getGroupName()).getTagPrefix(), "§7Desde de: §f" + CommonConst.DATE_FORMAT.format(Long.valueOf(((GroupInfo)entry.getValue()).getGivenDate())), "§7Autor: §f" + ((GroupInfo)entry.getValue()).getAuthorName() }); if (!((GroupInfo)entry.getValue()).isPermanent()) if (((GroupInfo)entry.getValue()).hasExpired()) { itemBuilder.lore("§cO cargo expirou."); } else { itemBuilder.lore("§7Expira em: §f" + DateUtils.getTime(Language.getLanguage(player.getUniqueId()), ((GroupInfo)entry.getValue()).getExpireTime())); }   itemBuilder.lore(""); }  return new MenuItem(itemBuilder.build(), ()); }).collect(Collectors.toList());
/*  72 */     create();
/*     */   }
/*     */   
/*     */   public MemberGroupListInventory(Player player, Group group, List<MenuItem> items, int page) {
/*  76 */     this.player = player;
/*  77 */     this.group = group;
/*  78 */     this.items = items;
/*  79 */     this.page = page;
/*  80 */     create();
/*     */   }
/*     */ 
/*     */   
/*     */   public void create() {
/*  85 */     MenuInventory menuInventory = new MenuInventory("§7Listando " + this.group.getGroupName() + " (" + this.items.size() + ")", 5);
/*     */     
/*  87 */     int pageStart = 0;
/*  88 */     int pageEnd = 21;
/*     */     
/*  90 */     if (this.page > 1) {
/*  91 */       pageStart = (this.page - 1) * 21;
/*  92 */       pageEnd = this.page * 21;
/*     */     } 
/*     */     
/*  95 */     if (pageEnd > this.items.size()) {
/*  96 */       pageEnd = this.items.size();
/*     */     }
/*     */     
/*  99 */     int w = 10;
/*     */     
/* 101 */     for (int i = pageStart; i < pageEnd; i++) {
/* 102 */       MenuItem item = this.items.get(i);
/* 103 */       menuInventory.setItem(item, w);
/*     */       
/* 105 */       if (w % 9 == 7) {
/* 106 */         w += 3;
/*     */       }
/*     */       else {
/*     */         
/* 110 */         w++;
/*     */       } 
/*     */     } 
/* 113 */     if (this.page != 1) {
/* 114 */       menuInventory.setItem(new MenuItem((new ItemBuilder())
/* 115 */             .type(Material.ARROW).name("§a§%page%§ " + (this.page - 1)).build(), (p, inv, type, stack, s) -> new MemberGroupListInventory(this.player, this.group, this.items, this.page - 1)), 39);
/*     */     }
/*     */ 
/*     */     
/* 119 */     if (Math.ceil((this.items.size() / 21)) + 1.0D > this.page) {
/* 120 */       menuInventory.setItem(new MenuItem((new ItemBuilder())
/* 121 */             .type(Material.ARROW).name("§a§%page%§ " + (this.page + 1)).build(), (p, inventory, clickType, item, slot) -> new MemberGroupListInventory(this.player, this.group, this.items, this.page + 1)), 41);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 127 */     menuInventory.open(this.player);
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/menu/group/MemberGroupListInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */