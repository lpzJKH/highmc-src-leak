/*    */ package net.highmc.bukkit.menu;
/*    */ 
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.bukkit.utils.helper.SkullHelper;
/*    */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*    */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*    */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*    */ import net.highmc.bukkit.utils.menu.click.MenuClickHandler;
/*    */ import net.highmc.language.Language;
/*    */ import net.highmc.member.Member;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ public class LanguageInventory
/*    */ {
/*    */   public LanguageInventory(final Player player) {
/* 20 */     final Member member = CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId());
/* 21 */     MenuInventory menuInventory = new MenuInventory("§7§%inventory-language%§", 3);
/*    */     
/* 23 */     for (int i = 1; i <= (Language.values()).length; i++) {
/* 24 */       final Language language = Language.values()[i - 1];
/*    */       
/* 26 */       if (language == Language.PORTUGUESE || player.hasPermission("command.language")) {
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 31 */         ItemBuilder itemBuilder = (new ItemBuilder()).type(Material.SKULL_ITEM).durability(3).skin(SkullHelper.getLanguageSkin(language), "").name("§a" + language.getLanguageName()).lore("§7" + language.t("inventory-language-" + language.name().toLowerCase() + "-description", new String[0]) + "\n\n§e" + language
/* 32 */             .t("inventory-language-click-to-change", new String[0]));
/*    */         
/* 34 */         if (member.getLanguage() == language) {
/* 35 */           itemBuilder.glow();
/*    */         }
/* 37 */         menuInventory.setItem(9 + i, itemBuilder.build(), new MenuClickHandler()
/*    */             {
/*    */               public void onClick(Player p, Inventory inv, ClickType type, ItemStack stack, int slot)
/*    */               {
/* 41 */                 if (member.getLanguage() == language) {
/* 42 */                   player.sendMessage(language
/* 43 */                       .t("inventory-language-already", new String[] { "%language%", this.val$language.getLanguageName() }));
/*    */                   
/*    */                   return;
/*    */                 } 
/* 47 */                 member.setLanguage(language);
/* 48 */                 member.sendMessage(language
/* 49 */                     .t("inventory-language-changed", new String[] { "%language%", this.val$language.getLanguageName() }));
/* 50 */                 new LanguageInventory(player);
/*    */               }
/*    */             });
/*    */       } 
/*    */     } 
/* 55 */     menuInventory.open(player);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/menu/LanguageInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */