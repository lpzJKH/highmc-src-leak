/*    */ package net.highmc.bukkit.menu.profile;
/*    */ 
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*    */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*    */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*    */ import net.highmc.bukkit.utils.menu.click.MenuClickHandler;
/*    */ import net.highmc.member.Member;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class PreferencesInventory
/*    */ {
/*    */   public PreferencesInventory(Player player, int page, long wait) {
/* 17 */     MenuInventory menuInventory = new MenuInventory("§7§%inventory-preferences%§", 4);
/* 18 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId());
/*    */     
/* 20 */     create(player, "Bate-papo", "Receber mensagens no bate-papo do servidor", Material.PAPER, 
/* 21 */         Boolean.valueOf(member.getMemberConfiguration().isSeeingChat()), 11, menuInventory, (p, inv, type, stack, s) -> {
/*    */           if (wait > System.currentTimeMillis()) {
/*    */             if (this.message) {
/*    */               return;
/*    */             }
/*    */             
/*    */             this.message = true;
/*    */             
/*    */             member.sendMessage("§cVocê precisa esperar para mudar uma configuração.");
/*    */             
/*    */             return;
/*    */           } 
/*    */           member.getMemberConfiguration().setSeeingChat(!member.getMemberConfiguration().isSeeingChat());
/*    */           new PreferencesInventory(player, page, System.currentTimeMillis() + 500L);
/*    */         });
/* 36 */     create(player, "Conversa privada", "Receber mensagens privadas no servidor", Material.PAPER, 
/* 37 */         Boolean.valueOf(member.getMemberConfiguration().isTellEnabled()), 12, menuInventory, (p, inv, type, stack, s) -> {
/*    */           if (wait > System.currentTimeMillis()) {
/*    */             if (this.message) {
/*    */               return;
/*    */             }
/*    */             
/*    */             this.message = true;
/*    */             
/*    */             member.sendMessage("§cVocê precisa esperar para mudar uma configuração.");
/*    */             return;
/*    */           } 
/*    */           member.getMemberConfiguration().setTellEnabled(!member.getMemberConfiguration().isTellEnabled());
/*    */           new PreferencesInventory(player, page, System.currentTimeMillis() + 500L);
/*    */         });
/* 51 */     create(player, "Convite de party", "Receber convites para party", Material.PAPER, 
/* 52 */         Boolean.valueOf(member.getMemberConfiguration().isPartyInvites()), 13, menuInventory, (p, inv, type, stack, s) -> {
/*    */           if (wait > System.currentTimeMillis()) {
/*    */             if (this.message) {
/*    */               return;
/*    */             }
/*    */             
/*    */             this.message = true;
/*    */             
/*    */             member.sendMessage("§cVocê precisa esperar para mudar uma configuração.");
/*    */             return;
/*    */           } 
/*    */           member.getMemberConfiguration().setPartyInvites(!member.getMemberConfiguration().isPartyInvites());
/*    */           new PreferencesInventory(player, page, System.currentTimeMillis() + 500L);
/*    */         });
/* 66 */     menuInventory.open(player);
/* 67 */     player.updateInventory();
/*    */   }
/*    */   private boolean message = false;
/*    */   public PreferencesInventory(Player player) {
/* 71 */     new PreferencesInventory(player, 1, -1L);
/*    */   }
/*    */ 
/*    */   
/*    */   public void create(Player player, String name, String description, Material material, Boolean active, int slot, MenuInventory menuInventory, MenuClickHandler handler) {
/* 76 */     menuInventory.setItem(slot, (new ItemBuilder())
/* 77 */         .name((active.booleanValue() ? "§a" : "§c") + name).type(material).lore("§7" + description).build(), handler);
/*    */     
/* 79 */     menuInventory.setItem(slot + 9, (new ItemBuilder())
/* 80 */         .name((active.booleanValue() ? "§a" : "§c") + name).type(Material.INK_SACK)
/* 81 */         .durability(active.booleanValue() ? 10 : 8).lore(active.booleanValue() ? "§7Clique para desativar." : "§7Clique para ativar.")
/* 82 */         .build(), handler);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/menu/profile/PreferencesInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */