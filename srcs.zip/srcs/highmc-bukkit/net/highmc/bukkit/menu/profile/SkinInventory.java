/*     */ package net.highmc.bukkit.menu.profile;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.highmc.CommonConst;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*     */ import net.highmc.bukkit.utils.menu.MenuItem;
/*     */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*     */ import net.highmc.bukkit.utils.player.PlayerAPI;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.packet.Packet;
/*     */ import net.highmc.packet.types.skin.SkinChange;
/*     */ import net.highmc.utils.skin.Skin;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SkinInventory
/*     */ {
/*     */   private static final int ITEMS_PER_PAGE = 21;
/*  27 */   private static final List<SkinModel> SKIN_LIST = Arrays.asList(new SkinModel[] { from("yandv"), from("yukiritoFLAME", "yukirito"), 
/*  28 */         from("Budokkan"), from("ClonexD"), from("NeoxGamer_"), from("AnjooGaming"), from("Kotcka"), from("Console") });
/*     */   
/*     */   public SkinInventory(Player player) {
/*  31 */     this(player, InventoryType.PRINCIPAL, 1);
/*     */   }
/*     */   
/*     */   public SkinInventory(Player player, InventoryType type, int page) {
/*  35 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId());
/*  36 */     MenuInventory menuInventory = new MenuInventory("§7Catálogo de skins", 5);
/*     */     
/*  38 */     if (type == InventoryType.PRINCIPAL) {
/*  39 */       menuInventory.setItem(13, (new ItemBuilder())
/*  40 */           .name("§a" + member.getSkin().getPlayerName()).type(Material.SKULL_ITEM)
/*  41 */           .lore(new String[] { "", "§7Fonte: §a" + (member.isCustomSkin() ? "Customizada" : "Padrão") }).durability(3)
/*  42 */           .skin(member.getPlayerName()).build());
/*  43 */       menuInventory.setItem(30, (new ItemBuilder())
/*  44 */           .name("§aCostumizar sua skin").type(Material.NAME_TAG)
/*  45 */           .lore(new String[] {
/*     */               "", "§7Escolha uma skin customizada", "§7baseada em um nickname.", "", "§cApenas para VIPs.", "", "§eClique para ver mais."
/*  47 */             }, ).build(), (p, inv, t, stack, slot) -> {
/*     */             p.closeInventory();
/*     */             
/*     */             p.performCommand("skin");
/*     */           });
/*  52 */       menuInventory.setItem(32, (new ItemBuilder())
/*  53 */           .name("§aBiblioteca").type(Material.BOOK)
/*  54 */           .lore(new String[] {
/*     */               "", "§7Confira o pacote de ", "§7skins padrão disponíveis", "§7de graça.", "", "§eClique para ver mais."
/*  56 */             }, ).build(), (p, inv, t, stack, slot) -> new SkinInventory(player, InventoryType.LIBRARY, 1));
/*     */ 
/*     */       
/*  59 */       menuInventory.setItem(40, (new ItemBuilder()).name("§aVoltar").type(Material.ARROW).build(), (p, inv, t, stack, slot) -> new ProfileInventory(player));
/*     */     } else {
/*     */       
/*  62 */       List<MenuItem> items = new ArrayList<>();
/*     */       
/*  64 */       for (SkinModel skinModel : SKIN_LIST) {
/*     */         
/*  66 */         ItemBuilder itemBuilder = (new ItemBuilder()).name("§a" + skinModel.getName()).type(Material.SKULL_ITEM).durability(3).lore("§eClique para selecionar.");
/*     */         
/*  68 */         if (skinModel.getSkin() != null && skinModel.getSkin().getValue() != null) {
/*  69 */           itemBuilder.skin(skinModel.getSkin().getValue(), (skinModel.getSkin().getSignature() == null) ? "" : skinModel.getSkin().getSignature());
/*     */         } else {
/*  71 */           itemBuilder.skin(skinModel.getSkin().getPlayerName());
/*     */         } 
/*  73 */         items.add(new MenuItem(itemBuilder.build(), (p, inv, t, stack, slot) -> {
/*     */                 player.closeInventory();
/*     */                 
/*     */                 PlayerAPI.changePlayerSkin(player, skinModel.getSkin().getValue(), skinModel.getSkin().getSignature(), true);
/*     */                 
/*     */                 member.setSkin(skinModel.getSkin(), true);
/*     */                 CommonPlugin.getInstance().getServerData().sendPacket((Packet)new SkinChange(p.getUniqueId(), member.getSkin()));
/*     */               }));
/*     */       } 
/*  82 */       int pageStart = 0;
/*  83 */       int pageEnd = 21;
/*     */       
/*  85 */       if (page > 1) {
/*  86 */         pageStart = (page - 1) * 21;
/*  87 */         pageEnd = page * 21;
/*     */       } 
/*     */       
/*  90 */       if (pageEnd > items.size()) {
/*  91 */         pageEnd = items.size();
/*     */       }
/*     */       
/*  94 */       int w = 10;
/*     */       
/*  96 */       for (int i = pageStart; i < pageEnd; i++) {
/*  97 */         MenuItem item = items.get(i);
/*  98 */         menuInventory.setItem(item, w);
/*     */         
/* 100 */         if (w % 9 == 7) {
/* 101 */           w += 3;
/*     */         }
/*     */         else {
/*     */           
/* 105 */           w++;
/*     */         } 
/*     */       } 
/* 108 */       if (page == 1) {
/* 109 */         menuInventory.setItem(new MenuItem((new ItemBuilder()).type(Material.ARROW).name("§aVoltar").build(), (p, inv, t, stack, s) -> new SkinInventory(player)), 39);
/*     */       } else {
/*     */         
/* 112 */         menuInventory.setItem(new MenuItem((new ItemBuilder())
/* 113 */               .type(Material.ARROW).name("§a§%page%§ " + (page - 1)).build(), (p, inv, t, stack, s) -> new SkinInventory(p, type, page - 1)), 39);
/*     */       } 
/*     */ 
/*     */       
/* 117 */       if (Math.ceil((items.size() / 21)) + 1.0D > page) {
/* 118 */         menuInventory.setItem(new MenuItem((new ItemBuilder())
/* 119 */               .type(Material.ARROW).name("§a§%page%§ " + (page + 1)).build(), (p, inv, t, stack, s) -> new SkinInventory(p, type, page + 1)), 41);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 125 */     menuInventory.open(player);
/*     */   }
/*     */   
/*     */   public enum InventoryType
/*     */   {
/* 130 */     PRINCIPAL, LIBRARY; }
/*     */   public static class SkinModel { private String name;
/*     */     
/*     */     public SkinModel(String name, Skin skin) {
/* 134 */       this.name = name; this.skin = skin;
/*     */     }
/*     */     private Skin skin;
/*     */     public String getName() {
/* 138 */       return this.name; } public Skin getSkin() {
/* 139 */       return this.skin;
/*     */     } }
/*     */ 
/*     */   
/*     */   public static SkinModel from(String name, String displayName) {
/* 144 */     return new SkinModel(displayName, CommonPlugin.getInstance().getSkinData().loadData(name)
/* 145 */         .orElse(new Skin(name, CommonConst.CONSOLE_ID, "", "")));
/*     */   }
/*     */   
/*     */   public static SkinModel from(String name) {
/* 149 */     return from(name, name);
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/menu/profile/SkinInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */