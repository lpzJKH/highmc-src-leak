/*     */ package net.highmc.bukkit.menu.profile;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.highmc.CommonConst;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.PluginInfo;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*     */ import net.highmc.bukkit.utils.menu.MenuItem;
/*     */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*     */ import net.highmc.command.CommandSender;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.punish.Punish;
/*     */ import net.highmc.punish.PunishType;
/*     */ import net.highmc.utils.DateUtils;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.inventory.InventoryType;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ public class PunishmentInventory {
/*     */   public PunishmentInventory(Player player) {
/*  25 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId());
/*     */     
/*  27 */     MenuInventory menuInventory = new MenuInventory(PluginInfo.t((CommandSender)member, "inventory.punishment.title", new String[] { "%player%", member.getPlayerName() }), InventoryType.HOPPER);
/*     */     
/*  29 */     menuInventory.setItem(0, (new ItemBuilder())
/*  30 */         .name("§%inventory.punishment.item.ban-name%§").type(Material.PAPER)
/*  31 */         .lore("§%inventory.punishment.item.ban-description%§").build(), (p, inv, type, stack, slot) -> new PunishmentInventory(player, PunishType.BAN, 1));
/*     */ 
/*     */     
/*  34 */     menuInventory.setItem(1, (new ItemBuilder())
/*  35 */         .name("§%inventory.punishment.item.mute-name%§").type(Material.PAPER)
/*  36 */         .lore("§%inventory.punishment.item.mute-description%§").build(), (p, inv, type, stack, slot) -> new PunishmentInventory(player, PunishType.MUTE, 1));
/*     */ 
/*     */     
/*  39 */     menuInventory.setItem(2, (new ItemBuilder())
/*  40 */         .name("§%inventory.punishment.item.kick-name%§").type(Material.PAPER)
/*  41 */         .lore("§%inventory.punishment.item.kick-description%§").build(), (p, inv, type, stack, slot) -> new PunishmentInventory(player, PunishType.KICK, 1));
/*     */ 
/*     */     
/*  44 */     menuInventory.setItem(4, (new ItemBuilder()).name("§a§%back%§").type(Material.ARROW).build(), (p, inv, type, stack, slot) -> new ProfileInventory(player));
/*     */ 
/*     */     
/*  47 */     menuInventory.open(player);
/*     */   }
/*     */   
/*     */   public PunishmentInventory(Player player, Punish punish, int page) {
/*  51 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId());
/*     */     
/*  53 */     MenuInventory menuInventory = new MenuInventory(PluginInfo.t((CommandSender)member, "inventory.punishment.title", new String[] { "%player%", member.getPlayerName() }), 3);
/*     */     
/*  55 */     menuInventory.setItem(10, (new ItemBuilder()).name("§a" + punish.getId())
/*  56 */         .lore(CommonConst.GSON_PRETTY.toJson(punish)).type(Material.PAPER).build());
/*     */     
/*  58 */     menuInventory.setItem(11, (new ItemBuilder()).name(PluginInfo.t((CommandSender)member, "inventory.punishment.item.reason-name"))
/*  59 */         .lore(PluginInfo.t((CommandSender)member, "inventory.punishment.item.reason-description", new String[] { "%reason%", punish.getPunishReason()
/*  60 */             })).type(Material.PAPER).build());
/*     */     
/*  62 */     menuInventory.setItem(12, (new ItemBuilder())
/*  63 */         .name(PluginInfo.t((CommandSender)member, "inventory.punishment.item.date-name"))
/*  64 */         .lore(PluginInfo.t((CommandSender)member, "inventory.punishment.item.date-description", new String[] {
/*  65 */               "%createAt%", CommonConst.DATE_FORMAT.format(Long.valueOf(punish.getCreatedAt())), "%expireAt%", 
/*  66 */               punish.isPermanent() ? "Never" : CommonConst.DATE_FORMAT.format(Long.valueOf(punish.getExpireAt())), "%duration%", 
/*     */               
/*  68 */               punish.isPermanent() ? "Permanent" : 
/*  69 */               DateUtils.getTime(member.getLanguage(), punish.getExpireAt())
/*  70 */             })).type(Material.WATCH).build());
/*     */     
/*  72 */     if (punish.isUnpunished() || punish.hasExpired()) {
/*  73 */       menuInventory.setItem(13, (new ItemBuilder()).name("§aOK").type(Material.BARRIER).build());
/*     */     }
/*  75 */     menuInventory.setItem(16, (new ItemBuilder()).name("§a§%back%§").type(Material.ARROW).build(), (p, inv, type, stack, slot) -> new PunishmentInventory(player, punish.getPunishType(), page));
/*     */ 
/*     */     
/*  78 */     menuInventory.open(player);
/*     */   }
/*     */   
/*     */   public PunishmentInventory(Player player, PunishType punishType, int page) {
/*  82 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId());
/*     */     
/*  84 */     MenuInventory menuInventory = new MenuInventory(PluginInfo.t((CommandSender)member, "inventory.punishment.title", new String[] { "%player%", member.getPlayerName() }), 5);
/*     */     
/*  86 */     List<MenuItem> items = new ArrayList<>();
/*     */     
/*  88 */     for (Punish punish : member.getPunishConfiguration().getPunish(punishType)) {
/*  89 */       items.add(new MenuItem((new ItemBuilder())
/*  90 */             .name(PluginInfo.t((CommandSender)member, "inventory.punishment.item.info-name", new String[] { "%id%", punish.getId().replace("#", "")
/*  91 */                 })).lore(PluginInfo.t((CommandSender)member, "inventory.punishment.item.info-description", new String[] { 
/*  92 */                   "%punisher%", punish.getPunisherName(), "%reason%", punish.getPunishReason(), "%createAt%", CommonConst.DATE_FORMAT
/*  93 */                   .format(Long.valueOf(punish.getCreatedAt())), "%expireAt%", 
/*  94 */                   punish.isPermanent() ? "Never" : CommonConst.DATE_FORMAT.format(Long.valueOf(punish.getExpireAt())), "%duration%", 
/*     */                   
/*  96 */                   punish.isPermanent() ? "Permanent" : 
/*  97 */                   DateUtils.getTime(member.getLanguage(), punish.getExpireAt()), "%id%", punish
/*  98 */                   .getId().replace("#", "")
/*     */                 
/* 100 */                 }) + (punish.isUnpunished() ? "§%inventory.punishment.item.info-description-pardoned%§" : (
/* 101 */               punish.hasExpired() ? "§%inventory.punishment.item.info-description-expired%§" : "")))
/*     */             
/* 103 */             .type(Material.PAPER).build(), (p, inv, type, stack, s) -> new PunishmentInventory(player, punish, page)));
/*     */     } 
/*     */ 
/*     */     
/* 107 */     int itemsPerPage = 21;
/* 108 */     int pageStart = 0;
/* 109 */     int pageEnd = itemsPerPage;
/*     */     
/* 111 */     if (page > 1) {
/* 112 */       pageStart = (page - 1) * itemsPerPage;
/* 113 */       pageEnd = page * itemsPerPage;
/*     */     } 
/*     */     
/* 116 */     if (pageEnd > items.size()) {
/* 117 */       pageEnd = items.size();
/*     */     }
/*     */     
/* 120 */     int w = 10;
/*     */     
/* 122 */     for (int i = pageStart; i < pageEnd; i++) {
/* 123 */       MenuItem item = items.get(i);
/* 124 */       menuInventory.setItem(item, w);
/*     */       
/* 126 */       if (w % 9 == 7) {
/* 127 */         w += 3;
/*     */       }
/*     */       else {
/*     */         
/* 131 */         w++;
/*     */       } 
/*     */     } 
/* 134 */     if (page == 1) {
/* 135 */       menuInventory.setItem(39, (new ItemBuilder()).name("§a§%back%§").type(Material.ARROW).build(), (p, inv, type, stack, slot) -> new PunishmentInventory(player));
/*     */     } else {
/*     */       
/* 138 */       menuInventory.setItem(new MenuItem((new ItemBuilder())
/* 139 */             .type(Material.ARROW).name("§a§%page%§ " + (page - 1)).build(), (p, inv, type, stack, s) -> new PunishmentInventory(player, punishType, page - 1)), 39);
/*     */     } 
/*     */ 
/*     */     
/* 143 */     if (Math.ceil((items.size() / itemsPerPage)) + 1.0D > page) {
/* 144 */       menuInventory.setItem(new MenuItem((new ItemBuilder())
/* 145 */             .type(Material.ARROW).name("§a§%page%§ " + (page + 1)).build(), (p, inventory, clickType, item, slot) -> new PunishmentInventory(player, punishType, page + 1)), 41);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 150 */     menuInventory.open(player);
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/menu/profile/PunishmentInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */