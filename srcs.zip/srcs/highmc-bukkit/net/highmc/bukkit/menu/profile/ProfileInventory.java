/*    */ package net.highmc.bukkit.menu.profile;
/*    */ 
/*    */ import java.util.Date;
/*    */ import net.highmc.CommonConst;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.bukkit.menu.LanguageInventory;
/*    */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*    */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*    */ import net.highmc.bukkit.utils.menu.MenuUpdateHandler;
/*    */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*    */ import net.highmc.language.Language;
/*    */ import net.highmc.member.Member;
/*    */ import net.highmc.utils.DateUtils;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class ProfileInventory
/*    */ {
/*    */   public ProfileInventory(Player player) {
/* 22 */     final Member member = CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId());
/*    */     
/* 24 */     MenuInventory menuInventory = new MenuInventory(member.getLanguage().t("inventory-profile", new String[] { "%player%", member.getPlayerName() }), 5);
/*    */     
/* 26 */     updateProfileItem(menuInventory, member);
/*    */     
/* 28 */     menuInventory.setItem(29, (new ItemBuilder())
/* 29 */         .name("§a§%inventory-profile-your-stats%§")
/* 30 */         .lore("§7§%inventory-profile-your-stats-description%§").type(Material.PAPER).build(), (p, inv, type, stack, slot) -> new StatisticsInventory(player, null));
/*    */ 
/*    */     
/* 33 */     menuInventory.setItem(30, (new ItemBuilder())
/* 34 */         .name("§a§%inventory-profile-your-medals%§")
/* 35 */         .lore("§7§%inventory-profile-your-medals-description%§").type(Material.NAME_TAG).build(), (p, inv, type, stack, slot) -> {
/*    */           p.closeInventory();
/*    */           
/*    */           p.performCommand("medals");
/*    */         });
/*    */     
/* 41 */     menuInventory.setItem(31, (new ItemBuilder())
/* 42 */         .name("§a§%inventory-profile-select-language%§")
/* 43 */         .lore("§7§%inventory-profile-select-language-description%§").type(Material.SKULL_ITEM)
/* 44 */         .durability(3).skin("e3RleHR1cmVzOntTS0lOOnt1cmw6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMTc5ZTIyNDhiZDc5OGViNjFmOTdhZWVlY2MyYWZkZGViYWQ1MmJmNDA1MmM3MjYxYjYxODBhNDU3N2Y4NjkzYSJ9fX0==", "").build(), (p, inv, type, stack, slot) -> new LanguageInventory(player));
/*    */ 
/*    */     
/* 47 */     menuInventory.setItem(32, (new ItemBuilder()).name("§a§%inventory-profile-preferences%§")
/* 48 */         .lore("§7§%inventory-profile-preferences-description%§").type(Material.REDSTONE_COMPARATOR).build(), (p, inv, type, stack, slot) -> new PreferencesInventory(player));
/*    */ 
/*    */     
/* 51 */     menuInventory.setItem(33, (new ItemBuilder())
/* 52 */         .name("§a§%inventory-profile-skin%§")
/* 53 */         .lore("§7§%inventory-profile-skin-description%§").type(Material.ITEM_FRAME).build(), (p, inv, type, stack, slot) -> new SkinInventory(player));
/*    */ 
/*    */     
/* 56 */     menuInventory.setUpdateHandler(new MenuUpdateHandler()
/*    */         {
/*    */           public void onUpdate(Player player, MenuInventory menu)
/*    */           {
/* 60 */             if (menu.hasItem(13)) {
/* 61 */               ProfileInventory.this.updateProfileItem(menu, member);
/*    */             }
/*    */           }
/*    */         });
/* 65 */     menuInventory.open(player);
/*    */   }
/*    */   
/*    */   private void updateProfileItem(MenuInventory menuInventory, Member member) {
/* 69 */     Language language = member.getLanguage();
/* 70 */     if (member.isOnline()) {
/* 71 */       menuInventory.setItem(13, (new ItemBuilder()).name("§a" + member.getPlayerName()).type(Material.SKULL_ITEM)
/* 72 */           .lore(new String[] {
/*    */               
/* 74 */               "", "§7§%inventory-profile-first-login%§: §f" + CommonConst.DATE_FORMAT.format(new Date(member.getFirstLogin())), "§7§%inventory-profile-last-login%§: §f" + CommonConst.DATE_FORMAT
/*    */               
/* 76 */               .format(new Date(member.getLastLogin())), "§7§%inventory-profile-total-logged-time%§: §f" + 
/*    */               
/* 78 */               DateUtils.formatDifference(language, member.getOnlineTime() / 1000L), "§7§%inventory-profile-actual-logged-time%§: §f" + 
/*    */               
/* 80 */               DateUtils.formatDifference(language, member.getSessionTime() / 1000L), "", "§a§%inventory-profile-user-online%§"
/*    */             
/* 82 */             }).durability(3).skin(member.getPlayerName()).build());
/*    */     } else {
/* 84 */       menuInventory.setItem(13, (new ItemBuilder())
/* 85 */           .name("§a" + member.getPlayerName()).type(Material.SKULL_ITEM)
/* 86 */           .lore(new String[] {
/*    */               
/* 88 */               "", "§7§%inventory-profile-first-login%§: §f" + CommonConst.DATE_FORMAT.format(new Date(member.getFirstLogin())), "§7§%inventory-profile-last-login%§: §f" + CommonConst.DATE_FORMAT
/*    */               
/* 90 */               .format(new Date(member.getLastLogin())), "§7§%inventory-profile-total-logged-time%§: §f" + 
/*    */               
/* 92 */               DateUtils.formatDifference(language, member.getOnlineTime() / 1000L)
/* 93 */             }).durability(3).skin(member.getPlayerName()).build());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/menu/profile/ProfileInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */