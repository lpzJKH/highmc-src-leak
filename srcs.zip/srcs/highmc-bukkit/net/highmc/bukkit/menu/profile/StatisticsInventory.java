/*     */ package net.highmc.bukkit.menu.profile;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*     */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*     */ import net.highmc.member.status.Status;
/*     */ import net.highmc.member.status.StatusType;
/*     */ import net.highmc.member.status.types.BedwarsCategory;
/*     */ import net.highmc.server.ServerType;
/*     */ import net.highmc.utils.string.StringFormat;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ public class StatisticsInventory {
/*     */   public StatisticsInventory(Player player, StatusType statusType) {
/*  21 */     MenuInventory menuInventory = new MenuInventory("§7Suas estatísticas", 3);
/*     */     
/*  23 */     if (statusType == null) {
/*     */       
/*  25 */       menuInventory
/*  26 */         .setItem(10, (new ItemBuilder())
/*  27 */           .type(Material.BED).name("§aBedwars")
/*  28 */           .lore("§7Suas estatísticas no Bedwars.").build(), (p, inv, t, stack, s) -> new StatisticsInventory(player, StatusType.BEDWARS));
/*     */ 
/*     */       
/*  31 */       menuInventory.setItem(11, (new ItemBuilder())
/*  32 */           .type(Material.IRON_CHESTPLATE).name("§aPvP")
/*  33 */           .lore("§7Suas estatísticas no PvP.").build(), (p, inv, t, stack, s) -> new StatisticsInventory(player, StatusType.PVP));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  47 */       menuInventory.setItem(22, (new ItemBuilder())
/*  48 */           .type(Material.ARROW).name("§a§%back%§").lore("§7Para Suas estatísticas").build(), (p, inv, type, stack, slot) -> new ProfileInventory(player));
/*     */     } else {
/*     */       int w;
/*  51 */       Status status = CommonPlugin.getInstance().getStatusManager().loadStatus(player.getUniqueId(), statusType);
/*     */       
/*  53 */       switch (statusType) {
/*     */         case BEDWARS:
/*  55 */           menuInventory.setRows(5);
/*  56 */           menuInventory
/*  57 */             .setItem(4, (new ItemBuilder())
/*     */               
/*  59 */               .name("§aBedwars Geral").type(Material.PAPER).lore(new String[] { "§fNível: §7" + 
/*  60 */                   BukkitCommon.getInstance().getColorByLevel(status
/*  61 */                     .getInteger((Enum)BedwarsCategory.BEDWARS_LEVEL)), "", "§fPartidas: §7" + status
/*  62 */                   .getInteger((Enum)BedwarsCategory.BEDWARS_MATCH), "", "§fCamas quebradas: §7" + status
/*     */ 
/*     */                   
/*  65 */                   .getInteger((Enum)BedwarsCategory.BEDWARS_BED_BREAK), "§fCamas perdidas: §7" + status
/*     */                   
/*  67 */                   .getInteger((Enum)BedwarsCategory.BEDWARS_BED_BROKEN), "", "§fKills: §7" + status
/*  68 */                   .getInteger((Enum)BedwarsCategory.BEDWARS_KILLS), "§fKills finais: §7" + status
/*     */                   
/*  70 */                   .getInteger((Enum)BedwarsCategory.BEDWARS_FINAL_KILLS), "§fMortes: §7" + status
/*  71 */                   .getInteger((Enum)BedwarsCategory.BEDWARS_DEATHS), "§fMortes finais: §7" + status
/*     */                   
/*  73 */                   .getInteger((Enum)BedwarsCategory.BEDWARS_FINAL_DEATHS), "", "§fWins: §7" + status
/*  74 */                   .getInteger((Enum)BedwarsCategory.BEDWARS_WINS), "§fWinstreak: §7" + status
/*     */                   
/*  76 */                   .getInteger((Enum)BedwarsCategory.BEDWARS_WINSTREAK), "§fDerrotas: §7" + status
/*  77 */                   .getInteger((Enum)BedwarsCategory.BEDWARS_LOSES)
/*  78 */                 }).build());
/*     */           
/*  80 */           w = 10;
/*     */           
/*  82 */           for (ServerType serverType : Arrays.<ServerType>asList(ServerType.values())) {
/*  83 */             if (!serverType.name().contains("BW") || serverType.isLobby()) {
/*     */               continue;
/*     */             }
/*  86 */             menuInventory.setItem(w, (new ItemBuilder())
/*  87 */                 .type(Material.BED)
/*  88 */                 .name("§aBedwars " + StringFormat.formatString(serverType.name().split("_")[1]))
/*  89 */                 .lore(new String[] { 
/*  90 */                     "§fPartidas: §7" + status.getInteger(BedwarsCategory.BEDWARS_MATCH.getSpecialServer(serverType)), "", "§fCamas quebradas: §7" + status
/*  91 */                     .getInteger(BedwarsCategory.BEDWARS_BED_BREAK
/*  92 */                       .getSpecialServer(serverType)), "§fCamas perdidas: §7" + status
/*  93 */                     .getInteger(BedwarsCategory.BEDWARS_BED_BROKEN
/*  94 */                       .getSpecialServer(serverType)), "", "§fKills: §7" + status
/*     */                     
/*  96 */                     .getInteger(BedwarsCategory.BEDWARS_KILLS
/*  97 */                       .getSpecialServer(serverType)), "§fKills finais: §7" + status
/*  98 */                     .getInteger(BedwarsCategory.BEDWARS_FINAL_KILLS
/*  99 */                       .getSpecialServer(serverType)), "§fMortes: §7" + status
/* 100 */                     .getInteger(BedwarsCategory.BEDWARS_DEATHS
/* 101 */                       .getSpecialServer(serverType)), "§fMortes finais: §7" + status
/* 102 */                     .getInteger(BedwarsCategory.BEDWARS_FINAL_DEATHS
/* 103 */                       .getSpecialServer(serverType)), "",
/*     */                     
/* 105 */                     "§fWins: §7" + status.getInteger(BedwarsCategory.BEDWARS_WINS
/* 106 */                       .getSpecialServer(serverType)), "§fWinstreak: §7" + status
/* 107 */                     .getInteger(BedwarsCategory.BEDWARS_WINSTREAK
/* 108 */                       .getSpecialServer(serverType)), "§fDerrotas: §7" + status
/* 109 */                     .getInteger(BedwarsCategory.BEDWARS_LOSES
/* 110 */                       .getSpecialServer(serverType))
/* 111 */                   }).build());
/*     */             
/* 113 */             if (w % 9 == 7) {
/* 114 */               w += 12;
/*     */               
/*     */               continue;
/*     */             } 
/* 118 */             w += 2;
/*     */           } 
/*     */           break;
/*     */         
/*     */         case PVP:
/* 123 */           menuInventory.setItem(10, (new ItemBuilder())
/* 124 */               .type(Material.PAPER).name("§aGeral")
/* 125 */               .lore(new String[] { "§fKills: §7" + status.getInteger("kills", 0), "§fDeaths: §7" + status
/* 126 */                   .getInteger("deaths", 0), "§fKillstreak: §7" + status
/* 127 */                   .getInteger("killstreak", 0), "§fKillstream máximo: §7" + status
/* 128 */                   .getInteger("killstreak-max", 0)
/* 129 */                 }).build());
/*     */           
/* 131 */           menuInventory.setItem(11, (new ItemBuilder()).type(Material.IRON_CHESTPLATE).name("§aArena")
/* 132 */               .lore(new String[] { "§fKills: §70", "§fDeaths: §70", "§fKillstreak: §70", "§fKillstream máximo: §70", ""
/* 133 */                 }).build());
/*     */           
/* 135 */           menuInventory.setItem(12, (new ItemBuilder()).type(Material.GLASS).name("§aFps")
/* 136 */               .lore(new String[] { "§fKills: §7" + status.getInteger("fps-kills", 0), "§fDeaths: §7" + status
/* 137 */                   .getInteger("fps-deaths", 0), "§fKillstreak: §7" + status
/* 138 */                   .getInteger("fps-killstreak", 0), "§fKillstream máximo: §7" + status
/* 139 */                   .getInteger("fps-killstreak-max", 0)
/* 140 */                 }).build());
/*     */           
/* 142 */           menuInventory.setItem(13, (new ItemBuilder()).type(Material.LAVA_BUCKET).name("§aLava").lore("").build());
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 150 */       menuInventory.setItem((menuInventory.getRows() - 1) * 9 + 4, (new ItemBuilder())
/* 151 */           .type(Material.ARROW).name("§a§%back%§").lore("§7Para Suas estatísticas").build(), (p, inv, type, stack, slot) -> new StatisticsInventory(player, null));
/*     */     } 
/*     */ 
/*     */     
/* 155 */     menuInventory.open(player);
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/menu/profile/StatisticsInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */