/*     */ package net.highmc.bukkit.menu.report;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*     */ import net.highmc.bukkit.utils.menu.MenuItem;
/*     */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*     */ import net.highmc.bukkit.utils.menu.confirm.ConfirmInventory;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.packet.Packet;
/*     */ import net.highmc.packet.types.staff.TeleportToTarget;
/*     */ import net.highmc.report.Report;
/*     */ import net.highmc.report.ReportInfo;
/*     */ import net.highmc.utils.DateUtils;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ public class ReportListInventory
/*     */   extends MenuInventory
/*     */ {
/*     */   private static final int ITEMS_PER_PAGE = 21;
/*     */   private Language language;
/*     */   private Ordenator ordenator;
/*     */   private boolean asc;
/*     */   private int page;
/*     */   private long wait;
/*     */   
/*     */   public ReportListInventory(Player player, Ordenator ordenator, boolean asc, int page) {
/*  38 */     super("§7Reports", 5);
/*  39 */     this.language = Language.getLanguage(player.getUniqueId());
/*     */     
/*  41 */     this.ordenator = ordenator;
/*  42 */     this.asc = asc;
/*  43 */     this.page = page;
/*     */     
/*  45 */     handleItems();
/*  46 */     setUpdateHandler((p, menu) -> handleItems());
/*     */     
/*  48 */     open(player);
/*     */   }
/*     */   
/*     */   public ReportListInventory(Player player, int page) {
/*  52 */     this(player, Ordenator.values()[0], true, page);
/*     */   }
/*     */   
/*     */   private void handleItems() {
/*  56 */     List<MenuItem> items = new ArrayList<>();
/*     */ 
/*     */     
/*  59 */     for (Iterator<Report> iterator = ((List)CommonPlugin.getInstance().getReportManager().getReports().stream().sorted((o1, o2) -> this.ordenator.compare(o1, o2) * (this.asc ? 1 : -1)).collect(Collectors.toList())).iterator(); iterator.hasNext(); ) { Report report = iterator.next();
/*  60 */       if (report.hasExpired()) {
/*  61 */         report.deleteReport();
/*     */         
/*     */         break;
/*     */       } 
/*  65 */       ReportInfo lastReport = report.getLastReport();
/*     */       
/*  67 */       items.add(new MenuItem((new ItemBuilder())
/*     */             
/*  69 */             .name("§a" + report.getPlayerName())
/*  70 */             .lore(Arrays.asList(new String[] {
/*  71 */                   "", "§eUltima denúncia:", "§f  Autor: §7" + lastReport.getPlayerName(), "§f  Motivo: §7" + lastReport
/*  72 */                   .getReason(), "§f  Criado há: §7" + 
/*  73 */                   DateUtils.formatDifference(this.language, (
/*  74 */                     System.currentTimeMillis() - lastReport.getCreatedAt()) / 1000L), "", "§fExpira em: §7" + 
/*  75 */                   DateUtils.getTime(this.language, report.getExpiresAt()), 
/*  76 */                   report.isOnline() ? "§aO jogador está online no momento." : ""
/*  77 */                 })).type(Material.SKULL_ITEM).durability(3).skin(report.getPlayerName()).build(), (p, inv, type, stack, s) -> {
/*     */               if (type == ClickType.RIGHT) {
/*     */                 new ConfirmInventory(p, "§7Deletar report " + report.getPlayerName(), (), this);
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 return;
/*     */               } 
/*     */ 
/*     */ 
/*     */               
/*     */               if (report.isOnline() ? (type == ClickType.LEFT) : (type == ClickType.SHIFT)) {
/*     */                 CommonPlugin.getInstance().getServerData().sendPacket((Packet)new TeleportToTarget(p.getUniqueId(), report.getReportId(), report.getPlayerName()));
/*     */               } else {
/*     */                 new ReportInventory(p, report, this);
/*     */               } 
/*     */             })); }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  99 */     int pageStart = 0;
/* 100 */     int pageEnd = 21;
/*     */     
/* 102 */     if (this.page > 1) {
/* 103 */       pageStart = (this.page - 1) * 21;
/* 104 */       pageEnd = this.page * 21;
/*     */     } 
/*     */     
/* 107 */     if (pageEnd > items.size()) {
/* 108 */       pageEnd = items.size();
/*     */     }
/*     */     
/* 111 */     int w = 10;
/*     */     
/* 113 */     for (int i = pageStart; i < this.page * 21; i++) {
/* 114 */       if (i < pageEnd) {
/* 115 */         MenuItem item = items.get(i);
/* 116 */         setItem(item, w);
/*     */       } else {
/* 118 */         removeItem(w);
/*     */       } 
/* 120 */       if (w % 9 == 7) {
/* 121 */         w += 3;
/*     */       }
/*     */       else {
/*     */         
/* 125 */         w++;
/*     */       } 
/*     */     } 
/* 128 */     setItem(40, (new ItemBuilder())
/*     */         
/* 130 */         .name("§a§%report.order." + this.ordenator.name().toLowerCase().replace("_", "-") + "-name%§")
/* 131 */         .type(Material.ITEM_FRAME)
/* 132 */         .lore(new String[] { "§7§%report.order." + this.ordenator.name().toLowerCase().replace("_", "-") + "-description%§", this.asc ? "§7Ordem crescente." : "§7Ordem decrescente."
/*     */           
/* 134 */           }).build(), (p, inv, type, stack, s) -> {
/*     */           if (this.wait > System.currentTimeMillis()) {
/*     */             p.sendMessage("§cAguarde para mudar a ordenação novamente.");
/*     */ 
/*     */             
/*     */             return;
/*     */           } 
/*     */ 
/*     */           
/*     */           this.wait = System.currentTimeMillis() + 500L;
/*     */           
/*     */           if (type == ClickType.RIGHT || type == ClickType.SHIFT) {
/*     */             this.asc = !this.asc;
/*     */           } else {
/*     */             this.ordenator = Ordenator.values()[(this.ordenator.ordinal() == (Ordenator.values()).length - 1) ? 0 : (this.ordenator.ordinal() + 1)];
/*     */           } 
/*     */           
/*     */           handleItems();
/*     */         });
/*     */     
/* 154 */     if (this.page == 1) {
/* 155 */       removeItem(39);
/*     */     } else {
/* 157 */       setItem(new MenuItem((new ItemBuilder()).type(Material.ARROW).name("§a§%page%§ " + (this.page - 1)).build(), (p, inv, type, stack, s) -> { this.page--; handleItems(); }), 39);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     if (Math.ceil((items.size() / 21)) + 1.0D > this.page) {
/* 164 */       setItem(new MenuItem((new ItemBuilder()).type(Material.ARROW).name("§a§%page%§ " + (this.page + 1)).build(), (p, inventory, clickType, item, slot) -> { this.page++; handleItems(); }), 41);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 170 */       removeItem(41);
/*     */     } 
/*     */   }
/*     */   
/*     */   public enum Ordenator implements Comparator<Report> {
/* 175 */     ALPHABETIC
/*     */     {
/*     */       public int compare(Report o1, Report o2)
/*     */       {
/* 179 */         return o1.getPlayerName().compareTo(o2.getPlayerName());
/*     */       }
/*     */     },
/*     */     
/* 183 */     EXPIRE_TIME
/*     */     {
/*     */       public int compare(Report o1, Report o2)
/*     */       {
/* 187 */         return Long.compare(o1.getExpiresAt(), o2.getExpiresAt()) * -1;
/*     */       }
/*     */     },
/*     */     
/* 191 */     CREATION_TIME
/*     */     {
/*     */       public int compare(Report o1, Report o2)
/*     */       {
/* 195 */         return Long.compare(o1.getCreatedAt(), o2.getCreatedAt());
/*     */       }
/*     */     },
/*     */     
/* 199 */     ONLINE
/*     */     {
/*     */       public int compare(Report o1, Report o2)
/*     */       {
/* 203 */         return Boolean.compare(o1.isOnline(), o2.isOnline());
/*     */       }
/*     */     };
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/menu/report/ReportListInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */