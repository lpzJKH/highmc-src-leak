/*    */ package net.highmc.bukkit.menu.report;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*    */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*    */ import net.highmc.bukkit.utils.menu.MenuItem;
/*    */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*    */ import net.highmc.language.Language;
/*    */ import net.highmc.report.Report;
/*    */ import net.highmc.report.ReportInfo;
/*    */ import net.highmc.utils.DateUtils;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class ReportInfoInventory
/*    */ {
/*    */   public ReportInfoInventory(Player player, Report report) {
/* 21 */     this(player, report, new ReportListInventory(player, 1), 1);
/*    */   }
/*    */   
/*    */   public ReportInfoInventory(Player player, Report report, MenuInventory backInventory, int page) {
/* 25 */     MenuInventory menuInventory = new MenuInventory("§7Report " + report.getPlayerName(), 5);
/* 26 */     Language language = Language.getLanguage(player.getUniqueId());
/*    */     
/* 28 */     List<MenuItem> items = new ArrayList<>();
/*    */     
/* 30 */     for (ReportInfo reportInfo : report.getReportMap().values()) {
/* 31 */       items.add(new MenuItem((new ItemBuilder()).name("§a" + reportInfo.getPlayerName())
/* 32 */             .lore(new String[] { "", "§eInformações:", "§f  Autor: §7" + reportInfo.getPlayerName(), "§f  Motivo: §7" + reportInfo
/* 33 */                 .getReason(), "§f  Criado há: §7" + 
/* 34 */                 DateUtils.formatDifference(language, (
/* 35 */                   System.currentTimeMillis() - reportInfo.getCreatedAt()) / 1000L)
/* 36 */               }).type(Material.SKULL_ITEM).durability(3).skin(reportInfo.getPlayerName()).build()));
/*    */     } 
/*    */     
/* 39 */     int pageStart = 0;
/* 40 */     int pageEnd = 21;
/*    */     
/* 42 */     if (page > 1) {
/* 43 */       pageStart = (page - 1) * 21;
/* 44 */       pageEnd = page * 21;
/*    */     } 
/*    */     
/* 47 */     if (pageEnd > items.size()) {
/* 48 */       pageEnd = items.size();
/*    */     }
/*    */     
/* 51 */     int w = 10;
/*    */     
/* 53 */     for (int i = pageStart; i < pageEnd; i++) {
/* 54 */       MenuItem item = items.get(i);
/* 55 */       menuInventory.setItem(item, w);
/*    */       
/* 57 */       if (w % 9 == 7) {
/* 58 */         w += 3;
/*    */       }
/*    */       else {
/*    */         
/* 62 */         w++;
/*    */       } 
/*    */     } 
/* 65 */     if (page == 1) {
/* 66 */       menuInventory.setItem(new MenuItem((new ItemBuilder()).type(Material.ARROW).name("§aVoltar").build(), (p, inv, type, stack, s) -> new ReportInventory(player, report, backInventory)), 39);
/*    */     } else {
/*    */       
/* 69 */       menuInventory.setItem(new MenuItem((new ItemBuilder())
/* 70 */             .type(Material.ARROW).name("§a§%page%§ " + (page - 1)).build(), (p, inv, type, stack, s) -> new ReportInfoInventory(player, report, backInventory, page - 1)), 39);
/*    */     } 
/*    */ 
/*    */     
/* 74 */     if (Math.ceil((items.size() / 21)) + 1.0D > page) {
/* 75 */       menuInventory.setItem(new MenuItem((new ItemBuilder())
/* 76 */             .type(Material.ARROW).name("§a§%page%§ " + (page + 1)).build(), (p, inventory, clickType, item, slot) -> new ReportInfoInventory(player, report, backInventory, page + 1)), 41);
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 82 */     menuInventory.open(player);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/menu/report/ReportInfoInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */