/*    */ package net.highmc.bukkit.menu.report;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*    */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*    */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*    */ import net.highmc.bukkit.utils.menu.confirm.ConfirmInventory;
/*    */ import net.highmc.language.Language;
/*    */ import net.highmc.report.Report;
/*    */ import net.highmc.report.ReportInfo;
/*    */ import net.highmc.utils.DateUtils;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class ReportInventory
/*    */ {
/*    */   public ReportInventory(Player player, Report report) {
/* 20 */     this(player, report, new ReportListInventory(player, 1));
/*    */   }
/*    */   
/*    */   public ReportInventory(Player player, Report report, MenuInventory backInventory) {
/* 24 */     MenuInventory menuInventory = new MenuInventory("§7Report " + report.getPlayerName(), 3);
/* 25 */     Language language = Language.getLanguage(player.getUniqueId());
/*    */     
/* 27 */     ReportInfo lastReport = report.getLastReport();
/*    */     
/* 29 */     menuInventory.setItem(10, (new ItemBuilder())
/* 30 */         .name("§a" + report.getPlayerName())
/* 31 */         .lore(Arrays.asList(new String[] { "", "§eUltima denúncia:", "§f  Autor: §7" + lastReport.getPlayerName(), "§f  Motivo: §7" + lastReport
/* 32 */               .getReason(), "§f  Criado há: §7" + 
/* 33 */               DateUtils.formatDifference(language, (
/* 34 */                 System.currentTimeMillis() - lastReport.getCreatedAt()) / 1000L), "", "§fExpira em: §7" + 
/* 35 */               DateUtils.getTime(language, report.getExpiresAt())
/* 36 */             })).type(Material.SKULL_ITEM).durability(3).skin(report.getPlayerName()).build());
/*    */     
/* 38 */     menuInventory.setItem(11, (new ItemBuilder()).name("§eTodas as denúncias")
/* 39 */         .lore("§7Clique para ver todas as denúncias feitas a esse jogador.").type(Material.BOOK).build(), (p, inv, type, stack, slot) -> new ReportInfoInventory(player, report, backInventory, 1));
/*    */ 
/*    */     
/* 42 */     menuInventory.setItem(15, (new ItemBuilder()).name("§cDeletar report").lore("§7Clique para excluir o report")
/* 43 */         .type(Material.BARRIER).build(), (p, inv, type, stack, slot) -> {
/*    */           if (type == ClickType.SHIFT) {
/*    */             report.deleteReport();
/*    */ 
/*    */ 
/*    */ 
/*    */             
/*    */             backInventory.open(p);
/*    */           } else {
/*    */             new ConfirmInventory(player, "§7Deletar report " + report.getPlayerName(), (), menuInventory);
/*    */           } 
/*    */         });
/*    */ 
/*    */ 
/*    */     
/* 58 */     menuInventory.setItem(16, (new ItemBuilder()).name("§a§%back%§").lore("§7Voltar para " + backInventory.getTitle())
/* 59 */         .type(Material.ARROW).build(), (p, inv, type, stack, slot) -> backInventory.open(p));
/*    */     
/* 61 */     menuInventory.open(player);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/menu/report/ReportInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */