/*    */ package net.highmc.bukkit.member.party;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import net.highmc.member.Member;
/*    */ import net.highmc.member.party.Party;
/*    */ 
/*    */ public class BukkitParty
/*    */   extends Party
/*    */ {
/*    */   public BukkitParty(UUID partyId, Member member) {
/* 11 */     super(partyId, member);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/member/party/BukkitParty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */