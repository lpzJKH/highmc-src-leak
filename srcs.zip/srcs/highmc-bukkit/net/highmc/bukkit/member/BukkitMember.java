/*     */ package net.highmc.bukkit.member;
/*     */ 
/*     */ import java.util.UUID;
/*     */ import net.highmc.bukkit.anticheat.gamer.UserData;
/*     */ import net.highmc.bukkit.event.member.PlayerChangeTagEvent;
/*     */ import net.highmc.bukkit.event.member.PlayerChangedTagEvent;
/*     */ import net.highmc.bukkit.event.member.PlayerGroupChangeEvent;
/*     */ import net.highmc.bukkit.event.member.PlayerLanguageChangeEvent;
/*     */ import net.highmc.bukkit.utils.player.PlayerHelper;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.member.configuration.LoginConfiguration;
/*     */ import net.highmc.permission.GroupInfo;
/*     */ import net.highmc.permission.Tag;
/*     */ import net.md_5.bungee.api.chat.BaseComponent;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ 
/*     */ public class BukkitMember
/*     */   extends Member
/*     */ {
/*     */   private transient Player player;
/*     */   private transient boolean buildEnabled;
/*     */   private transient UserData userData;
/*     */   private boolean anticheatBypass;
/*     */   
/*     */   public void setPlayer(Player player) {
/*  29 */     this.player = player;
/*  30 */   } public Player getPlayer() { return this.player; }
/*  31 */   public void setBuildEnabled(boolean buildEnabled) { this.buildEnabled = buildEnabled; } public boolean isBuildEnabled() {
/*  32 */     return this.buildEnabled;
/*     */   }
/*     */   
/*     */   public boolean isAnticheatBypass() {
/*  36 */     return this.anticheatBypass;
/*     */   }
/*     */   public BukkitMember(UUID uniqueId, String playerName) {
/*  39 */     super(uniqueId, playerName, LoginConfiguration.AccountType.NONE);
/*     */   }
/*     */   
/*     */   public void setAnticheatBypass(boolean anticheatBypass) {
/*  43 */     this.anticheatBypass = anticheatBypass;
/*  44 */     save(new String[] { "anticheatBypass" });
/*     */   }
/*     */   
/*     */   public UserData getUserData() {
/*  48 */     if (this.userData == null)
/*  49 */       this.userData = new UserData(getUniqueId(), getPlayerName()); 
/*  50 */     return this.userData;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setServerGroup(String groupName, GroupInfo groupInfo) {
/*  55 */     super.setServerGroup(groupName, groupInfo);
/*  56 */     Bukkit.getPluginManager()
/*  57 */       .callEvent((Event)new PlayerGroupChangeEvent(this.player, this, groupName, groupInfo.getExpireTime(), PlayerGroupChangeEvent.Action.SET));
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeServerGroup(String groupName) {
/*  62 */     super.removeServerGroup(groupName);
/*  63 */     Bukkit.getPluginManager().callEvent((Event)new PlayerGroupChangeEvent(this.player, this, groupName, 0L, PlayerGroupChangeEvent.Action.REMOVE));
/*     */   }
/*     */ 
/*     */   
/*     */   public void addServerGroup(String groupName, GroupInfo groupInfo) {
/*  68 */     super.addServerGroup(groupName, groupInfo);
/*  69 */     Bukkit.getPluginManager()
/*  70 */       .callEvent((Event)new PlayerGroupChangeEvent(this.player, this, groupName, groupInfo.getExpireTime(), PlayerGroupChangeEvent.Action.ADD));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLanguage(Language language) {
/*  75 */     super.setLanguage(language);
/*  76 */     Bukkit.getPluginManager().callEvent((Event)new PlayerLanguageChangeEvent(this.player, language));
/*     */   }
/*     */ 
/*     */   
/*     */   public void sendMessage(String str) {
/*  81 */     if (this.player != null) {
/*  82 */       this.player.sendMessage(PlayerHelper.translate(getLanguage(), str));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void sendMessage(BaseComponent str) {
/*  88 */     if (this.player != null) {
/*  89 */       this.player.spigot().sendMessage(str);
/*     */     }
/*     */   }
/*     */   
/*     */   public void sendMessage(BaseComponent... fromLegacyText) {
/*  94 */     if (this.player != null) {
/*  95 */       this.player.spigot().sendMessage(fromLegacyText);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean hasPermission(String permission) {
/* 100 */     if (this.player != null) {
/* 101 */       return (this.player.hasPermission(permission) || super.hasPermission(permission));
/*     */     }
/* 103 */     return super.hasPermission(permission);
/*     */   }
/*     */ 
/*     */   
/*     */   public void sendTitle(String title, String subTitle, int fadeIn, int stayIn, int fadeOut) {
/* 108 */     if (this.player != null) {
/* 109 */       PlayerHelper.title(this.player, title, subTitle, fadeIn, stayIn, fadeOut);
/*     */     }
/*     */   }
/*     */   
/*     */   public void sendActionBar(String message) {
/* 114 */     if (this.player != null) {
/* 115 */       PlayerHelper.actionbar(this.player, message);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean setTag(Tag tag) {
/* 120 */     return setTag(tag, false);
/*     */   }
/*     */   
/*     */   public boolean setTag(Tag tag, boolean forcetag) {
/* 124 */     PlayerChangeTagEvent event = new PlayerChangeTagEvent(this.player, getTag(), tag, forcetag);
/* 125 */     Bukkit.getPluginManager().callEvent((Event)event);
/*     */     
/* 127 */     tag = event.getNewTag();
/*     */     
/* 129 */     if (!event.isCancelled() && 
/* 130 */       !forcetag) {
/* 131 */       PlayerChangedTagEvent change = new PlayerChangedTagEvent(this.player, this, getTag(), tag, forcetag);
/* 132 */       Bukkit.getPluginManager().callEvent((Event)change);
/* 133 */       tag = change.getNewTag();
/* 134 */       super.setTag(tag);
/*     */     } 
/*     */     
/* 137 */     return !event.isCancelled();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOnline() {
/* 142 */     return super.isOnline();
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/member/BukkitMember.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */