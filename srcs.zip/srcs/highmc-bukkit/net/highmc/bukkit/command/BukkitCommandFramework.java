/*     */ package net.highmc.bukkit.command;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.command.CommandArgs;
/*     */ import net.highmc.command.CommandClass;
/*     */ import net.highmc.command.CommandFramework;
/*     */ import net.highmc.server.ServerType;
/*     */ import org.apache.commons.lang.Validate;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandException;
/*     */ import org.bukkit.command.CommandExecutor;
/*     */ import org.bukkit.command.CommandMap;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.command.TabCompleter;
/*     */ import org.bukkit.help.GenericCommandHelpTopic;
/*     */ import org.bukkit.help.HelpTopic;
/*     */ import org.bukkit.help.HelpTopicComparator;
/*     */ import org.bukkit.help.IndexHelpTopic;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.SimplePluginManager;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ import org.spigotmc.CustomTimingsHandler;
/*     */ 
/*     */ public class BukkitCommandFramework
/*     */   implements CommandFramework {
/*  40 */   public static final BukkitCommandFramework INSTANCE = new BukkitCommandFramework((Plugin)BukkitCommon.getInstance());
/*     */   
/*     */   private Plugin plugin;
/*  43 */   private final Map<String, Map.Entry<Method, Object>> commandMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private CommandMap map;
/*     */ 
/*     */   
/*     */   private Map<String, Command> knownCommands;
/*     */ 
/*     */ 
/*     */   
/*     */   public BukkitCommandFramework(Plugin plugin) {
/*  55 */     this.plugin = plugin;
/*     */     
/*  57 */     if (plugin.getServer().getPluginManager() instanceof SimplePluginManager) {
/*  58 */       SimplePluginManager manager = (SimplePluginManager)plugin.getServer().getPluginManager();
/*     */       
/*     */       try {
/*  61 */         Field field = SimplePluginManager.class.getDeclaredField("commandMap");
/*  62 */         field.setAccessible(true);
/*  63 */         this.map = (CommandMap)field.get(manager);
/*  64 */       } catch (IllegalArgumentException|NoSuchFieldException|IllegalAccessException|SecurityException e) {
/*  65 */         e.printStackTrace();
/*     */       } 
/*     */       
/*     */       try {
/*  69 */         Field field = this.map.getClass().getDeclaredField("knownCommands");
/*     */         
/*  71 */         field.setAccessible(true);
/*  72 */         this.knownCommands = (HashMap)field.get(this.map);
/*  73 */       } catch (IllegalArgumentException|NoSuchFieldException|IllegalAccessException|SecurityException e) {
/*  74 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean handleCommand(final CommandSender sender, final String label, Command cmd, final String[] args) {
/*  80 */     for (int i = args.length; i >= 0; i--) {
/*  81 */       StringBuilder buffer = new StringBuilder();
/*  82 */       buffer.append(label.toLowerCase());
/*     */       
/*  84 */       for (int x = 0; x < i; x++) {
/*  85 */         buffer.append(".").append(args[x].toLowerCase());
/*     */       }
/*     */       
/*  88 */       final String cmdLabel = buffer.toString();
/*     */       
/*  90 */       if (this.commandMap.containsKey(cmdLabel)) {
/*  91 */         final Map.Entry<Method, Object> entry = this.commandMap.get(cmdLabel);
/*  92 */         CommandFramework.Command command = ((Method)entry.getKey()).<CommandFramework.Command>getAnnotation(CommandFramework.Command.class);
/*     */         
/*  94 */         if (!command.console() && !(sender instanceof org.bukkit.entity.Player)) {
/*  95 */           sender.sendMessage("§%command-only-for-players%§");
/*  96 */           return true;
/*     */         } 
/*     */         
/*  99 */         if (command.runAsync() && Bukkit.isPrimaryThread()) {
/* 100 */           (new BukkitRunnable()
/*     */             {
/*     */               public void run() {
/*     */                 try {
/* 104 */                   ((Method)entry.getKey()).invoke(entry.getValue(), new Object[] { new BukkitCommandArgs(this.val$sender, this.val$label, this.val$args, (this.val$cmdLabel
/* 105 */                           .split("\\.")).length - 1) });
/* 106 */                 } catch (IllegalArgumentException|InvocationTargetException|IllegalAccessException e) {
/* 107 */                   e.printStackTrace();
/*     */                 } 
/*     */               }
/* 110 */             }).runTaskAsynchronously(this.plugin);
/*     */         } else {
/*     */           try {
/* 113 */             ((Method)entry.getKey()).invoke(entry.getValue(), new Object[] { new BukkitCommandArgs(sender, label, args, (cmdLabel
/* 114 */                     .split("\\.")).length - 1) });
/* 115 */           } catch (IllegalArgumentException|InvocationTargetException|IllegalAccessException e) {
/* 116 */             e.printStackTrace();
/*     */           } 
/*     */         } 
/* 119 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 123 */     sender.sendMessage("§cO comando está inacessível no momento!");
/* 124 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerCommands(CommandClass commandClass) {
/* 129 */     for (Method m : commandClass.getClass().getMethods()) {
/* 130 */       if (m.getAnnotation(CommandFramework.Command.class) != null) {
/* 131 */         CommandFramework.Command command = m.<CommandFramework.Command>getAnnotation(CommandFramework.Command.class);
/* 132 */         if ((m.getParameterTypes()).length > 1 || (m.getParameterTypes()).length <= 0 || 
/* 133 */           !CommandArgs.class.isAssignableFrom(m.getParameterTypes()[0])) {
/* 134 */           System.out.println("Unable to register command " + m.getName() + ". Unexpected method arguments");
/*     */         } else {
/*     */           
/* 137 */           registerCommand(command, command.name(), m, commandClass);
/*     */           
/* 139 */           for (String alias : command.aliases()) {
/* 140 */             registerCommand(command, alias, m, commandClass);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 145 */     for (Method m : commandClass.getClass().getMethods()) {
/* 146 */       if (m.getAnnotation(CommandFramework.Completer.class) != null) {
/* 147 */         CommandFramework.Completer comp = m.<CommandFramework.Completer>getAnnotation(CommandFramework.Completer.class);
/* 148 */         if ((m.getParameterTypes()).length > 1 || (m.getParameterTypes()).length == 0 || m
/* 149 */           .getParameterTypes()[0] != CommandArgs.class) {
/* 150 */           System.out.println("Unable to register tab completer " + m
/* 151 */               .getName() + ". Unexpected method arguments");
/*     */ 
/*     */         
/*     */         }
/* 155 */         else if (m.getReturnType() != List.class) {
/* 156 */           System.out.println("Unable to register tab completer " + m.getName() + ". Unexpected return type");
/*     */         }
/*     */         else {
/*     */           
/* 160 */           registerCompleter(comp.name(), m, commandClass);
/*     */           
/* 162 */           for (String alias : comp.aliases())
/* 163 */             registerCompleter(alias, m, commandClass); 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void registerHelp() {
/* 170 */     Set<HelpTopic> help = new TreeSet<>((Comparator<? super HelpTopic>)HelpTopicComparator.helpTopicComparatorInstance());
/*     */     
/* 172 */     for (String s : this.commandMap.keySet()) {
/* 173 */       if (!s.contains(".")) {
/* 174 */         Command cmd = this.map.getCommand(s);
/* 175 */         GenericCommandHelpTopic genericCommandHelpTopic = new GenericCommandHelpTopic(cmd);
/* 176 */         help.add(genericCommandHelpTopic);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 181 */     IndexHelpTopic topic = new IndexHelpTopic(this.plugin.getName(), "All commands for " + this.plugin.getName(), null, help, "Below is a list of all " + this.plugin.getName() + " commands:");
/* 182 */     Bukkit.getServer().getHelpMap().addTopic((HelpTopic)topic);
/*     */   }
/*     */   
/*     */   private void registerCommand(CommandFramework.Command command, String label, Method m, Object obj) {
/* 186 */     Map.Entry<Method, Object> entry = new AbstractMap.SimpleEntry<>(m, obj);
/* 187 */     this.commandMap.put(label.toLowerCase(), entry);
/* 188 */     String cmdLabel = label.replace(".", ",").split(",")[0].toLowerCase();
/*     */     
/* 190 */     if (this.map.getCommand(cmdLabel) == null) {
/* 191 */       Command cmd = new BukkitCommand(command.name(), cmdLabel, this.plugin, command.permission());
/* 192 */       this.knownCommands.put(cmdLabel, cmd);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 200 */     else if (this.map.getCommand(cmdLabel) instanceof BukkitCommand) {
/* 201 */       BukkitCommand bukkitCommand = (BukkitCommand)this.map.getCommand(cmdLabel);
/* 202 */       bukkitCommand.setPermission(command.permission());
/*     */     } 
/*     */ 
/*     */     
/* 206 */     if (!command.description().equalsIgnoreCase("") && cmdLabel == label) {
/* 207 */       this.map.getCommand(cmdLabel).setDescription(command.description());
/*     */     }
/*     */     
/* 210 */     if (!command.usage().equalsIgnoreCase("") && cmdLabel == label) {
/* 211 */       this.map.getCommand(cmdLabel).setUsage(command.usage());
/*     */     }
/*     */   }
/*     */   
/*     */   private void registerCompleter(String label, Method m, Object obj) {
/* 216 */     String cmdLabel = label.replace(".", ",").split(",")[0].toLowerCase();
/*     */     
/* 218 */     if (this.map.getCommand(cmdLabel) == null) {
/* 219 */       Command command = new BukkitCommand(cmdLabel, cmdLabel, this.plugin, "");
/* 220 */       this.knownCommands.put(cmdLabel, command);
/*     */     } 
/*     */     
/* 223 */     if (this.map.getCommand(cmdLabel) instanceof BukkitCommand) {
/* 224 */       BukkitCommand command = (BukkitCommand)this.map.getCommand(cmdLabel);
/*     */       
/* 226 */       if (command.getCompleter() == null) {
/* 227 */         command.setCompleter(new BukkitCompleter());
/*     */       }
/*     */       
/* 230 */       command.getCompleter().addCompleter(label, m, obj);
/* 231 */     } else if (this.map.getCommand(cmdLabel) instanceof org.bukkit.command.PluginCommand) {
/*     */       try {
/* 233 */         Object command = this.map.getCommand(cmdLabel);
/* 234 */         Field field = command.getClass().getDeclaredField("completer");
/* 235 */         field.setAccessible(true);
/* 236 */         if (field.get(command) == null) {
/* 237 */           BukkitCompleter completer = new BukkitCompleter();
/* 238 */           completer.addCompleter(label, m, obj);
/* 239 */           field.set(command, completer);
/* 240 */         } else if (field.get(command) instanceof BukkitCompleter) {
/* 241 */           BukkitCompleter completer = (BukkitCompleter)field.get(command);
/* 242 */           completer.addCompleter(label, m, obj);
/*     */         } else {
/* 244 */           System.out.println("Unable to register tab completer " + m.getName() + ". A tab completer is already registered for that command!");
/*     */         }
/*     */       
/* 247 */       } catch (Exception ex) {
/* 248 */         ex.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void unregisterCommands(String... commands) {
/*     */     try {
/* 255 */       Field f1 = Bukkit.getServer().getClass().getDeclaredField("commandMap");
/* 256 */       f1.setAccessible(true);
/*     */       
/* 258 */       CommandMap commandMap = (CommandMap)f1.get(Bukkit.getServer());
/* 259 */       Field f2 = commandMap.getClass().getDeclaredField("knownCommands");
/*     */       
/* 261 */       f2.setAccessible(true);
/*     */       
/* 263 */       for (String command : commands) {
/* 264 */         if (this.knownCommands.containsKey(command)) {
/* 265 */           this.knownCommands.remove(command);
/*     */           
/* 267 */           List<String> aliases = new ArrayList<>();
/*     */           
/* 269 */           for (String key : this.knownCommands.keySet()) {
/* 270 */             if (!key.contains(":")) {
/*     */               continue;
/*     */             }
/* 273 */             String substr = key.substring(key.indexOf(":") + 1);
/*     */             
/* 275 */             if (substr.equalsIgnoreCase(command)) {
/* 276 */               aliases.add(key);
/*     */             }
/*     */           } 
/*     */           
/* 280 */           for (String alias : aliases) {
/* 281 */             this.knownCommands.remove(alias);
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 286 */       Iterator<Map.Entry<String, Command>> iterator = this.knownCommands.entrySet().iterator();
/*     */       
/* 288 */       while (iterator.hasNext()) {
/* 289 */         Map.Entry<String, Command> entry = iterator.next();
/*     */         
/* 291 */         if (((String)entry.getKey()).contains(":")) {
/* 292 */           ((Command)entry.getValue()).unregister(commandMap);
/* 293 */           iterator.remove();
/*     */         } 
/*     */       } 
/* 296 */     } catch (Exception e) {
/* 297 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getJarClass() {
/* 303 */     return this.plugin.getClass();
/*     */   }
/*     */   public class BukkitCommand extends Command {
/*     */     private Plugin owningPlugin;
/*     */     private CommandExecutor executor;
/*     */     private BukkitCommandFramework.BukkitCompleter completer;
/*     */     private String permission;
/*     */     
/* 311 */     public void setCompleter(BukkitCommandFramework.BukkitCompleter completer) { this.completer = completer; } public BukkitCommandFramework.BukkitCompleter getCompleter() {
/* 312 */       return this.completer;
/*     */     }
/*     */     public String getPermission() {
/* 315 */       return this.permission;
/*     */     }
/*     */     
/*     */     public BukkitCommand(String fallbackPrefix, String label, Plugin owner, String permission) {
/* 319 */       super(label);
/* 320 */       this.executor = (CommandExecutor)owner;
/* 321 */       this.owningPlugin = owner;
/* 322 */       this.usageMessage = "";
/* 323 */       this.permission = permission;
/*     */       
/* 325 */       if (CommonPlugin.getInstance().getServerType() == ServerType.RANKUP) {
/*     */         try {
/* 327 */           Class<?> timingsClass = Class.forName("co.aikar.timings.Timings");
/*     */           
/* 329 */           Method method = timingsClass.getDeclaredMethod("ofSafe", new Class[] { String.class });
/* 330 */           method.setAccessible(true);
/* 331 */           Field field = Command.class.getDeclaredField("timings");
/* 332 */           field.setAccessible(true);
/* 333 */           field.set(this, method.invoke(null, new Object[] { "** Command: " + getName() }));
/* 334 */         } catch (ClassNotFoundException|NoSuchMethodException e) {
/* 335 */           e.printStackTrace();
/* 336 */         } catch (NoSuchFieldException e) {
/* 337 */           throw new RuntimeException(e);
/* 338 */         } catch (InvocationTargetException e) {
/* 339 */           throw new RuntimeException(e);
/* 340 */         } catch (IllegalAccessException e) {
/* 341 */           throw new RuntimeException(e);
/*     */         } 
/*     */       } else {
/* 344 */         this.timings = new CustomTimingsHandler("** Command: " + getName());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean execute(CommandSender sender, String commandLabel, String[] args) {
/* 350 */       boolean success = false;
/*     */       
/* 352 */       if (!this.owningPlugin.isEnabled()) {
/* 353 */         return false;
/*     */       }
/*     */       
/* 356 */       if (!testPermission(sender)) {
/* 357 */         return true;
/*     */       }
/*     */       
/*     */       try {
/* 361 */         success = BukkitCommandFramework.this.handleCommand(sender, commandLabel, this, args);
/* 362 */       } catch (Throwable ex) {
/* 363 */         throw new CommandException("Unhandled exception executing command '" + commandLabel + "' in plugin " + this.owningPlugin
/* 364 */             .getDescription().getFullName(), ex);
/*     */       } 
/*     */       
/* 367 */       if (!success && this.usageMessage.length() > 0) {
/* 368 */         for (String line : this.usageMessage.replace("<command>", commandLabel).split("\n")) {
/* 369 */           sender.sendMessage(line);
/*     */         }
/*     */       }
/*     */       
/* 373 */       return success;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public List<String> tabComplete(CommandSender sender, String alias, String[] args) throws CommandException, IllegalArgumentException {
/* 379 */       Validate.notNull(sender, "Sender cannot be null");
/* 380 */       Validate.notNull(args, "Arguments cannot be null");
/* 381 */       Validate.notNull(alias, "Alias cannot be null");
/*     */       
/* 383 */       List<String> completions = null;
/*     */       try {
/* 385 */         if (this.completer != null) {
/* 386 */           completions = this.completer.onTabComplete(sender, this, alias, args);
/*     */         }
/* 388 */         if (completions == null && this.executor instanceof TabCompleter) {
/* 389 */           completions = ((TabCompleter)this.executor).onTabComplete(sender, this, alias, args);
/*     */         }
/* 391 */       } catch (Throwable ex) {
/* 392 */         StringBuilder message = new StringBuilder();
/* 393 */         message.append("Unhandled exception during tab completion for command '/").append(alias).append(' ');
/*     */         
/* 395 */         for (String arg : args) {
/* 396 */           message.append(arg).append(' ');
/*     */         }
/*     */         
/* 399 */         message.deleteCharAt(message.length() - 1).append("' in plugin ")
/* 400 */           .append(this.owningPlugin.getDescription().getFullName());
/* 401 */         throw new CommandException(message.toString(), ex);
/*     */       } 
/*     */       
/* 404 */       if (completions == null) {
/* 405 */         return super.tabComplete(sender, alias, args);
/*     */       }
/* 407 */       return completions;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean testPermission(CommandSender target) {
/* 412 */       if (testPermissionSilent(target)) {
/* 413 */         return true;
/*     */       }
/*     */       
/* 416 */       target.sendMessage("§%no-permission%§");
/* 417 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean testPermissionSilent(CommandSender target) {
/* 422 */       if (getPermission().isEmpty()) {
/* 423 */         return true;
/*     */       }
/* 425 */       if (target instanceof org.bukkit.entity.Player) {
/* 426 */         return target.hasPermission(getPermission());
/*     */       }
/* 428 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */   public class BukkitCompleter
/*     */     implements TabCompleter {
/* 434 */     private final Map<String, Map.Entry<Method, Object>> completers = new HashMap<>();
/*     */     
/*     */     public void addCompleter(String label, Method m, Object obj) {
/* 437 */       this.completers.put(label, new AbstractMap.SimpleEntry<>(m, obj));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
/* 443 */       for (int i = args.length; i >= 0; i--) {
/* 444 */         StringBuilder buffer = new StringBuilder();
/* 445 */         buffer.append(label.toLowerCase());
/* 446 */         for (int x = 0; x < i; x++) {
/* 447 */           if (!args[x].equals("") && !args[x].equals(" ")) {
/* 448 */             buffer.append(".").append(args[x].toLowerCase());
/*     */           }
/*     */         } 
/* 451 */         String cmdLabel = buffer.toString();
/* 452 */         if (this.completers.containsKey(cmdLabel)) {
/* 453 */           Map.Entry<Method, Object> entry = this.completers.get(cmdLabel);
/*     */           try {
/* 455 */             return (List<String>)((Method)entry.getKey()).invoke(entry.getValue(), new Object[] { new BukkitCommandArgs(sender, label, args, (cmdLabel
/* 456 */                     .split("\\.")).length - 1) });
/* 457 */           } catch (IllegalArgumentException|IllegalAccessException|InvocationTargetException e) {
/* 458 */             e.printStackTrace();
/*     */           } 
/*     */         } 
/*     */       } 
/* 462 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/command/BukkitCommandFramework.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */