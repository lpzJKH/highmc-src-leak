/*    */ package net.highmc.bukkit.command;
/*    */ 
/*    */ import net.highmc.BukkitConst;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.bukkit.member.BukkitMember;
/*    */ import net.highmc.command.CommandArgs;
/*    */ import net.highmc.command.CommandSender;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class BukkitCommandArgs
/*    */   extends CommandArgs
/*    */ {
/*    */   protected BukkitCommandArgs(CommandSender sender, String label, String[] args, int subCommand) {
/* 15 */     super((sender instanceof Player) ? 
/* 16 */         (CommandSender)CommonPlugin.getInstance().getMemberManager().getMember(((Player)sender).getUniqueId()) : BukkitConst.CONSOLE_SENDER, label, args, subCommand);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isPlayer() {
/* 22 */     return getSender() instanceof net.highmc.member.Member;
/*    */   }
/*    */   
/*    */   public BukkitMember getSenderAsBukkitMember() {
/* 26 */     return BukkitMember.class.cast(getSender());
/*    */   }
/*    */   
/*    */   public Player getPlayer() {
/* 30 */     if (!isPlayer())
/* 31 */       return null; 
/* 32 */     return ((BukkitMember)getSender()).getPlayer();
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/command/BukkitCommandArgs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */