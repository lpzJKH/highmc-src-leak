/*     */ package net.highmc.bukkit.command;
/*     */ 
/*     */ import com.google.common.base.Joiner;
/*     */ import java.util.Arrays;
/*     */ import java.util.UUID;
/*     */ import java.util.stream.Collectors;
/*     */ import net.highmc.CommonConst;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.utils.player.PlayerHelper;
/*     */ import net.highmc.command.CommandSender;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.member.Profile;
/*     */ import net.md_5.bungee.api.chat.BaseComponent;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ public class BukkitCommandSender implements CommandSender {
/*     */   private final CommandSender sender;
/*     */   private UUID replyId;
/*     */   private boolean tellEnabled;
/*     */   
/*     */   public BukkitCommandSender(CommandSender sender) {
/*  24 */     this.sender = sender;
/*     */   }
/*     */   
/*     */   public CommandSender getSender() {
/*  28 */     return this.sender;
/*  29 */   } public void setReplyId(UUID replyId) { this.replyId = replyId; }
/*  30 */   public UUID getReplyId() { return this.replyId; }
/*  31 */   public void setTellEnabled(boolean tellEnabled) { this.tellEnabled = tellEnabled; } public boolean isTellEnabled() {
/*  32 */     return this.tellEnabled;
/*     */   }
/*     */   
/*     */   public UUID getUniqueId() {
/*  36 */     if (this.sender instanceof Player)
/*  37 */       return ((Player)this.sender).getUniqueId(); 
/*  38 */     return CommonConst.EMPTY_UNIQUE_ID;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSenderName() {
/*  43 */     if (this.sender instanceof Player)
/*  44 */       return this.sender.getName(); 
/*  45 */     return "CONSOLE";
/*     */   }
/*     */ 
/*     */   
/*     */   public void sendMessage(String message) {
/*  50 */     this.sender.sendMessage(PlayerHelper.translate(CommonPlugin.getInstance().getPluginInfo().getDefaultLanguage(), message));
/*     */   }
/*     */ 
/*     */   
/*     */   public void sendMessage(BaseComponent baseComponent) {
/*  55 */     if (this.sender instanceof Player) {
/*  56 */       ((Player)this.sender).spigot().sendMessage(baseComponent);
/*     */     } else {
/*  58 */       this.sender.sendMessage(
/*  59 */           PlayerHelper.translate(CommonPlugin.getInstance().getPluginInfo().getDefaultLanguage(), baseComponent.toLegacyText()));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void sendMessage(BaseComponent... baseComponent) {
/*  64 */     if (this.sender instanceof Player) {
/*  65 */       ((Player)this.sender).spigot().sendMessage(baseComponent);
/*     */     } else {
/*  67 */       this.sender.sendMessage(Joiner.on("")
/*  68 */           .join((Iterable)Arrays.<BaseComponent>asList(baseComponent).stream()
/*  69 */             .map(str -> PlayerHelper.translate(CommonPlugin.getInstance().getPluginInfo().getDefaultLanguage(), str.toLegacyText()))
/*     */             
/*  71 */             .collect(Collectors.toList())));
/*     */     } 
/*     */   }
/*     */   
/*     */   public Player getPlayer() {
/*  76 */     return (Player)this.sender;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPlayer() {
/*  81 */     return this.sender instanceof Player;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasPermission(String permission) {
/*  86 */     return this.sender.hasPermission(permission);
/*     */   }
/*     */ 
/*     */   
/*     */   public Language getLanguage() {
/*  91 */     return isPlayer() ? ((Member)getSender()).getLanguage() : 
/*  92 */       CommonPlugin.getInstance().getPluginInfo().getDefaultLanguage();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isStaff() {
/*  97 */     if (this.sender instanceof Player) {
/*  98 */       Member member = CommonPlugin.getInstance().getMemberManager().getMember(((Player)this.sender).getUniqueId());
/*  99 */       return member.getServerGroup().isStaff();
/*     */     } 
/*     */     
/* 102 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isUserBlocked(Profile profile) {
/* 107 */     return isPlayer() ? ((Member)getSender()).isUserBlocked(profile) : false;
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/command/BukkitCommandSender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */