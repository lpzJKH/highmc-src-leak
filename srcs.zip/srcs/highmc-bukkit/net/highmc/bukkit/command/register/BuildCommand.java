/*     */ package net.highmc.bukkit.command.register;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.bukkit.member.BukkitMember;
/*     */ import net.highmc.command.CommandArgs;
/*     */ import net.highmc.command.CommandClass;
/*     */ import net.highmc.command.CommandFramework.Command;
/*     */ import net.highmc.command.CommandSender;
/*     */ import net.highmc.server.ServerType;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.BlockState;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BuildCommand
/*     */   implements CommandClass
/*     */ {
/*     */   @Command(name = "build", aliases = {"b"}, permission = "command.build", console = false)
/*     */   public void buildCommand(CommandArgs cmdArgs) {
/*  26 */     CommandSender sender = cmdArgs.getSender();
/*  27 */     String[] args = cmdArgs.getArgs();
/*     */     
/*  29 */     if (args.length == 0) {
/*  30 */       if (CommonPlugin.getInstance().getServerType() == ServerType.BUILD || sender
/*  31 */         .hasPermission("command.build-bypass")) {
/*  32 */         BukkitMember player = (BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class);
/*  33 */         player.setBuildEnabled(!player.isBuildEnabled());
/*  34 */         player.sendMessage("§%command-build-" + (player.isBuildEnabled() ? "enabled" : "disabled") + "%§");
/*     */       } else {
/*  36 */         sender.sendMessage("§cVocê não tem acesso a esse comando neste servidor no momento.");
/*     */       } 
/*     */       return;
/*     */     } 
/*  40 */     if (sender.hasPermission("command.build-bypass")) {
/*  41 */       BukkitMember player = (BukkitMember)CommonPlugin.getInstance().getMemberManager().getMemberByName(args[0], BukkitMember.class);
/*     */ 
/*     */       
/*  44 */       if (player == null) {
/*  45 */         sender.sendMessage(sender.getLanguage().t("player-is-not-online", new String[] { "%player%", args[0] }));
/*     */         
/*     */         return;
/*     */       } 
/*  49 */       player.setBuildEnabled(!player.isBuildEnabled());
/*  50 */       sender.sendMessage(sender
/*  51 */           .getLanguage().t("command-build-target-" + (player.isBuildEnabled() ? "enabled" : "disabled"), new String[] { "%target%", player
/*  52 */               .getName() }));
/*  53 */       player.sendMessage("§%command-build-" + (player.isBuildEnabled() ? "enabled" : "disabled") + "%§");
/*     */     } else {
/*  55 */       sender.sendMessage("§cVocê não tem acesso a esse comando neste servidor no momento.");
/*     */     } 
/*     */   }
/*     */   @Command(name = "wand", permission = "command.build")
/*     */   public void wandCommand(CommandArgs cmdArgs) {
/*  60 */     if (!cmdArgs.isPlayer()) {
/*     */       return;
/*     */     }
/*  63 */     BukkitCommon.getInstance().getBlockManager()
/*  64 */       .giveWand(((BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class)).getPlayer());
/*  65 */     cmdArgs.getSender().sendMessage(" §a* §fVocê recebeu a varinha do §aWorldedit§f!");
/*     */   }
/*     */   
/*     */   @Command(name = "set", permission = "command.build")
/*     */   public void setCommand(CommandArgs cmdArgs) {
/*  70 */     if (!cmdArgs.isPlayer()) {
/*     */       return;
/*     */     }
/*  73 */     Player player = ((BukkitMember)cmdArgs.getSender()).getPlayer();
/*     */     
/*  75 */     String[] args = cmdArgs.getArgs();
/*     */     
/*  77 */     if (args.length == 0) {
/*  78 */       player.sendMessage(" §e» §fUse §a/set <material:id>§f para setar um grupo.");
/*     */       
/*     */       return;
/*     */     } 
/*  82 */     Material blockMaterial = null;
/*  83 */     byte blockId = 0;
/*     */     
/*  85 */     if (args[0].contains(":")) {
/*  86 */       blockMaterial = Material.getMaterial(args[0].split(":")[0].toUpperCase());
/*     */       
/*  88 */       if (blockMaterial == null) {
/*     */         try {
/*  90 */           blockMaterial = Material.getMaterial(Integer.valueOf(args[0].split(":")[0]).intValue());
/*  91 */         } catch (NumberFormatException e) {
/*  92 */           player.sendMessage(" §c» §fNão foi possível encontrar esse bloco!");
/*     */           
/*     */           return;
/*     */         } 
/*     */       }
/*     */       try {
/*  98 */         blockId = Byte.valueOf(args[0].split(":")[1]).byteValue();
/*  99 */       } catch (Exception e) {
/* 100 */         player.sendMessage(" §c» §fO bloco " + args[0] + " não existe!");
/*     */         return;
/*     */       } 
/*     */     } else {
/* 104 */       blockMaterial = Material.getMaterial(args[0]);
/*     */       
/* 106 */       if (blockMaterial == null) {
/*     */         try {
/* 108 */           blockMaterial = Material.getMaterial(Integer.valueOf(args[0]).intValue());
/* 109 */         } catch (NumberFormatException e) {
/* 110 */           player.sendMessage(" §c» §fNão foi possível encontrar esse bloco!");
/*     */           
/*     */           return;
/*     */         } 
/*     */       }
/*     */     } 
/* 116 */     if (blockMaterial == null) {
/* 117 */       player.sendMessage(" §c» §fNão foi possível encontrar o bloco " + args[0] + "!");
/*     */       
/*     */       return;
/*     */     } 
/* 121 */     if (!BukkitCommon.getInstance().getBlockManager().hasFirstPosition(player)) {
/* 122 */       player.sendMessage("§cA primeira posição não foi setada!");
/*     */       
/*     */       return;
/*     */     } 
/* 126 */     if (!BukkitCommon.getInstance().getBlockManager().hasSecondPosition(player)) {
/* 127 */       player.sendMessage("§cA segunda posição não foi setada!");
/*     */       
/*     */       return;
/*     */     } 
/* 131 */     Location first = BukkitCommon.getInstance().getBlockManager().getFirstPosition(player);
/* 132 */     Location second = BukkitCommon.getInstance().getBlockManager().getSecondPosition(player);
/*     */     
/* 134 */     Map<Location, BlockState> map = new HashMap<>();
/* 135 */     int amount = 0;
/*     */     
/* 137 */     for (Location location : BukkitCommon.getInstance().getBlockManager().getLocationsFromTwoPoints(first, second)) {
/*     */       
/* 139 */       map.put(location.clone(), location.getBlock().getState());
/*     */       
/* 141 */       if (location.getBlock().getType() != blockMaterial || location.getBlock().getData() != blockId) {
/* 142 */         BukkitCommon.getInstance().getBlockManager().setBlockFast(location.getWorld(), location, blockMaterial
/* 143 */             .getId(), blockId);
/* 144 */         amount++;
/*     */       } 
/*     */     } 
/*     */     
/* 148 */     BukkitCommon.getInstance().getBlockManager().addUndo(player, map);
/* 149 */     player.sendMessage("§dVocê colocou " + amount + " blocos!");
/*     */   }
/*     */   
/*     */   @Command(name = "undo", permission = "command.build")
/*     */   public void undoCommand(CommandArgs cmdArgs) {
/* 154 */     if (!cmdArgs.isPlayer()) {
/*     */       return;
/*     */     }
/* 157 */     Player player = ((BukkitMember)cmdArgs.getSender()).getPlayer();
/*     */     
/* 159 */     if (!BukkitCommon.getInstance().getBlockManager().hasUndoList(player)) {
/* 160 */       player.sendMessage("§cVocê não tem nada para desfazer");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 165 */     Map<Location, BlockState> map = BukkitCommon.getInstance().getBlockManager().getUndoList(player).get(BukkitCommon.getInstance().getBlockManager().getUndoList(player).size() - 1);
/*     */     
/* 167 */     int amount = 0;
/*     */     
/* 169 */     for (Map.Entry<Location, BlockState> entry : map.entrySet()) {
/* 170 */       BukkitCommon.getInstance().getBlockManager().setBlockFast(((Location)entry.getKey()).getWorld(), entry.getKey(), ((BlockState)entry
/* 171 */           .getValue()).getType().getId(), ((BlockState)entry.getValue()).getData().getData());
/* 172 */       amount++;
/*     */     } 
/*     */     
/* 175 */     BukkitCommon.getInstance().getBlockManager().removeUndo(player, map);
/* 176 */     player.sendMessage("§dVocê colocou " + amount + " blocos!");
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/command/register/BuildCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */