/*    */ package net.highmc.bukkit.command.register;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ import net.highmc.command.CommandArgs;
/*    */ import net.highmc.command.CommandClass;
/*    */ import net.highmc.command.CommandFramework.Command;
/*    */ import net.highmc.command.CommandFramework.Completer;
/*    */ import net.highmc.member.Member;
/*    */ import net.highmc.member.configuration.MemberConfiguration;
/*    */ import net.highmc.punish.PunishType;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.OfflinePlayer;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PunishCommand
/*    */   implements CommandClass
/*    */ {
/*    */   @Command(name = "ban", aliases = {"kick", "mute", "tempban", "tempmute", "tempbanir", "tempmutar", "punish"}, permission = "command.punish")
/*    */   public void banCommand(CommandArgs cmdArgs) {}
/*    */   
/*    */   @Command(name = "pardon", aliases = {"unpunish", "unban", "unmute"}, permission = "command.pardon")
/*    */   public void pardonCommand(CommandArgs cmdArgs) {}
/*    */   
/*    */   @Command(name = "anticheat", aliases = {"ac"}, permission = "command.anticheat", console = false)
/*    */   public void anticheatCommand(CommandArgs cmdArgs) {
/* 31 */     Member member = cmdArgs.getSenderAsMember(Member.class);
/*    */     
/* 33 */     member.getMemberConfiguration().setCheatState(member.getMemberConfiguration().isAnticheatEnabled() ? MemberConfiguration.CheatState.DISABLED : MemberConfiguration.CheatState.ENABLED);
/* 34 */     member.sendMessage(member.getLanguage().t("command.anticheat.state-" + member.getMemberConfiguration().getCheatState().name().toLowerCase(), new String[0]));
/*    */   }
/*    */   
/*    */   @Completer(name = "punish")
/*    */   public List<String> banCompleter(CommandArgs cmdArgs) {
/* 39 */     return ((cmdArgs.getArgs()).length == 2) ? 
/* 40 */       (List<String>)Arrays.<PunishType>asList(PunishType.values()).stream()
/* 41 */       .filter(state -> state.name().toLowerCase().startsWith(cmdArgs.getArgs()[1].toLowerCase()))
/* 42 */       .map(Enum::name).collect(Collectors.toList()) : 
/* 43 */       (List<String>)Bukkit.getOnlinePlayers().stream()
/* 44 */       .filter(player -> player.getName().toLowerCase().startsWith(cmdArgs.getArgs()[(cmdArgs.getArgs()).length - 1].toLowerCase()))
/*    */       
/* 46 */       .map(OfflinePlayer::getName).collect(Collectors.toList());
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/command/register/PunishCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */