/*     */ package net.highmc.bukkit.command.register;
/*     */ 
/*     */ import com.google.common.base.Joiner;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.OptionalDouble;
/*     */ import java.util.OptionalInt;
/*     */ import java.util.stream.Collectors;
/*     */ import net.highmc.CommonConst;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.bukkit.member.BukkitMember;
/*     */ import net.highmc.bukkit.menu.profile.StatisticsInventory;
/*     */ import net.highmc.bukkit.utils.ProtocolVersion;
/*     */ import net.highmc.command.CommandArgs;
/*     */ import net.highmc.command.CommandClass;
/*     */ import net.highmc.command.CommandFramework.Command;
/*     */ import net.highmc.command.CommandFramework.Completer;
/*     */ import net.highmc.command.CommandSender;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.server.ServerType;
/*     */ import net.highmc.server.loadbalancer.server.ProxiedServer;
/*     */ import net.highmc.utils.DateUtils;
/*     */ import net.highmc.utils.configuration.Configuration;
/*     */ import net.highmc.utils.string.StringFormat;
/*     */ import net.md_5.bungee.api.ChatColor;
/*     */ import net.minecraft.server.v1_8_R3.MinecraftServer;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.OfflinePlayer;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.WorldCreator;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ 
/*     */ public class ServerCommand
/*     */   implements CommandClass {
/*     */   @Command(name = "servermanager", aliases = {"ss", "smanager"}, permission = "command.server")
/*     */   public void servermanagerCommand(CommandArgs cmdArgs) {
/*     */     ServerType serverType;
/*     */     String serverId;
/*  52 */     CommandSender sender = cmdArgs.getSender();
/*  53 */     String[] args = cmdArgs.getArgs();
/*     */     
/*  55 */     if (args.length == 0) {
/*  56 */       sender.sendMessage("§%command-server-usage%§");
/*     */       
/*     */       return;
/*     */     } 
/*  60 */     switch (args[0].toLowerCase()) {
/*     */       case "reload-config":
/*     */         try {
/*  63 */           CommonPlugin.getInstance().loadConfig();
/*  64 */           sender.sendMessage("§%command-server-reload-config-successfully%§");
/*  65 */         } catch (Exception ex) {
/*  66 */           sender.sendMessage("§%command-server-reload-config-error%§");
/*  67 */           sender.sendMessage("§c" + ex.getLocalizedMessage());
/*  68 */           ex.printStackTrace();
/*     */         } 
/*     */         return;
/*     */       
/*     */       case "type":
/*  73 */         if (args.length == 1) {
/*  74 */           sender.sendMessage("§aInsira o tipo do servidor.");
/*     */           
/*     */           return;
/*     */         } 
/*  78 */         serverType = null;
/*     */         
/*     */         try {
/*  81 */           serverType = ServerType.valueOf(args[1].toUpperCase());
/*  82 */         } catch (Exception ex) {
/*  83 */           sender.sendMessage("§cO tipo do servidor não foi encontrado.");
/*     */           
/*     */           return;
/*     */         } 
/*  87 */         CommonPlugin.getInstance().setServerType(serverType);
/*  88 */         sender.sendMessage("§aO tipo do servidor foi alterado para §f" + serverType.name() + "§a.");
/*     */         return;
/*     */       
/*     */       case "serverid":
/*  92 */         if (args.length == 1) {
/*  93 */           sender.sendMessage("§aInsira o nome do servidor.");
/*     */           
/*     */           return;
/*     */         } 
/*  97 */         serverId = args[1];
/*  98 */         CommonPlugin.getInstance().setServerId(serverId);
/*  99 */         sender.sendMessage("§aO ID do servidor foi alterado para §f" + serverId + "§a.");
/*     */         return;
/*     */       
/*     */       case "start":
/* 103 */         CommonPlugin.getInstance().getServerData().startServer(Bukkit.getMaxPlayers());
/* 104 */         CommonPlugin.getInstance().getServerData().updateStatus();
/* 105 */         Bukkit.getOnlinePlayers().forEach(player -> CommonPlugin.getInstance().getServerData().joinPlayer(player.getUniqueId(), Bukkit.getMaxPlayers()));
/* 106 */         sender.sendMessage("§aO servidor foi iniciado com sucesso.");
/*     */         return;
/*     */       
/*     */       case "stop":
/* 110 */         Bukkit.getOnlinePlayers().forEach(player -> CommonPlugin.getInstance().getServerData().leavePlayer(player.getUniqueId(), Bukkit.getMaxPlayers()));
/* 111 */         CommonPlugin.getInstance().getServerData().stopServer();
/* 112 */         sender.sendMessage("§aO servidor foi parado com sucesso.");
/*     */         return;
/*     */       
/*     */       case "save-config":
/*     */         try {
/* 117 */           CommonPlugin.getInstance().saveConfig();
/* 118 */           sender.sendMessage("§%command-server-save-config-successfully%§");
/* 119 */         } catch (Exception ex) {
/* 120 */           sender.sendMessage("§%command-server-save-config-error%§");
/* 121 */           sender.sendMessage("§c" + ex.getLocalizedMessage());
/* 122 */           ex.printStackTrace();
/*     */         } 
/*     */         return;
/*     */ 
/*     */       
/*     */       case "debug":
/* 128 */         for (Map.Entry<String, ProxiedServer> entry : (Iterable<Map.Entry<String, ProxiedServer>>)BukkitCommon.getInstance().getServerManager().getActiveServers()
/* 129 */           .entrySet()) {
/* 130 */           sender.sendMessage("  §f" + (String)entry.getKey() + "§7: " + CommonConst.GSON.toJson(entry.getValue()));
/*     */         }
/*     */         return;
/*     */     } 
/*     */     
/* 135 */     sender.sendMessage("§%command-server-usage%§");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Command(name = "stats", aliases = {"status", "estatisticas"}, console = false)
/*     */   public void statsCommand(CommandArgs cmdArgs) {
/* 143 */     new StatisticsInventory(((BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class)).getPlayer(), null);
/*     */   }
/*     */   
/*     */   @Command(name = "config", permission = "command.config")
/*     */   public void configCommand(CommandArgs cmdArgs) {
/* 148 */     CommandSender sender = cmdArgs.getSender();
/* 149 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 151 */     if (args.length == 0) {
/* 152 */       sender.sendMessage("§%command-config-usage%§");
/*     */       
/*     */       return;
/*     */     } 
/* 156 */     if (args.length == 1 && 
/* 157 */       args[0].equalsIgnoreCase("list")) {
/* 158 */       sender.sendMessage("  §aConfig list:");
/*     */       
/* 160 */       for (String config : CommonPlugin.getInstance().getConfigurationManager().getConfigs()) {
/* 161 */         sender.sendMessage("    §f- §7" + config);
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 166 */     String configName = args[0];
/* 167 */     Configuration configuration = CommonPlugin.getInstance().getConfigurationManager().getConfigByName(configName);
/*     */     
/* 169 */     if (configuration == null) {
/* 170 */       sender.sendMessage(sender.getLanguage().t("command-config-configuration-not-found", new String[] { "%name%", configName }));
/*     */       
/*     */       return;
/*     */     } 
/* 174 */     switch (args[1].toLowerCase()) {
/*     */       case "save":
/*     */         try {
/* 177 */           configuration.saveConfig();
/* 178 */           sender.sendMessage(sender.getLanguage().t("command-config-configuration-saved", new String[] { "%name%", configName }));
/* 179 */         } catch (Exception ex) {
/* 180 */           sender.sendMessage("§%command-config-could-not-save%§");
/* 181 */           ex.printStackTrace();
/*     */         } 
/*     */         return;
/*     */       
/*     */       case "reload":
/*     */       case "load":
/*     */         try {
/* 188 */           configuration.loadConfig();
/* 189 */           sender.sendMessage(sender.getLanguage().t("command-config-configuration-loaded", new String[] { "%name%", configName }));
/* 190 */         } catch (Exception ex) {
/* 191 */           sender.sendMessage("§%command-config-could-not-load%§");
/* 192 */           ex.printStackTrace();
/*     */         } 
/*     */         return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 200 */     sender.sendMessage("§%command-config-usage%§");
/*     */   }
/*     */ 
/*     */   
/*     */   @Command(name = "gamemode", aliases = {"gm"}, permission = "command.gamemode")
/*     */   public void gamemodeCommand(CommandArgs cmdArgs) {
/* 206 */     CommandSender sender = cmdArgs.getSender();
/* 207 */     Language language = sender.getLanguage();
/* 208 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 210 */     if (args.length == 0) {
/* 211 */       sender.sendMessage(language.t("command-gamemode-usage", new String[] { "%label%", cmdArgs.getLabel() }));
/*     */       
/*     */       return;
/*     */     } 
/* 215 */     GameMode gameMode = null;
/* 216 */     OptionalInt optionalInt = StringFormat.parseInt(args[0]);
/*     */     
/* 218 */     if (optionalInt.isPresent()) {
/* 219 */       gameMode = GameMode.getByValue(optionalInt.getAsInt());
/*     */     } else {
/*     */       try {
/* 222 */         gameMode = GameMode.valueOf(args[0].toUpperCase());
/* 223 */       } catch (Exception exception) {}
/*     */     } 
/*     */ 
/*     */     
/* 227 */     if (gameMode == null) {
/* 228 */       sender.sendMessage(language.t("command-gamemode-not-found", new String[] { "%gamemode%", args[0] }));
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 234 */     Player target = (args.length == 1 && sender.isPlayer()) ? ((BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class)).getPlayer() : Bukkit.getPlayer(args[1]);
/*     */     
/* 236 */     if (target == null) {
/* 237 */       sender.sendMessage(language.t("player-not-found", new String[] { "%player%", args[1] }));
/*     */       
/*     */       return;
/*     */     } 
/* 241 */     target.setGameMode(gameMode);
/*     */     
/* 243 */     if (target.getUniqueId().equals(sender.getUniqueId())) {
/* 244 */       sender.sendMessage(language.t("command-gamemode-your-gamemode-changed", new String[] { "%gamemode%", 
/* 245 */               StringFormat.formatString(gameMode.name()) }));
/*     */     } else {
/* 247 */       sender.sendMessage(language.t("command-gamemode-target-gamemode-changed", new String[] { "%gamemode%", 
/* 248 */               StringFormat.formatString(gameMode.name()), "%target%", target.getName() }));
/*     */     } 
/*     */   }
/*     */   @Command(name = "clear", permission = "command.clear")
/*     */   public void clearCommand(CommandArgs cmdArgs) {
/* 253 */     CommandSender sender = cmdArgs.getSender();
/* 254 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 256 */     if (args.length == 0)
/* 257 */     { if (cmdArgs.isPlayer()) {
/* 258 */         Player player = ((BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class)).getPlayer();
/*     */         
/* 260 */         player.getInventory().clear();
/* 261 */         player.getInventory().setArmorContents(new org.bukkit.inventory.ItemStack[4]);
/* 262 */         player.getActivePotionEffects().clear();
/*     */         
/* 264 */         sender.sendMessage("§%command-clear-cleared-inventory%§");
/*     */       } else {
/* 266 */         sender.sendMessage("§%command-only-for-player%§");
/*     */       }  }
/* 268 */     else { Player player = Bukkit.getPlayer(args[0]);
/*     */       
/* 270 */       if (player == null) {
/* 271 */         sender.sendMessage(sender.getLanguage().t("player-not-found", new String[] { "%player%", args[0] }));
/*     */         
/*     */         return;
/*     */       } 
/* 275 */       player.getInventory().clear();
/* 276 */       player.getInventory().setArmorContents(new org.bukkit.inventory.ItemStack[4]);
/* 277 */       player.getActivePotionEffects().clear();
/* 278 */       sender.sendMessage(sender
/* 279 */           .getLanguage().t("command-clear-cleared-player-inventory", new String[] { "%player%", player.getName() })); }
/*     */   
/*     */   }
/*     */   
/*     */   @Command(name = "tpworld", aliases = {"tpw"}, permission = "command.teleport")
/*     */   public void teleportworldCommand(CommandArgs cmdArgs) {
/* 285 */     Player player = ((BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class)).getPlayer();
/* 286 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 288 */     World world = Bukkit.getWorld(args[0]);
/*     */     
/* 290 */     if (world == null) {
/* 291 */       world = WorldCreator.name(args[0]).createWorld();
/*     */     }
/* 293 */     player.teleport(new Location(Bukkit.getWorld(args[0]), 0.0D, 0.0D, 0.0D));
/*     */   }
/*     */   @Command(name = "teleport", aliases = {"tp"}, permission = "command.teleport")
/*     */   public void teleportCommand(CommandArgs cmdArgs) {
/*     */     Player target, player, player1;
/* 298 */     CommandSender sender = cmdArgs.getSender();
/* 299 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 301 */     switch (args.length) {
/*     */       case 1:
/* 303 */         target = Bukkit.getPlayer(args[0]);
/*     */         
/* 305 */         if (target == null) {
/* 306 */           sender.sendMessage(sender.getLanguage().t("player-not-found", new String[] { "%player%", args[0] }));
/*     */           
/*     */           return;
/*     */         } 
/* 310 */         if (sender.isPlayer()) {
/* 311 */           ((BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class)).getPlayer().teleport((Entity)target);
/* 312 */           sender.sendMessage(sender
/* 313 */               .getLanguage().t("command-teleport-teleported-to-target", new String[] { "%target%", target.getName() }));
/*     */         } else {
/* 315 */           sender.sendMessage("§%command-only-for-console%§");
/*     */         } 
/*     */         return;
/*     */       case 2:
/* 319 */         if (args[0].equalsIgnoreCase("location")) {
/* 320 */           if (cmdArgs.isPlayer()) {
/* 321 */             Player player2 = ((BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class)).getPlayer();
/* 322 */             String locationName = args[1];
/*     */             
/* 324 */             if (BukkitCommon.getInstance().getLocationManager().hasLocation(locationName)) {
/* 325 */               Location location = BukkitCommon.getInstance().getLocationManager().getLocation(locationName);
/*     */               
/* 327 */               player2.teleport(location);
/* 328 */               player2.sendMessage(sender.getLanguage().t("command-teleport-teleported-to-locationname", new String[] { "%location%", locationName }));
/*     */             } else {
/*     */               
/* 331 */               sender.sendMessage(sender.getLanguage().t("command-teleport-location-not-found", new String[] { "%location%", locationName }));
/*     */             }
/*     */           
/*     */           } else {
/*     */             
/* 336 */             sender.sendMessage("§%command-only-for-console%§");
/*     */           } 
/*     */           return;
/*     */         } 
/* 340 */         player = Bukkit.getPlayer(args[0]);
/*     */         
/* 342 */         if (player == null) {
/* 343 */           sender.sendMessage(sender.getLanguage().t("player-not-found", new String[] { "%player%", args[0] }));
/*     */           
/*     */           return;
/*     */         } 
/* 347 */         player1 = Bukkit.getPlayer(args[1]);
/*     */         
/* 349 */         if (player1 == null) {
/* 350 */           sender.sendMessage(sender.getLanguage().t("player-not-found", new String[] { "%player%", args[1] }));
/*     */           
/*     */           return;
/*     */         } 
/* 354 */         player.teleport((Entity)player1);
/* 355 */         sender.sendMessage(sender.getLanguage().t("command-teleport-teleported-player-to-target", new String[] { "%player%", player
/* 356 */                 .getName(), "%target%", player1.getName() }));
/*     */         return;
/*     */       
/*     */       case 3:
/* 360 */         if (sender.isPlayer()) {
/* 361 */           double x, y, z; player = ((BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class)).getPlayer();
/*     */           
/* 363 */           OptionalDouble optionalX = StringFormat.parseDouble(args[0]);
/* 364 */           OptionalDouble optionalY = StringFormat.parseDouble(args[1]);
/* 365 */           OptionalDouble optionalZ = StringFormat.parseDouble(args[2]);
/*     */ 
/*     */ 
/*     */           
/* 369 */           if (args[0].equals("~")) {
/* 370 */             x = player.getLocation().getX();
/*     */           }
/* 372 */           else if (optionalX.isPresent()) {
/* 373 */             x = optionalX.getAsDouble();
/*     */           } else {
/* 375 */             sender.sendMessage(sender.getLanguage().t("invalid-format-double", new String[] { "%value%", args[0] }));
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/* 380 */           if (args[1].equals("~")) {
/* 381 */             y = player.getLocation().getY();
/*     */           }
/* 383 */           else if (optionalY.isPresent()) {
/* 384 */             y = optionalY.getAsDouble();
/*     */           } else {
/* 386 */             sender.sendMessage(sender.getLanguage().t("invalid-format-double", new String[] { "%value%", args[1] }));
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/* 391 */           if (args[2].equals("~")) {
/* 392 */             z = player.getLocation().getZ();
/*     */           }
/* 394 */           else if (optionalZ.isPresent()) {
/* 395 */             z = optionalZ.getAsDouble();
/*     */           } else {
/* 397 */             sender.sendMessage(sender.getLanguage().t("invalid-format-double", new String[] { "%value%", args[2] }));
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/* 402 */           Location location = new Location(player.getWorld(), x, y, z);
/*     */           
/* 404 */           if (!location.getChunk().isLoaded()) {
/* 405 */             location.getChunk().load();
/*     */           }
/* 407 */           NumberFormat numberFormat = new DecimalFormat("#.##");
/*     */           
/* 409 */           player.setFallDistance(-1.0F);
/* 410 */           player.teleport(location);
/* 411 */           sender.sendMessage(sender.getLanguage().t("command-teleport-teleported-to-location", new String[] { "%x%", numberFormat
/* 412 */                   .format(x), "%y%", numberFormat.format(y), "%z%", numberFormat.format(z) }));
/*     */         } else {
/* 414 */           sender.sendMessage("§%command-only-for-console%§");
/*     */         } 
/*     */         return;
/*     */     } 
/* 418 */     sender.sendMessage(sender.getLanguage().t("command-teleport-usage", new String[] { "%label%", cmdArgs.getLabel() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Command(name = "setlocation", permission = "command.location", console = false)
/*     */   public void setlocationCommand(CommandArgs cmdArgs) {
/* 426 */     String[] args = cmdArgs.getArgs();
/* 427 */     BukkitMember member = (BukkitMember)cmdArgs.getSender();
/*     */     
/* 429 */     if (args.length == 0) {
/* 430 */       member.sendMessage("§aUse /" + cmdArgs.getLabel() + " <locationName> para salvar a localização.");
/*     */       
/*     */       return;
/*     */     } 
/* 434 */     String string = Joiner.on(' ').join(Arrays.copyOfRange((Object[])args, 0, args.length)).toLowerCase();
/*     */     
/* 436 */     member.sendMessage("§aLocalização " + args[0] + " com sucesso!");
/* 437 */     BukkitCommon.getInstance().getLocationManager().saveAndLoadLocation(string.replace(' ', '_'), member
/* 438 */         .getPlayer().getLocation());
/*     */   }
/*     */   
/*     */   @Command(name = "stop", aliases = {"fechar"}, permission = "command.stop")
/*     */   public void stopCommand(CommandArgs cmdArgs) {
/* 443 */     CommandSender sender = cmdArgs.getSender();
/* 444 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 446 */     int time = 0;
/*     */     
/* 448 */     if (args.length >= 1) {
/* 449 */       OptionalInt optional = StringFormat.parseInt(args[0]);
/*     */       
/* 451 */       if (optional.isPresent()) {
/* 452 */         time = optional.getAsInt();
/*     */       } else {
/* 454 */         sender.sendMessage(sender.getLanguage().t("invalid-format-integer", new String[] { "%value%", args[0] }));
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 459 */     final String reason = (args.length >= 2) ? Joiner.on(' ').join(Arrays.copyOfRange((Object[])args, 2, args.length)) : "Sem motivo";
/*     */     
/* 461 */     final int t = time;
/*     */     
/* 463 */     (new BukkitRunnable()
/*     */       {
/* 465 */         int totalTime = t;
/*     */ 
/*     */         
/*     */         public void run() {
/* 469 */           if (this.totalTime <= -2) {
/* 470 */             Bukkit.getOnlinePlayers().forEach(player -> player.kickPlayer("§cServer closed."));
/* 471 */             Bukkit.shutdown();
/*     */             
/*     */             return;
/*     */           } 
/* 475 */           if (this.totalTime <= 0) {
/* 476 */             if (this.totalTime == 0) {
/* 477 */               Bukkit.getOnlinePlayers()
/* 478 */                 .forEach(player -> player.sendMessage(reason.equals("Sem motivo") ? Language.getLanguage(player.getUniqueId()).t("server-was-closed", new String[0]) : Language.getLanguage(player.getUniqueId()).t("server-was-closed-reason", new String[] { "%reason%", reason })));
/*     */             }
/*     */ 
/*     */ 
/*     */             
/* 483 */             if (Bukkit.getOnlinePlayers().isEmpty()) {
/* 484 */               Bukkit.shutdown();
/*     */             } else {
/* 486 */               Bukkit.getOnlinePlayers().forEach(player -> BukkitCommon.getInstance().sendPlayerToServer(player, true, new ServerType[] { CommonPlugin.getInstance().getServerType().getServerLobby(), ServerType.LOBBY }));
/*     */             } 
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 492 */           this.totalTime--;
/*     */         }
/* 495 */       }).runTaskTimer((Plugin)BukkitCommon.getInstance(), 20L, 20L);
/*     */   }
/*     */   
/*     */   @Command(name = "tps", aliases = {"ticks"}, permission = "command.tps")
/*     */   public void tpsCommand(CommandArgs cmdArgs) {
/* 500 */     CommandSender sender = cmdArgs.getSender();
/*     */     
/* 502 */     if ((cmdArgs.getArgs()).length == 0) {
/* 503 */       long usedMemory = (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 2L / 1048576L;
/* 504 */       long allocatedMemory = Runtime.getRuntime().totalMemory() / 1048576L;
/*     */       
/* 506 */       sender.sendMessage(" §aServidor " + CommonPlugin.getInstance().getServerId() + ":");
/* 507 */       sender.sendMessage("    §fPlayers: §7" + Bukkit.getOnlinePlayers().size() + " jogadores");
/* 508 */       sender.sendMessage("    §fMáximo de players: §7" + Bukkit.getMaxPlayers() + " jogadores");
/* 509 */       sender.sendMessage("    §fMemória: §7" + usedMemory + "/" + allocatedMemory + " MB");
/* 510 */       sender.sendMessage("    §fLigado há: §7" + DateUtils.formatDifference(sender.getLanguage(), (
/* 511 */             System.currentTimeMillis() - ManagementFactory.getRuntimeMXBean().getStartTime()) / 1000L));
/* 512 */       sender.sendMessage("    §fTPS: ");
/* 513 */       sender.sendMessage("      §f1m: §7" + format((MinecraftServer.getServer()).recentTps[0]));
/* 514 */       sender.sendMessage("      §f5m: §7" + format((MinecraftServer.getServer()).recentTps[1]));
/* 515 */       sender.sendMessage("      §f15m: §7" + format((MinecraftServer.getServer()).recentTps[2]));
/*     */       
/* 517 */       int ping = 0;
/* 518 */       Map<ProtocolVersion, Integer> map = new HashMap<>();
/*     */       
/* 520 */       for (Player player : Bukkit.getOnlinePlayers()) {
/* 521 */         ping += ProtocolVersion.getPing(player);
/*     */         
/* 523 */         ProtocolVersion version = ProtocolVersion.getProtocolVersion(player);
/*     */         
/* 525 */         map.putIfAbsent(version, Integer.valueOf(0));
/* 526 */         map.put(version, Integer.valueOf(((Integer)map.get(version)).intValue() + 1));
/*     */       } 
/*     */       
/* 529 */       ping /= Math.max(Bukkit.getOnlinePlayers().size(), 1);
/*     */       
/* 531 */       sender.sendMessage("    §fPing médio: §7" + ping + "ms");
/* 532 */       if (!Bukkit.getOnlinePlayers().isEmpty()) {
/* 533 */         sender.sendMessage("    §fVersão: §7");
/*     */         
/* 535 */         for (Map.Entry<ProtocolVersion, Integer> entry : map.entrySet()) {
/* 536 */           sender.sendMessage("      §f- " + ((ProtocolVersion)entry.getKey()).name().replace("MINECRAFT_", "").replace("_", ".") + ": §7" + entry
/* 537 */               .getValue() + " jogadores");
/*     */         }
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 544 */     if (cmdArgs.getArgs()[0].equalsIgnoreCase("gc")) {
/* 545 */       Runtime.getRuntime().gc();
/* 546 */       sender.sendMessage(" §a» §fVocê passou o GarbargeCollector no servidor.");
/*     */     } else {
/* 548 */       World world = Bukkit.getWorld(cmdArgs.getArgs()[0]);
/*     */       
/* 550 */       if (world == null) {
/* 551 */         sender.sendMessage(" §c» §fO mundo " + cmdArgs.getArgs()[0] + " não existe.");
/*     */       } else {
/* 553 */         sender.sendMessage(" §aMundo " + world.getName());
/* 554 */         sender.sendMessage("    §fEntidades: §7" + world.getEntities().size());
/* 555 */         sender.sendMessage("    §fLoaded chunks: §7" + (world.getLoadedChunks()).length);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @Command(name = "memoryinfo", permission = "command.tps")
/*     */   public void memoryinfoCommand(CommandArgs cmdArgs) {
/* 562 */     long usedMemory = (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 2L / 1048576L;
/* 563 */     long allocatedMemory = Runtime.getRuntime().totalMemory() / 1048576L;
/*     */     
/* 565 */     cmdArgs.getSender().sendMessage("  §aMemory Info:");
/* 566 */     cmdArgs.getSender().sendMessage("    §fMemória usada: §7" + usedMemory + "MB (" + (usedMemory * 100L / allocatedMemory) + "%)");
/*     */     
/* 568 */     cmdArgs.getSender().sendMessage("    §fMemória livre: §7" + (allocatedMemory - usedMemory) + "MB (" + ((allocatedMemory - usedMemory) * 100L / allocatedMemory) + "%)");
/*     */     
/* 570 */     cmdArgs.getSender().sendMessage("    §fMemória máxima: §7" + allocatedMemory + "MB");
/* 571 */     cmdArgs.getSender()
/* 572 */       .sendMessage("    §fCPU: §7" + CommonConst.DECIMAL_FORMAT.format(CommonConst.getCpuUse()) + "%");
/*     */   }
/*     */   
/*     */   private String format(double tps) {
/* 576 */     return ((tps > 18.0D) ? (String)ChatColor.GREEN : ((tps > 16.0D) ? (String)ChatColor.YELLOW : (String)ChatColor.RED)) + ((tps > 20.0D) ? "*" : "") + 
/*     */       
/* 578 */       Math.min(Math.round(tps * 100.0D) / 100.0D, 20.0D);
/*     */   }
/*     */   
/*     */   @Completer(name = "party")
/*     */   public List<String> partyCompleter(CommandArgs cmdArgs) {
/* 583 */     List<String> returnList = new ArrayList<>();
/*     */     
/* 585 */     if ((cmdArgs.getArgs()).length == 1) {
/* 586 */       List<String> arguments = Arrays.asList(new String[] { "criar", "convidar", "aceitar", "expulsar", "sair", "chat" });
/*     */       
/* 588 */       if (cmdArgs.getArgs()[0].isEmpty()) {
/* 589 */         for (String argument : arguments)
/* 590 */           returnList.add(argument); 
/*     */       } else {
/* 592 */         for (String argument : arguments) {
/* 593 */           if (argument.toLowerCase().startsWith(cmdArgs.getArgs()[0].toLowerCase()))
/* 594 */             returnList.add(argument); 
/*     */         } 
/* 596 */         for (Player player : Bukkit.getOnlinePlayers()) {
/* 597 */           if (player.getName().toLowerCase().startsWith(cmdArgs.getArgs()[0].toLowerCase()))
/* 598 */             returnList.add(player.getName()); 
/*     */         } 
/*     */       } 
/*     */     } 
/* 602 */     return returnList;
/*     */   }
/*     */   
/*     */   @Completer(name = "servermanager", aliases = {"ss", "smanager"})
/*     */   public List<String> servermanagerCompleter(CommandArgs cmdArgs) {
/* 607 */     List<String> returnList = new ArrayList<>();
/*     */     
/* 609 */     if ((cmdArgs.getArgs()).length == 1) {
/* 610 */       List<String> arguments = Arrays.asList(new String[] { "reload-config", "save-config" });
/*     */       
/* 612 */       if (cmdArgs.getArgs()[0].isEmpty()) {
/* 613 */         for (String argument : arguments)
/* 614 */           returnList.add(argument); 
/*     */       } else {
/* 616 */         for (String argument : arguments) {
/* 617 */           if (argument.toLowerCase().startsWith(cmdArgs.getArgs()[0].toLowerCase()))
/* 618 */             returnList.add(argument); 
/*     */         } 
/*     */       } 
/*     */     } 
/* 622 */     return returnList;
/*     */   }
/*     */   
/*     */   @Completer(name = "setlocation")
/*     */   public List<String> serverCompleter(CommandArgs cmdArgs) {
/* 627 */     if (cmdArgs.isPlayer() && (
/* 628 */       cmdArgs.getArgs()).length == 1) {
/* 629 */       List<String> arg = new ArrayList<>();
/*     */       
/* 631 */       if (cmdArgs.getArgs()[0].isEmpty()) {
/* 632 */         for (String tag : BukkitCommon.getInstance().getLocationManager().getLocations())
/* 633 */           arg.add(tag); 
/*     */       } else {
/* 635 */         for (String tag : BukkitCommon.getInstance().getLocationManager().getLocations()) {
/* 636 */           if (tag.startsWith(cmdArgs.getArgs()[0].toLowerCase()))
/* 637 */             arg.add(tag); 
/*     */         } 
/*     */       } 
/* 640 */       return arg;
/*     */     } 
/*     */     
/* 643 */     return new ArrayList<>();
/*     */   }
/*     */   
/*     */   @Completer(name = "gamemode", aliases = {"gm"})
/*     */   public List<String> gamemodeCompleter(CommandArgs cmdArgs) {
/* 648 */     List<String> returnList = new ArrayList<>();
/*     */     
/* 650 */     if ((cmdArgs.getArgs()).length == 1) {
/* 651 */       returnList.addAll((Collection<? extends String>)Arrays.<GameMode>asList(GameMode.values()).stream()
/* 652 */           .filter(gameMode -> gameMode.name().toLowerCase().startsWith(cmdArgs.getArgs()[0].toLowerCase()))
/* 653 */           .map(Enum::name).collect(Collectors.toList()));
/* 654 */     } else if ((cmdArgs.getArgs()).length == 2) {
/* 655 */       returnList.addAll((Collection<? extends String>)Bukkit.getOnlinePlayers().stream()
/* 656 */           .filter(player -> player.getName().toLowerCase().startsWith(cmdArgs.getArgs()[1].toLowerCase()))
/* 657 */           .map(OfflinePlayer::getName).collect(Collectors.toList()));
/*     */     } 
/* 659 */     return returnList;
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/command/register/ServerCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */