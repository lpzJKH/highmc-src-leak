/*     */ package net.highmc.bukkit.command.register;
/*     */ 
/*     */ import com.comphenix.protocol.wrappers.WrappedSignedProperty;
/*     */ import com.google.common.base.Joiner;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import java.util.stream.Collectors;
/*     */ import net.highmc.BukkitConst;
/*     */ import net.highmc.CommonConst;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.command.BukkitCommandSender;
/*     */ import net.highmc.bukkit.member.BukkitMember;
/*     */ import net.highmc.bukkit.menu.profile.PreferencesInventory;
/*     */ import net.highmc.bukkit.menu.profile.ProfileInventory;
/*     */ import net.highmc.bukkit.utils.player.PlayerAPI;
/*     */ import net.highmc.command.CommandArgs;
/*     */ import net.highmc.command.CommandClass;
/*     */ import net.highmc.command.CommandFramework.Command;
/*     */ import net.highmc.command.CommandFramework.Completer;
/*     */ import net.highmc.command.CommandSender;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.member.Profile;
/*     */ import net.highmc.member.configuration.LoginConfiguration;
/*     */ import net.highmc.permission.Group;
/*     */ import net.highmc.permission.GroupInfo;
/*     */ import net.highmc.permission.Tag;
/*     */ import net.highmc.punish.Punish;
/*     */ import net.highmc.punish.PunishType;
/*     */ import net.highmc.utils.DateUtils;
/*     */ import net.highmc.utils.skin.Skin;
/*     */ import net.highmc.utils.string.MessageBuilder;
/*     */ import net.highmc.utils.string.StringFormat;
/*     */ import net.md_5.bungee.api.chat.BaseComponent;
/*     */ import net.md_5.bungee.api.chat.ClickEvent;
/*     */ import net.md_5.bungee.api.chat.HoverEvent;
/*     */ import net.md_5.bungee.api.chat.TextComponent;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProfileCommand
/*     */   implements CommandClass
/*     */ {
/*     */   @Command(name = "block", console = false)
/*     */   public void blockCommand(CommandArgs cmdArgs) {
/*  54 */     Member sender = cmdArgs.getSenderAsMember();
/*  55 */     String[] args = cmdArgs.getArgs();
/*     */     
/*  57 */     if (args.length == 0) {
/*  58 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " <player>§f para bloquear um jogador.");
/*     */       
/*     */       return;
/*     */     } 
/*  62 */     Member target = CommonPlugin.getInstance().getMemberManager().getMemberByName(cmdArgs.getArgs()[0]);
/*     */     
/*  64 */     if (target == null) {
/*  65 */       target = CommonPlugin.getInstance().getMemberData().loadMember(cmdArgs.getArgs()[0], true);
/*     */       
/*  67 */       if (target == null) {
/*  68 */         sender.sendMessage(sender.getLanguage().t("account-doesnt-exist", new String[] { "%player%", cmdArgs.getArgs()[0] }));
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*  73 */     if (sender.isUserBlocked(Profile.from((CommandSender)target))) {
/*  74 */       sender.sendMessage("§cO jogador " + target.getName() + " já está bloqueado.");
/*     */       
/*     */       return;
/*     */     } 
/*  78 */     sender.sendMessage("§aVocê bloqueou o jogador " + target.getName() + ".");
/*  79 */     sender.block(Profile.from((CommandSender)target));
/*     */   }
/*     */   
/*     */   @Command(name = "unblock", console = false)
/*     */   public void unblockCommand(CommandArgs cmdArgs) {
/*  84 */     Member sender = cmdArgs.getSenderAsMember();
/*  85 */     String[] args = cmdArgs.getArgs();
/*     */     
/*  87 */     if (args.length == 0) {
/*  88 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " <player>§f para desbloquear um jogador.");
/*     */       
/*     */       return;
/*     */     } 
/*  92 */     Member target = CommonPlugin.getInstance().getMemberManager().getMemberByName(cmdArgs.getArgs()[0]);
/*     */     
/*  94 */     if (target == null) {
/*  95 */       target = CommonPlugin.getInstance().getMemberData().loadMember(cmdArgs.getArgs()[0], true);
/*     */       
/*  97 */       if (target == null) {
/*  98 */         sender.sendMessage(sender.getLanguage().t("account-doesnt-exist", new String[] { "%player%", cmdArgs.getArgs()[0] }));
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 103 */     if (!sender.isUserBlocked(Profile.from((CommandSender)target))) {
/* 104 */       sender.sendMessage("§cO jogador " + target.getName() + " não está bloqueado.");
/*     */       
/*     */       return;
/*     */     } 
/* 108 */     sender.sendMessage("§aVocê desbloqueou o jogador " + target.getName() + ".");
/* 109 */     sender.unblock(Profile.from((CommandSender)target));
/*     */   }
/*     */   
/*     */   @Command(name = "ping", console = false)
/*     */   public void pingCommand(CommandArgs cmdArgs) {
/* 114 */     BukkitMember member = (BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class);
/* 115 */     member.sendMessage("§aSeu ping é " + (((CraftPlayer)member.getPlayer()).getHandle()).ping + "ms.");
/*     */   }
/*     */   
/*     */   @Command(name = "tell")
/*     */   public void tellCommand(CommandArgs cmdArgs) {
/* 120 */     CommandSender sender = cmdArgs.getSender();
/* 121 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 123 */     if (args.length <= 1) {
/* 124 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " <player> <message>§f para enviar uma mensagem para um jogador.");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 129 */     switch (args[0].toLowerCase()) {
/*     */       case "on":
/* 131 */         sender.setTellEnabled(true);
/* 132 */         sender.sendMessage("§aVocê agora receberá mensagens privadas.");
/*     */         return;
/*     */       
/*     */       case "off":
/* 136 */         sender.setTellEnabled(false);
/* 137 */         sender.sendMessage("§cVocê agora não receberá mais mensagens privadas.");
/*     */         return;
/*     */     } 
/*     */     
/* 141 */     if (sender instanceof Member) {
/* 142 */       Member member = (Member)sender;
/* 143 */       Punish punish = member.getPunishConfiguration().getActualPunish(PunishType.MUTE);
/*     */       
/* 145 */       if (punish != null) {
/* 146 */         member.sendMessage((BaseComponent)(new MessageBuilder(punish.getMuteMessage(member.getLanguage())))
/* 147 */             .setHoverEvent("§fPunido em: §7" + CommonConst.DATE_FORMAT.format(Long.valueOf(punish.getCreatedAt())) + "\n§fExpire em: §7" + (
/*     */               
/* 149 */               punish.isPermanent() ? "§cnunca" : 
/* 150 */               DateUtils.formatDifference(member.getLanguage(), punish
/* 151 */                 .getExpireAt() / 1000L)))
/* 152 */             .create());
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 159 */     CommandSender target = args[0].equalsIgnoreCase("console") ? (CommandSender)new BukkitCommandSender((CommandSender)Bukkit.getConsoleSender()) : (CommandSender)CommonPlugin.getInstance().getMemberManager().getMemberByName(args[0]);
/*     */     
/* 161 */     if (target == null) {
/* 162 */       sender.sendMessage(sender.getLanguage().t("player-is-not-online", new String[] { "%player%", args[0] }));
/*     */       
/*     */       return;
/*     */     } 
/* 166 */     if (target.isUserBlocked(Profile.from(sender))) {
/* 167 */       sender.sendMessage("§cO jogador " + target.getName() + " bloqueou você.");
/*     */       
/*     */       return;
/*     */     } 
/* 171 */     if (!target.isTellEnabled() && !sender.hasPermission("command.admin")) {
/* 172 */       sender.sendMessage("§cO jogador " + target
/* 173 */           .getName() + " não está recebendo mensagens privadas no momento.");
/*     */       
/*     */       return;
/*     */     } 
/* 177 */     sendMessage(sender, target, Joiner.on(' ').join(Arrays.copyOfRange((Object[])args, 1, args.length)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Command(name = "reply", aliases = {"r"})
/*     */   public void replyCommand(CommandArgs cmdArgs) {
/* 185 */     CommandSender sender = cmdArgs.getSender();
/* 186 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 188 */     if (args.length == 0) {
/* 189 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs
/* 190 */           .getLabel() + " <message>§f para enviar uma mensagem para um jogador.");
/*     */       
/*     */       return;
/*     */     } 
/* 194 */     if (!sender.hasReply()) {
/* 195 */       sender.sendMessage("§cVocê não possui mensagem para responder.");
/*     */       
/*     */       return;
/*     */     } 
/* 199 */     if (sender instanceof Member) {
/* 200 */       Member member = (Member)sender;
/* 201 */       Punish punish = member.getPunishConfiguration().getActualPunish(PunishType.MUTE);
/*     */       
/* 203 */       if (punish != null) {
/* 204 */         member.sendMessage((BaseComponent)(new MessageBuilder(punish
/* 205 */               .getMuteMessage(member.getLanguage()))).setHoverEvent("§fPunido em: §7" + CommonConst.DATE_FORMAT
/* 206 */               .format(Long.valueOf(punish.getCreatedAt())) + "\n§fExpire em: §7" + (
/* 207 */               punish.isPermanent() ? "§cnunca" : 
/* 208 */               DateUtils.formatDifference(member.getLanguage(), punish
/* 209 */                 .getExpireAt() / 1000L)))
/* 210 */             .create());
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 216 */     CommandSender target = (sender.getReplyId() == CommonConst.CONSOLE_ID) ? BukkitConst.CONSOLE_SENDER : (CommandSender)CommonPlugin.getInstance().getMemberManager().getMember(sender.getReplyId());
/*     */     
/* 218 */     if (target == null) {
/* 219 */       sender.sendMessage("§cO último jogador que você te mandou mensagem não está mais online.");
/*     */       
/*     */       return;
/*     */     } 
/* 223 */     if (target.isUserBlocked(Profile.from(sender))) {
/* 224 */       sender.sendMessage("§cO jogador " + target.getName() + " bloqueou você.");
/*     */       
/*     */       return;
/*     */     } 
/* 228 */     sendMessage(sender, target, Joiner.on(' ').join(Arrays.copyOfRange((Object[])args, 0, args.length)));
/*     */   }
/*     */   
/*     */   @Command(name = "profile", aliases = {"perfil"}, console = false)
/*     */   public void profileCommand(CommandArgs cmdArgs) {
/* 233 */     new ProfileInventory(((BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class)).getPlayer());
/*     */   }
/*     */   
/*     */   @Command(name = "preferences", aliases = {"pref", "prefs", "preferencias"}, console = false)
/*     */   public void preferencesCommand(CommandArgs cmdArgs) {
/* 238 */     new PreferencesInventory(((BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class)).getPlayer());
/*     */   }
/*     */   
/*     */   @Command(name = "account", aliases = {"acc"}, runAsync = true)
/*     */   public void accountCommand(CommandArgs cmdArgs) {
/* 243 */     CommandSender sender = cmdArgs.getSender();
/* 244 */     Member member = cmdArgs.isPlayer() ? cmdArgs.getSenderAsMember() : null;
/*     */     
/* 246 */     if (!cmdArgs.isPlayer() && (cmdArgs.getArgs()).length == 0) {
/* 247 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " <player>§f para ver o perfil de alguém.");
/*     */       
/*     */       return;
/*     */     } 
/* 251 */     if ((cmdArgs.getArgs()).length >= 1) {
/* 252 */       if (sender.hasPermission("command.admin")) {
/* 253 */         member = CommonPlugin.getInstance().getMemberManager().getMemberByName(cmdArgs.getArgs()[0]);
/*     */         
/* 255 */         if (member == null) {
/* 256 */           member = CommonPlugin.getInstance().getMemberData().loadMember(cmdArgs.getArgs()[0], true);
/*     */           
/* 258 */           if (member == null) {
/* 259 */             sender.sendMessage(sender
/* 260 */                 .getLanguage().t("account-doesnt-exist", new String[] { "%player%", cmdArgs.getArgs()[0] }));
/*     */             return;
/*     */           } 
/*     */         } 
/*     */       } else {
/* 265 */         sender.sendMessage("§cVocê não tem permissão para visualizar o perfil de outros jogadores.");
/*     */         
/*     */         return;
/*     */       } 
/*     */     }
/* 270 */     Group actualGroup = member.getServerGroup();
/* 271 */     GroupInfo groupInfo = member.getServerGroup(actualGroup.getGroupName());
/*     */     
/* 273 */     sender.sendMessage(" ");
/* 274 */     sender.sendMessage("§a  " + (
/* 275 */         (sender.getUniqueId() == member.getUniqueId()) ? "Sua conta" : ("Conta do " + member.getPlayerName())));
/* 276 */     sender.sendMessage("    §fPrimeiro login: §7" + CommonPlugin.getInstance().formatTime(member.getFirstLogin()));
/* 277 */     sender.sendMessage("    §fUltimo login: §7" + 
/* 278 */         CommonPlugin.getInstance().formatTime(member.getLastLogin()) + (
/*     */         
/* 280 */         member.isOnline() ? "" : (" (há " + 
/*     */ 
/*     */         
/* 283 */         DateUtils.formatDifference(sender.getLanguage(), (
/* 284 */           System.currentTimeMillis() - member.getLastLogin()) / 1000L) + ")")));
/*     */     
/* 286 */     sender.sendMessage("    §fTempo total de jogo: §7" + 
/* 287 */         DateUtils.formatDifference(sender.getLanguage(), member.getOnlineTime() / 1000L));
/* 288 */     sender.sendMessage("    §fTipo de conta: §7" + StringFormat.formatString(member.getLoginConfiguration().getAccountType().name()));
/*     */     
/* 290 */     sender.sendMessage(" ");
/* 291 */     sender.sendMessage((BaseComponent)(new MessageBuilder("    §fGrupo principal: §7" + 
/* 292 */           StringFormat.formatString(actualGroup.getGroupName())))
/* 293 */         .setHoverEvent("§aGrupo principal " + StringFormat.formatString(actualGroup.getGroupName()) + "\n\n  §fAutor: §7" + groupInfo
/* 294 */           .getAuthorName() + "\n  §fData: §7" + CommonConst.DATE_FORMAT
/* 295 */           .format(Long.valueOf(groupInfo.getGivenDate())) + "\n  §fExpire em: §7" + (
/* 296 */           groupInfo.isPermanent() ? "Nunca" : 
/* 297 */           DateUtils.getTime(sender.getLanguage(), groupInfo.getExpireTime())) + "\n\n§eClique para ver informações do grupo.")
/*     */         
/* 299 */         .setClickEvent("/group info " + actualGroup.getGroupName()).create());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 304 */     List<Group> list = (List<Group>)member.getGroups().keySet().stream().filter(groupName -> !actualGroup.getGroupName().equals(groupName)).map(groupName -> CommonPlugin.getInstance().getPluginInfo().getGroupByName(groupName)).collect(Collectors.toList());
/*     */     
/* 306 */     if (!list.isEmpty()) {
/* 307 */       MessageBuilder messageBuilder = new MessageBuilder("    §fGrupos adicionais: §7");
/*     */       
/* 309 */       Set<Map.Entry<String, GroupInfo>> entrySet = new HashSet<>(member.getGroups().entrySet());
/*     */       
/* 311 */       entrySet.removeIf(entry -> ((String)entry.getKey()).equalsIgnoreCase(actualGroup.getGroupName()));
/*     */       
/* 313 */       int i = 1;
/* 314 */       for (Map.Entry<String, GroupInfo> entry : entrySet) {
/* 315 */         messageBuilder.extra((new MessageBuilder("§7" + 
/* 316 */               StringFormat.formatString(entry.getKey()) + ((i == entrySet.size()) ? "§f." : "§f, §7")))
/* 317 */             .setHoverEvent("§aGrupo " + StringFormat.formatString(entry.getKey()) + "\n\n  §fAutor: §7" + ((GroupInfo)entry
/* 318 */               .getValue()).getAuthorName() + "\n  §fData: §7" + CommonConst.DATE_FORMAT
/* 319 */               .format(Long.valueOf(((GroupInfo)entry.getValue()).getGivenDate())) + "\n  §fExpire em: §7" + (
/*     */               
/* 321 */               ((GroupInfo)entry.getValue()).isPermanent() ? "Nunca" : 
/* 322 */               DateUtils.getTime(sender.getLanguage(), ((GroupInfo)entry.getValue()).getExpireTime())) + "\n\n§eClique para ver informações do grupo.")
/*     */             
/* 324 */             .setClickEvent("/group info " + (String)entry.getKey()).create());
/* 325 */         i++;
/*     */       } 
/*     */       
/* 328 */       sender.sendMessage((BaseComponent)messageBuilder.create());
/*     */     } 
/*     */     
/* 331 */     if (sender.isStaff() || sender.getUniqueId() == member.getUniqueId()) {
/* 332 */       if (!member.getPermissions().isEmpty()) {
/* 333 */         sender.sendMessage("    §fPermissões: §7" + Joiner.on(", ").join(member.getPermissions()));
/*     */       }
/* 335 */       if (member.getLastIpAddress() != null && sender
/* 336 */         .getServerGroup().getId() >= member.getServerGroup().getId()) {
/* 337 */         sender.sendMessage("");
/* 338 */         sender.sendMessage("    §fEndereço ip: §7" + member.getLastIpAddress());
/*     */       } 
/*     */     } 
/*     */     
/* 342 */     if (member.isOnline()) {
/* 343 */       if (member.getLastIpAddress() == null || sender.getServerGroup().getId() < member.getServerGroup().getId())
/* 344 */         sender.sendMessage(""); 
/* 345 */       sender.sendMessage((BaseComponent)(new MessageBuilder("    §fServidor atual: §7" + member.getActualServerId()))
/* 346 */           .setClickEvent(ClickEvent.Action.SUGGEST_COMMAND, "/connect " + member.getActualServerId())
/* 347 */           .setHoverEvent("§aClique para ir ao servidor.").create());
/* 348 */       sender.sendMessage("    §fTempo da sessão atual: §7" + 
/* 349 */           DateUtils.formatDifference(sender.getLanguage(), member.getSessionTime() / 1000L));
/* 350 */       sender.sendMessage("    §aO jogador está online no momento.");
/*     */     } else {
/* 352 */       sender.sendMessage("    §cO jogador está offline no momento.");
/*     */     } 
/* 354 */     sender.sendMessage("");
/*     */   }
/*     */ 
/*     */   
/*     */   @Command(name = "tag", runAsync = true, console = false)
/*     */   public void tagCommand(CommandArgs cmdArgs) {
/* 360 */     BukkitMember bukkitMember = (BukkitMember)cmdArgs.getSender();
/* 361 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 363 */     if (args.length == 0) {
/*     */       
/* 365 */       List<Tag> tags = (List<Tag>)CommonPlugin.getInstance().getPluginInfo().getTagMap().values().stream().filter(tag -> player.hasTag(tag)).collect(Collectors.toList());
/*     */       
/* 367 */       if (tags.isEmpty()) {
/*     */         
/* 369 */         bukkitMember.sendMessage("§cVocê não possui nenhuma tag.");
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 374 */       TextComponent message = new TextComponent("§aSelecione sua tag: ");
/*     */       
/* 376 */       int max = tags.size() * 2;
/* 377 */       int i = max - 1;
/*     */       
/* 379 */       for (Tag t : tags) {
/* 380 */         if (i < max - 1) {
/* 381 */           message.addExtra((BaseComponent)new TextComponent("§f, "));
/* 382 */           i--;
/*     */         } 
/*     */         
/* 385 */         message.addExtra((BaseComponent)(new MessageBuilder(t.getStrippedColor().toUpperCase()))
/* 386 */             .setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, (BaseComponent[])new TextComponent[] {
/* 387 */                   new TextComponent("§fExemplo: " + t.getRealPrefix() + bukkitMember
/* 388 */                     .getPlayerName() + "\n\n§aClique para selecionar!")
/* 389 */                 })).setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/tag " + t
/* 390 */                 .getTagName()))
/* 391 */             .create());
/* 392 */         i--;
/*     */       } 
/*     */       
/* 395 */       bukkitMember.sendMessage((BaseComponent)message);
/*     */       
/*     */       return;
/*     */     } 
/* 399 */     if (args[0].equalsIgnoreCase("default") || args[0].equalsIgnoreCase("normal")) {
/* 400 */       if (bukkitMember.setTag(bukkitMember.getDefaultTag())) {
/* 401 */         bukkitMember.sendMessage(" §a» §fVocê alterou sua tag para " + bukkitMember
/* 402 */             .getDefaultTag().getStrippedColor() + "§f.");
/*     */       }
/*     */       return;
/*     */     } 
/* 406 */     Tag tag = CommonPlugin.getInstance().getPluginInfo().getTagByName(args[0]);
/*     */     
/* 408 */     if (tag == null) {
/* 409 */       bukkitMember.sendMessage(" §4» §fA tag " + args[0] + " não existe!");
/*     */       
/*     */       return;
/*     */     } 
/* 413 */     if (bukkitMember.hasTag(tag)) {
/* 414 */       if (!bukkitMember.getTag().equals(tag)) {
/* 415 */         bukkitMember.setTag(tag);
/*     */       }
/* 417 */       bukkitMember.sendMessage("§aSua tag foi alterada para " + tag.getStrippedColor() + "§a.");
/*     */     } else {
/* 419 */       bukkitMember.sendMessage("§cVocê não tem permissão para usar essa tag.");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Command(name = "fake.#", aliases = {"nick.#", "nickreset", "fakereset", "fake.reset", "nick.reset"}, permission = "command.fake", console = false)
/*     */   public void fakeresetCommand(CommandArgs cmdArgs) {
/* 426 */     BukkitMember sender = (BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class);
/*     */     
/* 428 */     if (!sender.isUsingFake()) {
/* 429 */       sender.sendMessage("§cVocê não está usando fake.");
/*     */       
/*     */       return;
/*     */     } 
/* 433 */     if (!sender.hasCustomSkin()) {
/* 434 */       PlayerAPI.changePlayerSkin(sender.getPlayer(), sender.getName(), sender.getUniqueId(), false);
/*     */     }
/*     */     
/* 437 */     Player player = sender.getPlayer();
/* 438 */     PlayerAPI.changePlayerSkin(player, player.getName(), player.getUniqueId(), false);
/* 439 */     PlayerAPI.changePlayerName(player, sender.getName(), true);
/* 440 */     sender.setFakeName(sender.getPlayerName());
/* 441 */     sender.setTag(sender.getDefaultTag());
/* 442 */     sender.sendMessage("§aSeu fake foi removido com sucesso.");
/*     */   }
/*     */   
/*     */   @Command(name = "fake", aliases = {"nick"}, runAsync = true, permission = "command.fake", console = false)
/*     */   public void fakeCommand(CommandArgs cmdArgs) {
/* 447 */     BukkitMember sender = (BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class);
/* 448 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 450 */     if (args.length == 0) {
/* 451 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " <player>§f para alterar sua skin.");
/*     */       
/*     */       return;
/*     */     } 
/* 455 */     if (sender.hasCooldown("fake.command") && !sender.hasPermission("command.admin")) {
/* 456 */       sender.sendMessage("§cVocê precisa esperar " + sender.getCooldownFormatted("fake.command") + " para usar eses comando novamente.");
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 462 */     String playerName = args[0].equals("random") ? BukkitConst.RANDOM.get(CommonConst.RANDOM.nextInt(BukkitConst.RANDOM.size())) : args[0];
/*     */ 
/*     */     
/* 465 */     if (!PlayerAPI.validateName(playerName)) {
/* 466 */       sender.sendMessage("§cO nome inserido é inválido.");
/*     */       
/*     */       return;
/*     */     } 
/* 470 */     UUID uniqueId = CommonPlugin.getInstance().getUuidFetcher().request(playerName);
/*     */     
/* 472 */     if (uniqueId != null) {
/* 473 */       sender.sendMessage("§cVocê não pode usar fake de uma conta registrada na mojang, tente outro nick.");
/*     */       
/*     */       return;
/*     */     } 
/* 477 */     if (CommonPlugin.getInstance().getMemberData().loadMember(playerName, true) != null) {
/* 478 */       sender.sendMessage("§cVocê não pode usar fake de uma conta já registrada no servidor, tente outro nick.");
/*     */       
/*     */       return;
/*     */     } 
/* 482 */     if (Bukkit.getPlayerExact(playerName) != null) {
/* 483 */       sender.sendMessage("§cVocê não pode usar o fake do " + playerName + ". 3");
/*     */       
/*     */       return;
/*     */     } 
/* 487 */     if (!sender.isCustomSkin()) {
/* 488 */       CommonPlugin.getInstance().getMemberManager().getMembers().stream()
/* 489 */         .filter(member -> (member.hasCustomSkin() || member.getLoginConfiguration().getAccountType() == LoginConfiguration.AccountType.PREMIUM))
/*     */         
/* 491 */         .findFirst().ifPresent(member -> {
/*     */             if (member.isCustomSkin()) {
/*     */               sender.setSkin(member.getSkin());
/*     */ 
/*     */               
/*     */               PlayerAPI.changePlayerSkin(sender.getPlayer(), member.getSkin().getValue(), member.getSkin().getSignature(), false);
/*     */             } else {
/*     */               WrappedSignedProperty changePlayerSkin = PlayerAPI.changePlayerSkin(sender.getPlayer(), member.getName(), member.getUniqueId(), false);
/*     */               
/*     */               sender.setSkin(new Skin(member.getName(), member.getUniqueId(), changePlayerSkin.getValue(), changePlayerSkin.getSignature()));
/*     */             } 
/*     */           });
/*     */     }
/*     */     
/* 505 */     PlayerAPI.changePlayerName(sender.getPlayer(), playerName, true);
/* 506 */     sender.setFakeName(playerName);
/* 507 */     sender.setTag(CommonPlugin.getInstance().getPluginInfo().getDefaultTag());
/* 508 */     sender.sendMessage("§aSeu nick foi alterada para " + playerName + ".");
/* 509 */     sender.putCooldown("command.fake", 30L);
/*     */   }
/*     */   
/*     */   @Completer(name = "tag")
/*     */   public List<String> tagCompleter(CommandArgs cmdArgs) {
/* 514 */     if (cmdArgs.isPlayer() && (
/* 515 */       cmdArgs.getArgs()).length == 1) {
/* 516 */       List<String> tagList = new ArrayList<>();
/*     */       
/* 518 */       BukkitMember member = (BukkitMember)CommonPlugin.getInstance().getMemberManager().getMember(cmdArgs.getSender().getUniqueId());
/*     */       
/* 520 */       if (cmdArgs.getArgs()[0].isEmpty())
/* 521 */       { for (Tag tag : CommonPlugin.getInstance().getPluginInfo().getTags()) {
/* 522 */           if (member.hasTag(tag))
/* 523 */             tagList.add(tag.getTagName().toLowerCase()); 
/*     */         }  }
/* 525 */       else { for (Tag tag : CommonPlugin.getInstance().getPluginInfo().getTags()) {
/* 526 */           if (member.hasTag(tag) && tag
/* 527 */             .getTagName().toLowerCase().startsWith(cmdArgs.getArgs()[0].toLowerCase()))
/* 528 */             tagList.add(tag.getTagName().toLowerCase()); 
/*     */         }  }
/*     */       
/* 531 */       return tagList;
/*     */     } 
/*     */     
/* 534 */     return new ArrayList<>();
/*     */   }
/*     */   
/*     */   public void sendMessage(CommandSender sender, CommandSender target, String message) {
/* 538 */     sender.sendMessage("§7[" + sender.getName() + " -> " + target.getName() + "] " + message);
/* 539 */     target.sendMessage("§7[" + sender.getName() + " -> " + target.getName() + "] " + message);
/* 540 */     target.setReplyId(sender.getUniqueId());
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/command/register/ProfileCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */