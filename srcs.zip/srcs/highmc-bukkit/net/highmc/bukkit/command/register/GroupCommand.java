/*     */ package net.highmc.bukkit.command.register;
/*     */ 
/*     */ import com.google.common.base.Joiner;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.OptionalInt;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.bukkit.manager.ChatManager;
/*     */ import net.highmc.bukkit.member.BukkitMember;
/*     */ import net.highmc.bukkit.menu.group.MemberGroupListInventory;
/*     */ import net.highmc.command.CommandArgs;
/*     */ import net.highmc.command.CommandClass;
/*     */ import net.highmc.command.CommandFramework.Command;
/*     */ import net.highmc.command.CommandFramework.Completer;
/*     */ import net.highmc.command.CommandSender;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.permission.Group;
/*     */ import net.highmc.permission.GroupInfo;
/*     */ import net.highmc.permission.Tag;
/*     */ import net.highmc.utils.DateUtils;
/*     */ import net.highmc.utils.string.MessageBuilder;
/*     */ import net.highmc.utils.string.StringFormat;
/*     */ import net.highmc.utils.supertype.OptionalBoolean;
/*     */ import net.md_5.bungee.api.chat.BaseComponent;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GroupCommand
/*     */   implements CommandClass
/*     */ {
/*     */   @Command(name = "group", permission = "command.group")
/*     */   public void groupCommand(final CommandArgs cmdArgs) {
/*     */     Collection<Group> groupList;
/*     */     final Group g, group, group;
/*     */     String permission;
/*     */     boolean add, temp;
/*     */     long expireTime;
/*  51 */     CommandSender sender = cmdArgs.getSender();
/*  52 */     String[] args = cmdArgs.getArgs();
/*     */     
/*  54 */     if (args.length == 0) {
/*  55 */       sender.sendMessage(" §e» §fUse §a/group info§f para ver as informações do seu grupo.");
/*  56 */       sender.sendMessage(" §e» §fUse §a/group info <group>§f para ver as informações do grupo.");
/*  57 */       sender.sendMessage(" §e» §fUse §a/group playerlist <group>§f para ver as informações do grupo.");
/*  58 */       sender.sendMessage(" §e» §fUse §a/group list§f para listar os grupos.");
/*  59 */       sender.sendMessage("");
/*  60 */       sender.sendMessage(" §e» §fUse §a/group <player> add <group>§f para adicionar um grupo a alguém.");
/*  61 */       sender.sendMessage(" §e» §fUse §a/group <player> remove <group>§f para remover um grupo de alguém.");
/*  62 */       sender.sendMessage(" §e» §fUse §a/group <player> set <group>§f para setar um grupo a alguém.");
/*  63 */       sender.sendMessage("");
/*  64 */       sender.sendMessage(" §e» §fUse §a/group create <groupName>§f para criar um grupo.");
/*  65 */       sender.sendMessage(" §e» §fUse §a/group manager <groupName>§f para gerenciar um grupo.");
/*  66 */       sender.sendMessage(" §e» §fUse §a/group delete <groupName>§f para deletar um grupo.");
/*     */       
/*     */       return;
/*     */     } 
/*  70 */     switch (args[0].toLowerCase()) {
/*     */       case "list":
/*  72 */         groupList = CommonPlugin.getInstance().getPluginInfo().getGroupMap().values();
/*     */         
/*  74 */         sender.sendMessage("  §aGrupos disponíveis:");
/*     */         
/*  76 */         for (Group group3 : groupList) {
/*  77 */           sender.sendMessage((BaseComponent)(new MessageBuilder("    §f- " + 
/*  78 */                 StringFormat.formatString(group3.getGroupName())))
/*  79 */               .setHoverEvent("§fName: §7" + StringFormat.formatString(group3.getGroupName()) + "\n" + (
/*  80 */                 group3.getPermissions().isEmpty() ? "" : ("\n§fPermissions:\n  - §7" + 
/*     */                 
/*  82 */                 Joiner.on("\n  - §7").join(group3.getPermissions()))))
/*  83 */               .create());
/*     */         }
/*     */         return;
/*     */ 
/*     */       
/*     */       case "playerlist":
/*  89 */         if (!sender.isPlayer()) {
/*  90 */           sender.sendMessage("§cSomente jogadores podem executar esse comando.");
/*     */           
/*     */           return;
/*     */         } 
/*  94 */         if (!sender.hasPermission("command.group.playerlist")) {
/*  95 */           sender.sendMessage("§cVocê não tem permissão para executar esse argumento.");
/*     */           
/*     */           return;
/*     */         } 
/*  99 */         g = null;
/*     */         
/* 101 */         if (args.length == 1) {
/* 102 */           g = cmdArgs.getSenderAsMember().getServerGroup();
/*     */         } else {
/* 104 */           g = CommonPlugin.getInstance().getPluginInfo().getGroupByName(args[1]);
/*     */           
/* 106 */           if (g == null) {
/* 107 */             sender.sendMessage(sender.getLanguage().t("group-not-found", new String[] { "%group%", args[1] }));
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/* 112 */         group1 = g;
/* 113 */         sender.sendMessage("§aAguarde, isso pode demorar um pouco.");
/*     */         
/* 115 */         (new BukkitRunnable()
/*     */           {
/*     */             public void run()
/*     */             {
/* 119 */               final List<Member> memberList = CommonPlugin.getInstance().getMemberData().getMembersByGroup(group);
/*     */               
/* 121 */               (new BukkitRunnable()
/*     */                 {
/*     */                   public void run()
/*     */                   {
/* 125 */                     new MemberGroupListInventory(((BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class)).getPlayer(), group, memberList);
/*     */                   }
/* 128 */                 }).runTask((Plugin)BukkitCommon.getInstance());
/*     */             }
/* 130 */           }).runTaskAsynchronously((Plugin)BukkitCommon.getInstance());
/*     */         return;
/*     */       
/*     */       case "info":
/* 134 */         group = null;
/*     */         
/* 136 */         if (args.length == 1) {
/* 137 */           group = cmdArgs.getSenderAsMember().getServerGroup();
/*     */         } else {
/* 139 */           group = CommonPlugin.getInstance().getPluginInfo().getGroupByName(args[1]);
/*     */           
/* 141 */           if (group == null) {
/* 142 */             sender.sendMessage(sender.getLanguage().t("group-not-found", new String[] { "%group%", args[1] }));
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/* 147 */         sender.sendMessage("  §aGrupo " + StringFormat.formatString(group.getGroupName()));
/* 148 */         sender.sendMessage("    §fID: §7" + group.getId());
/* 149 */         sender.sendMessage("    §fPermissões:");
/*     */         
/* 151 */         for (String str : group.getPermissions()) {
/* 152 */           sender.sendMessage("      §f- §7" + str);
/*     */         }
/*     */         return;
/*     */       case "permission":
/* 156 */         if (!sender.hasPermission("command.group.create")) {
/* 157 */           sender.sendMessage("§cVocê não tem permissão para alterar as permissões de um grupo.");
/*     */           
/*     */           return;
/*     */         } 
/* 161 */         group = null;
/*     */         
/* 163 */         if (args.length <= 2) {
/* 164 */           group = cmdArgs.getSenderAsMember().getServerGroup();
/* 165 */           sender.sendMessage(" §e» §fUse §a/" + cmdArgs.getLabel() + " " + Joiner.on(' ').join((Object[])args) + " <add:remove> <permission>§f para adicionar ou remove uma permissão do grupo.");
/*     */ 
/*     */           
/* 168 */           sender.sendMessage(" §e» §fUse §a/" + cmdArgs.getLabel() + " " + Joiner.on(' ').join((Object[])args) + " list§f para listar as permissões do grupo.");
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/* 173 */         group = CommonPlugin.getInstance().getPluginInfo().getGroupByName(args[1]);
/*     */         
/* 175 */         if (group == null) {
/* 176 */           sender.sendMessage(sender.getLanguage().t("group-not-found", new String[] { "%group%", args[1] }));
/*     */           
/*     */           return;
/*     */         } 
/* 180 */         if (args.length <= 3) {
/* 181 */           if (args[2].equalsIgnoreCase("list")) {
/* 182 */             sender.sendMessage("  §aGrupo " + StringFormat.formatString(group.getGroupName()));
/* 183 */             sender.sendMessage("    §fPermissões:");
/*     */             
/* 185 */             for (String str : group.getPermissions()) {
/* 186 */               sender.sendMessage("      §f- §7" + str);
/*     */             }
/*     */             return;
/*     */           } 
/* 190 */           group = cmdArgs.getSenderAsMember().getServerGroup();
/* 191 */           sender.sendMessage(" §e» §fUse §a/" + cmdArgs.getLabel() + " " + Joiner.on(' ').join((Object[])args) + " <permission>§f para adicionar ou remove r");
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/* 196 */         permission = args[3].toLowerCase();
/* 197 */         add = args[2].equalsIgnoreCase("add");
/*     */         
/* 199 */         if (add) {
/* 200 */           if (group.getPermissions().contains(permission)) {
/* 201 */             sender.sendMessage("§cO grupo " + StringFormat.formatString(group.getGroupName()) + " já tem a permissão \"" + permission + "\".");
/*     */           } else {
/*     */             
/* 204 */             group.getPermissions().add(permission);
/* 205 */             CommonPlugin.getInstance().saveConfig("groupMap");
/* 206 */             sender.sendMessage("§aPermissão \"" + permission + "\" foi adicionada ao grupo " + 
/* 207 */                 StringFormat.formatString(group.getGroupName()) + ".");
/* 208 */             staffLog("O grupo " + StringFormat.formatString(group.getGroupName()) + " teve a permissão " + permission + " adicionadada.", true);
/*     */           }
/*     */         
/*     */         }
/* 212 */         else if (!group.getPermissions().contains(permission)) {
/* 213 */           sender.sendMessage("§cO grupo " + StringFormat.formatString(group.getGroupName()) + " não tem a permissão \"" + permission + "\".");
/*     */         } else {
/*     */           
/* 216 */           group.getPermissions().remove(permission);
/* 217 */           sender.sendMessage("§aPermissão \"" + permission + "\" foi removida do grupo " + 
/* 218 */               StringFormat.formatString(group.getGroupName()) + ".");
/* 219 */           CommonPlugin.getInstance().saveConfig("groupMap");
/* 220 */           staffLog("O grupo " + StringFormat.formatString(group.getGroupName()) + " teve a permissão " + permission + " removida.", true);
/*     */         } 
/*     */         return;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case "create":
/* 228 */         if (!sender.hasPermission("command.group.create")) {
/* 229 */           sender.sendMessage("§cVocê não tem permissão para criar grupo.");
/*     */           
/*     */           return;
/*     */         } 
/* 233 */         if (args.length == 1) {
/* 234 */           sender.sendMessage(" §e» §fUse §a/group create <group>§f para criar um grupo.");
/*     */         } else {
/* 236 */           String groupName = args[1];
/*     */           
/* 238 */           ChatManager.Callback confirm = (cancel, answers) -> {
/*     */               if (cancel) {
/*     */                 sender.sendMessage("§cOperation cancelled.");
/*     */                 
/*     */                 return;
/*     */               } 
/*     */               
/*     */               int id = StringFormat.parseInt(answers[0]).getAsInt();
/*     */               
/*     */               boolean defaultGroup = StringFormat.parseBoolean(sender.getLanguage(), answers[1]).getAsBoolean();
/*     */               
/*     */               boolean isStaff = StringFormat.parseBoolean(sender.getLanguage(), answers[2]).getAsBoolean();
/*     */               
/*     */               Group group = new Group(id, groupName, new ArrayList(), defaultGroup, isStaff);
/*     */               
/*     */               if (defaultGroup);
/*     */               
/*     */               boolean sort = false;
/*     */               
/*     */               if (CommonPlugin.getInstance().getPluginInfo().getGroupById(id) != null) {
/*     */                 CommonPlugin.getInstance().getPluginInfo().getGroupMap().values().stream().filter(()).forEach(());
/*     */                 
/*     */                 sort = true;
/*     */               } 
/*     */               
/*     */               CommonPlugin.getInstance().getPluginInfo().loadGroup(group);
/*     */               
/*     */               CommonPlugin.getInstance().saveConfig();
/*     */               
/*     */               sender.sendMessage("§aO grupo " + groupName + " foi criada.");
/*     */               
/*     */               staffLog("O grupo " + StringFormat.formatString(group.getGroupName()) + " foi criado.", true);
/*     */               if (sort) {
/*     */                 CommonPlugin.getInstance().getPluginInfo().sortGroup();
/*     */               }
/*     */             };
/* 274 */           ChatManager.Validator validator = (message, index) -> {
/*     */               OptionalInt optionalInt;
/*     */               OptionalBoolean optionalBool;
/*     */               switch (index) {
/*     */                 case 0:
/*     */                   optionalInt = StringFormat.parseInt(message);
/*     */                   if (!optionalInt.isPresent()) {
/*     */                     sender.sendMessage(sender.getLanguage().t("number-format-invalid", new String[] { "%number%", message }));
/*     */                     return false;
/*     */                   } 
/*     */                   return true;
/*     */ 
/*     */ 
/*     */                 
/*     */                 case 1:
/*     */                 case 2:
/*     */                   optionalBool = StringFormat.parseBoolean(sender.getLanguage(), message);
/*     */                   if (!optionalBool.isPresent()) {
/*     */                     sender.sendMessage(sender.getLanguage().t("format-invalid", new String[] { "%object%", message }));
/*     */                     return false;
/*     */                   } 
/*     */                   break;
/*     */               } 
/*     */ 
/*     */               
/*     */               return true;
/*     */             };
/* 301 */           BukkitCommon.getInstance().getChatManager().loadChat(sender, confirm, validator, new String[] { "§aInsira o id do grupo (número).", "§aInsira se o grupo é \"default\" (true ou false).", "§aInsira se o grupo é \"staff\" (true ou false)." });
/*     */         } 
/*     */         return;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case "createtag":
/* 309 */         if (args.length == 1) {
/* 310 */           sender.sendMessage(" §e» §fUse §a/group createtag <group>§f para criar um grupo.");
/*     */         } else {
/* 312 */           String tagName = args[1];
/*     */           
/* 314 */           ChatManager.Callback confirm = (cancel, answers) -> {
/*     */               if (cancel) {
/*     */                 sender.sendMessage("§cOperation cancelled.");
/*     */                 
/*     */                 return;
/*     */               } 
/*     */               
/*     */               int id = StringFormat.parseInt(answers[0]).getAsInt();
/*     */               
/*     */               String tagPrefix = answers[1].replace('&', '§');
/*     */               
/*     */               List<String> aliases = answers[2].equalsIgnoreCase("nenhum") ? new ArrayList<>() : Arrays.<String>asList(answers[2].contains(", ") ? answers[2].split(", ") : answers[2].split(","));
/*     */               
/*     */               boolean exclusive = StringFormat.parseBoolean(sender.getLanguage(), answers[3]).getAsBoolean();
/*     */               
/*     */               boolean defaultTag = StringFormat.parseBoolean(sender.getLanguage(), answers[4]).getAsBoolean();
/*     */               
/*     */               Tag tag = new Tag(id, tagName, tagPrefix, aliases, exclusive, defaultTag);
/*     */               
/*     */               boolean sort = false;
/*     */               
/*     */               if (CommonPlugin.getInstance().getPluginInfo().getTagById(id) != null) {
/*     */                 CommonPlugin.getInstance().getPluginInfo().getTagMap().values().stream().filter(()).forEach(());
/*     */                 
/*     */                 sort = true;
/*     */               } 
/*     */               
/*     */               CommonPlugin.getInstance().getPluginInfo().loadTag(tag);
/*     */               
/*     */               CommonPlugin.getInstance().saveConfig();
/*     */               
/*     */               sender.sendMessage("§aO tag " + tagName + " foi criada.");
/*     */               staffLog("A tag " + StringFormat.formatString(tag.getTagName()) + " foi criada.", true);
/*     */               if (sort) {
/*     */                 CommonPlugin.getInstance().getPluginInfo().sortGroup();
/*     */               }
/*     */             };
/* 351 */           ChatManager.Validator validator = (message, index) -> {
/*     */               OptionalInt optionalInt;
/*     */               OptionalBoolean optionalBool;
/*     */               switch (index) {
/*     */                 case 0:
/*     */                   optionalInt = StringFormat.parseInt(message);
/*     */                   if (!optionalInt.isPresent()) {
/*     */                     sender.sendMessage(sender.getLanguage().t("number-format-invalid", new String[] { "%number%", message }));
/*     */                     return false;
/*     */                   } 
/*     */                   return true;
/*     */ 
/*     */ 
/*     */                 
/*     */                 case 3:
/*     */                 case 4:
/*     */                   optionalBool = StringFormat.parseBoolean(sender.getLanguage(), message);
/*     */                   if (!optionalBool.isPresent()) {
/*     */                     sender.sendMessage(sender.getLanguage().t("format-invalid", new String[] { "%object%", message }));
/*     */                     return false;
/*     */                   } 
/*     */                   break;
/*     */               } 
/*     */ 
/*     */               
/*     */               return true;
/*     */             };
/* 378 */           BukkitCommon.getInstance().getChatManager().loadChat(sender, confirm, validator, new String[] { "§aInsira o id do tag (número).", "§aInsira a tag do grupo sem espaço e com cor usando o símbolo &.", "§aInsira as aliases usando \",\" para separar.", "§aInsira se a tag é exclusiva ou não (true ou false).", "§aInsira se a tag é \"default\" ou não (true ou false)." });
/*     */         } 
/*     */         return;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case "delete":
/*     */       case "remove":
/* 390 */         group = CommonPlugin.getInstance().getPluginInfo().getGroupByName(args[1]);
/*     */         
/* 392 */         if (group == null) {
/* 393 */           sender.sendMessage(sender.getLanguage().t("group-not-found", new String[] { "%group%", args[1] }));
/*     */           
/*     */           return;
/*     */         } 
/* 397 */         CommonPlugin.getInstance().getPluginInfo().getGroupMap().remove(group.getGroupName().toLowerCase());
/* 398 */         sender.sendMessage(sender.getLanguage().t("command.group.deleted-group", new String[] { "%groupName%", 
/* 399 */                 StringFormat.formatString(group.getGroupName()) }));
/* 400 */         staffLog("O grupo " + StringFormat.formatString(group.getGroupName()) + " foi deletado.", true);
/*     */         return;
/*     */     } 
/*     */     
/* 404 */     Member member = CommonPlugin.getInstance().getMemberManager().getMemberByName(args[0]);
/*     */     
/* 406 */     if (member == null) {
/* 407 */       member = CommonPlugin.getInstance().getMemberData().loadMember(args[0], true);
/*     */       
/* 409 */       if (member == null) {
/* 410 */         sender.sendMessage(sender.getLanguage().t("account-doesnt-exist", new String[] { "%player%", args[0] }));
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 415 */     Group actualGroup = member.getServerGroup();
/*     */     
/* 417 */     if (args.length <= 1) {
/* 418 */       GroupInfo groupInfo = member.getServerGroup(actualGroup.getGroupName());
/* 419 */       sender.sendMessage("  §aMembro " + member.getPlayerName());
/* 420 */       sender.sendMessage((BaseComponent)(new MessageBuilder("    §fGrupo: §7" + 
/* 421 */             StringFormat.formatString(actualGroup.getGroupName())))
/* 422 */           .setHoverEvent("§aClique para ver informações do grupo.")
/* 423 */           .setClickEvent("/group info " + actualGroup.getGroupName().toLowerCase()).create());
/* 424 */       sender.sendMessage("    §fExpire em: §7" + (groupInfo.isPermanent() ? "Nunca" : 
/* 425 */           DateUtils.getTime(sender.getLanguage(), groupInfo.getExpireTime())));
/*     */       
/*     */       return;
/*     */     } 
/* 429 */     Group group2 = CommonPlugin.getInstance().getPluginInfo().getGroupByName(args[2]);
/*     */     
/* 431 */     if (group2 == null) {
/* 432 */       sender.sendMessage(sender.getLanguage().t("group-not-found", new String[] { "%group%", args[2] }));
/*     */       
/*     */       return;
/*     */     } 
/* 436 */     if (args.length == 2) {
/* 437 */       sender.sendMessage(" §e» §fUse §a/group " + member.getPlayerName() + " add <group>§f para adicionar um grupo a alguém.");
/*     */       
/* 439 */       sender.sendMessage(" §e» §fUse §a/group " + member.getPlayerName() + " remove <group>§f para remover um grupo de alguém.");
/*     */       
/* 441 */       sender.sendMessage(" §e» §fUse §a/group " + member.getPlayerName() + " set <group>§f para setar um grupo a alguém.");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 446 */     switch (args[1].toLowerCase()) {
/*     */       case "add":
/* 448 */         temp = (args.length >= 4);
/* 449 */         expireTime = temp ? DateUtils.getTime(args[3]).longValue() : -1L;
/*     */         
/* 451 */         member.addServerGroup(group2.getGroupName(), new GroupInfo(sender, expireTime));
/* 452 */         member.setTag(member.getDefaultTag());
/* 453 */         member.getMemberConfiguration().setStaffChat(false);
/*     */         
/* 455 */         sender.sendMessage("§aVocê adicionou o cargo " + group2.getGroupName() + " ao jogador " + member
/* 456 */             .getPlayerName() + " por tempo " + (temp ? 
/* 457 */             DateUtils.getTime(sender.getLanguage(), expireTime) : "indeterminado") + ".");
/* 458 */         staffLog("O jogador " + member.getPlayerName() + " recebeu cargo " + group2.getRealPrefix() + " §7por " + (temp ? 
/* 459 */             DateUtils.getTime(sender.getLanguage(), expireTime) : "indeterminado") + " do " + sender
/* 460 */             .getName(), true);
/*     */         return;
/*     */       
/*     */       case "remove":
/* 464 */         if (member.hasGroup(group2.getGroupName())) {
/* 465 */           member.removeServerGroup(group2.getGroupName());
/*     */           
/* 467 */           member.setTag(member.getDefaultTag());
/* 468 */           member.getMemberConfiguration().setStaffChat(false);
/*     */           
/* 470 */           sender.sendMessage("§aVocê removeu o cargo " + group2.getGroupName() + " do jogador " + member
/* 471 */               .getPlayerName() + ".");
/* 472 */           staffLog("O jogador " + member.getPlayerName() + " teve o seu cargo " + group2.getRealPrefix() + " §7removido pelo " + sender
/* 473 */               .getName(), true);
/*     */         } else {
/* 475 */           sender.sendMessage("§cO player " + member
/* 476 */               .getPlayerName() + " não tem o grupo " + group2.getGroupName() + ".");
/*     */         } 
/*     */         return;
/*     */       case "set":
/* 480 */         member.setServerGroup(group2.getGroupName(), new GroupInfo(sender, -1L));
/*     */         
/* 482 */         member.setTag(member.getDefaultTag());
/* 483 */         member.getMemberConfiguration().setStaffChat(false);
/*     */         
/* 485 */         sender.sendMessage("§aVocê adicionou o cargo " + group2.getGroupName() + " ao jogador " + member
/* 486 */             .getPlayerName() + ".");
/* 487 */         staffLog("O jogador " + member.getPlayerName() + " teve o cargo alterado para " + group2.getRealPrefix() + " §7pelo " + sender
/* 488 */             .getName(), true);
/*     */         return;
/*     */     } 
/*     */     
/* 492 */     sender.sendMessage(" §e» §fUse §a/group <player> add <group>§f para adicionar um grupo a alguém.");
/* 493 */     sender.sendMessage(" §e» §fUse §a/group <player> remove <group>§f para remover um grupo de alguém.");
/* 494 */     sender.sendMessage(" §e» §fUse §a/group <player> set <group>§f para setar um grupo a alguém.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Completer(name = "group")
/*     */   public List<String> groupCompleter(CommandArgs cmdArgs) {
/* 505 */     List<String> returnList = new ArrayList<>();
/*     */     
/* 507 */     if ((cmdArgs.getArgs()).length == 1) {
/* 508 */       List<String> arguments = Arrays.asList(new String[] { "info", "list", "create", "manager", "delete" });
/*     */       
/* 510 */       if (cmdArgs.getArgs()[0].isEmpty()) {
/* 511 */         for (String argument : arguments)
/* 512 */           returnList.add(argument); 
/*     */       } else {
/* 514 */         for (String argument : arguments) {
/* 515 */           if (argument.toLowerCase().startsWith(cmdArgs.getArgs()[0].toLowerCase()))
/* 516 */             returnList.add(argument); 
/*     */         } 
/* 518 */         for (Player player : Bukkit.getOnlinePlayers())
/* 519 */         { if (player.getName().toLowerCase().startsWith(cmdArgs.getArgs()[0].toLowerCase()))
/* 520 */             returnList.add(player.getName());  } 
/*     */       } 
/* 522 */     } else if ((cmdArgs.getArgs()).length == 2) {
/* 523 */       if (cmdArgs.getArgs()[0].equalsIgnoreCase("info"))
/* 524 */       { if (cmdArgs.getArgs()[1].isEmpty()) {
/* 525 */           for (Group group : CommonPlugin.getInstance().getPluginInfo().getGroupMap().values())
/* 526 */             returnList.add(group.getGroupName()); 
/*     */         } else {
/* 528 */           for (Group group : CommonPlugin.getInstance().getPluginInfo().getGroupMap().values()) {
/* 529 */             if (group.getGroupName().toLowerCase().startsWith(cmdArgs.getArgs()[1].toLowerCase()))
/* 530 */               returnList.add(group.getGroupName()); 
/*     */           } 
/*     */         }  }
/* 533 */       else { List<String> arguments = Arrays.asList(new String[] { "add", "set", "remove" });
/*     */         
/* 535 */         if (cmdArgs.getArgs()[1].isEmpty()) {
/* 536 */           for (String argument : arguments)
/* 537 */             returnList.add(argument); 
/*     */         } else {
/* 539 */           for (String argument : arguments)
/* 540 */           { if (argument.toLowerCase().startsWith(cmdArgs.getArgs()[1].toLowerCase()))
/* 541 */               returnList.add(argument);  } 
/*     */         }  }
/*     */     
/* 544 */     } else if ((cmdArgs.getArgs()).length == 3) {
/* 545 */       Player player = Bukkit.getPlayer(cmdArgs.getArgs()[0]);
/*     */       
/* 547 */       if (player != null) {
/* 548 */         List<String> arguments = Arrays.asList(new String[] { "add", "set", "remove" });
/*     */         
/* 550 */         if (arguments.contains(cmdArgs.getArgs()[1]))
/* 551 */           if (cmdArgs.getArgs()[2].isEmpty()) {
/* 552 */             for (Group group : CommonPlugin.getInstance().getPluginInfo().getGroupMap().values())
/* 553 */               returnList.add(group.getGroupName()); 
/*     */           } else {
/* 555 */             for (Group group : CommonPlugin.getInstance().getPluginInfo().getGroupMap().values()) {
/* 556 */               if (group.getGroupName().toLowerCase().startsWith(cmdArgs.getArgs()[2].toLowerCase())) {
/* 557 */                 returnList.add(group.getGroupName());
/*     */               }
/*     */             } 
/*     */           }  
/*     */       } 
/*     */     } 
/* 563 */     return returnList;
/*     */   }
/*     */   
/*     */   public void set(Group group, int id) throws Exception {
/* 567 */     Field field = Group.class.getDeclaredField("id");
/* 568 */     field.setAccessible(true);
/* 569 */     field.set(group, Integer.valueOf(id));
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/command/register/GroupCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */