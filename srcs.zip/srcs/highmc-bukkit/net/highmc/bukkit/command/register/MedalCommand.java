/*     */ package net.highmc.bukkit.command.register;
/*     */ import com.google.common.base.Joiner;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.bukkit.manager.ChatManager;
/*     */ import net.highmc.bukkit.member.BukkitMember;
/*     */ import net.highmc.bukkit.utils.menu.confirm.ConfirmInventory;
/*     */ import net.highmc.command.CommandArgs;
/*     */ import net.highmc.command.CommandClass;
/*     */ import net.highmc.command.CommandFramework.Command;
/*     */ import net.highmc.command.CommandFramework.Completer;
/*     */ import net.highmc.command.CommandSender;
/*     */ import net.highmc.medal.Medal;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.permission.Tag;
/*     */ import net.highmc.utils.string.MessageBuilder;
/*     */ import net.highmc.utils.string.StringFormat;
/*     */ import net.md_5.bungee.api.ChatColor;
/*     */ import net.md_5.bungee.api.chat.BaseComponent;
/*     */ import net.md_5.bungee.api.chat.ClickEvent;
/*     */ 
/*     */ public class MedalCommand implements CommandClass {
/*     */   @Command(name = "medalmanager", permission = "command.medalmanager")
/*     */   public void medalManagerCommand(CommandArgs cmdArgs) {
/*     */     Medal medal;
/*     */     String medalName;
/*     */     ChatManager.Callback confirm;
/*     */     ChatManager.Validator validator;
/*     */     Medal medal1;
/*  34 */     CommandSender sender = cmdArgs.getSender();
/*  35 */     String[] args = cmdArgs.getArgs();
/*     */     
/*  37 */     if (args.length == 0) {
/*  38 */       handleMedalUsage(sender, cmdArgs.getLabel());
/*     */       
/*     */       return;
/*     */     } 
/*  42 */     switch (args[0].toLowerCase()) {
/*     */       case "deletar":
/*  44 */         if (args.length == 1) {
/*  45 */           sender.sendMessage(" §a» §fUse §a/" + cmdArgs
/*  46 */               .getLabel() + " create <medalName>§f para deletar uma medalha");
/*     */           
/*     */           return;
/*     */         } 
/*  50 */         medal = CommonPlugin.getInstance().getPluginInfo().getMedalByName(args[0]);
/*     */         
/*  52 */         if (medal == null) {
/*  53 */           sender.sendMessage("§cA medalha \"" + args[0] + "\" não existe.");
/*     */           
/*     */           return;
/*     */         } 
/*  57 */         if (sender.isPlayer()) {
/*  58 */           new ConfirmInventory(((BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class)).getPlayer(), "Confirme a ação.", bool -> { if (bool) { CommonPlugin.getInstance().getPluginInfo().getMedalMap().remove(medal.getMedalName().toLowerCase()); sender.sendMessage("§aMedalha deletada com sucesso."); }  }null);
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */ 
/*     */           
/*  67 */           CommonPlugin.getInstance().getPluginInfo().getMedalMap().remove(medal.getMedalName().toLowerCase());
/*  68 */           sender.sendMessage("§aMedalha deletada com sucesso.");
/*     */         } 
/*     */         return;
/*     */ 
/*     */       
/*     */       case "list":
/*  74 */         sender.sendMessage("  §aLista de medalha: ");
/*     */         
/*  76 */         for (Medal medal2 : CommonPlugin.getInstance().getPluginInfo().getMedalMap().values()) {
/*  77 */           sender.sendMessage((BaseComponent)(new MessageBuilder("    §f- " + medal2.getChatColor() + medal2.getMedalName() + ""))
/*  78 */               .setHoverEvent("" + medal2.getChatColor() + medal2.getMedalName() + "\n\n§eInfo:\n  §fSímbolo: §7" + medal2
/*  79 */                 .getChatColor() + medal2.getSymbol() + "\n  §fCor: §7" + medal2
/*  80 */                 .getChatColor() + StringFormat.formatString(medal2.getChatColor().name()))
/*  81 */               .create());
/*     */         }
/*     */         return;
/*     */ 
/*     */ 
/*     */       
/*     */       case "create":
/*  88 */         if (args.length == 1) {
/*  89 */           sender.sendMessage(" §a» §fUse §a/" + cmdArgs
/*  90 */               .getLabel() + " create <medalName>§f para criar uma medalha.");
/*     */           
/*     */           return;
/*     */         } 
/*  94 */         medalName = args[1];
/*     */         
/*  96 */         confirm = ((cancel, answers) -> {
/*     */             if (cancel) {
/*     */               sender.sendMessage("§cOperation cancelled.");
/*     */               
/*     */               return;
/*     */             } 
/*     */             
/*     */             String color = answers[0];
/*     */             
/*     */             ChatColor chatColor = ChatColor.getByChar(color.contains("&") ? color.charAt(1) : color.toCharArray()[0]);
/*     */             
/*     */             if (chatColor == null) {
/*     */               chatColor = ChatColor.valueOf(color.toUpperCase());
/*     */             }
/*     */             
/*     */             String symbol = "" + answers[1].toCharArray()[0];
/*     */             
/*     */             String[] aliases = answers[2].contains(", ") ? answers[2].split(", ") : answers[2].split(",");
/*     */             
/*     */             if (CommonPlugin.getInstance().getPluginInfo().getMedalByName(medalName) == null) {
/*     */               Medal medal = new Medal(medalName, symbol, chatColor.name().toUpperCase(), Arrays.asList(aliases));
/*     */               
/*     */               CommonPlugin.getInstance().getPluginInfo().loadMedal(medal);
/*     */               
/*     */               sender.sendMessage("§aA medalha " + medalName + " §7(" + chatColor + symbol + "§7) foi criada com sucesso.");
/*     */             } else {
/*     */               sender.sendMessage("§cA medalha inserida já existe.");
/*     */             } 
/*     */           });
/* 125 */         validator = ((message, index) -> {
/*     */             switch (index) {
/*     */               case 0:
/*     */                 try {
/*     */                   return (ChatColor.valueOf(message) != null);
/* 130 */                 } catch (Exception ex) {
/*     */                   
/* 132 */                   return ((message.contains("&") ? ChatColor.getByChar(message.toCharArray()[1]) : ChatColor.getByChar(message.toCharArray()[0])) != null);
/*     */                 } 
/*     */               
/*     */               case 1:
/*     */                 return true;
/*     */               
/*     */               case 2:
/* 139 */                 return (!message.isEmpty() && message.length() > 3);
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             return true;
/*     */           });
/* 147 */         BukkitCommon.getInstance().getChatManager().loadChat(sender, confirm, validator, new String[] { "§aPara criar uma medalha, digite qual será a cor usada\n§aPaleta de cores disponíveis: " + 
/*     */               
/* 149 */               Joiner.on(' ')
/* 150 */               .join((Iterable)Arrays.<ChatColor>asList(ChatColor.values()).stream()
/* 151 */                 .map(chatColor -> "" + chatColor + chatColor.getName())
/* 152 */                 .collect(Collectors.toList())), "§aInsira qual será o simbolo da medalha:", "§aInsira quais serão as aliases da medalha, utilizando vírgula para separar" });
/*     */         return;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 158 */     Member member = CommonPlugin.getInstance().getMemberManager().getMemberByName(args[0]);
/*     */     
/* 160 */     if (member == null) {
/* 161 */       member = CommonPlugin.getInstance().getMemberData().loadMember(args[0], true);
/*     */       
/* 163 */       if (member == null) {
/* 164 */         sender.sendMessage(sender.getLanguage().t("account-doesnt-exist", new String[] { "%player%", args[0] }));
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 169 */     if (args.length == 1) {
/* 170 */       if (member.getMedals().isEmpty()) {
/* 171 */         sender.sendMessage("§cO jogador " + member.getPlayerName() + " não possui medalhas.");
/*     */       } else {
/* 173 */         sender.sendMessage("  §aMembro " + member.getPlayerName());
/*     */       } 
/* 175 */       Member m = member;
/*     */       
/* 177 */       for (Medal medal2 : CommonPlugin.getInstance().getPluginInfo().getMedalMap().values().stream()
/* 178 */         .filter(medal -> m.hasMedal(medal)).collect(Collectors.toList())) {
/* 179 */         sender.sendMessage((BaseComponent)(new MessageBuilder("    §f- " + medal2.getChatColor() + medal2.getMedalName() + ""))
/* 180 */             .setHoverEvent("" + medal2.getChatColor() + medal2.getMedalName() + "\n\n  §eInfo:\n  §fSímbolo: §7" + medal2
/* 181 */               .getChatColor() + medal2.getSymbol() + "\n  §fCor: §7" + medal2
/* 182 */               .getChatColor() + 
/* 183 */               StringFormat.formatString(medal2.getChatColor().name()))
/* 184 */             .create());
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 190 */     switch (args[1].toLowerCase()) {
/*     */       case "add":
/* 192 */         if (args.length == 2) {
/* 193 */           sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " <player> add <medal>§f para adicionar uma medalha a um jogador.");
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/* 198 */         medal1 = CommonPlugin.getInstance().getPluginInfo().getMedalByName(args[2]);
/*     */         
/* 200 */         if (medal1 == null) {
/* 201 */           sender.sendMessage("§cA medalha \"" + args[2] + "\" não existe.");
/*     */           
/*     */           return;
/*     */         } 
/* 205 */         if (member.addMedal(medal1)) {
/* 206 */           sender.sendMessage("§aVocê deu a medalha " + medal1.getChatColor() + medal1.getMedalName() + "§a para o " + member
/* 207 */               .getPlayerName() + ".");
/*     */         } else {
/* 209 */           sender.sendMessage("§cO jogador " + member.getPlayerName() + " já possui a medalha " + medal1
/* 210 */               .getChatColor() + medal1.getMedalName() + "§c.");
/*     */         } 
/*     */         return;
/*     */       case "remove":
/* 214 */         if (args.length == 2) {
/* 215 */           sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " <player> remove <medal>§f para remover uma medalha de um jogador.");
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/* 220 */         medal1 = CommonPlugin.getInstance().getPluginInfo().getMedalByName(args[2]);
/*     */         
/* 222 */         if (medal1 == null) {
/* 223 */           sender.sendMessage("§cA medalha \"" + args[2] + "\" não existe.");
/*     */           
/*     */           return;
/*     */         } 
/* 227 */         if (member.removeMedal(medal1)) {
/* 228 */           sender.sendMessage("§aVocê removeu a medalha " + medal1.getChatColor() + medal1.getMedalName() + "§a do " + member
/* 229 */               .getPlayerName() + ".");
/*     */         } else {
/* 231 */           sender.sendMessage("§cO jogador " + member.getPlayerName() + " não possui a medalha " + medal1
/* 232 */               .getChatColor() + medal1.getMedalName() + "§c.");
/*     */         } 
/*     */         return;
/*     */     } 
/* 236 */     sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " <player> remove <medal>§f para adicionar uma medalha a um jogador.");
/*     */     
/* 238 */     sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " <player> add <medal>§f para remover uma medalha de um jogador.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Command(name = "medal", aliases = {"medalhas", "medals", "emblemas"}, console = false)
/*     */   public void medalCommand(CommandArgs cmdArgs) {
/* 250 */     Member sender = cmdArgs.getSenderAsMember();
/* 251 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 253 */     if (args.length == 0) {
/* 254 */       if (sender.getMedals().isEmpty()) {
/* 255 */         sender.sendMessage("§cVocê não possui nenhuma medalha.");
/*     */       } else {
/* 257 */         MessageBuilder messageBuilder = new MessageBuilder("§aSuas medalhas: ");
/*     */         
/* 259 */         messageBuilder.extra((new MessageBuilder("§7Nenhum§f, "))
/* 260 */             .setHoverEvent("§eRemover sua medalha.\n\n§aClique para selecionar.")
/* 261 */             .setClickEvent(ClickEvent.Action.RUN_COMMAND, "/medal nenhum").create());
/*     */ 
/*     */         
/* 264 */         List<Medal> medals = (List<Medal>)CommonPlugin.getInstance().getPluginInfo().getMedalMap().values().stream().filter(medal -> sender.hasMedal(medal)).collect(Collectors.toList());
/* 265 */         int size = medals.size();
/*     */         
/* 267 */         for (int i = 0; i < size; i++) {
/* 268 */           Medal medal1 = medals.get(i);
/* 269 */           messageBuilder.extra((new MessageBuilder("" + medal1
/* 270 */                 .getChatColor() + medal1.getSymbol() + ((i == size - 1) ? "§f." : "§f,")))
/* 271 */               .setHoverEvent("" + medal1
/* 272 */                 .getChatColor() + medal1.getMedalName() + "\n\n§aClique para selecionar.")
/* 273 */               .setClickEvent(ClickEvent.Action.RUN_COMMAND, "/medal " + medal1.getMedalName()).create());
/*     */         } 
/*     */         
/* 276 */         sender.sendMessage((BaseComponent)messageBuilder.create());
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 282 */     String medalName = Joiner.on(' ').join((Object[])args);
/*     */     
/* 284 */     if (medalName.equalsIgnoreCase("nenhum") || medalName.equalsIgnoreCase("nenhuma") || medalName
/* 285 */       .equalsIgnoreCase("remover")) {
/* 286 */       sender.setMedal(null);
/* 287 */       sender.sendMessage("§aSua medalha foi removida.");
/*     */       
/*     */       return;
/*     */     } 
/* 291 */     Medal medal = CommonPlugin.getInstance().getPluginInfo().getMedalByName(medalName);
/*     */     
/* 293 */     if (medal == null) {
/* 294 */       sender.sendMessage("§cA medalha \"" + medalName + "\" não existe.");
/*     */       
/*     */       return;
/*     */     } 
/* 298 */     if (!sender.hasMedal(medal)) {
/* 299 */       sender.sendMessage("§cVocê não possui a medalha " + medal.getChatColor() + medal.getMedalName() + "§c.");
/*     */       
/*     */       return;
/*     */     } 
/* 303 */     sender.setMedal(medal);
/* 304 */     sender.sendMessage("§aSua medalha foi alterada para " + medal.getChatColor() + medal.getMedalName() + "§a.");
/*     */   }
/*     */   
/*     */   @Completer(name = "tag")
/*     */   public List<String> tagCompleter(CommandArgs cmdArgs) {
/* 309 */     if (cmdArgs.isPlayer() && (
/* 310 */       cmdArgs.getArgs()).length == 1) {
/* 311 */       List<String> tagList = new ArrayList<>();
/*     */       
/* 313 */       BukkitMember member = (BukkitMember)CommonPlugin.getInstance().getMemberManager().getMember(cmdArgs.getSender().getUniqueId());
/*     */       
/* 315 */       if (cmdArgs.getArgs()[0].isEmpty())
/* 316 */       { for (Tag tag : CommonPlugin.getInstance().getPluginInfo().getTags()) {
/* 317 */           if (member.hasTag(tag))
/* 318 */             tagList.add(tag.getTagName().toLowerCase()); 
/*     */         }  }
/* 320 */       else { for (Tag tag : CommonPlugin.getInstance().getPluginInfo().getTags()) {
/* 321 */           if (member.hasTag(tag) && tag
/* 322 */             .getTagName().toLowerCase().startsWith(cmdArgs.getArgs()[0].toLowerCase()))
/* 323 */             tagList.add(tag.getTagName().toLowerCase()); 
/*     */         }  }
/*     */       
/* 326 */       return tagList;
/*     */     } 
/*     */     
/* 329 */     return new ArrayList<>();
/*     */   }
/*     */   
/*     */   private void handleMedalUsage(CommandSender sender, String label) {
/* 333 */     sender.sendMessage(" §a» §fUse §a/" + label + " create <medalName>§f para criar uma medalha.");
/* 334 */     sender.sendMessage(" §a» §fUse §a/" + label + " create <medalName>§f para deletar uma medalha.");
/* 335 */     sender.sendMessage(" §a» §fUse §a/" + label + " list§f para listar as medalhas.");
/*     */     
/* 337 */     sender.sendMessage(" §a» §fUse §a/" + label + " <player>§f para listar as medalhas de um jogador.");
/* 338 */     sender.sendMessage("");
/* 339 */     sender.sendMessage(" §a» §fUse §a/" + label + " <player> add <medal>§f para adicionar uma medalha a um jogador.");
/*     */     
/* 341 */     sender.sendMessage(" §a» §fUse §a/" + label + " <player> remove <medal>§f para adicionar uma medalha a um jogador.");
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/command/register/MedalCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */