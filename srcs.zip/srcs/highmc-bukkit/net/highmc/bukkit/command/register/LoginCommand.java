/*    */ package net.highmc.bukkit.command.register;
/*    */ 
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.bukkit.BukkitCommon;
/*    */ import net.highmc.bukkit.event.member.PlayerAuthEvent;
/*    */ import net.highmc.bukkit.member.BukkitMember;
/*    */ import net.highmc.command.CommandArgs;
/*    */ import net.highmc.command.CommandClass;
/*    */ import net.highmc.command.CommandFramework.Command;
/*    */ import net.highmc.member.Member;
/*    */ import net.highmc.member.configuration.LoginConfiguration;
/*    */ import net.highmc.server.ServerType;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.event.Event;
/*    */ 
/*    */ public class LoginCommand implements CommandClass {
/*    */   @Command(name = "register", aliases = {"registrar"}, console = false)
/*    */   public void registerCommand(CommandArgs cmdArgs) {
/* 19 */     BukkitMember sender = (BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class);
/* 20 */     String[] args = cmdArgs.getArgs();
/*    */     
/* 22 */     if (sender.getLoginConfiguration().isRegistered()) {
/* 23 */       sender.sendMessage("§cVocê já está registrado.");
/*    */       
/*    */       return;
/*    */     } 
/* 27 */     if (sender.getLoginConfiguration().getAccountType() != LoginConfiguration.AccountType.PREMIUM && 
/* 28 */       !sender.getLoginConfiguration().isCaptcha()) {
/* 29 */       sender.sendMessage("§cComplete o captcha para se logar.");
/*    */       
/*    */       return;
/*    */     } 
/* 33 */     if (args.length <= 1) {
/* 34 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs
/* 35 */           .getLabel() + " <sua senha> <repita sua senha>§f para se registrar.");
/* 36 */       sender.sendMessage("§cNão utilize coloque os símbolos < e > na sua senha.");
/*    */       
/*    */       return;
/*    */     } 
/* 40 */     if (args[0].equals(args[1])) {
/* 41 */       sender.sendMessage("§%command.register.success%§");
/* 42 */       sender.getLoginConfiguration().register(args[0]);
/* 43 */       sender.getLoginConfiguration().startSession();
/* 44 */       Bukkit.getPluginManager().callEvent((Event)new PlayerAuthEvent(sender.getPlayer(), (Member)sender));
/*    */     } else {
/* 46 */       sender.sendMessage("§cAs senhas inseridas não são iguais.");
/*    */     } 
/*    */   }
/*    */   
/*    */   @Command(name = "logout", aliases = {"deslogar"}, console = false)
/*    */   public void logoutCommand(CommandArgs cmdArgs) {
/* 52 */     BukkitMember sender = (BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class);
/*    */     
/* 54 */     if (sender.getLoginConfiguration().getAccountType() == LoginConfiguration.AccountType.PREMIUM) {
/*    */       return;
/*    */     }
/* 57 */     sender.getLoginConfiguration().logOut();
/* 58 */     sender.getLoginConfiguration().stopSession();
/* 59 */     BukkitCommon.getInstance().sendPlayerToServer(sender.getPlayer(), new ServerType[] { ServerType.LOGIN });
/*    */   }
/*    */   
/*    */   @Command(name = "login", aliases = {"logar"}, console = false)
/*    */   public void loginCommand(CommandArgs cmdArgs) {
/* 64 */     BukkitMember sender = (BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class);
/* 65 */     String[] args = cmdArgs.getArgs();
/*    */     
/* 67 */     if (!sender.getLoginConfiguration().isRegistered()) {
/* 68 */       sender.sendMessage("§cVocê ainda não se registrou, utilize /register para se autenticar.");
/*    */       
/*    */       return;
/*    */     } 
/* 72 */     if (sender.getLoginConfiguration().isLogged()) {
/* 73 */       sender.sendMessage("§cVocê já está logado.");
/*    */       
/*    */       return;
/*    */     } 
/* 77 */     if (args.length == 0) {
/* 78 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " <sua senha>§f para se logar.");
/*    */       
/*    */       return;
/*    */     } 
/* 82 */     if (sender.getLoginConfiguration().isPassword(args[0])) {
/* 83 */       sender.sendMessage("§%command.login.success%§");
/* 84 */       sender.getLoginConfiguration().logIn();
/* 85 */       sender.getLoginConfiguration().startSession();
/* 86 */       Bukkit.getPluginManager().callEvent((Event)new PlayerAuthEvent(sender.getPlayer(), (Member)sender));
/*    */     } else {
/* 88 */       int attemp = sender.getLoginConfiguration().attemp().intValue();
/*    */       
/* 90 */       if (attemp >= 5) {
/* 91 */         sender.getPlayer()
/* 92 */           .kickPlayer("§cVocê errou sua senha diversas vezes.\n§f\n§ePara mais informações, acesse §b" + 
/* 93 */             CommonPlugin.getInstance().getPluginInfo().getWebsite());
/*    */       } else {
/* 95 */         sender.sendMessage("§cSenha inserida inválida, você possui mais " + (5 - attemp) + "tentativas.");
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/command/register/LoginCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */