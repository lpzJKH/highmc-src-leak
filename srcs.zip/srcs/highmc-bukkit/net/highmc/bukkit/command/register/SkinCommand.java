/*    */ package net.highmc.bukkit.command.register;
/*    */ 
/*    */ import com.comphenix.protocol.wrappers.WrappedSignedProperty;
/*    */ import java.util.Optional;
/*    */ import net.highmc.CommonConst;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.bukkit.member.BukkitMember;
/*    */ import net.highmc.bukkit.menu.profile.SkinInventory;
/*    */ import net.highmc.bukkit.utils.player.PlayerAPI;
/*    */ import net.highmc.command.CommandArgs;
/*    */ import net.highmc.command.CommandClass;
/*    */ import net.highmc.command.CommandFramework.Command;
/*    */ import net.highmc.member.Member;
/*    */ import net.highmc.member.configuration.LoginConfiguration;
/*    */ import net.highmc.packet.Packet;
/*    */ import net.highmc.packet.types.skin.SkinChange;
/*    */ import net.highmc.utils.skin.Skin;
/*    */ 
/*    */ public class SkinCommand
/*    */   implements CommandClass
/*    */ {
/*    */   @Command(name = "skin.#", runAsync = true, console = false)
/*    */   public void skinresetCommand(CommandArgs cmdArgs) {
/* 24 */     BukkitMember sender = (BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class);
/*    */     
/* 26 */     if (!sender.isCustomSkin()) {
/* 27 */       sender.sendMessage("§cVocê não está usando uma skin customizada.");
/*    */       
/*    */       return;
/*    */     } 
/* 31 */     Skin skin = null;
/*    */     
/* 33 */     if (sender.getLoginConfiguration().getAccountType() == LoginConfiguration.AccountType.PREMIUM) {
/* 34 */       WrappedSignedProperty changePlayerSkin = PlayerAPI.changePlayerSkin(sender.getPlayer(), sender.getName(), sender
/* 35 */           .getUniqueId(), true);
/*    */       
/* 37 */       skin = new Skin(sender.getName(), sender.getUniqueId(), changePlayerSkin.getValue(), changePlayerSkin.getSignature());
/*    */     } else {
/* 39 */       WrappedSignedProperty changePlayerSkin = PlayerAPI.changePlayerSkin(sender.getPlayer(), CommonConst.DEFAULT_SKIN
/* 40 */           .getValue(), CommonConst.DEFAULT_SKIN.getSignature(), true);
/*    */       
/* 42 */       skin = new Skin(sender.getName(), sender.getUniqueId(), changePlayerSkin.getValue(), changePlayerSkin.getSignature());
/*    */     } 
/*    */     
/* 45 */     sender.setSkin(skin, false);
/* 46 */     sender.sendMessage("§aSua skin foi resetada com sucesso..");
/* 47 */     sender.putCooldown("command.skin", 120L);
/* 48 */     CommonPlugin.getInstance().getServerData().sendPacket((Packet)new SkinChange((Member)sender));
/*    */   }
/*    */   
/*    */   @Command(name = "skin", runAsync = true, console = false)
/*    */   public void skinCommand(CommandArgs cmdArgs) {
/* 53 */     BukkitMember sender = (BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class);
/* 54 */     String[] args = cmdArgs.getArgs();
/*    */     
/* 56 */     if (args.length == 0) {
/* 57 */       new SkinInventory(sender.getPlayer());
/*    */       
/*    */       return;
/*    */     } 
/* 61 */     if (!sender.hasPermission("command.skin")) {
/* 62 */       sender.sendMessage("§cVocê não tem permissão para usar skins fora do catálogo de skins.");
/*    */       
/*    */       return;
/*    */     } 
/* 66 */     if (sender.hasCooldown("command.skin") && !sender.hasPermission("command.admin")) {
/* 67 */       sender.sendMessage("§cVocê precisa esperar " + sender.getCooldownFormatted("command.skin") + " para usar eses comando novamente.");
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 72 */     String playerName = args[0];
/*    */     
/* 74 */     if (!PlayerAPI.validateName(playerName)) {
/* 75 */       sender.sendMessage("§cO nome inserido é inválido.");
/*    */       
/*    */       return;
/*    */     } 
/* 79 */     Optional<Skin> optional = CommonPlugin.getInstance().getSkinData().loadData(playerName);
/*    */     
/* 81 */     if (!optional.isPresent()) {
/* 82 */       sender.sendMessage("§cO jogador não possui conta na mojang.");
/*    */       
/*    */       return;
/*    */     } 
/* 86 */     Skin skin = optional.get();
/*    */     
/* 88 */     PlayerAPI.changePlayerSkin(sender.getPlayer(), skin.getValue(), skin.getSignature(), true);
/* 89 */     sender.setSkin(skin, true);
/* 90 */     sender.sendMessage("§aSua skin foi alterada para " + playerName + ".");
/* 91 */     sender.putCooldown("command.skin", 120L);
/* 92 */     CommonPlugin.getInstance().getServerData().sendPacket((Packet)new SkinChange((Member)sender));
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/command/register/SkinCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */