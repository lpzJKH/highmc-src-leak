/*     */ package net.highmc.bukkit.command.register;
/*     */ 
/*     */ import com.google.common.base.Joiner;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.bukkit.member.BukkitMember;
/*     */ import net.highmc.bukkit.menu.staff.AdminInventory;
/*     */ import net.highmc.bukkit.menu.staff.punish.PunishInfoInventory;
/*     */ import net.highmc.bukkit.menu.staff.server.ServerListInventory;
/*     */ import net.highmc.command.CommandArgs;
/*     */ import net.highmc.command.CommandClass;
/*     */ import net.highmc.command.CommandFramework.Command;
/*     */ import net.highmc.command.CommandFramework.Completer;
/*     */ import net.highmc.command.CommandSender;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.permission.Group;
/*     */ import net.highmc.utils.string.StringFormat;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModeradorCommand
/*     */   implements CommandClass
/*     */ {
/*     */   @Command(name = "punishinfo", aliases = {"cc"}, console = false, permission = "command.punish")
/*     */   public void punishinfoCommand(CommandArgs cmdArgs) {
/*  36 */     BukkitMember sender = (BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class);
/*  37 */     String[] args = cmdArgs.getArgs();
/*     */     
/*  39 */     if (args.length == 0) {
/*  40 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs
/*  41 */           .getLabel() + " <player>§f para ver as punições de um jogador.");
/*     */       
/*     */       return;
/*     */     } 
/*  45 */     Member target = CommonPlugin.getInstance().getMemberManager().getMemberByName(cmdArgs.getArgs()[0]);
/*     */     
/*  47 */     if (target == null) {
/*  48 */       target = CommonPlugin.getInstance().getMemberData().loadMember(cmdArgs.getArgs()[0], true);
/*     */       
/*  50 */       if (target == null) {
/*  51 */         sender.sendMessage(sender.getLanguage().t("account-doesnt-exist", new String[] { "%player%", cmdArgs.getArgs()[0] }));
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*  56 */     new PunishInfoInventory(sender.getPlayer(), target);
/*     */   }
/*     */   
/*     */   @Command(name = "serverlist", console = false, permission = "command.server")
/*     */   public void serverlistCommand(CommandArgs cmdArgs) {
/*  61 */     new ServerListInventory(((BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class)).getPlayer(), 1);
/*     */   }
/*     */   
/*     */   @Command(name = "clearchat", aliases = {"cc"}, permission = "command.clearchat")
/*     */   public void clearchatCommand(CommandArgs cmdArgs) {
/*  66 */     for (int i = 0; i < 128; i++) {
/*  67 */       Bukkit.broadcastMessage(" ");
/*     */     }
/*  69 */     staffLog("O chat foi limpo pelo " + cmdArgs.getSender().getName());
/*     */   }
/*     */   
/*     */   @Command(name = "chat", permission = "command.chat")
/*     */   public void chatCommand(CommandArgs cmdArgs) {
/*  74 */     CommandSender sender = cmdArgs.getSender();
/*  75 */     String[] args = cmdArgs.getArgs();
/*     */     
/*  77 */     if (args.length == 0) {
/*  78 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " <on:off>§f para desativar ou ativar o chat.");
/*     */       
/*     */       return;
/*     */     } 
/*  82 */     BukkitCommon.ChatState chatState = null;
/*     */     
/*  84 */     switch (args[0].toLowerCase()) {
/*     */       case "on":
/*  86 */         chatState = BukkitCommon.ChatState.ENABLED;
/*     */         break;
/*     */       
/*     */       case "off":
/*  90 */         chatState = BukkitCommon.ChatState.DISABLED;
/*     */         break;
/*     */       
/*     */       case "vips":
/*  94 */         chatState = BukkitCommon.ChatState.PAYMENT;
/*     */         break;
/*     */       
/*     */       default:
/*     */         try {
/*  99 */           chatState = BukkitCommon.ChatState.valueOf(cmdArgs.getArgs()[0].toUpperCase());
/* 100 */         } catch (Exception ex) {
/* 101 */           sender.sendMessage(" §a» §fUse §a/" + cmdArgs
/* 102 */               .getLabel() + " <on:off>§f para desativar ou ativar o chat.");
/*     */         } 
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 109 */     BukkitCommon.getInstance().setChatState(chatState);
/* 110 */     sender.sendMessage("§aO chat do servidor foi alterado para " + chatState.name() + ".");
/* 111 */     staffLog("O " + sender.getName() + " alterou o estado do chat para " + chatState.name() + "");
/*     */   }
/*     */   
/*     */   @Command(name = "inventorysee", aliases = {"invsee", "inv"}, console = false, permission = "command.invsee")
/*     */   public void invseeCommand(CommandArgs cmdArgs) {
/* 116 */     CommandSender sender = cmdArgs.getSender();
/* 117 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 119 */     if (args.length == 0) {
/* 120 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs
/* 121 */           .getLabel() + " <player>§f para abrir o inventário do player.");
/*     */       
/*     */       return;
/*     */     } 
/* 125 */     Player player = Bukkit.getPlayer(args[0]);
/*     */     
/* 127 */     if (player == null) {
/* 128 */       sender.sendMessage(sender.getLanguage().t("player-is-not-online", new String[] { "%player%", args[0] }));
/*     */       
/*     */       return;
/*     */     } 
/* 132 */     ((BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class)).getPlayer().openInventory((Inventory)player.getInventory());
/* 133 */     staffLog("O " + sender.getName() + " abriu o inventário de " + player.getName());
/*     */   }
/*     */   
/*     */   @Command(name = "say", permission = "command.say")
/*     */   public void sayCommand(CommandArgs cmdArgs) {
/* 138 */     CommandSender sender = cmdArgs.getSender();
/* 139 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 141 */     if (args.length == 0) {
/* 142 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs
/* 143 */           .getLabel() + " <message>§f para enviar uma mensagem no servidor.");
/*     */       
/*     */       return;
/*     */     } 
/* 147 */     String message = Joiner.on(' ').join((Object[])args).replace('&', '§');
/*     */     
/* 149 */     Bukkit.broadcastMessage("");
/* 150 */     Bukkit.broadcastMessage("§dServer> §f" + message);
/* 151 */     Bukkit.broadcastMessage("");
/* 152 */     staffLog("O " + sender.getName() + " mandou uma mensagem global.");
/*     */   }
/*     */   
/*     */   @Command(name = "admin", aliases = {"adm"}, console = false, permission = "command.admin")
/*     */   public void adminCommand(CommandArgs cmdArgs) {
/* 157 */     Player player = ((BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class)).getPlayer();
/*     */     
/* 159 */     if ((cmdArgs.getArgs()).length >= 1 && cmdArgs.getArgs()[0].equals("config")) {
/* 160 */       new AdminInventory(player, 0L);
/*     */       
/*     */       return;
/*     */     } 
/* 164 */     if (BukkitCommon.getInstance().getVanishManager().isPlayerInAdmin(player)) {
/* 165 */       BukkitCommon.getInstance().getVanishManager().setPlayer(player);
/* 166 */       staffLog("O " + player.getName() + " saiu do modo admin");
/*     */     } else {
/* 168 */       BukkitCommon.getInstance().getVanishManager().setPlayerInAdmin(player);
/* 169 */       staffLog("O " + player.getName() + " entrou no modo admin");
/*     */     } 
/*     */   }
/*     */   
/*     */   @Command(name = "anticheatbypass", permission = "staff.super")
/*     */   public void anticheatbypassCommand(CommandArgs cmdArgs) {
/* 175 */     CommandSender sender = cmdArgs.getSender();
/* 176 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 178 */     if (args.length == 0) {
/* 179 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " <player>§f para remover o autoban de um player.");
/*     */       
/*     */       return;
/*     */     } 
/* 183 */     BukkitMember member = (BukkitMember)CommonPlugin.getInstance().getMemberManager().getMemberByName(args[0], BukkitMember.class);
/*     */     
/* 185 */     if (member == null) {
/* 186 */       sender.sendMessage(sender.getLanguage().t("player-is-not-online", new String[] { "%player%", args[0] }));
/*     */       
/*     */       return;
/*     */     } 
/* 190 */     member.setAnticheatBypass(!member.isAnticheatBypass());
/* 191 */     sender.sendMessage("§aO modo anticheat bypass do player " + member.getName() + " foi alterado para " + member
/* 192 */         .isAnticheatBypass() + ".");
/*     */   }
/*     */   
/*     */   @Command(name = "autoban", permission = "command.anticheat")
/*     */   public void autobanCommand(CommandArgs cmdArgs) {
/* 197 */     CommandSender sender = cmdArgs.getSender();
/* 198 */     String[] args = cmdArgs.getArgs();
/*     */     
/* 200 */     if (args.length == 0) {
/* 201 */       sender.sendMessage(" §a» §fUse §a/" + cmdArgs.getLabel() + " <player>§f para remover o autoban de um player.");
/*     */       
/*     */       return;
/*     */     } 
/* 205 */     BukkitMember member = (BukkitMember)CommonPlugin.getInstance().getMemberManager().getMemberByName(args[0], BukkitMember.class);
/*     */     
/* 207 */     if (member == null) {
/* 208 */       sender.sendMessage(sender.getLanguage().t("player-is-not-online", new String[] { "%player%", args[0] }));
/*     */       
/*     */       return;
/*     */     } 
/* 212 */     if (!BukkitCommon.getInstance().getStormCore().getBanPlayerMap().containsKey(member.getUniqueId())) {
/* 213 */       sender.sendMessage("§cO jogador não está na lista de pré banimento.");
/*     */       
/*     */       return;
/*     */     } 
/* 217 */     sender.sendMessage("§aO jogador foi removido da lista de pré banimento e seus alertas foram limpos.");
/* 218 */     member.getUserData().getHackMap().clear();
/* 219 */     BukkitCommon.getInstance().getStormCore().getBanPlayerMap().remove(member.getUniqueId());
/*     */   }
/*     */   @Command(name = "vanish", aliases = {"v"}, permission = "command.vanish", console = false)
/*     */   public void vanishCommand(CommandArgs cmdArgs) {
/*     */     Group hidePlayer;
/* 224 */     Player player = ((BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class)).getPlayer();
/* 225 */     String[] args = cmdArgs.getArgs();
/*     */ 
/*     */ 
/*     */     
/* 229 */     if (args.length == 0) {
/* 230 */       if (BukkitCommon.getInstance().getVanishManager().isPlayerVanished(player.getUniqueId())) {
/* 231 */         BukkitCommon.getInstance().getVanishManager().showPlayer(player);
/* 232 */         player.sendMessage("§dVocê está visível para todos os jogadores.");
/* 233 */         staffLog("O " + player.getName() + " não está mais invisível");
/*     */         
/*     */         return;
/*     */       } 
/* 237 */       hidePlayer = BukkitCommon.getInstance().getVanishManager().hidePlayer(player);
/*     */     } else {
/* 239 */       Group group = CommonPlugin.getInstance().getPluginInfo().getGroupByName(args[0]);
/*     */       
/* 241 */       if (group == null) {
/* 242 */         player.sendMessage("§cO grupo " + StringFormat.formatString(args[0]) + " não existe.");
/*     */         
/*     */         return;
/*     */       } 
/* 246 */       hidePlayer = group;
/*     */     } 
/*     */     
/* 249 */     if (hidePlayer.getId() > cmdArgs.getSender().getServerGroup().getId()) {
/* 250 */       player.sendMessage("§cVocê não pode ficar invisível para um grupo superior ao seu.");
/*     */       
/*     */       return;
/*     */     } 
/* 254 */     BukkitCommon.getInstance().getVanishManager().setPlayerVanishToGroup(player, hidePlayer);
/* 255 */     player.sendMessage(Language.getLanguage(player.getUniqueId()).t("vanish.player-group-hided", new String[] { "%group%", 
/* 256 */             StringFormat.formatString(hidePlayer.getGroupName()) }));
/* 257 */     staffLog("O " + player.getName() + " ficou invisível para " + 
/* 258 */         StringFormat.formatString(hidePlayer.getGroupName()));
/*     */   }
/*     */   
/*     */   @Completer(name = "chat")
/*     */   public List<String> chatCompleter(CommandArgs cmdArgs) {
/* 263 */     return ((cmdArgs.getArgs()).length == 1) ? (List<String>)Arrays.<BukkitCommon.ChatState>asList(BukkitCommon.ChatState.values()).stream()
/* 264 */       .filter(state -> state.name().toLowerCase().startsWith(cmdArgs.getArgs()[0].toLowerCase()))
/* 265 */       .map(Enum::name).collect(Collectors.toList()) : new ArrayList<>();
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/command/register/ModeradorCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */