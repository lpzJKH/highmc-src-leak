/*    */ package net.highmc.bukkit.command.register;
/*    */ 
/*    */ import java.util.Optional;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.bukkit.BukkitCommon;
/*    */ import net.highmc.bukkit.member.BukkitMember;
/*    */ import net.highmc.bukkit.menu.report.ReportInventory;
/*    */ import net.highmc.bukkit.menu.report.ReportListInventory;
/*    */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*    */ import net.highmc.command.CommandArgs;
/*    */ import net.highmc.command.CommandClass;
/*    */ import net.highmc.command.CommandFramework.Command;
/*    */ import net.highmc.report.Report;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class ReportCommand
/*    */   implements CommandClass
/*    */ {
/*    */   @Command(name = "report", aliases = {"reports"}, permission = "command.report", console = false)
/*    */   public void reportCommand(CommandArgs cmdArgs) {
/* 21 */     Player sender = ((BukkitMember)cmdArgs.getSenderAsMember(BukkitMember.class)).getPlayer();
/* 22 */     String[] args = cmdArgs.getArgs();
/*    */     
/* 24 */     if (args.length == 0) {
/* 25 */       new ReportListInventory(sender, 1);
/*    */       
/*    */       return;
/*    */     } 
/* 29 */     Optional<Player> optional = BukkitCommon.getPlayer(args[0], false);
/*    */     
/* 31 */     if (!optional.isPresent()) {
/* 32 */       sender.sendMessage(cmdArgs.getSender().getLanguage().t("player-is-not-online", new String[] { "%player%", args[0] }));
/*    */       
/*    */       return;
/*    */     } 
/* 36 */     Player target = optional.get();
/* 37 */     Report report = CommonPlugin.getInstance().getReportManager().getReportById(target.getUniqueId());
/*    */     
/* 39 */     if (report == null) {
/* 40 */       new ReportListInventory(sender, 1);
/*    */     } else {
/* 42 */       new ReportInventory(target, report, (MenuInventory)new ReportListInventory(sender, 1));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/command/register/ReportCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */