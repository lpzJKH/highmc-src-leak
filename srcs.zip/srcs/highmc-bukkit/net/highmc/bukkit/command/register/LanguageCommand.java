/*     */ package net.highmc.bukkit.command.register;
/*     */ 
/*     */ import com.google.common.base.Joiner;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Collectors;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.member.BukkitMember;
/*     */ import net.highmc.bukkit.menu.LanguageInventory;
/*     */ import net.highmc.bukkit.menu.staff.LanguageInventory;
/*     */ import net.highmc.command.CommandArgs;
/*     */ import net.highmc.command.CommandClass;
/*     */ import net.highmc.command.CommandFramework.Command;
/*     */ import net.highmc.command.CommandFramework.Completer;
/*     */ import net.highmc.command.CommandSender;
/*     */ import net.highmc.language.Language;
/*     */ import net.highmc.member.Member;
/*     */ import net.md_5.bungee.api.ChatColor;
/*     */ 
/*     */ 
/*     */ public class LanguageCommand
/*     */   implements CommandClass
/*     */ {
/*     */   @Command(name = "language", aliases = {"lang", "lingua", "linguagem", "idioma", "idiomas"}, permission = "command.language")
/*     */   public void languageCommand(CommandArgs cmdArgs) {
/*  29 */     CommandSender sender = cmdArgs.getSender();
/*  30 */     String[] args = cmdArgs.getArgs();
/*     */     
/*  32 */     if (args.length == 0) {
/*  33 */       if (cmdArgs.isPlayer()) {
/*  34 */         new LanguageInventory(((BukkitMember)sender).getPlayer());
/*     */       } else {
/*  36 */         sender.sendMessage(sender.getLanguage().t("command-language-usage", new String[] { "%label%", cmdArgs.getLabel() }));
/*     */       } 
/*     */       return;
/*     */     } 
/*  40 */     Language language = Language.getLanguageByName(args[0]);
/*     */     
/*  42 */     if (language == null) {
/*  43 */       sender.sendMessage(sender.getLanguage().t("language-not-found", new String[] { "%language%", args[0] }));
/*     */       
/*     */       return;
/*     */     } 
/*  47 */     if (cmdArgs.isPlayer()) {
/*  48 */       ((Member)sender).setLanguage(language);
/*     */     } else {
/*  50 */       CommonPlugin.getInstance().getPluginInfo().setDefaultLanguage(language);
/*     */     } 
/*  52 */     sender.sendMessage(sender
/*  53 */         .getLanguage().t("command-language-changed", new String[] { "%language%", language.getLanguageName() }));
/*     */   }
/*     */   
/*     */   @Command(name = "translate", permission = "command.translate")
/*     */   public void translateCommand(CommandArgs cmdArgs) {
/*  58 */     CommandSender sender = cmdArgs.getSender();
/*  59 */     String[] args = cmdArgs.getArgs();
/*     */     
/*  61 */     if (args.length == 0) {
/*  62 */       sender.sendMessage(sender.getLanguage().t("command-translate-usage", new String[] { "%label%", cmdArgs.getLabel() }));
/*  63 */       if (cmdArgs.isPlayer()) {
/*  64 */         new LanguageInventory(((BukkitMember)sender).getPlayer());
/*     */       }
/*     */       return;
/*     */     } 
/*  68 */     Language language = Language.getLanguageByName(args[0]);
/*     */     
/*  70 */     if (language == null) {
/*  71 */       sender.sendMessage(sender.getLanguage().t("language-not-found", new String[] { "%language%", args[0] }));
/*     */       
/*     */       return;
/*     */     } 
/*  75 */     if (args.length == 1) {
/*  76 */       sender.sendMessage("  §aIdioma " + language.getLanguageName());
/*  77 */       sender.sendMessage("    §fTotal de traduções: §7" + (
/*  78 */           (Map)CommonPlugin.getInstance().getPluginInfo().getLanguageMap().get(language)).size());
/*  79 */       sender.sendMessage("    §fTotal de traduções incompletas: §7" + (
/*  80 */           (Map)CommonPlugin.getInstance().getPluginInfo().getLanguageMap().get(language)).entrySet().stream()
/*  81 */           .filter(entry -> ((String)entry.getValue()).startsWith("[NOT FOUND: ")).count());
/*  82 */       for (Map.Entry<String, String> entry : (Iterable<Map.Entry<String, String>>)((Map)CommonPlugin.getInstance().getPluginInfo().getLanguageMap().get(language))
/*  83 */         .entrySet()) {
/*  84 */         if (((String)entry.getValue()).startsWith("[NOT FOUND: ")) {
/*  85 */           sender.sendMessage("      §f- " + (String)entry.getKey());
/*     */         }
/*     */       } 
/*     */       return;
/*     */     } 
/*  90 */     String translateKey = args[1];
/*     */     
/*  92 */     if (args.length == 2) {
/*  93 */       sender.sendMessage("  §aTradução da " + translateKey + " no idioma " + language.getLanguageName());
/*  94 */       sender.sendMessage("    §f- " + language.t(translateKey, new String[0]));
/*     */     } else {
/*  96 */       String translate = Joiner.on(' ').join(Arrays.copyOfRange((Object[])args, 2, args.length)).replace("|n", "\n");
/*     */       
/*  98 */       CommonPlugin.getInstance().getPluginInfo().addTranslate(language, translateKey, translate);
/*  99 */       sender.sendMessage("§aA tradução do idioma " + language.name() + " para do key " + translateKey + " foi alterada para " + 
/* 100 */           ChatColor.translateAlternateColorCodes('&', translate));
/* 101 */       CommonPlugin.getInstance().saveConfig();
/*     */     } 
/*     */   }
/*     */   
/*     */   @Completer(name = "language", aliases = {"lang", "lingua", "linguagem", "idioma", "idiomas"})
/*     */   public List<String> languageCompleter(CommandArgs cmdArgs) {
/* 107 */     List<String> languageList = new ArrayList<>();
/*     */     
/* 109 */     if ((cmdArgs.getArgs()).length == 1)
/* 110 */       if (cmdArgs.getArgs()[0].isEmpty()) {
/* 111 */         for (Language language : Language.values())
/* 112 */           languageList.add(language.name()); 
/*     */       } else {
/* 114 */         for (Language language : Language.values()) {
/* 115 */           if (language.name().toLowerCase().startsWith(cmdArgs.getArgs()[0].toLowerCase())) {
/* 116 */             languageList.add(language.name());
/*     */           }
/*     */         } 
/*     */       }  
/* 120 */     return languageList;
/*     */   }
/*     */   
/*     */   @Completer(name = "translate")
/*     */   public List<String> translateCompleter(CommandArgs cmdArgs) {
/* 125 */     List<String> translateList = new ArrayList<>();
/*     */     
/* 127 */     if ((cmdArgs.getArgs()).length == 1) {
/* 128 */       if (cmdArgs.getArgs()[0].isEmpty()) {
/* 129 */         for (Language language : Language.values())
/* 130 */           translateList.add(language.name()); 
/*     */       } else {
/* 132 */         for (Language language : Language.values())
/* 133 */         { if (language.name().toLowerCase().startsWith(cmdArgs.getArgs()[0].toLowerCase()))
/* 134 */             translateList.add(language.name());  } 
/*     */       } 
/* 136 */     } else if ((cmdArgs.getArgs()).length == 2) {
/* 137 */       Language language = Language.getLanguageByName(cmdArgs.getArgs()[0]);
/*     */       
/* 139 */       if (language != null)
/* 140 */         for (Map.Entry<String, String> entry : (Iterable<Map.Entry<String, String>>)((Map)CommonPlugin.getInstance().getPluginInfo().getLanguageMap()
/* 141 */           .computeIfAbsent(language, v -> new HashMap<>())).entrySet().stream()
/* 142 */           .sorted((o1, o2) -> ((String)o1.getKey()).compareTo((String)o2.getKey())).collect(Collectors.toList())) {
/* 143 */           if (((String)entry.getKey()).toLowerCase().startsWith(cmdArgs.getArgs()[1].toLowerCase())) {
/* 144 */             translateList.add(((String)entry.getKey()).toLowerCase());
/*     */           }
/*     */         }  
/*     */     } 
/* 148 */     return translateList;
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/command/register/LanguageCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */