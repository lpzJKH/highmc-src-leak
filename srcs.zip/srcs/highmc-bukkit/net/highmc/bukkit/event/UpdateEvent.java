/*    */ package net.highmc.bukkit.event;
/*    */ 
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class UpdateEvent
/*    */   extends Event {
/*  8 */   public static final HandlerList handlers = new HandlerList();
/*    */   private UpdateType type;
/*    */   private long currentTick;
/*    */   
/*    */   public UpdateEvent(UpdateType type) {
/* 13 */     this(type, -1L);
/*    */   }
/*    */   
/*    */   public UpdateEvent(UpdateType type, long currentTick) {
/* 17 */     this.type = type;
/* 18 */     this.currentTick = currentTick;
/*    */   }
/*    */   
/*    */   public UpdateType getType() {
/* 22 */     return this.type;
/*    */   }
/*    */   
/*    */   public long getCurrentTick() {
/* 26 */     return this.currentTick;
/*    */   }
/*    */   
/*    */   public HandlerList getHandlers() {
/* 30 */     return handlers;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 34 */     return handlers;
/*    */   }
/*    */   
/*    */   public enum UpdateType {
/* 38 */     TICK, SECOND, MINUTE;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/event/UpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */