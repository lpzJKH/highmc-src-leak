/*    */ package net.highmc.bukkit.event.server;
/*    */ import org.bukkit.Location;
/*    */ 
/*    */ public class LocationChangeEvent extends NormalEvent {
/*    */   private String configName;
/*    */   private Location newLocation;
/*    */   private Location oldLocation;
/*    */   
/*    */   public LocationChangeEvent(String configName, Location newLocation, Location oldLocation) {
/* 10 */     this.configName = configName; this.newLocation = newLocation; this.oldLocation = oldLocation;
/*    */   }
/*    */   
/* 13 */   public String getConfigName() { return this.configName; }
/* 14 */   public Location getNewLocation() { return this.newLocation; } public Location getOldLocation() {
/* 15 */     return this.oldLocation;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/event/server/LocationChangeEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */