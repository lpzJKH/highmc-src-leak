/*    */ package net.highmc.bukkit.event.server;
/*    */ import net.highmc.backend.data.DataServerMessage;
/*    */ import net.highmc.server.ServerType;
/*    */ 
/*    */ public class ServerEvent extends NormalEvent {
/*    */   private String serverId;
/*    */   private ServerType serverType;
/*    */   
/*    */   public ServerEvent(String serverId, ServerType serverType, ProxiedServer proxiedServer, DataServerMessage<?> data, DataServerMessage.Action action) {
/* 10 */     this.serverId = serverId; this.serverType = serverType; this.proxiedServer = proxiedServer; this.data = data; this.action = action;
/*    */   }
/*    */   private ProxiedServer proxiedServer; private DataServerMessage<?> data; private DataServerMessage.Action action;
/*    */   public String getServerId() {
/* 14 */     return this.serverId; } public ServerType getServerType() {
/* 15 */     return this.serverType;
/*    */   }
/* 17 */   public ProxiedServer getProxiedServer() { return this.proxiedServer; }
/* 18 */   public DataServerMessage<?> getData() { return this.data; } public DataServerMessage.Action getAction() {
/* 19 */     return this.action;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/event/server/ServerEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */