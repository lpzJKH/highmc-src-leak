/*    */ package net.highmc.bukkit.event.server;
/*    */ 
/*    */ import net.highmc.bukkit.event.NormalEvent;
/*    */ 
/*    */ public class PlayerChangeEvent
/*    */   extends NormalEvent {
/*    */   public PlayerChangeEvent(int totalMembers) {
/*  8 */     this.totalMembers = totalMembers;
/*    */   } private int totalMembers;
/*    */   public int getTotalMembers() {
/* 11 */     return this.totalMembers;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/event/server/PlayerChangeEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */