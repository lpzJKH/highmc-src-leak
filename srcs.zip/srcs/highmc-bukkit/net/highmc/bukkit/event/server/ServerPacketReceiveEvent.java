/*    */ package net.highmc.bukkit.event.server;
/*    */ import net.highmc.packet.Packet;
/*    */ import net.highmc.packet.PacketType;
/*    */ 
/*    */ public class ServerPacketReceiveEvent extends NormalEvent {
/*    */   private PacketType packetType;
/*    */   
/*    */   public ServerPacketReceiveEvent(PacketType packetType, Packet packet) {
/*  9 */     this.packetType = packetType; this.packet = packet;
/*    */   }
/*    */   private Packet packet;
/*    */   public PacketType getPacketType() {
/* 13 */     return this.packetType; } public Packet getPacket() {
/* 14 */     return this.packet;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/event/server/ServerPacketReceiveEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */