/*    */ package net.highmc.bukkit.event;
/*    */ 
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class PlayerEvent
/*    */   extends NormalEvent {
/*    */   public PlayerEvent(Player player) {
/*  8 */     this.player = player;
/*    */   } private Player player;
/*    */   public Player getPlayer() {
/* 11 */     return this.player;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/event/PlayerEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */