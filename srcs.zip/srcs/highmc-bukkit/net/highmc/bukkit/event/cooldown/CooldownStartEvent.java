/*    */ package net.highmc.bukkit.event.cooldown;
/*    */ 
/*    */ import net.highmc.bukkit.utils.cooldown.Cooldown;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Cancellable;
/*    */ 
/*    */ public class CooldownStartEvent extends CooldownEvent implements Cancellable {
/*    */   private boolean cancelled;
/*    */   
/*    */   public void setCancelled(boolean cancelled) {
/* 11 */     this.cancelled = cancelled;
/*    */   }
/*    */   public boolean isCancelled() {
/* 14 */     return this.cancelled;
/*    */   }
/*    */   public CooldownStartEvent(Player player, Cooldown cooldown) {
/* 17 */     super(player, cooldown);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/event/cooldown/CooldownStartEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */