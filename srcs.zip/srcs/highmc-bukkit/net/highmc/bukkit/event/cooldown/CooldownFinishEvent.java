/*    */ package net.highmc.bukkit.event.cooldown;
/*    */ 
/*    */ import net.highmc.bukkit.utils.cooldown.Cooldown;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class CooldownFinishEvent
/*    */   extends CooldownStopEvent
/*    */ {
/*    */   public CooldownFinishEvent(Player player, Cooldown cooldown) {
/* 10 */     super(player, cooldown);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/event/cooldown/CooldownFinishEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */