/*    */ package net.highmc.bukkit.event.cooldown;
/*    */ 
/*    */ import lombok.NonNull;
/*    */ import net.highmc.bukkit.event.PlayerEvent;
/*    */ import net.highmc.bukkit.utils.cooldown.Cooldown;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public abstract class CooldownEvent
/*    */   extends PlayerEvent {
/*    */   @NonNull
/*    */   public Cooldown getCooldown() {
/* 12 */     return this.cooldown;
/*    */   }
/*    */   @NonNull
/*    */   private Cooldown cooldown;
/*    */   public CooldownEvent(Player player, Cooldown cooldown) {
/* 17 */     super(player);
/* 18 */     this.cooldown = cooldown;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/event/cooldown/CooldownEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */