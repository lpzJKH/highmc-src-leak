/*    */ package net.highmc.bukkit.event.player;
/*    */ 
/*    */ import net.highmc.bukkit.event.PlayerEvent;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ 
/*    */ public class PlayerOpenInventoryEvent
/*    */   extends PlayerEvent {
/*    */   private Inventory inventory;
/*    */   
/*    */   public Inventory getInventory() {
/* 12 */     return this.inventory;
/*    */   }
/*    */   public PlayerOpenInventoryEvent(Player player, Inventory inventory) {
/* 15 */     super(player);
/* 16 */     this.inventory = inventory;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/event/player/PlayerOpenInventoryEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */