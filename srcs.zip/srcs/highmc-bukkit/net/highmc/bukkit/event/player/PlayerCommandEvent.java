/*    */ package net.highmc.bukkit.event.player;
/*    */ 
/*    */ import net.highmc.bukkit.event.PlayerCancellableEvent;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class PlayerCommandEvent
/*    */   extends PlayerCancellableEvent {
/*    */   private String commandLabel;
/*    */   
/*    */   public String getCommandLabel() {
/* 11 */     return this.commandLabel;
/*    */   }
/*    */   public PlayerCommandEvent(Player player, String commandLabel) {
/* 14 */     super(player);
/* 15 */     this.commandLabel = commandLabel;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/event/player/PlayerCommandEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */