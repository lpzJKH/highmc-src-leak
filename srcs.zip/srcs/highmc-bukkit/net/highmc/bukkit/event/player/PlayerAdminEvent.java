/*    */ package net.highmc.bukkit.event.player;
/*    */ 
/*    */ import net.highmc.bukkit.event.PlayerCancellableEvent;
/*    */ import org.bukkit.GameMode;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class PlayerAdminEvent
/*    */   extends PlayerCancellableEvent {
/*    */   private AdminMode adminMode;
/*    */   private GameMode gameMode;
/*    */   
/*    */   public AdminMode getAdminMode() {
/* 13 */     return this.adminMode; }
/* 14 */   public void setGameMode(GameMode gameMode) { this.gameMode = gameMode; } public GameMode getGameMode() {
/* 15 */     return this.gameMode;
/*    */   }
/*    */   public PlayerAdminEvent(Player player, AdminMode adminMode, GameMode mode) {
/* 18 */     super(player);
/* 19 */     this.adminMode = adminMode;
/* 20 */     this.gameMode = mode;
/*    */   }
/*    */   
/*    */   public enum AdminMode {
/* 24 */     ADMIN,
/* 25 */     PLAYER;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/event/player/PlayerAdminEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */