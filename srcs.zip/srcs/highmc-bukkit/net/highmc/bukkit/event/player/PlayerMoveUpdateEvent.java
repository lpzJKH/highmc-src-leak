/*    */ package net.highmc.bukkit.event.player;
/*    */ 
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.player.PlayerMoveEvent;
/*    */ 
/*    */ public class PlayerMoveUpdateEvent
/*    */   extends PlayerMoveEvent {
/*    */   public PlayerMoveUpdateEvent(Player player, Location from, Location to) {
/* 10 */     super(player, from, to);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/event/player/PlayerMoveUpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */