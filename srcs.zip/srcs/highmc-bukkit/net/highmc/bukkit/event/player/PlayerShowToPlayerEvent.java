/*    */ package net.highmc.bukkit.event.player;
/*    */ 
/*    */ import net.highmc.bukkit.event.PlayerCancellableEvent;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class PlayerShowToPlayerEvent extends PlayerCancellableEvent {
/*    */   private Player toPlayer;
/*    */   
/*    */   public Player getToPlayer() {
/* 10 */     return this.toPlayer;
/*    */   }
/*    */   public PlayerShowToPlayerEvent(Player player, Player toPlayer) {
/* 13 */     super(player);
/* 14 */     this.toPlayer = toPlayer;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/event/player/PlayerShowToPlayerEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */