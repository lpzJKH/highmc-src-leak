/*    */ package net.highmc.bukkit.event.player;
/*    */ import net.highmc.bukkit.event.PlayerCancellableEvent;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class PlayerDamagePlayerEvent extends PlayerCancellableEvent {
/*    */   private Player damager;
/*    */   private double damage;
/*    */   private double finalDamage;
/*    */   
/*    */   public Player getDamager() {
/* 11 */     return this.damager;
/*    */   }
/* 13 */   public double getDamage() { return this.damage; } public double getFinalDamage() { return this.finalDamage; }
/*    */   
/*    */   public PlayerDamagePlayerEvent(Player entity, Player damager, boolean cancelled, double damage, double finalDamage) {
/* 16 */     super(entity);
/*    */     
/* 18 */     setCancelled(cancelled);
/* 19 */     this.damager = damager;
/* 20 */     this.damage = damage;
/* 21 */     this.finalDamage = finalDamage;
/*    */   }
/*    */   
/*    */   public void setDamage(double damage) {
/* 25 */     this.damage = damage;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/event/player/PlayerDamagePlayerEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */