/*    */ package net.highmc.bukkit.event.player;
/*    */ 
/*    */ import net.highmc.bukkit.event.PlayerCancellableEvent;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class PlayerHideToPlayerEvent
/*    */   extends PlayerCancellableEvent {
/*    */   private Player toPlayer;
/*    */   
/*    */   public Player getToPlayer() {
/* 11 */     return this.toPlayer;
/*    */   }
/*    */   public PlayerHideToPlayerEvent(Player player, Player toPlayer) {
/* 14 */     super(player);
/* 15 */     this.toPlayer = toPlayer;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/event/player/PlayerHideToPlayerEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */