/*    */ package net.highmc.bukkit.event;
/*    */ 
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class NormalEvent
/*    */   extends Event {
/*  8 */   private static final HandlerList HANDLER_LIST = new HandlerList();
/*    */ 
/*    */   
/*    */   public HandlerList getHandlers() {
/* 12 */     return HANDLER_LIST;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 16 */     return HANDLER_LIST;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/event/NormalEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */