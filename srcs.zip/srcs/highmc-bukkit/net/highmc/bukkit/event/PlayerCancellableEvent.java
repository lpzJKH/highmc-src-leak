/*    */ package net.highmc.bukkit.event;
/*    */ 
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Cancellable;
/*    */ 
/*    */ public class PlayerCancellableEvent extends PlayerEvent implements Cancellable {
/*    */   private boolean cancelled;
/*    */   
/*    */   public void setCancelled(boolean cancelled) {
/* 10 */     this.cancelled = cancelled;
/*    */   }
/*    */   public boolean isCancelled() {
/* 13 */     return this.cancelled;
/*    */   }
/*    */   public PlayerCancellableEvent(Player player) {
/* 16 */     super(player);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/event/PlayerCancellableEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */