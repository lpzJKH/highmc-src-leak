/*    */ package net.highmc.bukkit.event.member;
/*    */ 
/*    */ import net.highmc.bukkit.event.PlayerEvent;
/*    */ import net.highmc.member.Member;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class PlayerAuthEvent
/*    */   extends PlayerEvent {
/*    */   private Member member;
/*    */   
/*    */   public Member getMember() {
/* 12 */     return this.member;
/*    */   }
/*    */   public PlayerAuthEvent(Player player, Member member) {
/* 15 */     super(player);
/* 16 */     this.member = member;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/event/member/PlayerAuthEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */