/*    */ package net.highmc.bukkit.event.member;
/*    */ 
/*    */ import lombok.NonNull;
/*    */ import net.highmc.bukkit.event.PlayerEvent;
/*    */ import net.highmc.language.Language;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class PlayerLanguageChangeEvent
/*    */   extends PlayerEvent {
/*    */   private Language language;
/*    */   
/*    */   public Language getLanguage() {
/* 13 */     return this.language;
/*    */   }
/*    */   public PlayerLanguageChangeEvent(@NonNull Player player, @NonNull Language language) {
/* 16 */     super(player); if (player == null) throw new NullPointerException("player is marked non-null but is null");  if (language == null)
/* 17 */       throw new NullPointerException("language is marked non-null but is null");  this.language = language;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/event/member/PlayerLanguageChangeEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */