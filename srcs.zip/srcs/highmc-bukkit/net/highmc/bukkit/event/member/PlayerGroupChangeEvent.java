/*    */ package net.highmc.bukkit.event.member;
/*    */ 
/*    */ import lombok.NonNull;
/*    */ import net.highmc.bukkit.event.PlayerEvent;
/*    */ import net.highmc.member.Member;
/*    */ import net.highmc.permission.Group;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class PlayerGroupChangeEvent extends PlayerEvent {
/*    */   private Member member;
/*    */   private String groupName;
/*    */   private long newTime;
/*    */   private Action action;
/*    */   
/* 15 */   public Member getMember() { return this.member; }
/* 16 */   public String getGroupName() { return this.groupName; } public long getNewTime() {
/* 17 */     return this.newTime;
/*    */   } public Action getAction() {
/* 19 */     return this.action;
/*    */   }
/*    */   
/*    */   public PlayerGroupChangeEvent(@NonNull Player player, Member member, String groupName, long newTime, Action action) {
/* 23 */     super(player); if (player == null)
/* 24 */       throw new NullPointerException("player is marked non-null but is null");  this.member = member;
/* 25 */     this.groupName = groupName;
/* 26 */     this.newTime = newTime;
/* 27 */     this.action = action;
/*    */   }
/*    */   
/*    */   public PlayerGroupChangeEvent(@NonNull Player player, Member member, Group group, long newTime, Action action) {
/* 31 */     super(player); if (player == null)
/* 32 */       throw new NullPointerException("player is marked non-null but is null");  this.member = member;
/* 33 */     this.groupName = group.getGroupName();
/* 34 */     this.newTime = newTime;
/* 35 */     this.action = action;
/*    */   }
/*    */   
/*    */   public Group getGroup() {
/* 39 */     return (this.groupName == null) ? null : CommonPlugin.getInstance().getPluginInfo().getGroupByName(this.groupName);
/*    */   }
/*    */   
/*    */   public enum Action
/*    */   {
/* 44 */     ADD, SET, REMOVE, CLEAR, UNKNOWN;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/event/member/PlayerGroupChangeEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */