/*    */ package net.highmc.bukkit.event.member;
/*    */ 
/*    */ import net.highmc.bukkit.event.PlayerEvent;
/*    */ import net.highmc.bukkit.member.BukkitMember;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class PlayerUpdatedFieldEvent extends PlayerEvent {
/*    */   private BukkitMember bukkitMember;
/*    */   private String field;
/*    */   private Object oldObject;
/*    */   private Object object;
/*    */   
/* 13 */   public BukkitMember getBukkitMember() { return this.bukkitMember; }
/* 14 */   public String getField() { return this.field; }
/* 15 */   public Object getOldObject() { return this.oldObject; }
/* 16 */   public void setObject(Object object) { this.object = object; } public Object getObject() {
/* 17 */     return this.object;
/*    */   }
/*    */   public PlayerUpdatedFieldEvent(Player p, BukkitMember player, String field, Object oldObject, Object object) {
/* 20 */     super(p);
/* 21 */     this.bukkitMember = player;
/* 22 */     this.field = field;
/* 23 */     this.oldObject = oldObject;
/* 24 */     this.object = object;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/event/member/PlayerUpdatedFieldEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */