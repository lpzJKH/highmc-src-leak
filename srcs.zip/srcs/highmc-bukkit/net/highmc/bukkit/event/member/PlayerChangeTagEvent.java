/*    */ package net.highmc.bukkit.event.member;
/*    */ 
/*    */ import net.highmc.bukkit.event.PlayerCancellableEvent;
/*    */ import net.highmc.permission.Tag;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class PlayerChangeTagEvent extends PlayerCancellableEvent {
/*    */   private Tag oldTag;
/*    */   private Tag newTag;
/*    */   private boolean forced;
/*    */   
/*    */   public Tag getOldTag() {
/* 13 */     return this.oldTag;
/* 14 */   } public void setNewTag(Tag newTag) { this.newTag = newTag; }
/* 15 */   public Tag getNewTag() { return this.newTag; } public boolean isForced() {
/* 16 */     return this.forced;
/*    */   }
/*    */   public PlayerChangeTagEvent(Player p, Tag oldTag, Tag newTag, boolean forced) {
/* 19 */     super(p);
/* 20 */     this.oldTag = oldTag;
/* 21 */     this.newTag = newTag;
/* 22 */     this.forced = forced;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/event/member/PlayerChangeTagEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */