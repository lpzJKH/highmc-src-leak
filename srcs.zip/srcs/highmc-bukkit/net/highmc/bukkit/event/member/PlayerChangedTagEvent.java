/*    */ package net.highmc.bukkit.event.member;
/*    */ import net.highmc.bukkit.event.PlayerCancellableEvent;
/*    */ import net.highmc.member.Member;
/*    */ import net.highmc.permission.Tag;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class PlayerChangedTagEvent extends PlayerCancellableEvent {
/*    */   private Member member;
/*    */   private Tag oldTag;
/*    */   private Tag newTag;
/*    */   private boolean forced;
/*    */   
/*    */   public Member getMember() {
/* 14 */     return this.member;
/*    */   }
/* 16 */   public Tag getOldTag() { return this.oldTag; }
/* 17 */   public void setNewTag(Tag newTag) { this.newTag = newTag; }
/* 18 */   public Tag getNewTag() { return this.newTag; } public boolean isForced() {
/* 19 */     return this.forced;
/*    */   }
/*    */   public PlayerChangedTagEvent(Player player, Member member, Tag oldTag, Tag newTag, boolean forced) {
/* 22 */     super(player);
/* 23 */     this.member = member;
/* 24 */     this.oldTag = oldTag;
/* 25 */     this.newTag = newTag;
/* 26 */     this.forced = forced;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/event/member/PlayerChangedTagEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */