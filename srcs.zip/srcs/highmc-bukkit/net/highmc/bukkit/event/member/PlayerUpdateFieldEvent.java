/*    */ package net.highmc.bukkit.event.member;
/*    */ 
/*    */ import net.highmc.bukkit.event.PlayerCancellableEvent;
/*    */ import net.highmc.bukkit.member.BukkitMember;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class PlayerUpdateFieldEvent extends PlayerCancellableEvent {
/*    */   private BukkitMember bukkitMember;
/*    */   private String field;
/*    */   private Object oldObject;
/*    */   private Object object;
/*    */   
/* 13 */   public BukkitMember getBukkitMember() { return this.bukkitMember; }
/* 14 */   public String getField() { return this.field; }
/* 15 */   public void setOldObject(Object oldObject) { this.oldObject = oldObject; }
/* 16 */   public Object getOldObject() { return this.oldObject; }
/* 17 */   public void setObject(Object object) { this.object = object; } public Object getObject() {
/* 18 */     return this.object;
/*    */   }
/*    */   public PlayerUpdateFieldEvent(Player p, BukkitMember player, String field, Object oldObject, Object object) {
/* 21 */     super(p);
/* 22 */     this.bukkitMember = player;
/* 23 */     this.field = field;
/* 24 */     this.oldObject = oldObject;
/* 25 */     this.object = object;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/event/member/PlayerUpdateFieldEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */