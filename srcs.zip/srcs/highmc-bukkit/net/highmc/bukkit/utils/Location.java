/*    */ package net.highmc.bukkit.utils;
/*    */ 
/*    */ import java.util.OptionalInt;
/*    */ import net.highmc.CommonConst;
/*    */ 
/*    */ public class Location {
/*    */   private String worldName;
/*    */   private double x;
/*    */   private double y;
/*    */   private double z;
/*    */   private float yaw;
/*    */   private float pitch;
/*    */   
/* 14 */   public void setWorldName(String worldName) { this.worldName = worldName; } public void setX(double x) { this.x = x; } public void setY(double y) { this.y = y; } public void setZ(double z) { this.z = z; } public void setYaw(float yaw) { this.yaw = yaw; } public void setPitch(float pitch) { this.pitch = pitch; } public Location(String worldName, double x, double y, double z, float yaw, float pitch) {
/* 15 */     this.worldName = worldName; this.x = x; this.y = y; this.z = z; this.yaw = yaw; this.pitch = pitch;
/*    */   }
/*    */   public String getWorldName() {
/* 18 */     return this.worldName;
/*    */   }
/* 20 */   public double getX() { return this.x; }
/* 21 */   public double getY() { return this.y; } public double getZ() {
/* 22 */     return this.z;
/*    */   }
/* 24 */   public float getYaw() { return this.yaw; } public float getPitch() {
/* 25 */     return this.pitch;
/*    */   }
/*    */   public Location() {
/* 28 */     this(((World)Bukkit.getWorlds().stream().findFirst().orElse(null)).getName(), 0.0D, 0.0D, 0.0D, 0.0F, 0.0F);
/*    */   }
/*    */   
/*    */   public Location(String worldName) {
/* 32 */     this(worldName, 0.0D, 0.0D, 0.0D, 0.0F, 0.0F);
/*    */   }
/*    */   
/*    */   public Location(String worldName, double x, double y, double z) {
/* 36 */     this(worldName, x, y, z, 0.0F, 0.0F);
/*    */   }
/*    */   
/*    */   public World getWorld() {
/* 40 */     return Bukkit.getWorld(this.worldName);
/*    */   }
/*    */   
/*    */   public void set(org.bukkit.Location location) {
/* 44 */     this.x = location.getX();
/* 45 */     this.y = location.getY();
/* 46 */     this.z = location.getZ();
/*    */     
/* 48 */     this.yaw = location.getYaw();
/* 49 */     this.pitch = location.getPitch();
/*    */   }
/*    */   
/*    */   public org.bukkit.Location getAsLocation() {
/* 53 */     return new org.bukkit.Location(getWorld(), this.x, this.y, this.z, this.yaw, this.pitch);
/*    */   }
/*    */   
/*    */   public static Location fromLocation(org.bukkit.Location location) {
/* 57 */     return new Location(location.getWorld().getName(), location.getX(), location.getY(), location.getZ(), location
/* 58 */         .getYaw(), location.getPitch());
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 63 */     return CommonConst.GSON.toJson(this);
/*    */   }
/*    */   
/*    */   public static Location valueOf(String value) {
/* 67 */     if (value.startsWith("{") && value.endsWith("}")) {
/* 68 */       return (Location)CommonConst.GSON.fromJson(value, Location.class);
/*    */     }
/* 70 */     if (value.contains(",")) {
/* 71 */       boolean space = value.contains(", ");
/* 72 */       String[] split = value.split(space ? ", " : ",");
/*    */       
/* 74 */       String worldName = split[0];
/* 75 */       OptionalInt optionalX = OptionalInt.of(Integer.valueOf(split[1]).intValue());
/* 76 */       OptionalInt optionalY = OptionalInt.of(Integer.valueOf(split[2]).intValue());
/* 77 */       OptionalInt optionalZ = OptionalInt.of(Integer.valueOf(split[3]).intValue());
/* 78 */       return new Location(worldName, optionalX.getAsInt(), optionalY.getAsInt(), optionalZ.getAsInt(), 0.0F, 0.0F);
/*    */     } 
/*    */     
/* 81 */     return null;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/Location.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */