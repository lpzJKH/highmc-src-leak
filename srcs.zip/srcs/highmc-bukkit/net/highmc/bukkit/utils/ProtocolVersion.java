/*    */ package net.highmc.bukkit.utils;
/*    */ 
/*    */ import com.comphenix.protocol.ProtocolLibrary;
/*    */ import java.util.stream.Stream;
/*    */ import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ProtocolVersion
/*    */ {
/* 12 */   MINECRAFT_1_16_3(753), MINECRAFT_1_16_2(751), MINECRAFT_1_16_1(736), MINECRAFT_1_16(735), MINECRAFT_1_15_2(578),
/* 13 */   MINECRAFT_1_15_1(575), MINECRAFT_1_15(573), MINECRAFT_1_14_4(498), MINECRAFT_1_14_3(490), MINECRAFT_1_14_2(485),
/* 14 */   MINECRAFT_1_14_1(480), MINECRAFT_1_14(477), MINECRAFT_1_13_2(404), MINECRAFT_1_13_1(401), MINECRAFT_1_13(393),
/* 15 */   MINECRAFT_1_12_2(340), MINECRAFT_1_12_1(338), MINECRAFT_1_12(335), MINECRAFT_1_11_1(316), MINECRAFT_1_11(315),
/* 16 */   MINECRAFT_1_10(210), MINECRAFT_1_9_3(110), MINECRAFT_1_9_2(109), MINECRAFT_1_9_1(108), MINECRAFT_1_9(107),
/* 17 */   MINECRAFT_1_8(47), MINECRAFT_1_7_10(5), MINECRAFT_1_7_2(4), UNKNOWN(-1);
/*    */   
/*    */   private int id;
/*    */   
/*    */   ProtocolVersion(int id) {
/* 22 */     this.id = id;
/*    */   }
/*    */   
/*    */   public int getId() {
/* 26 */     return this.id;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 31 */     return super.toString().replace("MINECRAFT_", "").replace("_", ".");
/*    */   }
/*    */   
/*    */   public static int getPing(Player player) {
/* 35 */     return (((CraftPlayer)player).getHandle()).ping;
/*    */   }
/*    */   
/*    */   public static ProtocolVersion getById(int id) {
/* 39 */     return Stream.<ProtocolVersion>of(values()).filter(version -> (version.getId() == id)).findFirst().orElse(UNKNOWN);
/*    */   }
/*    */   
/*    */   public static ProtocolVersion getProtocolVersion(Player player) {
/* 43 */     return getById(ProtocolLibrary.getProtocolManager().getProtocolVersion(player));
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/ProtocolVersion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */