/*    */ package net.highmc.bukkit.utils.character;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import net.highmc.bukkit.utils.character.handler.ActionHandler;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Character
/*    */ {
/* 20 */   private static final Map<Integer, Character> OBSERVER_MAP = new HashMap<>();
/*    */   private ActionHandler interactHandler; private NPC npc;
/*    */   
/* 23 */   public ActionHandler getInteractHandler() { return this.interactHandler; } public NPC getNpc() {
/* 24 */     return this.npc;
/*    */   }
/*    */   public Character(NPC npc, ActionHandler interactHandler) {
/* 27 */     this.npc = npc;
/* 28 */     this.interactHandler = interactHandler;
/* 29 */     registerCharacter(this);
/*    */   }
/*    */   
/*    */   public Character(String skinName, Location location, ActionHandler interactHandler) {
/* 33 */     this.npc = new NPC(location, skinName);
/* 34 */     this.interactHandler = interactHandler;
/* 35 */     registerCharacter(this);
/*    */   }
/*    */   
/*    */   public static Character createCharacter(String skinName, Location location) {
/* 39 */     return new Character(skinName, location, new ActionHandler()
/*    */         {
/*    */           public boolean onInteract(Player player, boolean right)
/*    */           {
/* 43 */             return false;
/*    */           }
/*    */         });
/*    */   }
/*    */   
/*    */   public void show(Player player) {
/* 49 */     this.npc.show(player);
/*    */   }
/*    */   
/*    */   public void hide(Player player) {
/* 53 */     this.npc.hide(player);
/*    */   }
/*    */   
/*    */   public void remove() {
/* 57 */     getNpc().remove();
/* 58 */     unregisterCharacter(this);
/*    */   }
/*    */   
/*    */   public void teleport(Location location) {
/* 62 */     this.npc.teleport(location);
/*    */   }
/*    */   
/*    */   public boolean isShowing(UUID uniqueId) {
/* 66 */     return this.npc.getShowing().contains(uniqueId);
/*    */   }
/*    */   
/*    */   public static NPC createNpc(Location location, String skinName) {
/* 70 */     NPC citizen = new NPC(location, skinName);
/* 71 */     return citizen;
/*    */   }
/*    */   
/*    */   public static void registerCharacter(Character character) {
/* 75 */     OBSERVER_MAP.put(Integer.valueOf(character.getNpc().getEntityPlayer().getId()), character);
/*    */   }
/*    */   
/*    */   public static void unregisterCharacter(Integer id) {
/* 79 */     OBSERVER_MAP.remove(id);
/*    */   }
/*    */   
/*    */   public static void unregisterCharacter(Character character) {
/* 83 */     OBSERVER_MAP.remove(Integer.valueOf(character.getNpc().getEntityPlayer().getId()));
/*    */   }
/*    */   
/*    */   public static Character getCharacter(Integer id) {
/* 87 */     return OBSERVER_MAP.get(id);
/*    */   }
/*    */   
/*    */   public static Collection<Character> getCharacters() {
/* 91 */     return OBSERVER_MAP.values();
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/character/Character.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */