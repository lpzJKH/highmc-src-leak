package net.highmc.bukkit.utils.character.handler;

import org.bukkit.entity.Player;

public interface ActionHandler {
  boolean onInteract(Player paramPlayer, boolean paramBoolean);
}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/character/handler/ActionHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */