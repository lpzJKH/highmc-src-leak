/*     */ package net.highmc.bukkit.utils.character;
/*     */ import com.google.common.collect.Multimap;
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import com.mojang.authlib.properties.Property;
/*     */ import com.mojang.authlib.properties.PropertyMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.utils.skin.Skin;
/*     */ import net.highmc.utils.string.CodeCreator;
/*     */ import net.minecraft.server.v1_8_R3.DataWatcher;
/*     */ import net.minecraft.server.v1_8_R3.Entity;
/*     */ import net.minecraft.server.v1_8_R3.EntityBat;
/*     */ import net.minecraft.server.v1_8_R3.EntityHuman;
/*     */ import net.minecraft.server.v1_8_R3.EntityLiving;
/*     */ import net.minecraft.server.v1_8_R3.EntityPlayer;
/*     */ import net.minecraft.server.v1_8_R3.MinecraftServer;
/*     */ import net.minecraft.server.v1_8_R3.Packet;
/*     */ import net.minecraft.server.v1_8_R3.PacketPlayOutEntityDestroy;
/*     */ import net.minecraft.server.v1_8_R3.PacketPlayOutEntityMetadata;
/*     */ import net.minecraft.server.v1_8_R3.PacketPlayOutNamedEntitySpawn;
/*     */ import net.minecraft.server.v1_8_R3.PacketPlayOutPlayerInfo;
/*     */ import net.minecraft.server.v1_8_R3.PacketPlayOutSpawnEntityLiving;
/*     */ import net.minecraft.server.v1_8_R3.PlayerConnection;
/*     */ import net.minecraft.server.v1_8_R3.PlayerInteractManager;
/*     */ import net.minecraft.server.v1_8_R3.World;
/*     */ import net.minecraft.server.v1_8_R3.WorldServer;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.craftbukkit.v1_8_R3.CraftServer;
/*     */ import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;
/*     */ import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class NPC {
/*     */   private GameProfile gameProfile;
/*     */   private Location location;
/*  41 */   public static final CodeCreator CODE_CREATOR = (new CodeCreator(10)).setSpecialCharacters(false).setUpperCase(false)
/*  42 */     .setNumbers(true); private EntityPlayer entityPlayer; private EntityBat entityBat;
/*     */   public GameProfile getGameProfile() {
/*  44 */     return this.gameProfile;
/*     */   } public Location getLocation() {
/*  46 */     return this.location;
/*     */   }
/*  48 */   public EntityPlayer getEntityPlayer() { return this.entityPlayer; } public EntityBat getEntityBat() {
/*  49 */     return this.entityBat;
/*     */   }
/*  51 */   private Set<UUID> showing = new HashSet<>(); public Set<UUID> getShowing() { return this.showing; }
/*     */   
/*     */   public NPC(Location location, String skinName) {
/*  54 */     this(location, CommonPlugin.getInstance().getSkinData().loadData(skinName).orElse(null));
/*     */   }
/*     */   
/*     */   public NPC(Location location, Skin skin) {
/*  58 */     this
/*  59 */       .location = new Location(location.getWorld(), location.getX(), location.getY(), location.getZ(), location.getYaw(), location.getPitch());
/*     */     
/*  61 */     MinecraftServer server = ((CraftServer)Bukkit.getServer()).getServer();
/*  62 */     WorldServer world = ((CraftWorld)location.getWorld()).getHandle();
/*     */     
/*  64 */     this.gameProfile = new GameProfile(UUID.randomUUID(), "§8[" + CODE_CREATOR.random() + "]");
/*     */     
/*  66 */     this.entityPlayer = new EntityPlayer(server, world, this.gameProfile, new PlayerInteractManager((World)world));
/*     */     
/*  68 */     if (skin != null) {
/*  69 */       this.gameProfile.getProperties().clear();
/*  70 */       PropertyMap propertyMap = new PropertyMap();
/*  71 */       propertyMap.put("textures", new Property("textures", skin.getValue(), skin.getSignature()));
/*  72 */       this.gameProfile.getProperties().putAll((Multimap)propertyMap);
/*     */     } 
/*     */     
/*  75 */     this.entityPlayer.getBukkitEntity().setRemoveWhenFarAway(false);
/*  76 */     this.entityPlayer.setLocation(location.getX(), location.getY(), location.getZ(), location.getYaw(), location
/*  77 */         .getPitch());
/*  78 */     this.entityPlayer.setInvisible(false);
/*     */     
/*  80 */     this.entityBat = new EntityBat((World)world);
/*  81 */     this.entityBat.setLocation(location.getX() * 32.0D, location.getY() * 32.0D, location.getZ() * 32.0D, 0.0F, 0.0F);
/*  82 */     this.entityBat.setInvisible(true);
/*     */     
/*  84 */     Bukkit.getOnlinePlayers().forEach(player -> show(player));
/*     */   }
/*     */   
/*     */   public void teleport(Location location) {
/*  88 */     this.location = location;
/*  89 */     this.entityPlayer.setLocation(location.getX(), location.getY(), location.getZ(), location.getYaw(), location
/*  90 */         .getPitch());
/*  91 */     this.entityBat.setLocation(location.getX() * 32.0D, location.getY() * 32.0D, location.getZ() * 32.0D, 0.0F, 0.0F);
/*     */     
/*  93 */     for (Player player : Bukkit.getOnlinePlayers()) {
/*  94 */       hide(player);
/*  95 */       show(player);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void show(Player player) {
/* 100 */     if (this.showing.contains(player.getUniqueId())) {
/*     */       return;
/*     */     }
/* 103 */     this.showing.add(player.getUniqueId());
/* 104 */     PlayerConnection connection = (((CraftPlayer)player).getHandle()).playerConnection;
/*     */     
/* 106 */     connection.sendPacket((Packet)new PacketPlayOutPlayerInfo(PacketPlayOutPlayerInfo.EnumPlayerInfoAction.ADD_PLAYER, new EntityPlayer[] { this.entityPlayer }));
/*     */     
/* 108 */     connection.sendPacket((Packet)new PacketPlayOutNamedEntitySpawn((EntityHuman)this.entityPlayer));
/* 109 */     connection
/* 110 */       .sendPacket((Packet)new PacketPlayOutEntityMetadata(this.entityPlayer.getId(), this.entityPlayer.getDataWatcher(), true));
/* 111 */     connection.sendPacket((Packet)new PacketPlayOutEntityHeadRotation((Entity)this.entityPlayer, 
/* 112 */           (byte)(int)(this.location.getYaw() * 256.0F / 360.0F)));
/* 113 */     connection.sendPacket((Packet)new PacketPlayOutSpawnEntityLiving((EntityLiving)this.entityBat));
/* 114 */     connection.sendPacket((Packet)new PacketPlayOutAttachEntity(0, (Entity)this.entityBat, (Entity)this.entityPlayer));
/*     */     
/* 116 */     DataWatcher watcher = this.entityPlayer.getDataWatcher();
/* 117 */     watcher.watch(10, Byte.valueOf(127));
/* 118 */     connection.sendPacket((Packet)new PacketPlayOutEntityMetadata(this.entityPlayer.getId(), watcher, true));
/*     */     
/* 120 */     Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)BukkitCommon.getInstance(), () -> connection.sendPacket((Packet)new PacketPlayOutPlayerInfo(PacketPlayOutPlayerInfo.EnumPlayerInfoAction.REMOVE_PLAYER, new EntityPlayer[] { this.entityPlayer })), 85L);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void hide(Player player) {
/* 126 */     if (!this.showing.contains(player.getUniqueId())) {
/*     */       return;
/*     */     }
/* 129 */     this.showing.remove(player.getUniqueId());
/*     */     
/* 131 */     PlayerConnection playerConnection = (((CraftPlayer)player).getHandle()).playerConnection;
/*     */     
/* 133 */     playerConnection.sendPacket((Packet)new PacketPlayOutPlayerInfo(PacketPlayOutPlayerInfo.EnumPlayerInfoAction.REMOVE_PLAYER, new EntityPlayer[] { this.entityPlayer }));
/*     */     
/* 135 */     playerConnection.sendPacket((Packet)new PacketPlayOutEntityDestroy(new int[] { this.entityPlayer.getId() }));
/* 136 */     playerConnection.sendPacket((Packet)new PacketPlayOutEntityDestroy(new int[] { this.entityBat.getId() }));
/*     */   }
/*     */   
/*     */   public void remove() {
/* 140 */     Bukkit.getOnlinePlayers().forEach(player -> hide(player));
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/character/NPC.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */