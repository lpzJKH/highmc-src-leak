/*    */ package net.highmc.bukkit.utils;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ public class ItemUtils
/*    */ {
/*    */   public static void dropAndClear(Player p, List<ItemStack> items, Location l) {
/* 14 */     dropItems(items, l);
/* 15 */     p.closeInventory();
/* 16 */     p.getInventory().setArmorContents(new ItemStack[4]);
/* 17 */     p.getInventory().clear();
/* 18 */     p.setItemOnCursor(null);
/*    */   }
/*    */   
/*    */   public static void dropItems(List<ItemStack> items, Location l) {
/* 22 */     World world = l.getWorld();
/* 23 */     for (ItemStack item : items) {
/* 24 */       if (item == null || item.getType() == Material.AIR)
/*    */         continue; 
/* 26 */       if (item.hasItemMeta()) {
/* 27 */         world.dropItemNaturally(l, item.clone()).getItemStack().setItemMeta(item.getItemMeta()); continue;
/*    */       } 
/* 29 */       world.dropItemNaturally(l, item);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static void addItem(Player player, ItemStack item, Location location) {
/* 34 */     int slot = player.getInventory().first(item.getType());
/*    */     
/* 36 */     if (slot == -1) {
/* 37 */       slot = player.getInventory().firstEmpty();
/*    */       
/* 39 */       if (slot == -1) {
/* 40 */         boolean needDrop = true;
/*    */         
/* 42 */         for (ItemStack itemContent : player.getInventory().getContents()) {
/* 43 */           if (itemContent.getType() == item.getType()) {
/* 44 */             if (itemContent.getAmount() + item.getAmount() <= 64) {
/* 45 */               player.getInventory().addItem(new ItemStack[] { item });
/* 46 */               needDrop = false;
/*    */             } else {
/*    */               
/* 49 */               while (itemContent.getAmount() + item.getAmount() <= 64 && item.getAmount() >= 0) {
/* 50 */                 itemContent.setAmount(itemContent.getAmount() + 1);
/* 51 */                 item.setAmount(item.getAmount() - 1);
/*    */               } 
/*    */               
/* 54 */               if (item.getAmount() <= 0) {
/* 55 */                 needDrop = false;
/*    */               }
/*    */             } 
/*    */           }
/*    */         } 
/* 60 */         if (needDrop)
/* 61 */           location.getWorld().dropItem(location, item); 
/*    */       } else {
/* 63 */         player.getInventory().addItem(new ItemStack[] { item });
/*    */       }
/*    */     
/* 66 */     } else if (player.getInventory().getItem(slot).getAmount() + item.getAmount() > 64) {
/* 67 */       slot = player.getInventory().firstEmpty();
/*    */       
/* 69 */       if (slot == -1) {
/* 70 */         boolean needDrop = true;
/*    */         
/* 72 */         for (ItemStack itemContent : player.getInventory().getContents()) {
/* 73 */           if (itemContent.getType() == item.getType()) {
/* 74 */             if (itemContent.getAmount() + item.getAmount() <= 64) {
/* 75 */               player.getInventory().addItem(new ItemStack[] { item });
/* 76 */               needDrop = false;
/*    */             } else {
/* 78 */               while (itemContent.getAmount() + item.getAmount() <= 64 && item.getAmount() >= 0) {
/* 79 */                 itemContent.setAmount(itemContent.getAmount() + 1);
/* 80 */                 item.setAmount(item.getAmount() - 1);
/*    */               } 
/*    */               
/* 83 */               if (item.getAmount() <= 0) {
/* 84 */                 needDrop = false;
/*    */               }
/*    */             } 
/*    */           }
/*    */         } 
/* 89 */         if (needDrop) {
/* 90 */           location.getWorld().dropItem(location, item);
/*    */         }
/*    */       } else {
/* 93 */         player.getInventory().addItem(new ItemStack[] { item });
/*    */       } 
/*    */     } else {
/* 96 */       player.getInventory().addItem(new ItemStack[] { item });
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/ItemUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */