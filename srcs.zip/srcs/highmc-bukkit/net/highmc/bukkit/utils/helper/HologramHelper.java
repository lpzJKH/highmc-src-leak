/*    */ package net.highmc.bukkit.utils.helper;
/*    */ 
/*    */ import net.highmc.bukkit.BukkitCommon;
/*    */ import net.highmc.bukkit.utils.hologram.Hologram;
/*    */ import net.highmc.bukkit.utils.hologram.HologramBuilder;
/*    */ import net.highmc.bukkit.utils.hologram.impl.SimpleHologram;
/*    */ import org.bukkit.Location;
/*    */ 
/*    */ 
/*    */ public class HologramHelper
/*    */ {
/*    */   public static Hologram createHologram(String text, Location location) {
/* 13 */     return BukkitCommon.getInstance().getHologramManager().createHologram((new HologramBuilder()).setDisplayName(text)
/* 14 */         .setLocation(location).setHologramClass(SimpleHologram.class));
/*    */   }
/*    */   
/*    */   public static Hologram createHologram(Hologram hologram) {
/* 18 */     return BukkitCommon.getInstance().getHologramManager().createHologram(hologram);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/helper/HologramHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */