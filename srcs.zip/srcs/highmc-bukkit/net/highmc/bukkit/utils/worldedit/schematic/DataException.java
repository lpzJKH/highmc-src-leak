/*   */ package net.highmc.bukkit.utils.worldedit.schematic;
/*   */ 
/*   */ public class DataException extends Exception {
/*   */   private static final long serialVersionUID = 5806521052111023788L;
/*   */   
/*   */   public DataException(String msg) {
/* 7 */     super(msg);
/*   */   }
/*   */   
/*   */   public DataException() {}
/*   */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/worldedit/schematic/DataException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */