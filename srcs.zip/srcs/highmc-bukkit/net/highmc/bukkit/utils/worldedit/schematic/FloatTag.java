/*    */ package net.highmc.bukkit.utils.worldedit.schematic;
/*    */ 
/*    */ public final class FloatTag
/*    */   extends Tag {
/*    */   private final float value;
/*    */   
/*    */   public FloatTag(String name, float value) {
/*  8 */     super(name);
/*  9 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public Float getValue() {
/* 14 */     return Float.valueOf(this.value);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 19 */     String name = getName();
/* 20 */     String append = "";
/* 21 */     if (name != null && !name.equals("")) {
/* 22 */       append = "(\"" + getName() + "\")";
/*    */     }
/* 24 */     return "TAG_Float" + append + ": " + this.value;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/worldedit/schematic/FloatTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */