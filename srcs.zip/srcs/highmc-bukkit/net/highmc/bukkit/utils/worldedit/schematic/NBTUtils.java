/*    */ package net.highmc.bukkit.utils.worldedit.schematic;
/*    */ 
/*    */ public final class NBTUtils
/*    */ {
/*    */   public static String getTypeName(Class<? extends Tag> clazz) {
/*  6 */     if (clazz.equals(ByteArrayTag.class))
/*  7 */       return "TAG_Byte_Array"; 
/*  8 */     if (clazz.equals(ByteTag.class))
/*  9 */       return "TAG_Byte"; 
/* 10 */     if (clazz.equals(CompoundTag.class))
/* 11 */       return "TAG_Compound"; 
/* 12 */     if (clazz.equals(DoubleTag.class))
/* 13 */       return "TAG_Double"; 
/* 14 */     if (clazz.equals(EndTag.class))
/* 15 */       return "TAG_End"; 
/* 16 */     if (clazz.equals(FloatTag.class))
/* 17 */       return "TAG_Float"; 
/* 18 */     if (clazz.equals(IntTag.class))
/* 19 */       return "TAG_Int"; 
/* 20 */     if (clazz.equals(ListTag.class))
/* 21 */       return "TAG_List"; 
/* 22 */     if (clazz.equals(LongTag.class))
/* 23 */       return "TAG_Long"; 
/* 24 */     if (clazz.equals(ShortTag.class))
/* 25 */       return "TAG_Short"; 
/* 26 */     if (clazz.equals(StringTag.class)) {
/* 27 */       return "TAG_String";
/*    */     }
/* 29 */     throw new IllegalArgumentException("Invalid tag classs (" + clazz.getName() + ").");
/*    */   }
/*    */ 
/*    */   
/*    */   public static int getTypeCode(Class<? extends Tag> clazz) {
/* 34 */     if (clazz.equals(ByteArrayTag.class))
/* 35 */       return 7; 
/* 36 */     if (clazz.equals(ByteTag.class))
/* 37 */       return 1; 
/* 38 */     if (clazz.equals(CompoundTag.class))
/* 39 */       return 10; 
/* 40 */     if (clazz.equals(DoubleTag.class))
/* 41 */       return 6; 
/* 42 */     if (clazz.equals(EndTag.class))
/* 43 */       return 0; 
/* 44 */     if (clazz.equals(FloatTag.class))
/* 45 */       return 5; 
/* 46 */     if (clazz.equals(IntTag.class))
/* 47 */       return 3; 
/* 48 */     if (clazz.equals(ListTag.class))
/* 49 */       return 9; 
/* 50 */     if (clazz.equals(LongTag.class))
/* 51 */       return 4; 
/* 52 */     if (clazz.equals(ShortTag.class))
/* 53 */       return 2; 
/* 54 */     if (clazz.equals(StringTag.class)) {
/* 55 */       return 8;
/*    */     }
/* 57 */     throw new IllegalArgumentException("Invalid tag classs (" + clazz.getName() + ").");
/*    */   }
/*    */ 
/*    */   
/*    */   public static Class<? extends Tag> getTypeClass(int type) {
/* 62 */     switch (type) {
/*    */       case 0:
/* 64 */         return (Class)EndTag.class;
/*    */       case 1:
/* 66 */         return (Class)ByteTag.class;
/*    */       case 2:
/* 68 */         return (Class)ShortTag.class;
/*    */       case 3:
/* 70 */         return (Class)IntTag.class;
/*    */       case 4:
/* 72 */         return (Class)LongTag.class;
/*    */       case 5:
/* 74 */         return (Class)FloatTag.class;
/*    */       case 6:
/* 76 */         return (Class)DoubleTag.class;
/*    */       case 7:
/* 78 */         return (Class)ByteArrayTag.class;
/*    */       case 8:
/* 80 */         return (Class)StringTag.class;
/*    */       case 9:
/* 82 */         return (Class)ListTag.class;
/*    */       case 10:
/* 84 */         return (Class)CompoundTag.class;
/*    */     } 
/* 86 */     throw new IllegalArgumentException("Invalid tag type : " + type + ".");
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/worldedit/schematic/NBTUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */