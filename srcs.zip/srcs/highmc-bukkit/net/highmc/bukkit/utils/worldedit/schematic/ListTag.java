/*    */ package net.highmc.bukkit.utils.worldedit.schematic;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ public final class ListTag
/*    */   extends Tag
/*    */ {
/*    */   private final Class<? extends Tag> type;
/*    */   private final List<Tag> value;
/*    */   
/*    */   public ListTag(String name, Class<? extends Tag> type, List<Tag> value) {
/* 13 */     super(name);
/* 14 */     this.type = type;
/* 15 */     this.value = Collections.unmodifiableList(value);
/*    */   }
/*    */   
/*    */   public Class<? extends Tag> getType() {
/* 19 */     return this.type;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Tag> getValue() {
/* 24 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 29 */     String name = getName();
/* 30 */     String append = "";
/* 31 */     if (name != null && !name.equals("")) {
/* 32 */       append = "(\"" + getName() + "\")";
/*    */     }
/* 34 */     StringBuilder bldr = new StringBuilder();
/* 35 */     bldr.append("TAG_List" + append + ": " + this.value.size() + " entries of type " + NBTUtils.getTypeName(this.type) + "\r\n{\r\n");
/*    */     
/* 37 */     for (Tag t : this.value) {
/* 38 */       bldr.append("   " + t.toString().replaceAll("\r\n", "\r\n   ") + "\r\n");
/*    */     }
/* 40 */     bldr.append("}");
/* 41 */     return bldr.toString();
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/worldedit/schematic/ListTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */