/*     */ package net.highmc.bukkit.utils.worldedit.schematic;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.List;
/*     */ import java.util.zip.GZIPOutputStream;
/*     */ 
/*     */ public final class NBTOutputStream
/*     */   implements Closeable {
/*     */   private final DataOutputStream os;
/*     */   
/*     */   public NBTOutputStream(OutputStream os) throws IOException {
/*  15 */     this.os = new DataOutputStream(new GZIPOutputStream(os));
/*     */   }
/*     */   
/*     */   public void writeTag(Tag tag) throws IOException {
/*  19 */     int type = NBTUtils.getTypeCode((Class)tag.getClass());
/*  20 */     String name = tag.getName();
/*  21 */     byte[] nameBytes = name.getBytes(NBTConstants.CHARSET);
/*     */     
/*  23 */     this.os.writeByte(type);
/*  24 */     this.os.writeShort(nameBytes.length);
/*  25 */     this.os.write(nameBytes);
/*     */     
/*  27 */     if (type == 0) {
/*  28 */       throw new IOException("Named TAG_End not permitted.");
/*     */     }
/*     */     
/*  31 */     writeTagPayload(tag);
/*     */   }
/*     */   
/*     */   private void writeTagPayload(Tag tag) throws IOException {
/*  35 */     int type = NBTUtils.getTypeCode((Class)tag.getClass());
/*  36 */     switch (type) {
/*     */       case 0:
/*  38 */         writeEndTagPayload((EndTag)tag);
/*     */         return;
/*     */       case 1:
/*  41 */         writeByteTagPayload((ByteTag)tag);
/*     */         return;
/*     */       case 2:
/*  44 */         writeShortTagPayload((ShortTag)tag);
/*     */         return;
/*     */       case 3:
/*  47 */         writeIntTagPayload((IntTag)tag);
/*     */         return;
/*     */       case 4:
/*  50 */         writeLongTagPayload((LongTag)tag);
/*     */         return;
/*     */       case 5:
/*  53 */         writeFloatTagPayload((FloatTag)tag);
/*     */         return;
/*     */       case 6:
/*  56 */         writeDoubleTagPayload((DoubleTag)tag);
/*     */         return;
/*     */       case 7:
/*  59 */         writeByteArrayTagPayload((ByteArrayTag)tag);
/*     */         return;
/*     */       case 8:
/*  62 */         writeStringTagPayload((StringTag)tag);
/*     */         return;
/*     */       case 9:
/*  65 */         writeListTagPayload((ListTag)tag);
/*     */         return;
/*     */       case 10:
/*  68 */         writeCompoundTagPayload((CompoundTag)tag);
/*     */         return;
/*     */     } 
/*  71 */     throw new IOException("Invalid tag type: " + type + ".");
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeByteTagPayload(ByteTag tag) throws IOException {
/*  76 */     this.os.writeByte(tag.getValue().byteValue());
/*     */   }
/*     */   
/*     */   private void writeByteArrayTagPayload(ByteArrayTag tag) throws IOException {
/*  80 */     byte[] bytes = tag.getValue();
/*  81 */     this.os.writeInt(bytes.length);
/*  82 */     this.os.write(bytes);
/*     */   }
/*     */   
/*     */   private void writeCompoundTagPayload(CompoundTag tag) throws IOException {
/*  86 */     for (Tag childTag : tag.getValue().values()) {
/*  87 */       writeTag(childTag);
/*     */     }
/*  89 */     this.os.writeByte(0);
/*     */   }
/*     */   
/*     */   private void writeListTagPayload(ListTag tag) throws IOException {
/*  93 */     Class<? extends Tag> clazz = tag.getType();
/*  94 */     List<Tag> tags = tag.getValue();
/*  95 */     int size = tags.size();
/*     */     
/*  97 */     this.os.writeByte(NBTUtils.getTypeCode(clazz));
/*  98 */     this.os.writeInt(size);
/*  99 */     for (int i = 0; i < size; i++) {
/* 100 */       writeTagPayload(tags.get(i));
/*     */     }
/*     */   }
/*     */   
/*     */   private void writeStringTagPayload(StringTag tag) throws IOException {
/* 105 */     byte[] bytes = tag.getValue().getBytes(NBTConstants.CHARSET);
/* 106 */     this.os.writeShort(bytes.length);
/* 107 */     this.os.write(bytes);
/*     */   }
/*     */   
/*     */   private void writeDoubleTagPayload(DoubleTag tag) throws IOException {
/* 111 */     this.os.writeDouble(tag.getValue().doubleValue());
/*     */   }
/*     */   
/*     */   private void writeFloatTagPayload(FloatTag tag) throws IOException {
/* 115 */     this.os.writeFloat(tag.getValue().floatValue());
/*     */   }
/*     */   
/*     */   private void writeLongTagPayload(LongTag tag) throws IOException {
/* 119 */     this.os.writeLong(tag.getValue().longValue());
/*     */   }
/*     */   
/*     */   private void writeIntTagPayload(IntTag tag) throws IOException {
/* 123 */     this.os.writeInt(tag.getValue().intValue());
/*     */   }
/*     */   
/*     */   private void writeShortTagPayload(ShortTag tag) throws IOException {
/* 127 */     this.os.writeShort(tag.getValue().shortValue());
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeEndTagPayload(EndTag tag) {}
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 135 */     this.os.close();
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/worldedit/schematic/NBTOutputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */