/*    */ package net.highmc.bukkit.utils.worldedit.schematic;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class Schematic
/*    */ {
/*    */   public Schematic() {}
/*    */   
/*    */   private short[] blocks;
/*    */   private byte[] data;
/*    */   private short width;
/*    */   private short lenght;
/* 16 */   private static Schematic instance = new Schematic(); private short height;
/*    */   public short[] getBlocks() {
/* 18 */     return this.blocks; }
/* 19 */   public byte[] getData() { return this.data; }
/* 20 */   public short getWidth() { return this.width; }
/* 21 */   public short getLenght() { return this.lenght; } public short getHeight() {
/* 22 */     return this.height;
/*    */   }
/*    */   private Schematic(short[] blocks, byte[] data, short width, short lenght, short height) {
/* 25 */     this.blocks = blocks;
/* 26 */     this.data = data;
/* 27 */     this.width = width;
/* 28 */     this.lenght = lenght;
/* 29 */     this.height = height;
/*    */   }
/*    */   
/*    */   public Schematic loadSchematic(File file) throws IOException, DataException {
/* 33 */     FileInputStream stream = new FileInputStream(file);
/* 34 */     NBTInputStream nbtStream = new NBTInputStream(stream);
/* 35 */     CompoundTag schematicTag = (CompoundTag)nbtStream.readTag();
/*    */     
/* 37 */     nbtStream.close();
/*    */     
/* 39 */     if (!schematicTag.getName().equalsIgnoreCase("Schematic")) {
/* 40 */       throw new IllegalArgumentException("Tag \"Schematic\" does not exist or is not first");
/*    */     }
/*    */     
/*    */     Map<String, Tag> schematic;
/*    */     
/* 45 */     if (!(schematic = schematicTag.getValue()).containsKey("Blocks")) {
/* 46 */       throw new IllegalArgumentException("Schematic file is missing a \"Blocks\" tag");
/*    */     }
/*    */     
/* 49 */     short width = ((ShortTag)getChildTag(schematic, "Width", ShortTag.class)).getValue().shortValue();
/* 50 */     short length = ((ShortTag)getChildTag(schematic, "Length", ShortTag.class)).getValue().shortValue();
/* 51 */     short height = ((ShortTag)getChildTag(schematic, "Height", ShortTag.class)).getValue().shortValue();
/*    */     
/* 53 */     byte[] blockId = ((ByteArrayTag)getChildTag(schematic, "Blocks", ByteArrayTag.class)).getValue();
/* 54 */     byte[] blockData = ((ByteArrayTag)getChildTag(schematic, "Data", ByteArrayTag.class)).getValue();
/* 55 */     byte[] addId = new byte[0];
/* 56 */     short[] blocks = new short[blockId.length];
/*    */     
/* 58 */     if (schematic.containsKey("AddBlocks")) {
/* 59 */       addId = ((ByteArrayTag)getChildTag(schematic, "AddBlocks", ByteArrayTag.class)).getValue();
/*    */     }
/*    */     
/* 62 */     for (int index = 0; index < blockId.length; index++) {
/* 63 */       if (index >> 1 >= addId.length) {
/* 64 */         blocks[index] = (short)(blockId[index] & 0xFF);
/* 65 */       } else if ((index & 0x1) == 0) {
/* 66 */         blocks[index] = (short)(((addId[index >> 1] & 0xF) << 8) + (blockId[index] & 0xFF));
/*    */       } else {
/* 68 */         blocks[index] = (short)(((addId[index >> 1] & 0xF0) << 4) + (blockId[index] & 0xFF));
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 73 */     return new Schematic(blocks, blockData, width, length, height);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private <T extends Tag> Tag getChildTag(Map<String, Tag> items, String key, Class<T> expected) throws DataException {
/* 79 */     if (!items.containsKey(key)) {
/* 80 */       throw new DataException("Schematic file is missing a \"" + key + "\" tag");
/*    */     }
/* 82 */     Tag tag = items.get(key);
/* 83 */     if (!expected.isInstance(tag)) {
/* 84 */       throw new DataException(key + " tag is not of tag type " + expected.getName());
/*    */     }
/*    */     
/* 87 */     return (Tag)expected.cast(tag);
/*    */   }
/*    */   
/*    */   public static Schematic getInstance() {
/* 91 */     return instance;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/worldedit/schematic/Schematic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */