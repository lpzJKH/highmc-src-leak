/*    */ package net.highmc.bukkit.utils.worldedit.schematic;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ 
/*    */ public final class CompoundTag
/*    */   extends Tag {
/*    */   private final Map<String, Tag> value;
/*    */   
/*    */   public CompoundTag(String name, Map<String, Tag> value) {
/* 11 */     super(name);
/* 12 */     this.value = Collections.unmodifiableMap(value);
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<String, Tag> getValue() {
/* 17 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 22 */     String name = getName();
/* 23 */     String append = "";
/* 24 */     if (name != null && !name.equals("")) {
/* 25 */       append = "(\"" + getName() + "\")";
/*    */     }
/* 27 */     StringBuilder bldr = new StringBuilder();
/* 28 */     bldr.append("TAG_Compound" + append + ": " + this.value.size() + " entries\r\n{\r\n");
/* 29 */     for (Map.Entry<String, Tag> entry : this.value.entrySet()) {
/* 30 */       bldr.append("   " + ((Tag)entry.getValue()).toString().replaceAll("\r\n", "\r\n   ") + "\r\n");
/*    */     }
/* 32 */     bldr.append("}");
/* 33 */     return bldr.toString();
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/worldedit/schematic/CompoundTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */