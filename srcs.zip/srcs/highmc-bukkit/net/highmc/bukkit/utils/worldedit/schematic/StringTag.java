/*    */ package net.highmc.bukkit.utils.worldedit.schematic;
/*    */ 
/*    */ public final class StringTag
/*    */   extends Tag {
/*    */   private final String value;
/*    */   
/*    */   public StringTag(String name, String value) {
/*  8 */     super(name);
/*  9 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValue() {
/* 14 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 19 */     String name = getName();
/* 20 */     String append = "";
/* 21 */     if (name != null && !name.equals("")) {
/* 22 */       append = "(\"" + getName() + "\")";
/*    */     }
/* 24 */     return "TAG_String" + append + ": " + this.value;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/worldedit/schematic/StringTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */