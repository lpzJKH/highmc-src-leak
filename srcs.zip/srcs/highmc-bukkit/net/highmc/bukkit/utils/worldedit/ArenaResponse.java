/*    */ package net.highmc.bukkit.utils.worldedit;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.block.BlockState;
/*    */ 
/*    */ public class ArenaResponse
/*    */ {
/*    */   private Map<Location, BlockState> map;
/*    */   private int blocks;
/*    */   
/*    */   public Map<Location, BlockState> getMap() {
/* 14 */     return this.map; } public int getBlocks() {
/* 15 */     return this.blocks;
/*    */   }
/*    */   public ArenaResponse(int blocks) {
/* 18 */     this.blocks = -1;
/* 19 */     this.map = new HashMap<>();
/*    */   }
/*    */   
/*    */   public ArenaResponse() {
/* 23 */     this.map = new HashMap<>();
/*    */   }
/*    */   
/*    */   public void addMap(Location location, BlockState blockState) {
/* 27 */     this.map.put(location, blockState);
/* 28 */     this.blocks++;
/*    */   }
/*    */   
/*    */   public void addBlock() {
/* 32 */     this.blocks++;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/worldedit/ArenaResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */