/*    */ package net.highmc.bukkit.utils.worldedit.schematic;
/*    */ 
/*    */ public final class EndTag
/*    */   extends Tag {
/*    */   public EndTag() {
/*  6 */     super("");
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getValue() {
/* 11 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 16 */     return "TAG_End";
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/worldedit/schematic/EndTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */