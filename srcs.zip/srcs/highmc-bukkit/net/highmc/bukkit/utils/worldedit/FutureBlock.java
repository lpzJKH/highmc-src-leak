/*    */ package net.highmc.bukkit.utils.worldedit;
/*    */ 
/*    */ import net.highmc.bukkit.BukkitCommon;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ 
/*    */ 
/*    */ public class FutureBlock
/*    */ {
/*    */   private Location location;
/*    */   private Material type;
/*    */   private byte data;
/*    */   private boolean async;
/*    */   
/*    */   public boolean isAsync() {
/* 16 */     return this.async;
/*    */   }
/*    */   
/*    */   public FutureBlock(Location location, Material type, byte data) {
/* 20 */     this.location = location;
/* 21 */     this.type = type;
/* 22 */     this.data = data;
/*    */   }
/*    */   
/*    */   public byte getData() {
/* 26 */     return this.data;
/*    */   }
/*    */   
/*    */   public Location getLocation() {
/* 30 */     return this.location;
/*    */   }
/*    */   
/*    */   public Material getType() {
/* 34 */     return this.type;
/*    */   }
/*    */   
/*    */   public FutureBlock async() {
/* 38 */     this.async = true;
/* 39 */     return this;
/*    */   }
/*    */   
/*    */   public void place() {
/* 43 */     BukkitCommon.getInstance().getBlockManager().setBlockFast(this.location.getWorld(), (int)this.location.getX(), 
/* 44 */         (int)this.location.getY(), (int)this.location.getZ(), this.type.getId(), this.data);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/worldedit/FutureBlock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */