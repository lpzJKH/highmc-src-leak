/*    */ package net.highmc.bukkit.utils.worldedit.schematic;
/*    */ 
/*    */ public abstract class Tag
/*    */ {
/*    */   private final String name;
/*    */   
/*    */   public Tag(String name) {
/*  8 */     this.name = name;
/*    */   }
/*    */   
/*    */   public final String getName() {
/* 12 */     return this.name;
/*    */   }
/*    */   
/*    */   public abstract Object getValue();
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/worldedit/schematic/Tag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */