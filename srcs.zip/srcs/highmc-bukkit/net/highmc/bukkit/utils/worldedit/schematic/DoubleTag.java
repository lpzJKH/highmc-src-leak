/*    */ package net.highmc.bukkit.utils.worldedit.schematic;
/*    */ 
/*    */ public final class DoubleTag
/*    */   extends Tag {
/*    */   private final double value;
/*    */   
/*    */   public DoubleTag(String name, double value) {
/*  8 */     super(name);
/*  9 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public Double getValue() {
/* 14 */     return Double.valueOf(this.value);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 19 */     String name = getName();
/* 20 */     String append = "";
/* 21 */     if (name != null && !name.equals("")) {
/* 22 */       append = "(\"" + getName() + "\")";
/*    */     }
/* 24 */     return "TAG_Double" + append + ": " + this.value;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/worldedit/schematic/DoubleTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */