/*    */ package net.highmc.bukkit.utils.worldedit.schematic;
/*    */ 
/*    */ public final class LongTag
/*    */   extends Tag {
/*    */   private final long value;
/*    */   
/*    */   public LongTag(String name, long value) {
/*  8 */     super(name);
/*  9 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public Long getValue() {
/* 14 */     return Long.valueOf(this.value);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 19 */     String name = getName();
/* 20 */     String append = "";
/* 21 */     if (name != null && !name.equals("")) {
/* 22 */       append = "(\"" + getName() + "\")";
/*    */     }
/* 24 */     return "TAG_Long" + append + ": " + this.value;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/worldedit/schematic/LongTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */