/*    */ package net.highmc.bukkit.utils.worldedit.schematic;
/*    */ 
/*    */ public final class ByteArrayTag
/*    */   extends Tag {
/*    */   private final byte[] value;
/*    */   
/*    */   public ByteArrayTag(String name, byte[] value) {
/*  8 */     super(name);
/*  9 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public byte[] getValue() {
/* 14 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 19 */     StringBuilder hex = new StringBuilder();
/* 20 */     for (byte b : this.value) {
/* 21 */       String hexDigits = Integer.toHexString(b).toUpperCase();
/* 22 */       if (hexDigits.length() == 1) {
/* 23 */         hex.append("0");
/*    */       }
/* 25 */       hex.append(hexDigits).append(" ");
/*    */     } 
/* 27 */     String name = getName();
/* 28 */     String append = "";
/* 29 */     if (name != null && !name.equals("")) {
/* 30 */       append = "(\"" + getName() + "\")";
/*    */     }
/* 32 */     return "TAG_Byte_Array" + append + ": " + hex.toString();
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/worldedit/schematic/ByteArrayTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */