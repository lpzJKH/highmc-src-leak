package net.highmc.bukkit.utils.hologram;

import org.bukkit.entity.Player;

public interface ViewHandler {
  String onView(Hologram paramHologram, Player paramPlayer, String paramString);
}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/hologram/ViewHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */