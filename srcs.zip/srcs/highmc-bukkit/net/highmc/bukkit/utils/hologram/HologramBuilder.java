/*     */ package net.highmc.bukkit.utils.hologram;
/*     */ 
/*     */ import net.highmc.bukkit.manager.HologramManager;
/*     */ import net.highmc.bukkit.utils.hologram.impl.SimpleHologram;
/*     */ import org.bukkit.Location;
/*     */ 
/*     */ 
/*     */ public class HologramBuilder
/*     */ {
/*     */   private String displayName;
/*     */   private Location location;
/*     */   private TouchHandler touchHandler;
/*     */   private ViewHandler viewHandler;
/*     */   private Class<? extends Hologram> clazz;
/*     */   private HologramManager hologramController;
/*     */   private boolean register;
/*     */   private boolean spawn;
/*     */   
/*     */   public HologramBuilder() {}
/*     */   
/*     */   public HologramBuilder(String displayName, Location location, TouchHandler touchHandler, ViewHandler viewHandler, Class<? extends Hologram> clazz, HologramManager hologramController, boolean register, boolean spawn) {
/*  22 */     this.displayName = displayName; this.location = location; this.touchHandler = touchHandler; this.viewHandler = viewHandler; this.clazz = clazz; this.hologramController = hologramController; this.register = register; this.spawn = spawn;
/*     */   }
/*     */   
/*     */   public String getDisplayName() {
/*  26 */     return this.displayName; } public Location getLocation() {
/*  27 */     return this.location;
/*     */   }
/*  29 */   public TouchHandler getTouchHandler() { return this.touchHandler; } public ViewHandler getViewHandler() {
/*  30 */     return this.viewHandler;
/*     */   } public Class<? extends Hologram> getClazz() {
/*  32 */     return this.clazz;
/*     */   }
/*  34 */   public HologramManager getHologramController() { return this.hologramController; }
/*  35 */   public boolean isRegister() { return this.register; } public boolean isSpawn() {
/*  36 */     return this.spawn;
/*     */   }
/*     */   public HologramBuilder(String displayName) {
/*  39 */     this.displayName = displayName;
/*     */   }
/*     */   
/*     */   public HologramBuilder(String displayName, Location location) {
/*  43 */     this.displayName = displayName;
/*  44 */     this.location = location;
/*     */   }
/*     */   
/*     */   public HologramBuilder setDisplayName(String displayName) {
/*  48 */     this.displayName = displayName;
/*  49 */     return this;
/*     */   }
/*     */   
/*     */   public HologramBuilder setLocation(Location location) {
/*  53 */     this.location = location;
/*  54 */     return this;
/*     */   }
/*     */   
/*     */   public HologramBuilder setTouchHandler(TouchHandler touchHandler) {
/*  58 */     this.touchHandler = touchHandler;
/*  59 */     return this;
/*     */   }
/*     */   
/*     */   public HologramBuilder setTouchHandler(ViewHandler viewHandler) {
/*  63 */     this.viewHandler = viewHandler;
/*  64 */     return this;
/*     */   }
/*     */   
/*     */   public HologramBuilder setHologramClass(Class<? extends Hologram> clazz) {
/*  68 */     this.clazz = clazz;
/*  69 */     return this;
/*     */   }
/*     */   
/*     */   public HologramBuilder setHologramController(HologramManager hologramController) {
/*  73 */     this.hologramController = hologramController;
/*  74 */     return this;
/*     */   }
/*     */   
/*     */   public HologramBuilder setRegister(boolean register) {
/*  78 */     this.register = register;
/*  79 */     return this;
/*     */   }
/*     */   
/*     */   public HologramBuilder setSpawn(boolean spawn) {
/*  83 */     this.spawn = spawn;
/*  84 */     return this;
/*     */   }
/*     */   
/*     */   public Hologram build() {
/*  88 */     Hologram hologram = null;
/*     */     
/*  90 */     if (this.location == null) {
/*  91 */       throw new NullPointerException("Location cannot be null!");
/*     */     }
/*  93 */     if (this.displayName == null) {
/*  94 */       throw new NullPointerException("DisplayName cannot be null!");
/*     */     }
/*  96 */     if (this.clazz == null) {
/*  97 */       this.clazz = (Class)SimpleHologram.class;
/*     */     }
/*     */     try {
/* 100 */       hologram = this.clazz.getConstructor(new Class[] { String.class, Location.class }).newInstance(new Object[] { this.displayName, this.location });
/* 101 */     } catch (InstantiationException|IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException|NoSuchMethodException|SecurityException e) {
/*     */       
/* 103 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 106 */     if (this.touchHandler != null) {
/* 107 */       hologram.setTouchHandler(this.touchHandler);
/*     */     }
/* 109 */     if (this.register) {
/* 110 */       if (this.hologramController == null) {
/* 111 */         throw new IllegalStateException("");
/*     */       }
/* 113 */       this.hologramController.registerHologram(hologram);
/*     */     } 
/*     */     
/* 116 */     if (this.spawn) {
/* 117 */       hologram.spawn();
/*     */     }
/*     */ 
/*     */     
/* 121 */     return hologram;
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/hologram/HologramBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */