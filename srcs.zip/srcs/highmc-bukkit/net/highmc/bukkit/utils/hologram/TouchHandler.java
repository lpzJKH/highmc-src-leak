/*    */ package net.highmc.bukkit.utils.hologram;
/*    */ 
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface TouchHandler
/*    */ {
/*    */   void onTouch(Hologram paramHologram, Player paramPlayer, TouchType paramTouchType);
/*    */   
/*    */   public enum TouchType
/*    */   {
/* 19 */     LEFT, RIGHT;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/hologram/TouchHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */