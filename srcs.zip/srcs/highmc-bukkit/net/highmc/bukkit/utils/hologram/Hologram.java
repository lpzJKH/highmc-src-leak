/*    */ package net.highmc.bukkit.utils.hologram;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Hologram
/*    */ {
/*    */   void spawn();
/*    */   
/*    */   void remove();
/*    */   
/*    */   boolean isSpawned();
/*    */   
/*    */   Hologram setDisplayName(String paramString);
/*    */   
/*    */   boolean hasDisplayName();
/*    */   
/*    */   boolean isCustomNameVisible();
/*    */   
/*    */   String getDisplayName();
/*    */   
/*    */   Hologram line(String paramString);
/*    */   
/*    */   Hologram line(Hologram paramHologram);
/*    */   
/*    */   List<Hologram> getLines();
/*    */   
/*    */   void teleport(Location paramLocation);
/*    */   
/*    */   default void teleport(World world, int x, int y, int z) {
/* 92 */     teleport(new Location(world, x, y, z));
/*    */   }
/*    */   
/*    */   default void teleport(int x, int y, int z) {
/* 96 */     teleport(new Location(getLocation().getWorld(), x, y, z));
/*    */   }
/*    */   
/*    */   Location getLocation();
/*    */   
/*    */   void show(Player paramPlayer);
/*    */   
/*    */   void hide(Player paramPlayer);
/*    */   
/*    */   Collection<? extends Player> getViewers();
/*    */   
/*    */   boolean isVisibleTo(Player paramPlayer);
/*    */   
/*    */   void setTouchHandler(TouchHandler paramTouchHandler);
/*    */   
/*    */   boolean hasTouchHandler();
/*    */   
/*    */   TouchHandler getTouchHandler();
/*    */   
/*    */   void setViewHandler(ViewHandler paramViewHandler);
/*    */   
/*    */   boolean hasViewHandler();
/*    */   
/*    */   ViewHandler getViewHandler();
/*    */   
/*    */   boolean compareEntity(Entity paramEntity);
/*    */   
/*    */   boolean isEntityOrLine(int paramInt);
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/hologram/Hologram.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */