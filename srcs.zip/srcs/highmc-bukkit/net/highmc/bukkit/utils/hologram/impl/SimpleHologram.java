/*     */ package net.highmc.bukkit.utils.hologram.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import net.highmc.bukkit.utils.hologram.Hologram;
/*     */ import net.highmc.bukkit.utils.hologram.TouchHandler;
/*     */ import net.highmc.bukkit.utils.hologram.ViewHandler;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.entity.ArmorStand;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ public class SimpleHologram implements Hologram {
/*     */   private String displayName;
/*     */   private Location location;
/*     */   private TouchHandler touchHandler;
/*     */   private ViewHandler viewHandler;
/*     */   private ArmorStand armorStand;
/*     */   private List<Hologram> hologramLines;
/*     */   private List<Player> invisibleTo;
/*     */   private boolean spawned;
/*     */   
/*  26 */   public void setTouchHandler(TouchHandler touchHandler) { this.touchHandler = touchHandler; }
/*  27 */   public TouchHandler getTouchHandler() { return this.touchHandler; }
/*  28 */   public void setViewHandler(ViewHandler viewHandler) { this.viewHandler = viewHandler; } public ViewHandler getViewHandler() {
/*  29 */     return this.viewHandler;
/*     */   } public ArmorStand getArmorStand() {
/*  31 */     return this.armorStand;
/*     */   }
/*  33 */   public List<Hologram> getHologramLines() { return this.hologramLines; } public List<Player> getInvisibleTo() {
/*  34 */     return this.invisibleTo;
/*     */   }
/*     */ 
/*     */   
/*     */   public SimpleHologram(String displayName, Location location, TouchHandler touchHandler, ViewHandler viewHandler) {
/*  39 */     this.displayName = displayName;
/*  40 */     this.location = location;
/*  41 */     this.touchHandler = touchHandler;
/*  42 */     this.viewHandler = viewHandler;
/*     */     
/*  44 */     this.hologramLines = new ArrayList<>();
/*  45 */     this.invisibleTo = new ArrayList<>();
/*     */   }
/*     */   
/*     */   public SimpleHologram(String displayName, Location location) {
/*  49 */     this(displayName, location, null, null);
/*     */   }
/*     */   
/*     */   public void spawn() {
/*  53 */     if (isSpawned())
/*     */       return; 
/*  55 */     this.spawned = true;
/*  56 */     if (!this.location.getChunk().isLoaded())
/*  57 */       this.location.getChunk().load(); 
/*     */     try {
/*  59 */       this.armorStand = createArmorStand();
/*  60 */     } catch (Exception e) {
/*  61 */       e.printStackTrace();
/*     */     } 
/*  63 */     if (!this.hologramLines.isEmpty())
/*  64 */       this.hologramLines.forEach(Hologram::spawn); 
/*     */   }
/*     */   
/*     */   public void remove() {
/*  68 */     this.spawned = false;
/*  69 */     if (this.armorStand != null)
/*  70 */       this.armorStand.remove(); 
/*  71 */     if (!this.hologramLines.isEmpty())
/*  72 */       this.hologramLines.forEach(Hologram::remove); 
/*     */   }
/*     */   
/*     */   public boolean isSpawned() {
/*  76 */     return this.spawned;
/*     */   }
/*     */   
/*     */   public Hologram setDisplayName(String displayName) {
/*  80 */     this.displayName = displayName;
/*  81 */     if (isSpawned()) {
/*  82 */       this.armorStand.setCustomName(displayName);
/*  83 */       this.armorStand.setCustomNameVisible(isCustomNameVisible());
/*     */     } 
/*  85 */     return this;
/*     */   }
/*     */   
/*     */   public boolean hasDisplayName() {
/*  89 */     return isCustomNameVisible();
/*     */   }
/*     */   
/*     */   public boolean isCustomNameVisible() {
/*  93 */     return (this.displayName != null && !this.displayName.isEmpty());
/*     */   }
/*     */   
/*     */   public String getDisplayName() {
/*  97 */     return this.displayName;
/*     */   }
/*     */ 
/*     */   
/*     */   public Hologram line(String line) {
/* 102 */     SimpleHologram hologram = new SimpleHologram(line, getLocation().clone().subtract(0.0D, (getLines().size() + 1) * 0.25D, 0.0D));
/*     */     
/* 104 */     hologram.setTouchHandler(getTouchHandler());
/*     */     
/* 106 */     if (isSpawned()) {
/* 107 */       hologram.spawn();
/*     */     }
/* 109 */     this.hologramLines.add(hologram);
/* 110 */     return hologram;
/*     */   }
/*     */   
/*     */   public Hologram line(Hologram hologram) {
/* 114 */     if (isSpawned())
/* 115 */       hologram.spawn(); 
/* 116 */     if (!hologram.hasTouchHandler())
/* 117 */       hologram.setTouchHandler(getTouchHandler()); 
/* 118 */     this.hologramLines.add(hologram);
/* 119 */     return hologram;
/*     */   }
/*     */   
/*     */   public List<Hologram> getLines() {
/* 123 */     return this.hologramLines;
/*     */   }
/*     */   
/*     */   public void teleport(Location location) {
/* 127 */     this.location = location;
/* 128 */     if (this.armorStand != null) {
/* 129 */       this.armorStand.teleport(location);
/* 130 */       this.hologramLines.forEach(hologram -> hologram.teleport(location));
/*     */     } 
/*     */   }
/*     */   
/*     */   public Location getLocation() {
/* 135 */     return this.location;
/*     */   }
/*     */   
/*     */   public void show(Player player) {
/* 139 */     if (this.invisibleTo.contains(player))
/* 140 */       this.invisibleTo.remove(player); 
/*     */   }
/*     */   
/*     */   public void hide(Player player) {
/* 144 */     if (!this.invisibleTo.contains(player))
/* 145 */       this.invisibleTo.add(player); 
/*     */   }
/*     */   
/*     */   public boolean isVisibleTo(Player player) {
/* 149 */     return !this.invisibleTo.contains(player);
/*     */   }
/*     */   
/*     */   public Collection<? extends Player> getViewers() {
/* 153 */     Collection<? extends Player> clone = Bukkit.getOnlinePlayers();
/* 154 */     clone.removeAll(this.invisibleTo);
/* 155 */     return clone;
/*     */   }
/*     */   
/*     */   private ArmorStand createArmorStand() throws Exception {
/* 159 */     if (!this.location.getChunk().isLoaded() && !this.location.getChunk().load(true)) {
/* 160 */       throw new Exception("Could not load the chunk " + this.location
/* 161 */           .getX() + ", " + this.location.getY() + ", " + this.location.getZ());
/*     */     }
/* 163 */     for (Entity entity : this.location.getWorld().getNearbyEntities(this.location, 0.3D, 0.3D, 0.3D)) {
/* 164 */       if (entity instanceof ArmorStand && 
/* 165 */         entity.isCustomNameVisible() == isCustomNameVisible() && entity.getCustomName().equals(this.displayName))
/* 166 */         return (ArmorStand)entity; 
/*     */     } 
/* 168 */     ArmorStand armorStand = (ArmorStand)this.location.getWorld().spawnEntity(this.location, EntityType.ARMOR_STAND);
/* 169 */     armorStand.setVisible(false);
/* 170 */     armorStand.setGravity(false);
/* 171 */     armorStand.setCustomName(this.displayName);
/* 172 */     armorStand.setCustomNameVisible(isCustomNameVisible());
/* 173 */     armorStand.setCanPickupItems(false);
/* 174 */     return armorStand;
/*     */   }
/*     */   
/*     */   public boolean hasTouchHandler() {
/* 178 */     return (this.touchHandler != null);
/*     */   }
/*     */   
/*     */   public boolean hasViewHandler() {
/* 182 */     return (this.viewHandler != null);
/*     */   }
/*     */   
/*     */   public boolean compareEntity(Entity rightClicked) {
/* 186 */     return (rightClicked == this.armorStand);
/*     */   }
/*     */   
/*     */   public int getEntityId() {
/* 190 */     return this.armorStand.getEntityId();
/*     */   }
/*     */   
/*     */   public boolean isEntityOrLine(int entityId) {
/* 194 */     if (this.armorStand == null) {
/* 195 */       return false;
/*     */     }
/* 197 */     if (this.armorStand.getEntityId() == entityId) {
/* 198 */       return true;
/*     */     }
/* 200 */     return this.hologramLines.stream().filter(hologram -> (getEntityId() == entityId)).findFirst().isPresent();
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/hologram/impl/SimpleHologram.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */