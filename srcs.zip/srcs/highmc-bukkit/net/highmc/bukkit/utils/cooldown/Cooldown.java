/*    */ package net.highmc.bukkit.utils.cooldown;
/*    */ import lombok.NonNull;
/*    */ 
/*    */ public class Cooldown {
/*    */   @NonNull
/*    */   private String name;
/*    */   private long duration;
/*    */   
/*    */   public Cooldown(@NonNull String name) {
/* 10 */     if (name == null) throw new NullPointerException("name is marked non-null but is null");  this.name = name;
/*    */   }
/*    */   @NonNull
/* 13 */   public String getName() { return this.name; } public void setName(@NonNull String name) {
/* 14 */     if (name == null) throw new NullPointerException("name is marked non-null but is null");  this.name = name;
/*    */   }
/*    */   
/*    */   public long getDuration() {
/* 18 */     return this.duration;
/*    */   } public long getStartTime() {
/* 20 */     return this.startTime;
/* 21 */   } private long startTime = System.currentTimeMillis();
/*    */   
/*    */   public Cooldown(String name, long duration) {
/* 24 */     this.name = name;
/* 25 */     this.duration = duration;
/*    */   }
/*    */   
/*    */   public void update(long duration, long startTime) {
/* 29 */     this.duration = duration;
/* 30 */     this.startTime = startTime;
/*    */   }
/*    */   
/*    */   public double getPercentage() {
/* 34 */     return getRemaining() * 100.0D / this.duration;
/*    */   }
/*    */   
/*    */   public double getRemaining() {
/* 38 */     long endTime = this.startTime + TimeUnit.SECONDS.toMillis(this.duration);
/* 39 */     return -(System.currentTimeMillis() - endTime) / 1000.0D;
/*    */   }
/*    */   
/*    */   public boolean expired() {
/* 43 */     return (getRemaining() < 0.0D);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/cooldown/Cooldown.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */