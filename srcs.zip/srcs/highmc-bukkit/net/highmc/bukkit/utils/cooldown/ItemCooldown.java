/*    */ package net.highmc.bukkit.utils.cooldown;
/*    */ 
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class ItemCooldown extends Cooldown {
/*    */   private ItemStack item;
/*    */   private boolean selected;
/*    */   
/*    */   public ItemStack getItem() {
/* 10 */     return this.item;
/*    */   }
/*    */   
/* 13 */   public boolean isSelected() { return this.selected; } public void setSelected(boolean selected) {
/* 14 */     this.selected = selected;
/*    */   }
/*    */   
/*    */   public ItemCooldown(ItemStack item, String name, Long duration) {
/* 18 */     super(name, duration.longValue());
/* 19 */     this.item = item;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/cooldown/ItemCooldown.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */