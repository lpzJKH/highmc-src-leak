package net.highmc.bukkit.utils.permission.injector;

public interface PermissionMatcher {
  boolean isMatches(String paramString1, String paramString2);
}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/permission/injector/PermissionMatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */