/*     */ package net.highmc.bukkit.utils.permission.injector.regexperms;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.List;
/*     */ import java.util.logging.Logger;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.permissions.Permissible;
/*     */ import org.bukkit.permissions.PermissibleBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PermissibleInjector
/*     */ {
/*     */   protected final String clazzName;
/*     */   protected final String fieldName;
/*     */   protected final boolean copyValues;
/*     */   
/*     */   public PermissibleInjector(String clazzName, String fieldName, boolean copyValues) {
/*  21 */     this.clazzName = clazzName;
/*  22 */     this.fieldName = fieldName;
/*  23 */     this.copyValues = copyValues;
/*     */   }
/*     */   
/*     */   public Permissible inject(Player player, Permissible permissible) throws NoSuchFieldException, IllegalAccessException {
/*  27 */     Field permField = getPermissibleField(player);
/*  28 */     if (permField == null) {
/*  29 */       return null;
/*     */     }
/*  31 */     Permissible oldPerm = (Permissible)permField.get(player);
/*  32 */     if (this.copyValues && permissible instanceof PermissibleBase) {
/*  33 */       PermissibleBase newBase = (PermissibleBase)permissible;
/*  34 */       PermissibleBase oldBase = (PermissibleBase)oldPerm;
/*  35 */       copyValues(oldBase, newBase);
/*     */     } 
/*  37 */     permField.set(player, permissible);
/*  38 */     return oldPerm;
/*     */   }
/*     */   
/*     */   public Permissible getPermissible(Player player) throws NoSuchFieldException, IllegalAccessException {
/*  42 */     return (Permissible)getPermissibleField(player).get(player);
/*     */   }
/*     */   
/*     */   private Field getPermissibleField(Player player) throws NoSuchFieldException {
/*     */     Class<?> humanEntity;
/*     */     try {
/*  48 */       humanEntity = Class.forName(this.clazzName);
/*  49 */     } catch (ClassNotFoundException e) {
/*  50 */       Logger.getLogger("yUtils").warning("[yUtils] Instance nao encontrada");
/*  51 */       return null;
/*     */     } 
/*     */     
/*  54 */     if (!humanEntity.isAssignableFrom(player.getClass())) {
/*  55 */       Logger.getLogger("yUtils").warning("[yUtils] Erro estranho enquanto injeta permissivel");
/*  56 */       return null;
/*     */     } 
/*     */     
/*  59 */     Field permField = humanEntity.getDeclaredField(this.fieldName);
/*  60 */     permField.setAccessible(true);
/*  61 */     return permField;
/*     */   }
/*     */ 
/*     */   
/*     */   private void copyValues(PermissibleBase old, PermissibleBase newPerm) throws NoSuchFieldException, IllegalAccessException {
/*  66 */     Field attachmentField = PermissibleBase.class.getDeclaredField("attachments");
/*  67 */     attachmentField.setAccessible(true);
/*  68 */     List<Object> attachmentPerms = (List<Object>)attachmentField.get(newPerm);
/*  69 */     attachmentPerms.clear();
/*  70 */     attachmentPerms.addAll((List)attachmentField.get(old));
/*  71 */     newPerm.recalculatePermissions();
/*     */   }
/*     */   
/*     */   public abstract boolean isApplicable(Player paramPlayer);
/*     */   
/*     */   public static class ServerNamePermissibleInjector extends PermissibleInjector {
/*     */     protected final String serverName;
/*     */     
/*     */     public ServerNamePermissibleInjector(String clazz, String field, boolean copyValues, String serverName) {
/*  80 */       super(clazz, field, copyValues);
/*  81 */       this.serverName = serverName;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isApplicable(Player player) {
/*  86 */       return player.getServer().getName().equalsIgnoreCase(this.serverName);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ClassPresencePermissibleInjector
/*     */     extends PermissibleInjector {
/*     */     public ClassPresencePermissibleInjector(String clazzName, String fieldName, boolean copyValues) {
/*  93 */       super(clazzName, fieldName, copyValues);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isApplicable(Player player) {
/*     */       try {
/*  99 */         return Class.forName(this.clazzName).isInstance(player);
/* 100 */       } catch (ClassNotFoundException e) {
/* 101 */         return false;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ClassNameRegexPermissibleInjector extends PermissibleInjector {
/*     */     private final String regex;
/*     */     
/*     */     public ClassNameRegexPermissibleInjector(String clazz, String field, boolean copyValues, String regex) {
/* 110 */       super(clazz, field, copyValues);
/* 111 */       this.regex = regex;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isApplicable(Player player) {
/* 116 */       return player.getClass().getName().matches(this.regex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/permission/injector/regexperms/PermissibleInjector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */