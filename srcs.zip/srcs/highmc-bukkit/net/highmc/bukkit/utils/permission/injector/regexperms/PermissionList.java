/*     */ package net.highmc.bukkit.utils.permission.injector.regexperms;
/*     */ 
/*     */ import com.google.common.collect.HashMultimap;
/*     */ import com.google.common.collect.Multimap;
/*     */ import com.google.common.collect.Multimaps;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import net.highmc.bukkit.utils.permission.injector.FieldReplacer;
/*     */ import org.bukkit.permissions.Permission;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PermissionList
/*     */   extends HashMap<String, Permission>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static FieldReplacer<PluginManager, Map> INJECTOR;
/*  33 */   private static final Map<Class<?>, FieldReplacer<Permission, Map>> CHILDREN_MAPS = new HashMap<>();
/*     */   
/*  35 */   private final Multimap<String, Map.Entry<String, Boolean>> childParentMapping = Multimaps.synchronizedMultimap((Multimap)HashMultimap.create());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PermissionList(Map<? extends String, ? extends Permission> existing) {
/*  42 */     super(existing);
/*     */   }
/*     */   
/*     */   private FieldReplacer<Permission, Map> getFieldReplacer(Permission perm) {
/*  46 */     FieldReplacer<Permission, Map> ret = CHILDREN_MAPS.get(perm.getClass());
/*  47 */     if (ret == null) {
/*  48 */       ret = new FieldReplacer(perm.getClass(), "children", Map.class);
/*  49 */       CHILDREN_MAPS.put(perm.getClass(), ret);
/*     */     } 
/*  51 */     return ret;
/*     */   }
/*     */   
/*     */   private void removeAllChildren(String perm) {
/*  55 */     Iterator<Map.Entry<String, Map.Entry<String, Boolean>>> it = this.childParentMapping.entries().iterator();
/*  56 */     while (it.hasNext()) {
/*  57 */       if (((String)((Map.Entry)((Map.Entry)it.next()).getValue()).getKey()).equals(perm)) {
/*  58 */         it.remove();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private class NotifyingChildrenMap
/*     */     extends LinkedHashMap<String, Boolean>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     private final Permission perm;
/*     */ 
/*     */     
/*     */     public NotifyingChildrenMap(Permission perm) {
/*  73 */       super(perm.getChildren());
/*  74 */       this.perm = perm;
/*     */     }
/*     */ 
/*     */     
/*     */     public Boolean remove(Object perm) {
/*  79 */       removeFromMapping(String.valueOf(perm));
/*  80 */       return super.remove(perm);
/*     */     }
/*     */     
/*     */     private void removeFromMapping(String child) {
/*  84 */       for (Iterator<Map.Entry<String, Boolean>> it = PermissionList.this.childParentMapping.get(child).iterator(); it.hasNext();) {
/*  85 */         if (((String)((Map.Entry)it.next()).getKey()).equals(this.perm.getName())) {
/*  86 */           it.remove();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Boolean put(String perm, Boolean val) {
/*  94 */       PermissionList.this.childParentMapping.put(perm, new AbstractMap.SimpleEntry<>(this.perm.getName(), val));
/*  95 */       return super.put(perm, val);
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 100 */       PermissionList.this.removeAllChildren(this.perm.getName());
/* 101 */       super.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public static PermissionList inject(PluginManager manager) {
/* 106 */     if (INJECTOR == null) {
/* 107 */       INJECTOR = new FieldReplacer(manager.getClass(), "permissions", Map.class);
/*     */     }
/*     */     
/* 110 */     Map<String, Permission> existing = (Map<String, Permission>)INJECTOR.get(manager);
/*     */     
/* 112 */     PermissionList list = new PermissionList(existing);
/* 113 */     INJECTOR.set(manager, list);
/* 114 */     return list;
/*     */   }
/*     */ 
/*     */   
/*     */   public Permission put(String k, Permission v) {
/* 119 */     for (Map.Entry<String, Boolean> ent : (Iterable<Map.Entry<String, Boolean>>)v.getChildren().entrySet()) {
/* 120 */       this.childParentMapping.put(ent.getKey(), new AbstractMap.SimpleEntry<>(v.getName(), ent.getValue()));
/*     */     }
/* 122 */     FieldReplacer<Permission, Map> repl = getFieldReplacer(v);
/* 123 */     repl.set(v, new NotifyingChildrenMap(v));
/* 124 */     return super.put(k, v);
/*     */   }
/*     */ 
/*     */   
/*     */   public Permission remove(Object k) {
/* 129 */     Permission ret = super.remove(k);
/* 130 */     if (ret != null) {
/* 131 */       removeAllChildren(k.toString());
/* 132 */       getFieldReplacer(ret).set(ret, new LinkedHashMap<>(ret.getChildren()));
/*     */     } 
/* 134 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 139 */     this.childParentMapping.clear();
/* 140 */     super.clear();
/*     */   }
/*     */   
/*     */   public Collection<Map.Entry<String, Boolean>> getParents(String permission) {
/* 144 */     return this.childParentMapping.get(permission.toLowerCase());
/*     */   }
/*     */   
/*     */   public PermissionList() {}
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/permission/injector/regexperms/PermissionList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */