/*    */ package net.highmc.bukkit.utils.permission;
/*    */ import net.highmc.bukkit.BukkitCommon;
/*    */ import net.highmc.bukkit.utils.permission.injector.PermissionMatcher;
/*    */ import net.highmc.bukkit.utils.permission.injector.RegExpMatcher;
/*    */ import net.highmc.bukkit.utils.permission.injector.regexperms.RegexPermissions;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public class PermissionManager {
/*    */   private BukkitCommon plugin;
/*    */   private RegexPermissions regexPerms;
/*    */   
/*    */   public BukkitCommon getPlugin() {
/* 15 */     return this.plugin;
/*    */   }
/*    */   
/* 18 */   protected PermissionMatcher matcher = (PermissionMatcher)new RegExpMatcher(); public PermissionMatcher getMatcher() { return this.matcher; }
/*    */   
/*    */   public PermissionManager(BukkitCommon plugin) {
/* 21 */     this.plugin = plugin;
/* 22 */     this.regexPerms = new RegexPermissions(this);
/*    */   }
/*    */   
/*    */   public void onDisable() {
/* 26 */     if (this.regexPerms != null) {
/* 27 */       this.regexPerms.onDisable();
/* 28 */       this.regexPerms = null;
/*    */     } 
/*    */   }
/*    */   
/*    */   public Server getServer() {
/* 33 */     return this.plugin.getServer();
/*    */   }
/*    */   
/*    */   public void registerListener(Listener listener) {
/* 37 */     getServer().getPluginManager().registerEvents(listener, (Plugin)this.plugin);
/*    */   }
/*    */   
/*    */   public RegexPermissions getRegexPerms() {
/* 41 */     return this.regexPerms;
/*    */   }
/*    */   
/*    */   public PermissionMatcher getPermissionMatcher() {
/* 45 */     return this.matcher;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/permission/PermissionManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */