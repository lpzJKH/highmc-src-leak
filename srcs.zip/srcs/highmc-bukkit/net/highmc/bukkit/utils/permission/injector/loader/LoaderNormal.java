/*    */ package net.highmc.bukkit.utils.permission.injector.loader;
/*    */ 
/*    */ import com.google.common.cache.CacheLoader;
/*    */ import java.util.regex.Pattern;
/*    */ import java.util.regex.PatternSyntaxException;
/*    */ 
/*    */ public class LoaderNormal
/*    */   extends CacheLoader<String, Pattern>
/*    */ {
/*    */   public static final String RAW_REGEX_CHAR = "$";
/*    */   
/*    */   public Pattern load(String arg0) throws Exception {
/* 13 */     return createPattern(arg0);
/*    */   }
/*    */   
/*    */   protected static Pattern createPattern(String expression) {
/*    */     try {
/* 18 */       return Pattern.compile(prepareRegexp(expression), 2);
/* 19 */     } catch (PatternSyntaxException e) {
/* 20 */       return Pattern.compile(Pattern.quote(expression), 2);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static String prepareRegexp(String expression) {
/* 25 */     if (expression.startsWith("-")) {
/* 26 */       expression = expression.substring(1);
/*    */     }
/* 28 */     if (expression.startsWith("#")) {
/* 29 */       expression = expression.substring(1);
/*    */     }
/* 31 */     boolean rawRegexp = expression.startsWith("$");
/* 32 */     if (rawRegexp) {
/* 33 */       expression = expression.substring(1);
/*    */     }
/* 35 */     String regexp = rawRegexp ? expression : expression.replace(".", "\\.").replace("*", "(.*)");
/* 36 */     return regexp;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/permission/injector/loader/LoaderNormal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */