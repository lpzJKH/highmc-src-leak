/*     */ package net.highmc.bukkit.utils.permission.injector.regexperms;
/*     */ 
/*     */ import com.google.common.collect.Sets;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.WeakHashMap;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import net.highmc.bukkit.utils.permission.injector.FieldReplacer;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.permissions.Permissible;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PEXPermissionSubscriptionMap
/*     */   extends HashMap<String, Map<Permissible, Boolean>>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static FieldReplacer<PluginManager, Map> INJECTOR;
/*  35 */   private static final AtomicReference<PEXPermissionSubscriptionMap> INSTANCE = new AtomicReference<>();
/*     */   
/*     */   private final Plugin plugin;
/*     */   private final PluginManager manager;
/*     */   
/*     */   private PEXPermissionSubscriptionMap(Plugin plugin, PluginManager manager, Map<String, Map<Permissible, Boolean>> backing) {
/*  41 */     super(backing);
/*  42 */     this.plugin = plugin;
/*  43 */     this.manager = manager;
/*     */   }
/*     */   
/*     */   public static PEXPermissionSubscriptionMap inject(Plugin plugin, PluginManager manager) {
/*  47 */     PEXPermissionSubscriptionMap map = INSTANCE.get();
/*  48 */     if (map != null) {
/*  49 */       return map;
/*     */     }
/*     */     
/*  52 */     if (INJECTOR == null) {
/*  53 */       INJECTOR = new FieldReplacer(manager.getClass(), "permSubs", Map.class);
/*     */     }
/*     */     
/*  56 */     Map<String, Map<Permissible, Boolean>> backing = (Map<String, Map<Permissible, Boolean>>)INJECTOR.get(manager);
/*     */     
/*  58 */     if (backing instanceof PEXPermissionSubscriptionMap) {
/*  59 */       return (PEXPermissionSubscriptionMap)backing;
/*     */     }
/*     */     
/*  62 */     PEXPermissionSubscriptionMap wrappedMap = new PEXPermissionSubscriptionMap(plugin, manager, backing);
/*     */     
/*  64 */     if (INSTANCE.compareAndSet(null, wrappedMap)) {
/*  65 */       INJECTOR.set(manager, wrappedMap);
/*  66 */       return wrappedMap;
/*     */     } 
/*  68 */     return INSTANCE.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void uninject() {
/*  76 */     if (INSTANCE.compareAndSet(this, null)) {
/*  77 */       Map<String, Map<Permissible, Boolean>> unwrappedMap = new HashMap<>(size());
/*  78 */       for (Map.Entry<String, Map<Permissible, Boolean>> entry : entrySet()) {
/*  79 */         if (entry.getValue() instanceof PEXSubscriptionValueMap) {
/*  80 */           unwrappedMap.put(entry.getKey(), ((PEXSubscriptionValueMap)entry.getValue()).backing);
/*     */         }
/*     */       } 
/*  83 */       INJECTOR.set(this.manager, unwrappedMap);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<Permissible, Boolean> get(Object key) {
/*  89 */     if (key == null) {
/*  90 */       return null;
/*     */     }
/*     */     
/*  93 */     Map<Permissible, Boolean> result = super.get(key);
/*  94 */     if (result == null) {
/*  95 */       result = new PEXSubscriptionValueMap((String)key, new WeakHashMap<>());
/*  96 */       super.put((String)key, result);
/*  97 */     } else if (!(result instanceof PEXSubscriptionValueMap)) {
/*  98 */       result = new PEXSubscriptionValueMap((String)key, result);
/*  99 */       super.put((String)key, result);
/*     */     } 
/* 101 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<Permissible, Boolean> put(String key, Map<Permissible, Boolean> value) {
/* 106 */     if (!(value instanceof PEXSubscriptionValueMap)) {
/* 107 */       value = new PEXSubscriptionValueMap(key, value);
/*     */     }
/* 109 */     return super.put(key, value);
/*     */   }
/*     */   
/*     */   public class PEXSubscriptionValueMap implements Map<Permissible, Boolean> {
/*     */     private final String permission;
/*     */     private final Map<Permissible, Boolean> backing;
/*     */     
/*     */     public PEXSubscriptionValueMap(String permission, Map<Permissible, Boolean> backing) {
/* 117 */       this.permission = permission;
/* 118 */       this.backing = backing;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 123 */       return this.backing.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 128 */       return this.backing.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean containsKey(Object key) {
/* 133 */       return (this.backing.containsKey(key) || (key instanceof Permissible && ((Permissible)key)
/* 134 */         .isPermissionSet(this.permission)));
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean containsValue(Object value) {
/* 139 */       return this.backing.containsValue(value);
/*     */     }
/*     */ 
/*     */     
/*     */     public Boolean put(Permissible key, Boolean value) {
/* 144 */       return this.backing.put(key, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public Boolean remove(Object key) {
/* 149 */       return this.backing.remove(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void putAll(Map<? extends Permissible, ? extends Boolean> m) {
/* 154 */       this.backing.putAll(m);
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 159 */       this.backing.clear();
/*     */     }
/*     */ 
/*     */     
/*     */     public Boolean get(Object key) {
/* 164 */       if (key instanceof Permissible) {
/* 165 */         Permissible p = (Permissible)key;
/* 166 */         if (p.isPermissionSet(this.permission)) {
/* 167 */           return Boolean.valueOf(p.hasPermission(this.permission));
/*     */         }
/*     */       } 
/* 170 */       return this.backing.get(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<Permissible> keySet() {
/* 175 */       Set<Permissible> pexMatches = new HashSet<>(PEXPermissionSubscriptionMap.this.plugin.getServer().getOnlinePlayers().size());
/* 176 */       for (Player player : Bukkit.getOnlinePlayers()) {
/* 177 */         if (player.hasPermission(this.permission)) {
/* 178 */           pexMatches.add(player);
/*     */         }
/*     */       } 
/* 181 */       return (Set<Permissible>)Sets.union(pexMatches, this.backing.keySet());
/*     */     }
/*     */ 
/*     */     
/*     */     public Collection<Boolean> values() {
/* 186 */       return this.backing.values();
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<Map.Entry<Permissible, Boolean>> entrySet() {
/* 191 */       return this.backing.entrySet();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/permission/injector/regexperms/PEXPermissionSubscriptionMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */