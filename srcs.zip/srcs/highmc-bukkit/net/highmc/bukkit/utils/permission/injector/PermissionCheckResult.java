/*    */ package net.highmc.bukkit.utils.permission.injector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum PermissionCheckResult
/*    */ {
/*  9 */   UNDEFINED(false), TRUE(true), FALSE(false);
/*    */   
/*    */   protected boolean result;
/*    */   
/*    */   PermissionCheckResult(boolean result) {
/* 14 */     this.result = result;
/*    */   }
/*    */   
/*    */   public boolean toBoolean() {
/* 18 */     return this.result;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 22 */     return (this == UNDEFINED) ? "undefined" : Boolean.toString(this.result);
/*    */   }
/*    */   
/*    */   public static PermissionCheckResult fromBoolean(boolean result) {
/* 26 */     return result ? TRUE : FALSE;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/permission/injector/PermissionCheckResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */