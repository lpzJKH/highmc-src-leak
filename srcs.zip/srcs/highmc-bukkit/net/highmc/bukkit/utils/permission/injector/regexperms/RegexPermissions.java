/*     */ package net.highmc.bukkit.utils.permission.injector.regexperms;
/*     */ 
/*     */ import java.util.logging.Level;
/*     */ import net.highmc.bukkit.utils.permission.PermissionManager;
/*     */ import net.highmc.bukkit.utils.permission.injector.CraftBukkitInterface;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.player.PlayerKickEvent;
/*     */ import org.bukkit.event.player.PlayerLoginEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.permissions.Permissible;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegexPermissions
/*     */ {
/*     */   private final PermissionManager plugin;
/*     */   private PermissionList permsList;
/*     */   private PEXPermissionSubscriptionMap subscriptionHandler;
/*     */   
/*     */   public RegexPermissions(PermissionManager plugin) {
/*  30 */     this.plugin = plugin;
/*  31 */     this.subscriptionHandler = PEXPermissionSubscriptionMap.inject((Plugin)plugin.getPlugin(), plugin.getServer().getPluginManager());
/*  32 */     this.permsList = PermissionList.inject(plugin.getServer().getPluginManager());
/*  33 */     plugin.getServer().getPluginManager().registerEvents(new EventListener(), (Plugin)plugin.getPlugin());
/*  34 */     injectAllPermissibles();
/*     */   }
/*     */   
/*     */   public void onDisable() {
/*  38 */     this.subscriptionHandler.uninject();
/*  39 */     uninjectAllPermissibles();
/*     */   }
/*     */   
/*     */   public PermissionList getPermissionList() {
/*  43 */     return this.permsList;
/*     */   }
/*     */   
/*     */   public void injectPermissible(Player player) {
/*     */     try {
/*  48 */       PermissiblePEX permissible = new PermissiblePEX(player, this.plugin);
/*  49 */       PermissibleInjector injector = new PermissibleInjector.ClassPresencePermissibleInjector(CraftBukkitInterface.getCBClassName("entity.CraftHumanEntity"), "perm", true);
/*  50 */       boolean success = false;
/*  51 */       if (injector.isApplicable(player)) {
/*  52 */         Permissible oldPerm = injector.inject(player, (Permissible)permissible);
/*  53 */         if (oldPerm != null) {
/*  54 */           permissible.setPreviousPermissible(oldPerm);
/*  55 */           success = true;
/*     */         } 
/*     */       } 
/*     */       
/*  59 */       if (!success) {
/*  60 */         this.plugin.getPlugin().getLogger().warning("Unable to inject PEX's permissible for " + player.getName());
/*     */       }
/*     */       
/*  63 */       permissible.recalculatePermissions();
/*     */     }
/*  65 */     catch (Throwable e) {
/*  66 */       this.plugin.getPlugin().getLogger().log(Level.SEVERE, "Unable to inject permissible for " + player.getName(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void injectAllPermissibles() {
/*  71 */     for (Player player : Bukkit.getOnlinePlayers()) {
/*  72 */       injectPermissible(player);
/*     */     }
/*     */   }
/*     */   
/*     */   private void uninjectPermissible(Player player) {
/*     */     try {
/*  78 */       boolean success = false;
/*  79 */       PermissibleInjector injector = new PermissibleInjector.ClassPresencePermissibleInjector(CraftBukkitInterface.getCBClassName("entity.CraftHumanEntity"), "perm", true);
/*  80 */       if (injector.isApplicable(player)) {
/*  81 */         Permissible pexPerm = injector.getPermissible(player);
/*  82 */         if (pexPerm instanceof PermissiblePEX) {
/*  83 */           if (injector.inject(player, ((PermissiblePEX)pexPerm).getPreviousPermissible()) != null) {
/*  84 */             success = true;
/*     */           }
/*     */         } else {
/*  87 */           success = true;
/*     */         } 
/*     */       } 
/*  90 */       if (!success) {
/*  91 */         this.plugin.getPlugin().getLogger().warning("No Permissible injector found for your server implementation (while uninjecting for " + player.getName() + "!");
/*     */       }
/*  93 */     } catch (Throwable e) {
/*  94 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void uninjectAllPermissibles() {
/*  99 */     for (Player player : this.plugin.getServer().getOnlinePlayers())
/* 100 */       uninjectPermissible(player); 
/*     */   }
/*     */   
/*     */   private class EventListener
/*     */     implements Listener {
/*     */     @EventHandler(priority = EventPriority.LOWEST)
/*     */     public void onPlayerLogin(PlayerLoginEvent event) {
/* 107 */       RegexPermissions.this.injectPermissible(event.getPlayer());
/*     */     }
/*     */     private EventListener() {}
/*     */     @EventHandler(priority = EventPriority.MONITOR)
/*     */     public void onPlayerQuit(PlayerQuitEvent event) {
/* 112 */       RegexPermissions.this.uninjectPermissible(event.getPlayer());
/*     */     }
/*     */     
/*     */     @EventHandler(priority = EventPriority.MONITOR)
/*     */     public void onPlayerKick(PlayerKickEvent event) {
/* 117 */       RegexPermissions.this.uninjectPermissible(event.getPlayer());
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/permission/injector/regexperms/RegexPermissions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */