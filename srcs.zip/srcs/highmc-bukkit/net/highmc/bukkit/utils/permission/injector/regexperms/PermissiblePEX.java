/*     */ package net.highmc.bukkit.utils.permission.injector.regexperms;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import net.highmc.bukkit.utils.permission.PermissionManager;
/*     */ import net.highmc.bukkit.utils.permission.injector.FieldReplacer;
/*     */ import net.highmc.bukkit.utils.permission.injector.PermissionCheckResult;
/*     */ import org.apache.commons.lang.Validate;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.permissions.Permissible;
/*     */ import org.bukkit.permissions.PermissibleBase;
/*     */ import org.bukkit.permissions.Permission;
/*     */ import org.bukkit.permissions.PermissionAttachment;
/*     */ import org.bukkit.permissions.PermissionAttachmentInfo;
/*     */ import org.bukkit.permissions.ServerOperator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PermissiblePEX
/*     */   extends PermissibleBase
/*     */ {
/*  35 */   private static final FieldReplacer<PermissibleBase, Map> PERMISSIONS_FIELD = new FieldReplacer(PermissibleBase.class, "permissions", Map.class);
/*     */   
/*  37 */   private static final FieldReplacer<PermissibleBase, List> ATTACHMENTS_FIELD = new FieldReplacer(PermissibleBase.class, "attachments", List.class);
/*     */   
/*     */   private static final Method CALC_CHILD_PERMS_METH;
/*     */   
/*     */   static {
/*     */     try {
/*  43 */       CALC_CHILD_PERMS_METH = PermissibleBase.class.getDeclaredMethod("calculateChildPermissions", new Class[] { Map.class, boolean.class, PermissionAttachment.class });
/*     */     }
/*  45 */     catch (NoSuchMethodException e) {
/*  46 */       throw new ExceptionInInitializerError(e);
/*     */     } 
/*  48 */     CALC_CHILD_PERMS_METH.setAccessible(true);
/*     */   }
/*     */   
/*     */   private final Map<String, PermissionAttachmentInfo> permissions;
/*     */   private final List<PermissionAttachment> attachments;
/*  53 */   private static final AtomicBoolean LAST_CALL_ERRORED = new AtomicBoolean(false);
/*     */   
/*     */   protected final Player player;
/*     */   protected final PermissionManager plugin;
/*  57 */   private Permissible previousPermissible = null;
/*  58 */   protected final Map<String, PermissionCheckResult> cache = new ConcurrentHashMap<>();
/*  59 */   private final Object permissionsLock = new Object();
/*     */   
/*     */   public PermissiblePEX(Player player, PermissionManager plugin) {
/*  62 */     super((ServerOperator)player);
/*  63 */     this.player = player;
/*  64 */     this.plugin = plugin;
/*  65 */     this.permissions = new LinkedHashMap<String, PermissionAttachmentInfo>()
/*     */       {
/*     */         private static final long serialVersionUID = 1L;
/*     */ 
/*     */         
/*     */         public PermissionAttachmentInfo put(String k, PermissionAttachmentInfo v) {
/*  71 */           PermissionAttachmentInfo existing = get(k);
/*  72 */           if (existing != null) {
/*  73 */             return existing;
/*     */           }
/*  75 */           return super.put(k, v);
/*     */         }
/*     */       };
/*  78 */     PERMISSIONS_FIELD.set(this, this.permissions);
/*  79 */     this.attachments = (List<PermissionAttachment>)ATTACHMENTS_FIELD.get(this);
/*  80 */     recalculatePermissions();
/*     */   }
/*     */   
/*     */   public Permissible getPreviousPermissible() {
/*  84 */     return this.previousPermissible;
/*     */   }
/*     */   
/*     */   public void setPreviousPermissible(Permissible previousPermissible) {
/*  88 */     this.previousPermissible = previousPermissible;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasPermission(String permission) {
/*  93 */     PermissionCheckResult res = permissionValue(permission);
/*  94 */     switch (res) {
/*     */       case TRUE:
/*     */       case FALSE:
/*  97 */         return res.toBoolean();
/*     */     } 
/*     */     
/* 100 */     if (super.isPermissionSet(permission)) {
/* 101 */       boolean ret = super.hasPermission(permission);
/* 102 */       return ret;
/*     */     } 
/* 104 */     Permission perm = this.player.getServer().getPluginManager().getPermission(permission);
/* 105 */     return (perm == null) ? Permission.DEFAULT_PERMISSION.getValue(this.player.isOp()) : perm
/* 106 */       .getDefault().getValue(this.player.isOp());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasPermission(Permission permission) {
/* 113 */     PermissionCheckResult res = permissionValue(permission.getName());
/* 114 */     switch (res) {
/*     */       case TRUE:
/*     */       case FALSE:
/* 117 */         return res.toBoolean();
/*     */     } 
/*     */     
/* 120 */     if (super.isPermissionSet(permission.getName())) {
/* 121 */       boolean ret = super.hasPermission(permission);
/* 122 */       return ret;
/*     */     } 
/* 124 */     return permission.getDefault().getValue(this.player.isOp());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recalculatePermissions() {
/* 131 */     if (this.cache != null && this.permissions != null && this.attachments != null) {
/* 132 */       synchronized (this.permissionsLock) {
/* 133 */         clearPermissions();
/* 134 */         this.cache.clear();
/* 135 */         ListIterator<PermissionAttachment> it = this.attachments.listIterator(this.attachments.size());
/* 136 */         while (it.hasPrevious()) {
/* 137 */           PermissionAttachment attach = it.previous();
/* 138 */           calculateChildPerms(attach.getPermissions(), false, attach);
/*     */         } 
/* 140 */         for (Permission p : this.player.getServer().getPluginManager().getDefaultPermissions(isOp())) {
/* 141 */           this.permissions.put(p.getName(), new PermissionAttachmentInfo((Permissible)this.player, p.getName(), null, true));
/* 142 */           calculateChildPerms(p.getChildren(), false, (PermissionAttachment)null);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   protected void calculateChildPerms(Map<String, Boolean> children, boolean invert, PermissionAttachment attachment) {
/*     */     
/* 150 */     try { CALC_CHILD_PERMS_METH.invoke(this, new Object[] { children, Boolean.valueOf(invert), attachment }); }
/* 151 */     catch (IllegalAccessException illegalAccessException) {  }
/* 152 */     catch (InvocationTargetException e)
/* 153 */     { throw new RuntimeException(e); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPermissionSet(String permission) {
/* 159 */     return (super.isPermissionSet(permission) || permissionValue(permission) != PermissionCheckResult.UNDEFINED);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<PermissionAttachmentInfo> getEffectivePermissions() {
/* 164 */     synchronized (this.permissionsLock) {
/* 165 */       return new LinkedHashSet<>(this.permissions.values());
/*     */     } 
/*     */   }
/*     */   
/*     */   private PermissionCheckResult checkSingle(String expression, String permission, boolean value) {
/* 170 */     if (this.plugin.getPermissionMatcher().isMatches(expression, permission)) {
/* 171 */       PermissionCheckResult res = PermissionCheckResult.fromBoolean(value);
/* 172 */       return res;
/*     */     } 
/* 174 */     return PermissionCheckResult.UNDEFINED;
/*     */   }
/*     */   
/*     */   protected PermissionCheckResult permissionValue(String permission) {
/*     */     try {
/* 179 */       Validate.notNull(permission, "Permissions being checked must not be null!");
/* 180 */       permission = permission.toLowerCase();
/* 181 */       PermissionCheckResult res = this.cache.get(permission);
/* 182 */       if (res != null) {
/* 183 */         return res;
/*     */       }
/*     */       
/* 186 */       res = PermissionCheckResult.UNDEFINED;
/*     */       
/* 188 */       synchronized (this.permissionsLock) {
/* 189 */         for (PermissionAttachmentInfo pai : this.permissions.values()) {
/* 190 */           if ((res = checkSingle(pai.getPermission(), permission, pai
/* 191 */               .getValue())) != PermissionCheckResult.UNDEFINED) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */       } 
/* 196 */       if (res == PermissionCheckResult.UNDEFINED) {
/* 197 */         for (Map.Entry<String, Boolean> ent : this.plugin.getRegexPerms().getPermissionList()
/* 198 */           .getParents(permission)) {
/* 199 */           if ((res = permissionValue(ent.getKey())) != PermissionCheckResult.UNDEFINED) {
/* 200 */             res = PermissionCheckResult.fromBoolean(((res.toBoolean() ^ ((Boolean)ent.getValue()).booleanValue()) == 0));
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 205 */       this.cache.put(permission, res);
/* 206 */       LAST_CALL_ERRORED.set(false);
/* 207 */       return res;
/* 208 */     } catch (Throwable t) {
/* 209 */       if (LAST_CALL_ERRORED.compareAndSet(false, true)) {
/* 210 */         t.printStackTrace();
/*     */       }
/* 212 */       return PermissionCheckResult.UNDEFINED;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/permission/injector/regexperms/PermissiblePEX.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */