/*    */ package net.highmc.bukkit.utils.permission.injector;
/*    */ 
/*    */ import org.bukkit.Bukkit;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CraftBukkitInterface
/*    */ {
/*    */   private static final String VERSION;
/*    */   
/*    */   static {
/* 16 */     Class<?> serverClass = Bukkit.getServer().getClass();
/* 17 */     if (!serverClass.getSimpleName().equals("CraftServer")) {
/* 18 */       VERSION = null;
/* 19 */     } else if (serverClass.getName().equals("org.bukkit.craftbukkit.CraftServer")) {
/* 20 */       VERSION = ".";
/*    */     } else {
/* 22 */       String name = serverClass.getName();
/* 23 */       name = name.substring("org.bukkit.craftbukkit".length());
/* 24 */       name = name.substring(0, name.length() - "CraftServer".length());
/* 25 */       VERSION = name;
/*    */     } 
/*    */   }
/*    */   
/*    */   public static String getCBClassName(String simpleName) {
/* 30 */     if (VERSION == null) {
/* 31 */       return null;
/*    */     }
/* 33 */     return "org.bukkit.craftbukkit" + VERSION + simpleName;
/*    */   }
/*    */   
/*    */   public static Class<?> getCBClass(String name) {
/* 37 */     if (VERSION == null) {
/* 38 */       return null;
/*    */     }
/*    */     try {
/* 41 */       return Class.forName(getCBClassName(name));
/* 42 */     } catch (ClassNotFoundException classNotFoundException) {
/*    */       
/* 44 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/permission/injector/CraftBukkitInterface.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */