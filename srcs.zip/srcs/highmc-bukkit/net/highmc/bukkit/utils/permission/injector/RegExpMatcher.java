/*    */ package net.highmc.bukkit.utils.permission.injector;
/*    */ 
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.regex.Pattern;
/*    */ import net.highmc.bukkit.utils.permission.injector.loader.LoaderNormal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RegExpMatcher
/*    */   implements PermissionMatcher
/*    */ {
/*    */   public static final String RAW_REGEX_CHAR = "$";
/* 17 */   protected static Pattern rangeExpression = Pattern.compile("(\\d+)-(\\d+)");
/*    */   private Object patternCache;
/*    */   
/*    */   public RegExpMatcher() {
/* 21 */     Class<?> cacheBuilder = getClassGuava("com.google.common.cache.CacheBuilder");
/* 22 */     Class<?> cacheLoader = getClassGuava("com.google.common.cache.CacheLoader");
/*    */     try {
/* 24 */       Object obj = cacheBuilder.getMethod("newBuilder", new Class[0]).invoke(null, new Object[0]);
/* 25 */       Method maximumSize = obj.getClass().getMethod("maximumSize", new Class[] { long.class });
/* 26 */       Object obj2 = maximumSize.invoke(obj, new Object[] { Integer.valueOf(500) });
/* 27 */       Object loader = new LoaderNormal();
/* 28 */       Method build = obj2.getClass().getMethod("build", new Class[] { cacheLoader });
/* 29 */       this.patternCache = build.invoke(obj2, new Object[] { loader });
/* 30 */     } catch (Exception e) {
/* 31 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isMatches(String expression, String permission) {
/*    */     try {
/* 38 */       Method get = this.patternCache.getClass().getMethod("get", new Class[] { Object.class });
/* 39 */       get.setAccessible(true);
/* 40 */       Object obj = get.invoke(this.patternCache, new Object[] { expression });
/* 41 */       return ((Pattern)obj).matcher(permission).matches();
/* 42 */     } catch (IllegalArgumentException e) {
/* 43 */       e.printStackTrace();
/* 44 */     } catch (IllegalAccessException e) {
/* 45 */       e.printStackTrace();
/* 46 */     } catch (InvocationTargetException e) {
/* 47 */       e.printStackTrace();
/* 48 */     } catch (NoSuchMethodException e) {
/* 49 */       e.printStackTrace();
/* 50 */     } catch (SecurityException e) {
/* 51 */       e.printStackTrace();
/*    */     } 
/* 53 */     return false;
/*    */   }
/*    */   
/*    */   private Class<?> getClassGuava(String str) {
/* 57 */     Class<?> clasee = null;
/*    */     try {
/* 59 */       if (hasNetUtil()) {
/* 60 */         str = "net.minecraft.util." + str;
/*    */       }
/* 62 */       clasee = Class.forName(str);
/* 63 */     } catch (ClassNotFoundException e) {
/* 64 */       e.printStackTrace();
/*    */     } 
/* 66 */     return clasee;
/*    */   }
/*    */   
/*    */   private boolean hasNetUtil() {
/*    */     try {
/* 71 */       Class.forName("net.minecraft.util.com.google.common.cache.LoadingCache");
/* 72 */       return true;
/* 73 */     } catch (ClassNotFoundException e) {
/* 74 */       return false;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/permission/injector/RegExpMatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */