/*    */ package net.highmc.bukkit.utils.permission.injector;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FieldReplacer<Instance, Type>
/*    */ {
/*    */   private final Class<Type> requiredType;
/*    */   private final Field field;
/*    */   
/*    */   public FieldReplacer(Class<? extends Instance> clazz, String fieldName, Class<Type> requiredType) {
/* 15 */     this.requiredType = requiredType;
/* 16 */     this.field = getField(clazz, fieldName);
/* 17 */     if (this.field == null) {
/* 18 */       throw new ExceptionInInitializerError("No such field " + fieldName + " in class " + clazz);
/*    */     }
/* 20 */     this.field.setAccessible(true);
/* 21 */     if (!requiredType.isAssignableFrom(this.field.getType())) {
/* 22 */       throw new ExceptionInInitializerError("Field of wrong type");
/*    */     }
/*    */   }
/*    */   
/*    */   public Type get(Instance instance) {
/*    */     try {
/* 28 */       return this.requiredType.cast(this.field.get(instance));
/* 29 */     } catch (IllegalAccessException e) {
/* 30 */       throw new Error(e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void set(Instance instance, Type newValue) {
/*    */     try {
/* 36 */       this.field.set(instance, newValue);
/* 37 */     } catch (IllegalAccessException e) {
/* 38 */       throw new Error(e);
/*    */     } 
/*    */   }
/*    */   
/*    */   private static Field getField(Class<?> clazz, String fieldName) {
/* 43 */     while (clazz != null && clazz != Object.class) {
/*    */       try {
/* 45 */         return clazz.getDeclaredField(fieldName);
/* 46 */       } catch (NoSuchFieldException e) {
/* 47 */         clazz = clazz.getSuperclass();
/*    */       } 
/*    */     } 
/* 50 */     return null;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/permission/injector/FieldReplacer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */