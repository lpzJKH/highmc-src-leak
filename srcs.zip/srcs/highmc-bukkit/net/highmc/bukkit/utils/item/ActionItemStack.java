/*     */ package net.highmc.bukkit.utils.item;
/*     */ 
/*     */ import com.comphenix.protocol.utility.MinecraftReflection;
/*     */ import com.comphenix.protocol.wrappers.nbt.NbtCompound;
/*     */ import com.comphenix.protocol.wrappers.nbt.NbtFactory;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.HandlerList;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.block.Action;
/*     */ import org.bukkit.event.block.BlockBreakEvent;
/*     */ import org.bukkit.event.block.BlockPlaceEvent;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEntityEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.metadata.FixedMetadataValue;
/*     */ import org.bukkit.metadata.MetadataValue;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ActionItemStack
/*     */ {
/*     */   private static Listener listener;
/*     */   private Interact interactHandler;
/*  38 */   private static final Map<Integer, Interact> HANDLERS = new HashMap<>(); private ItemStack itemStack;
/*     */   
/*     */   public Interact getInteractHandler() {
/*  41 */     return this.interactHandler;
/*     */   } public ItemStack getItemStack() {
/*  43 */     return this.itemStack;
/*     */   }
/*     */   
/*     */   public ActionItemStack(ItemStack stack, Interact handler) {
/*  47 */     this.itemStack = setTag(stack, registerHandler(handler));
/*     */     
/*  49 */     if (this.itemStack == null) {
/*  50 */       this.itemStack = stack;
/*     */     }
/*  52 */     this.interactHandler = handler;
/*     */   }
/*     */   
/*     */   public static int registerHandler(Interact handler) {
/*  56 */     if (HANDLERS.containsValue(handler)) {
/*  57 */       return ((Integer)HANDLERS.entrySet().stream().filter(entry -> (entry.getValue() == handler)).map(Map.Entry::getKey)
/*  58 */         .findFirst().orElse(Integer.valueOf(-1))).intValue();
/*     */     }
/*  60 */     handler.setHandler(HANDLERS.size() + 1);
/*  61 */     HANDLERS.put(Integer.valueOf(HANDLERS.size() + 1), handler);
/*     */     
/*  63 */     if (listener == null) {
/*  64 */       listener = new ActionItemListener();
/*  65 */       Bukkit.getPluginManager().registerEvents(listener, (Plugin)BukkitCommon.getInstance());
/*     */     } 
/*     */     
/*  68 */     return HANDLERS.size();
/*     */   }
/*     */   
/*     */   public static void unregisterHandler(Integer id) {
/*  72 */     HANDLERS.remove(id);
/*     */     
/*  74 */     if (listener != null && HANDLERS.isEmpty()) {
/*  75 */       HandlerList.unregisterAll(listener);
/*  76 */       listener = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void unregisterHandler(Interact handler) {
/*  81 */     Iterator<Map.Entry<Integer, Interact>> iterator = HANDLERS.entrySet().iterator();
/*     */     
/*  83 */     while (iterator.hasNext()) {
/*  84 */       Map.Entry<Integer, Interact> entry = iterator.next();
/*     */       
/*  86 */       if (entry.getValue() == handler) {
/*  87 */         iterator.remove();
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Interact getHandler(Integer id) {
/*  94 */     return HANDLERS.get(id);
/*     */   }
/*     */   
/*     */   public static ItemStack setTag(ItemStack stack, int id) {
/*     */     try {
/*  99 */       if (stack == null || stack.getType() == Material.AIR) {
/* 100 */         throw new Exception();
/*     */       }
/* 102 */       Constructor<?> caller = MinecraftReflection.getCraftItemStackClass().getDeclaredConstructor(new Class[] { ItemStack.class });
/* 103 */       caller.setAccessible(true);
/* 104 */       ItemStack item = (ItemStack)caller.newInstance(new Object[] { stack });
/* 105 */       NbtCompound compound = (NbtCompound)NbtFactory.fromItemTag(item);
/* 106 */       compound.put("interactHandler", id);
/* 107 */       return item;
/* 108 */     } catch (Exception e) {
/* 109 */       e.printStackTrace();
/*     */       
/* 111 */       return null;
/*     */     } 
/*     */   }
/*     */   public static ActionItemStack create(ItemStack stack, Interact handler) {
/* 115 */     return new ActionItemStack(stack, handler);
/*     */   }
/*     */   
/*     */   public static abstract class Interact {
/*     */     private ActionItemStack.InteractType interactType;
/*     */     
/* 121 */     public ActionItemStack.InteractType getInteractType() { return this.interactType; } private boolean inventoryClick; private int handler; public boolean isInventoryClick() {
/* 122 */       return this.inventoryClick;
/*     */     } public int getHandler() {
/* 124 */       return this.handler;
/*     */     }
/*     */     public Interact() {
/* 127 */       this.interactType = ActionItemStack.InteractType.CLICK;
/*     */     }
/*     */     
/*     */     public Interact setHandler(int handler) {
/* 131 */       this.handler = handler;
/* 132 */       return this;
/*     */     }
/*     */     
/*     */     public Interact(ActionItemStack.InteractType interactType) {
/* 136 */       this.interactType = interactType;
/*     */     }
/*     */     
/*     */     public Interact setInventoryClick(boolean inventoryClick) {
/* 140 */       this.inventoryClick = inventoryClick;
/* 141 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public abstract boolean onInteract(Player param1Player, Entity param1Entity, Block param1Block, ItemStack param1ItemStack, ActionItemStack.ActionType param1ActionType);
/*     */   }
/*     */   
/*     */   public enum ActionType
/*     */   {
/* 150 */     CLICK_PLAYER, RIGHT, LEFT;
/*     */   }
/*     */ 
/*     */   
/*     */   public enum InteractType
/*     */   {
/* 156 */     PLAYER, CLICK;
/*     */   }
/*     */   
/*     */   private static class ActionItemListener implements Listener {
/*     */     private ActionItemListener() {}
/*     */     
/*     */     @EventHandler
/*     */     public void onPlayerInteract(PlayerInteractEvent event) {
/* 164 */       if (event.getItem() == null || event.getItem().getType() == Material.AIR) {
/*     */         return;
/*     */       }
/* 167 */       ItemStack stack = event.getItem();
/*     */       
/*     */       try {
/* 170 */         NbtCompound compound = getNbtCompound(stack);
/*     */         
/* 172 */         if (compound.containsKey("interactHandler")) {
/* 173 */           ActionItemStack.Interact handler = ActionItemStack.getHandler(Integer.valueOf(compound.getInteger("interactHandler")));
/*     */           
/* 175 */           if (handler == null || handler.getInteractType() == ActionItemStack.InteractType.PLAYER) {
/*     */             return;
/*     */           }
/* 178 */           Player player = event.getPlayer();
/* 179 */           Action action = event.getAction();
/*     */           
/* 181 */           event.setCancelled(handler.onInteract(player, null, event.getClickedBlock(), stack, 
/* 182 */                 action.name().contains("RIGHT") ? ActionItemStack.ActionType.RIGHT : ActionItemStack.ActionType.LEFT));
/*     */         } 
/* 184 */       } catch (Exception e) {
/* 185 */         e.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/*     */     @EventHandler
/*     */     public void onPlayerInteractEntity(PlayerInteractEntityEvent event) {
/* 191 */       if (event.getPlayer().getItemInHand() == null || event
/* 192 */         .getPlayer().getItemInHand().getType() == Material.AIR) {
/*     */         return;
/*     */       }
/* 195 */       ItemStack stack = event.getPlayer().getItemInHand();
/*     */       
/*     */       try {
/* 198 */         NbtCompound compound = getNbtCompound(stack);
/*     */         
/* 200 */         if (compound.containsKey("interactHandler")) {
/* 201 */           ActionItemStack.Interact handler = ActionItemStack.getHandler(Integer.valueOf(compound.getInteger("interactHandler")));
/*     */           
/* 203 */           if (handler == null || handler.getInteractType() == ActionItemStack.InteractType.CLICK) {
/*     */             return;
/*     */           }
/* 206 */           Player player = event.getPlayer();
/*     */           
/* 208 */           event.setCancelled(handler
/* 209 */               .onInteract(player, event.getRightClicked(), null, stack, ActionItemStack.ActionType.CLICK_PLAYER));
/*     */         } 
/* 211 */       } catch (Exception e) {
/* 212 */         e.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/*     */     @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
/*     */     public void onInventoryClick(InventoryClickEvent event) {
/* 218 */       if (event.getCurrentItem() == null || event.getCurrentItem().getType() == Material.AIR) {
/*     */         return;
/*     */       }
/* 221 */       ItemStack stack = event.getCurrentItem();
/*     */       
/*     */       try {
/* 224 */         NbtCompound compound = getNbtCompound(stack);
/*     */         
/* 226 */         if (compound.containsKey("interactHandler")) {
/* 227 */           ActionItemStack.Interact handler = ActionItemStack.getHandler(Integer.valueOf(compound.getInteger("interactHandler")));
/*     */           
/* 229 */           if (handler == null) {
/* 230 */             compound.remove("interactHandler");
/*     */             
/*     */             return;
/*     */           } 
/* 234 */           if (handler.getInteractType() == ActionItemStack.InteractType.PLAYER || !handler.isInventoryClick()) {
/*     */             return;
/*     */           }
/* 237 */           Player player = (Player)event.getWhoClicked();
/* 238 */           event.setCancelled(handler.onInteract(player, null, null, stack, ActionItemStack.ActionType.LEFT));
/*     */         } 
/* 240 */       } catch (Exception e) {
/* 241 */         e.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/*     */     @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
/*     */     public void onBlockPlace(BlockPlaceEvent event) {
/* 247 */       if (event.getItemInHand() == null || event.getItemInHand().getType() == Material.AIR) {
/*     */         return;
/*     */       }
/* 250 */       ItemStack stack = event.getItemInHand();
/*     */       
/*     */       try {
/* 253 */         NbtCompound compound = getNbtCompound(stack);
/*     */         
/* 255 */         if (compound.containsKey("interactHandler")) {
/* 256 */           Block b = event.getBlock();
/* 257 */           int id = compound.getInteger("interactHandler");
/* 258 */           b.setMetadata("interactHandler", (MetadataValue)new FixedMetadataValue((Plugin)BukkitCommon.getInstance(), Integer.valueOf(id)));
/* 259 */           b.getDrops().clear();
/* 260 */           b.getDrops().add(
/* 261 */               ActionItemStack.setTag(new ItemStack(event.getBlock().getType(), 1, (short)event.getBlock().getData()), id));
/*     */         } 
/* 263 */       } catch (Exception e) {
/* 264 */         e.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/*     */     @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
/*     */     public void onBlockBreak(BlockBreakEvent event) {
/* 270 */       Block b = event.getBlock();
/*     */       
/* 272 */       if (!b.hasMetadata("interactHandler")) {
/*     */         return;
/*     */       }
/* 275 */       b.getDrops().clear();
/* 276 */       b.getDrops()
/* 277 */         .add(ActionItemStack.setTag(new ItemStack(event
/* 278 */               .getBlock().getType(), 1, (short)event.getBlock().getData()), ((MetadataValue)b
/* 279 */             .getMetadata("interactHandler").get(0)).asInt()));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private NbtCompound getNbtCompound(ItemStack stack) throws NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
/* 285 */       Constructor<?> caller = MinecraftReflection.getCraftItemStackClass().getDeclaredConstructor(new Class[] { ItemStack.class });
/* 286 */       caller.setAccessible(true);
/* 287 */       ItemStack item = (ItemStack)caller.newInstance(new Object[] { stack });
/* 288 */       NbtCompound compound = (NbtCompound)NbtFactory.fromItemTag(item);
/* 289 */       return compound;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/item/ActionItemStack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */