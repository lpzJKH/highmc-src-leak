/*     */ package net.highmc.bukkit.utils.item;
/*     */ 
/*     */ import com.comphenix.protocol.utility.MinecraftReflection;
/*     */ import com.comphenix.protocol.wrappers.nbt.NbtCompound;
/*     */ import com.comphenix.protocol.wrappers.nbt.NbtFactory;
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import com.mojang.authlib.properties.Property;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Base64;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import net.highmc.bukkit.utils.StringLoreUtils;
/*     */ import net.highmc.utils.skin.Skin;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Color;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
/*     */ import org.bukkit.enchantments.Enchantment;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.ItemFlag;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.inventory.meta.LeatherArmorMeta;
/*     */ import org.bukkit.inventory.meta.PotionMeta;
/*     */ import org.bukkit.inventory.meta.SkullMeta;
/*     */ import org.bukkit.potion.PotionEffect;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ItemBuilder
/*     */ {
/*     */   public Material getMaterial() {
/*  44 */     return this.material;
/*  45 */   } public int getAmount() { return this.amount; }
/*  46 */   public short getDurability() { return this.durability; }
/*  47 */   public boolean isUseMeta() { return this.useMeta; }
/*  48 */   public boolean isGlow() { return this.glow; }
/*  49 */   public String getDisplayName() { return this.displayName; }
/*  50 */   public Map<Enchantment, Integer> getEnchantments() { return this.enchantments; }
/*  51 */   public List<PotionEffect> getPotions() { return this.potions; } public List<String> getLore() {
/*  52 */     return this.lore;
/*     */   }
/*  54 */   public Color getColor() { return this.color; }
/*  55 */   public String getSkinOwner() { return this.skinOwner; }
/*  56 */   public Skin getSkin() { return this.skin; } public String getSkinUrl() {
/*  57 */     return this.skinUrl;
/*     */   }
/*  59 */   public boolean isHideAttributes() { return this.hideAttributes; }
/*  60 */   public boolean isUnbreakable() { return this.unbreakable; } public List<ItemFlag> getItemFlags() {
/*  61 */     return this.itemFlags;
/*     */   }
/*     */   
/*  64 */   private Material material = Material.STONE;
/*  65 */   private int amount = 1;
/*  66 */   private short durability = 0; private boolean hideAttributes = false;
/*     */   private boolean unbreakable = false;
/*     */   private boolean useMeta = false;
/*     */   private boolean glow = false;
/*     */   private String displayName;
/*     */   private Map<Enchantment, Integer> enchantments;
/*     */   
/*     */   public ItemBuilder flag(ItemFlag itemFlag) {
/*  74 */     if (this.itemFlags == null) {
/*  75 */       this.itemFlags = new ArrayList<>();
/*     */     }
/*  77 */     this.itemFlags.add(itemFlag);
/*     */     
/*  79 */     if (!this.useMeta)
/*  80 */       this.useMeta = true; 
/*  81 */     return this;
/*     */   }
/*     */   private List<PotionEffect> potions; private List<String> lore; private Color color; private String skinOwner; private Skin skin; private String skinUrl; private List<ItemFlag> itemFlags;
/*     */   public ItemBuilder flag(Set<ItemFlag> itemFlags) {
/*  85 */     if (this.itemFlags == null) {
/*  86 */       this.itemFlags = new ArrayList<>();
/*     */     }
/*  88 */     this.itemFlags.addAll(itemFlags);
/*     */     
/*  90 */     if (!this.useMeta)
/*  91 */       this.useMeta = true; 
/*  92 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder type(Material material) {
/*  96 */     this.material = material;
/*  97 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder amount(int amount) {
/* 101 */     if (amount <= 0)
/* 102 */       amount = 1; 
/* 103 */     this.amount = amount;
/* 104 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder durability(short durability) {
/* 108 */     this.durability = durability;
/* 109 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder durability(int durability) {
/* 113 */     this.durability = (short)durability;
/* 114 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder name(String text) {
/* 118 */     if (!this.useMeta) {
/* 119 */       this.useMeta = true;
/*     */     }
/* 121 */     this.displayName = text.replace("&", "§");
/* 122 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder enchantment(Enchantment enchantment) {
/* 126 */     return enchantment(enchantment, Integer.valueOf(1));
/*     */   }
/*     */   
/*     */   public ItemBuilder enchantment(Enchantment enchantment, Integer level) {
/* 130 */     if (this.enchantments == null) {
/* 131 */       this.enchantments = new HashMap<>();
/*     */     }
/*     */     
/* 134 */     if (level.intValue() == 0) {
/* 135 */       return this;
/*     */     }
/* 137 */     this.enchantments.put(enchantment, level);
/* 138 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder enchantment(Map<Enchantment, Integer> enchantments) {
/* 142 */     if (this.enchantments == null) {
/* 143 */       this.enchantments = new HashMap<>();
/*     */     }
/*     */     
/* 146 */     for (Map.Entry<Enchantment, Integer> entry : enchantments.entrySet()) {
/* 147 */       this.enchantments.put(entry.getKey(), entry.getValue());
/*     */     }
/* 149 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder clearLore() {
/* 153 */     if (!this.useMeta) {
/* 154 */       this.useMeta = true;
/*     */     }
/*     */     
/* 157 */     if (this.lore != null) {
/* 158 */       this.lore.clear();
/*     */     }
/* 160 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder lore(String text) {
/* 164 */     if (!this.useMeta) {
/* 165 */       this.useMeta = true;
/*     */     }
/*     */     
/* 168 */     if (this.lore == null) {
/* 169 */       this.lore = new ArrayList<>(StringLoreUtils.getLore(30, text));
/*     */     } else {
/* 171 */       this.lore.addAll(StringLoreUtils.getLore(30, text));
/*     */     } 
/* 173 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder lore(String... lore) {
/* 177 */     return lore(Arrays.asList(lore));
/*     */   }
/*     */   
/*     */   public ItemBuilder lore(List<String> text) {
/* 181 */     if (!this.useMeta) {
/* 182 */       this.useMeta = true;
/*     */     }
/* 184 */     if (this.lore == null) {
/* 185 */       this.lore = new ArrayList<>();
/*     */     }
/* 187 */     for (String str : text) {
/* 188 */       this.lore.add(str.replace("&", "§"));
/*     */     }
/*     */     
/* 191 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder potion(PotionEffect potionEffect) {
/* 195 */     if (!this.useMeta) {
/* 196 */       this.useMeta = true;
/*     */     }
/*     */     
/* 199 */     if (this.potions == null) {
/* 200 */       this.potions = new ArrayList<>();
/*     */     }
/* 202 */     this.potions.add(potionEffect);
/* 203 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder potion(List<PotionEffect> potions) {
/* 207 */     if (potions == null) {
/* 208 */       return this;
/*     */     }
/*     */     
/* 211 */     if (!this.useMeta) {
/* 212 */       this.useMeta = true;
/*     */     }
/*     */     
/* 215 */     if (this.potions == null) {
/* 216 */       this.potions = new ArrayList<>();
/*     */     }
/* 218 */     this.potions.addAll(potions);
/* 219 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder glow() {
/* 223 */     this.glow = true;
/* 224 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder color(Color color) {
/* 228 */     this.useMeta = true;
/* 229 */     this.color = color;
/* 230 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder skin(String skin) {
/* 234 */     this.useMeta = true;
/* 235 */     this.skinOwner = skin;
/* 236 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder skin(Skin skin) {
/* 240 */     this.useMeta = true;
/* 241 */     this.skin = skin;
/* 242 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder skin(Player player) {
/* 246 */     this.useMeta = true;
/*     */     
/* 248 */     GameProfile gameProfile = ((CraftPlayer)player).getHandle().getProfile();
/* 249 */     Property property = gameProfile.getProperties().get("textures").stream().findFirst().orElse(null);
/*     */     
/* 251 */     this.skin = new Skin(player.getName(), property.getValue(), property.getSignature());
/* 252 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder skin(String value, String signature) {
/* 256 */     this.useMeta = true;
/* 257 */     this.skin = new Skin("none", value, signature);
/* 258 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder skinURL(String skinURL) {
/* 262 */     this.useMeta = true;
/* 263 */     this.skinUrl = skinURL;
/* 264 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder hideAttributes() {
/* 268 */     this.useMeta = true;
/* 269 */     this.hideAttributes = true;
/* 270 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder showAttributes() {
/* 274 */     this.useMeta = true;
/* 275 */     this.hideAttributes = false;
/* 276 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder unbreakable() {
/* 280 */     this.unbreakable = true;
/* 281 */     return this;
/*     */   }
/*     */   
/*     */   public ItemStack build() {
/* 285 */     ItemStack stack = new ItemStack(this.material, this.amount, this.durability);
/*     */     
/* 287 */     if (this.enchantments != null && !this.enchantments.isEmpty()) {
/* 288 */       for (Map.Entry<Enchantment, Integer> entry : this.enchantments.entrySet()) {
/* 289 */         stack.addUnsafeEnchantment(entry.getKey(), ((Integer)entry.getValue()).intValue());
/*     */       }
/*     */     }
/*     */     
/* 293 */     if (this.useMeta) {
/* 294 */       ItemMeta meta = stack.getItemMeta();
/*     */       
/* 296 */       if (this.displayName != null) {
/* 297 */         meta.setDisplayName(this.displayName.replace("&", "§"));
/*     */       }
/*     */       
/* 300 */       if (this.lore != null && !this.lore.isEmpty()) {
/* 301 */         meta.setLore(this.lore);
/*     */       }
/*     */ 
/*     */       
/* 305 */       if (this.color != null && 
/* 306 */         meta instanceof LeatherArmorMeta) {
/* 307 */         ((LeatherArmorMeta)meta).setColor(this.color);
/*     */       }
/*     */ 
/*     */       
/* 311 */       if (this.potions != null && 
/* 312 */         meta instanceof PotionMeta) {
/* 313 */         PotionMeta potionMeta = (PotionMeta)meta;
/*     */         
/* 315 */         for (PotionEffect potionEffect : this.potions) {
/* 316 */           potionMeta.addCustomEffect(potionEffect, true);
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 321 */       if (meta instanceof SkullMeta) {
/* 322 */         SkullMeta skullMeta = (SkullMeta)meta;
/*     */         
/* 324 */         if (this.skin != null) {
/*     */           
/* 326 */           GameProfile profile = new GameProfile((this.skin.getUniqueId() == null) ? UUID.randomUUID() : this.skin.getUniqueId(), this.skin.getPlayerName());
/* 327 */           profile.getProperties().put("textures", new Property("textures", this.skin
/* 328 */                 .getValue(), this.skin.getSignature()));
/*     */           try {
/* 330 */             Field field = skullMeta.getClass().getDeclaredField("profile");
/* 331 */             field.setAccessible(true);
/* 332 */             field.set(skullMeta, profile);
/* 333 */           } catch (Exception e) {
/* 334 */             e.printStackTrace();
/*     */           } 
/* 336 */         } else if (this.skinUrl != null) {
/*     */           
/* 338 */           GameProfile profile = new GameProfile((this.skin.getUniqueId() == null) ? UUID.randomUUID() : this.skin.getUniqueId(), this.skin.getPlayerName());
/* 339 */           profile.getProperties().put("textures", new Property("textures", 
/*     */                 
/* 341 */                 Base64.getEncoder()
/* 342 */                 .encodeToString(String.format("{textures:{SKIN:{url:\"%s\"}}}", new Object[] { this.skinUrl
/* 343 */                     }).getBytes(StandardCharsets.UTF_8))));
/*     */           
/*     */           try {
/* 346 */             Field field = skullMeta.getClass().getDeclaredField("profile");
/* 347 */             field.setAccessible(true);
/* 348 */             field.set(skullMeta, profile);
/* 349 */           } catch (Exception e) {
/* 350 */             e.printStackTrace();
/*     */           } 
/* 352 */         } else if (this.skinOwner != null) {
/* 353 */           Player player = Bukkit.getPlayer(this.skinOwner);
/*     */           
/* 355 */           if (player == null) {
/* 356 */             skullMeta.setOwner(this.skinOwner);
/*     */           } else {
/*     */             try {
/* 359 */               Field field = skullMeta.getClass().getDeclaredField("profile");
/* 360 */               field.setAccessible(true);
/* 361 */               field.set(skullMeta, ((CraftPlayer)player).getHandle().getProfile());
/* 362 */             } catch (Exception e) {
/* 363 */               e.printStackTrace();
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 369 */       meta.spigot().setUnbreakable(this.unbreakable);
/*     */ 
/*     */       
/* 372 */       if (this.hideAttributes) {
/* 373 */         meta.addItemFlags(ItemFlag.values());
/*     */       } else {
/* 375 */         meta.removeItemFlags(ItemFlag.values());
/*     */       } 
/* 377 */       if (this.itemFlags != null) {
/* 378 */         meta.addItemFlags((ItemFlag[])this.itemFlags.stream().toArray(x$0 -> new ItemFlag[x$0]));
/*     */       }
/* 380 */       stack.setItemMeta(meta);
/*     */     } 
/*     */     
/* 383 */     if (this.glow && (this.enchantments == null || this.enchantments.isEmpty())) {
/*     */       
/*     */       try {
/* 386 */         Constructor<?> caller = MinecraftReflection.getCraftItemStackClass().getDeclaredConstructor(new Class[] { ItemStack.class });
/* 387 */         caller.setAccessible(true);
/* 388 */         ItemStack item = (ItemStack)caller.newInstance(new Object[] { stack });
/* 389 */         NbtCompound compound = (NbtCompound)NbtFactory.fromItemTag(item);
/* 390 */         compound.put(NbtFactory.ofList("ench", new Object[0]));
/* 391 */         return item;
/* 392 */       } catch (NoSuchMethodException|SecurityException|InstantiationException|IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException e) {
/*     */         
/* 394 */         e.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/* 398 */     this.material = Material.STONE;
/* 399 */     this.amount = 1;
/* 400 */     this.durability = 0;
/*     */     
/* 402 */     if (this.useMeta) {
/* 403 */       this.useMeta = false;
/*     */     }
/*     */     
/* 406 */     if (this.glow) {
/* 407 */       this.glow = false;
/*     */     }
/*     */     
/* 410 */     if (this.hideAttributes) {
/* 411 */       this.hideAttributes = false;
/*     */     }
/*     */     
/* 414 */     if (this.unbreakable) {
/* 415 */       this.unbreakable = false;
/*     */     }
/*     */     
/* 418 */     if (this.displayName != null) {
/* 419 */       this.displayName = null;
/*     */     }
/*     */     
/* 422 */     if (this.enchantments != null) {
/* 423 */       this.enchantments.clear();
/* 424 */       this.enchantments = null;
/*     */     } 
/*     */     
/* 427 */     if (this.lore != null) {
/* 428 */       this.lore.clear();
/* 429 */       this.lore = null;
/*     */     } 
/*     */     
/* 432 */     this.skinOwner = null;
/* 433 */     this.skinUrl = null;
/* 434 */     this.color = null;
/* 435 */     return stack;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ItemStack glow(ItemStack stack) {
/*     */     try {
/* 441 */       Constructor<?> caller = MinecraftReflection.getCraftItemStackClass().getDeclaredConstructor(new Class[] { ItemStack.class });
/* 442 */       caller.setAccessible(true);
/* 443 */       ItemStack item = (ItemStack)caller.newInstance(new Object[] { stack });
/* 444 */       NbtCompound compound = (NbtCompound)NbtFactory.fromItemTag(item);
/* 445 */       compound.put(NbtFactory.ofList("ench", new Object[0]));
/* 446 */       return item;
/* 447 */     } catch (NoSuchMethodException|SecurityException|InstantiationException|IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException e) {
/*     */       
/* 449 */       e.printStackTrace();
/*     */       
/* 451 */       return stack;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static ItemBuilder fromStack(ItemStack stack) {
/* 456 */     ItemBuilder builder = (new ItemBuilder()).type(stack.getType()).amount(stack.getAmount()).durability(stack.getDurability());
/*     */     
/* 458 */     if (stack.hasItemMeta()) {
/* 459 */       ItemMeta meta = stack.getItemMeta();
/*     */       
/* 461 */       builder.flag(meta.getItemFlags());
/*     */       
/* 463 */       if (meta.hasDisplayName()) {
/* 464 */         builder.name(meta.getDisplayName());
/*     */       }
/* 466 */       if (meta.hasLore()) {
/* 467 */         builder.lore(meta.getLore());
/*     */       }
/* 469 */       if (meta instanceof LeatherArmorMeta) {
/* 470 */         Color color = ((LeatherArmorMeta)meta).getColor();
/* 471 */         if (color != null) {
/* 472 */           builder.color(color);
/*     */         }
/*     */       } 
/* 475 */       if (meta instanceof SkullMeta) {
/* 476 */         SkullMeta sm = (SkullMeta)meta;
/* 477 */         if (sm.hasOwner())
/* 478 */           builder.skin(sm.getOwner()); 
/* 479 */       } else if (meta instanceof PotionMeta) {
/* 480 */         PotionMeta potionMeta = (PotionMeta)meta;
/*     */         
/* 482 */         builder.potion(potionMeta.getCustomEffects());
/*     */       } 
/*     */       
/* 485 */       for (Map.Entry<Enchantment, Integer> entry : (Iterable<Map.Entry<Enchantment, Integer>>)meta.getEnchants().entrySet()) {
/* 486 */         builder.enchantment(entry.getKey(), entry.getValue());
/*     */       }
/*     */     } 
/* 489 */     return builder;
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/item/ItemBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */