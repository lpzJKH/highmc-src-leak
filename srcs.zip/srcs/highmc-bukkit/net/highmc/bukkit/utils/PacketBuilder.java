/*    */ package net.highmc.bukkit.utils;
/*    */ 
/*    */ import com.comphenix.protocol.PacketType;
/*    */ import com.comphenix.protocol.events.PacketContainer;
/*    */ import com.comphenix.protocol.wrappers.EnumWrappers;
/*    */ import com.comphenix.protocol.wrappers.WrappedChatComponent;
/*    */ 
/*    */ public class PacketBuilder
/*    */ {
/*    */   private PacketContainer packetContainer;
/*    */   
/*    */   public PacketBuilder(PacketType packetType) {
/* 13 */     this.packetContainer = new PacketContainer(packetType);
/*    */   }
/*    */   
/*    */   public PacketBuilder writeTitleAction(int fieldIndex, EnumWrappers.TitleAction value) {
/* 17 */     this.packetContainer.getTitleActions().write(fieldIndex, value);
/* 18 */     return this;
/*    */   }
/*    */   
/*    */   public PacketBuilder writeChatComponents(int fieldIndex, WrappedChatComponent value) {
/* 22 */     this.packetContainer.getChatComponents().write(fieldIndex, value);
/* 23 */     return this;
/*    */   }
/*    */   
/*    */   public PacketBuilder writeInteger(int fieldIndex, int value) {
/* 27 */     this.packetContainer.getIntegers().write(fieldIndex, Integer.valueOf(value));
/* 28 */     return this;
/*    */   }
/*    */   
/*    */   public PacketContainer build() {
/* 32 */     return this.packetContainer;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/PacketBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */