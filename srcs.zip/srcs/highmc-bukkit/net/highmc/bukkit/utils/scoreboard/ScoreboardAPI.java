/*     */ package net.highmc.bukkit.utils.scoreboard;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.scoreboard.DisplaySlot;
/*     */ import org.bukkit.scoreboard.Objective;
/*     */ import org.bukkit.scoreboard.Team;
/*     */ 
/*     */ 
/*     */ public class ScoreboardAPI
/*     */ {
/*     */   public static Team getTeamFromPlayer(Player player, String teamID) {
/*  14 */     if (teamID.length() > 16) {
/*  15 */       teamID = teamID.substring(0, 16);
/*     */     }
/*  17 */     return player.getScoreboard().getTeam(teamID);
/*     */   }
/*     */   
/*     */   public static boolean teamExistsForPlayer(Player player, String teamID) {
/*  21 */     return (getTeamFromPlayer(player, teamID) != null);
/*     */   }
/*     */   
/*     */   public static Team getPlayerCurrentTeamForPlayer(Player player, Player get) {
/*  25 */     return player.getScoreboard().getEntryTeam(get.getName());
/*     */   }
/*     */   
/*     */   public static boolean playerHasCurrentTeamForPlayer(Player player, Player has) {
/*  29 */     return (getPlayerCurrentTeamForPlayer(player, has) != null);
/*     */   }
/*     */   
/*     */   public static Team createTeamToPlayer(Player player, String teamID, String teamPrefix, String teamSuffix) {
/*  33 */     Team team = getTeamFromPlayer(player, teamID);
/*  34 */     if (team == null) {
/*  35 */       if (teamID.length() > 16) {
/*  36 */         teamID = teamID.substring(0, 16);
/*     */       }
/*  38 */       if (teamPrefix.length() > 16) {
/*  39 */         teamPrefix = teamPrefix.substring(0, 16);
/*     */       }
/*  41 */       if (teamSuffix.length() > 16) {
/*  42 */         teamSuffix = teamSuffix.substring(0, 16);
/*     */       }
/*  44 */       team = player.getScoreboard().registerNewTeam(teamID);
/*     */     } 
/*  46 */     team.setPrefix(teamPrefix);
/*  47 */     team.setSuffix(teamSuffix);
/*  48 */     return team;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void createTeamForPlayers(Collection<? extends Player> players, String teamID, String teamPrefix, String teamSuffix) {
/*  53 */     for (Player player : players) {
/*  54 */       createTeamToPlayer(player, teamID, teamPrefix, teamSuffix);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void createTeamForOnlinePlayers(String teamID, String teamPrefix, String teamSuffix) {
/*  59 */     for (Player player : Bukkit.getOnlinePlayers()) {
/*  60 */       createTeamToPlayer(player, teamID, teamPrefix, teamSuffix);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static Team createTeamIfNotExistsToPlayer(Player player, String teamID, String teamPrefix, String teamSuffix) {
/*  66 */     Team team = getTeamFromPlayer(player, teamID);
/*  67 */     if (team == null) {
/*  68 */       team = createTeamToPlayer(player, teamID, teamPrefix, teamSuffix);
/*     */     }
/*  70 */     return team;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void createTeamIfNotExistsForPlayers(Collection<? extends Player> players, String teamID, String teamPrefix, String teamSuffix) {
/*  75 */     for (Player player : players) {
/*  76 */       createTeamIfNotExistsToPlayer(player, teamID, teamPrefix, teamSuffix);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void createTeamIfNotExistsForOnlinePlayers(String teamID, String teamPrefix, String teamSuffix) {
/*  81 */     for (Player player : Bukkit.getOnlinePlayers()) {
/*  82 */       createTeamIfNotExistsToPlayer(player, teamID, teamPrefix, teamSuffix);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void joinTeam(Team team, String join) {
/*  87 */     if (team != null) {
/*  88 */       if (join.length() > 16) {
/*  89 */         join = join.substring(0, 16);
/*     */       }
/*  91 */       if (!team.getEntries().contains(join)) {
/*  92 */         team.addEntry(join);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void joinTeam(Team team, Player join) {
/*  98 */     joinTeam(team, join.getName());
/*     */   }
/*     */   
/*     */   public static void joinTeamForPlayer(Player player, String teamID, String join) {
/* 102 */     joinTeam(getTeamFromPlayer(player, teamID), join);
/*     */   }
/*     */   
/*     */   public static void joinTeamForPlayer(Player player, String teamID, Player join) {
/* 106 */     Team team = getTeamFromPlayer(player, teamID);
/* 107 */     if (team != null) {
/* 108 */       if (!team.getEntries().contains(join.getName())) {
/* 109 */         leaveCurrentTeamForPlayer(player, join);
/* 110 */         team.addEntry(join.getName());
/*     */       } 
/* 112 */       team = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void joinTeamForPlayers(Collection<? extends Player> players, String teamID, String join) {
/* 117 */     for (Player player : players) {
/* 118 */       joinTeamForPlayer(player, teamID, join);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void joinTeamForPlayers(Collection<? extends Player> players, String teamID, Player join) {
/* 123 */     for (Player player : players) {
/* 124 */       joinTeamForPlayer(player, teamID, join);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void joinTeamForOnlinePlayers(String join, String teamID) {
/* 129 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 130 */       joinTeamForPlayer(player, teamID, join);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void joinTeamForOnlinePlayers(Player join, String teamID) {
/* 135 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 136 */       joinTeamForPlayer(player, teamID, join);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void leaveCurrentTeamForPlayer(Player player, Player leave) {
/* 141 */     Team team = getPlayerCurrentTeamForPlayer(player, leave);
/* 142 */     if (team != null) {
/* 143 */       leaveTeam(team, leave);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void leaveCurrentTeamForPlayers(Collection<? extends Player> players, Player leave) {
/* 148 */     for (Player player : players) {
/* 149 */       leaveCurrentTeamForPlayer(player, leave);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void leaveCurrentTeamForOnlinePlayers(Player leave) {
/* 154 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 155 */       leaveCurrentTeamForPlayer(player, leave);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void leaveTeam(Team team, String leave) {
/* 160 */     if (team != null) {
/* 161 */       if (leave.length() > 16) {
/* 162 */         leave = leave.substring(0, 16);
/*     */       }
/* 164 */       if (team.getEntries().contains(leave)) {
/* 165 */         team.removeEntry(leave);
/* 166 */         unregisterTeamIfEmpty(team);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void leaveTeam(Player player, String teamId, Player leave) {
/* 172 */     Team team = getTeamFromPlayer(player, teamId);
/*     */     
/* 174 */     if (team != null)
/* 175 */       leaveTeam(team, leave.getName()); 
/*     */   }
/*     */   
/*     */   public static void leaveTeam(Team team, Player leave) {
/* 179 */     leaveTeam(team, leave.getName());
/*     */   }
/*     */   
/*     */   public static void leaveTeamToPlayer(Player player, String teamID, String leave) {
/* 183 */     leaveTeam(getTeamFromPlayer(player, teamID), leave);
/*     */   }
/*     */   
/*     */   public static void leaveTeamToPlayer(Player player, String teamID, Player leave) {
/* 187 */     leaveTeamToPlayer(player, teamID, leave.getName());
/*     */   }
/*     */   
/*     */   public static void leaveTeamForPlayers(Collection<? extends Player> players, String teamID, String leave) {
/* 191 */     for (Player player : players) {
/* 192 */       leaveTeamToPlayer(player, teamID, leave);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void leaveTeamForPlayers(Collection<? extends Player> players, String teamID, Player leave) {
/* 197 */     leaveTeamForPlayers(players, teamID, leave.getName());
/*     */   }
/*     */   
/*     */   public static void leaveTeamForOnlinePlayers(String teamID, String leave) {
/* 201 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 202 */       leaveTeamToPlayer(player, teamID, leave);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void leaveTeamForOnlinePlayers(String teamID, Player leave) {
/* 207 */     leaveTeamForOnlinePlayers(teamID, leave.getName());
/*     */   }
/*     */   
/*     */   public static void unregisterTeam(Team team) {
/* 211 */     if (team != null) {
/* 212 */       team.unregister();
/*     */     }
/*     */   }
/*     */   
/*     */   public static void unregisterTeamToPlayer(Player player, String teamID) {
/* 217 */     unregisterTeam(getTeamFromPlayer(player, teamID));
/*     */   }
/*     */   
/*     */   public static void unregisterTeamForPlayers(Collection<? extends Player> players, String teamID) {
/* 221 */     for (Player player : players) {
/* 222 */       unregisterTeamToPlayer(player, teamID);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void unregisterTeamForOnlinePlayers(String teamID) {
/* 227 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 228 */       unregisterTeamToPlayer(player, teamID);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void unregisterTeamIfEmpty(Team team) {
/* 233 */     if (team != null && 
/* 234 */       team.getEntries().size() == 0) {
/* 235 */       unregisterTeam(team);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void unregisterTeamIfEmptyToPlayer(Player player, String teamID) {
/* 241 */     unregisterTeamIfEmpty(getTeamFromPlayer(player, teamID));
/*     */   }
/*     */   
/*     */   public static void unregisterTeamForEmptyForPlayers(Collection<? extends Player> players, String teamID) {
/* 245 */     for (Player player : players) {
/* 246 */       unregisterTeamIfEmptyToPlayer(player, teamID);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void unregisterTeamIfEmptyForOnlinePlayers(String teamID) {
/* 251 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 252 */       unregisterTeamIfEmptyToPlayer(player, teamID);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void setTeamPrefix(Team team, String prefix) {
/* 257 */     if (team != null) {
/* 258 */       if (prefix.length() > 16) {
/* 259 */         prefix = prefix.substring(0, 16);
/*     */       }
/* 261 */       team.setPrefix(prefix);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void setTeamPrefixToPlayer(Player player, String teamID, String prefix) {
/* 266 */     setTeamPrefix(getTeamFromPlayer(player, teamID), prefix);
/*     */   }
/*     */   
/*     */   public static void setTeamPrefixForPlayers(Collection<? extends Player> players, String teamID, String prefix) {
/* 270 */     for (Player player : players) {
/* 271 */       setTeamPrefixToPlayer(player, teamID, prefix);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void setTeamPrefixForOnlinePlayers(String teamID, String prefix) {
/* 276 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 277 */       setTeamPrefixToPlayer(player, teamID, prefix);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void setTeamSuffix(Team team, String suffix) {
/* 282 */     if (team != null) {
/* 283 */       if (suffix.length() > 16) {
/* 284 */         suffix = suffix.substring(0, 16);
/*     */       }
/* 286 */       team.setSuffix(suffix);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void setTeamSuffixToPlayer(Player player, String teamID, String suffix) {
/* 291 */     setTeamSuffix(getTeamFromPlayer(player, teamID), suffix);
/*     */   }
/*     */   
/*     */   public static void setTeamSuffixForPlayers(Collection<? extends Player> players, String teamID, String suffix) {
/* 295 */     for (Player player : players) {
/* 296 */       setTeamSuffixToPlayer(player, teamID, suffix);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void setTeamSuffixForOnlinePlayers(String teamID, String suffix) {
/* 301 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 302 */       setTeamSuffixToPlayer(player, teamID, suffix);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void setTeamPrefixAndSuffix(Team team, String prefix, String suffix) {
/* 307 */     if (team != null) {
/* 308 */       if (prefix.length() > 16) {
/* 309 */         prefix = prefix.substring(0, 16);
/*     */       }
/* 311 */       if (suffix.length() > 16) {
/* 312 */         suffix = suffix.substring(0, 16);
/*     */       }
/* 314 */       team.setPrefix(prefix);
/* 315 */       team.setSuffix(suffix);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void setTeamPrefixAndSuffixToPlayer(Player player, String teamID, String prefix, String suffix) {
/* 320 */     setTeamPrefixAndSuffix(getTeamFromPlayer(player, teamID), prefix, suffix);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setTeamPrefixAndSuffixForPlayers(Collection<? extends Player> players, String teamID, String prefix, String suffix) {
/* 325 */     for (Player player : players) {
/* 326 */       setTeamPrefixAndSuffixToPlayer(player, teamID, prefix, suffix);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void setTeamPrefixAndSuffixForOnlinePlayers(String teamID, String prefix, String suffix) {
/* 331 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 332 */       setTeamPrefixAndSuffixToPlayer(player, teamID, prefix, suffix);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void setTeamDisplayName(Team team, String name) {
/* 337 */     if (team != null) {
/* 338 */       if (name.length() > 16) {
/* 339 */         name = name.substring(0, 16);
/*     */       }
/* 341 */       team.setDisplayName(name);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void setTeamDisplayNameToPlayer(Player player, String teamID, String name) {
/* 346 */     setTeamDisplayName(getTeamFromPlayer(player, teamID), name);
/*     */   }
/*     */   
/*     */   public static void setTeamDisplayNameForPlayers(Collection<? extends Player> players, String teamID, String name) {
/* 350 */     for (Player player : players) {
/* 351 */       setTeamDisplayNameToPlayer(player, teamID, name);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void setTeamDisplayNameForOnlinesPlayers(String teamID, String name) {
/* 356 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 357 */       setTeamDisplayNameToPlayer(player, teamID, name);
/*     */     }
/*     */   }
/*     */   
/*     */   public static Objective getObjectiveFromPlayer(Player player, String objectiveID) {
/* 362 */     if (objectiveID.length() > 16) {
/* 363 */       objectiveID = objectiveID.substring(0, 16);
/*     */     }
/*     */     
/* 366 */     return player.getScoreboard().getObjective(objectiveID);
/*     */   }
/*     */   
/*     */   public static Objective getObjectiveFromPlayer(Player player, DisplaySlot displaySlot) {
/* 370 */     return player.getScoreboard().getObjective(displaySlot);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Objective createObjectiveToPlayer(Player player, String objectiveID, String displayName, DisplaySlot displaySlot) {
/* 375 */     Objective objective = getObjectiveFromPlayer(player, objectiveID);
/*     */     
/* 377 */     if (objective == null) {
/* 378 */       if (objectiveID.length() > 16) {
/* 379 */         objectiveID = objectiveID.substring(0, 16);
/*     */       }
/* 381 */       objective = player.getScoreboard().registerNewObjective(objectiveID, "dummy");
/*     */     } 
/*     */     
/* 384 */     if (displayName.length() > 32) {
/* 385 */       displayName = displayName.substring(0, 32);
/*     */     }
/*     */     
/* 388 */     objective.setDisplayName(displayName);
/* 389 */     objective.setDisplaySlot(displaySlot);
/* 390 */     return objective;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void createObjectiveForPlayers(Collection<? extends Player> players, String objectiveID, String displayName, DisplaySlot displaySlot) {
/* 395 */     for (Player player : players) {
/* 396 */       createObjectiveToPlayer(player, objectiveID, displayName, displaySlot);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void createObjectiveForOnlinePlayers(String objectiveID, String displayName, DisplaySlot displaySlot) {
/* 402 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 403 */       createObjectiveToPlayer(player, objectiveID, displayName, displaySlot);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static Objective createObjectiveIfNotExistsToPlayer(Player player, String objectiveID, String displayName, DisplaySlot displaySlot) {
/* 409 */     Objective objective = getObjectiveFromPlayer(player, objectiveID);
/*     */     
/* 411 */     if (objective == null) {
/* 412 */       objective = createObjectiveToPlayer(player, objectiveID, displayName, displaySlot);
/* 413 */       objective.setDisplaySlot(displaySlot);
/*     */     } 
/*     */     
/* 416 */     return objective;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void createObjectiveIfNotExistsToPlayer(Collection<? extends Player> players, String objectiveID, String displayName, DisplaySlot displaySlot) {
/* 421 */     for (Player player : players) {
/* 422 */       createObjectiveIfNotExistsToPlayer(player, objectiveID, displayName, displaySlot);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void createObjectiveIfNotExistsForOnlinePlayers(String objectiveID, String displayName, DisplaySlot displaySlot) {
/* 428 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 429 */       createObjectiveIfNotExistsToPlayer(player, objectiveID, displayName, displaySlot);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void setObjectiveDisplayName(Objective objective, String name) {
/* 434 */     if (objective != null) {
/* 435 */       if (name.length() > 32) {
/* 436 */         name = name.substring(0, 32);
/*     */       }
/* 438 */       objective.setDisplayName(name);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void setObjectiveDisplayNameToPlayer(Player player, String objectiveID, String name) {
/* 443 */     setObjectiveDisplayName(getObjectiveFromPlayer(player, objectiveID), name);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setObjectiveDisplayNameForPlayers(Collection<? extends Player> players, String objectiveID, String name) {
/* 448 */     for (Player player : players) {
/* 449 */       setObjectiveDisplayNameToPlayer(player, objectiveID, name);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void setObjectiveDisplayNameForOnlinePlayers(String objectiveID, String name) {
/* 454 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 455 */       setObjectiveDisplayNameToPlayer(player, objectiveID, name);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void setObjectiveDisplaySlot(Objective objective, DisplaySlot displaySlot) {
/* 460 */     if (objective != null) {
/* 461 */       objective.setDisplaySlot(displaySlot);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void setObjectiveDisplaySlotToPlayer(Player player, String objectiveID, DisplaySlot displaySlot) {
/* 466 */     setObjectiveDisplaySlot(getObjectiveFromPlayer(player, objectiveID), displaySlot);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setObjectiveDisplaySlotForPlayers(Collection<? extends Player> players, String objectiveID, DisplaySlot displaySlot) {
/* 471 */     for (Player player : players) {
/* 472 */       setObjectiveDisplaySlotToPlayer(player, objectiveID, displaySlot);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void setObjectiveDisplaySlotForOnlinePlayers(String objectiveID, DisplaySlot displaySlot) {
/* 477 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 478 */       setObjectiveDisplaySlotToPlayer(player, objectiveID, displaySlot);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void setScoreOnObjective(Objective objective, String scoreName, int scoreValue) {
/* 483 */     if (scoreName.length() > 16) {
/* 484 */       scoreName = scoreName.substring(0, 16);
/*     */     }
/* 486 */     if (objective != null) {
/* 487 */       objective.getScore(scoreName).setScore(scoreValue);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setScoreOnObjectiveToPlayer(Player player, String objectiveID, String scoreName, int scoreValue) {
/* 493 */     setScoreOnObjective(getObjectiveFromPlayer(player, objectiveID), scoreName, scoreValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setScoreOnObjectiveToPlayer(Player player, DisplaySlot objectiveSlot, String scoreName, int scoreValue) {
/* 498 */     setScoreOnObjective(getObjectiveFromPlayer(player, objectiveSlot), scoreName, scoreValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setScoreOnObjectiveForPlayers(Collection<? extends Player> players, String objectiveID, String scoreName, int scoreValue) {
/* 503 */     for (Player player : players) {
/* 504 */       setScoreOnObjective(getObjectiveFromPlayer(player, objectiveID), scoreName, scoreValue);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setScoreOnObjectiveForPlayers(Collection<? extends Player> players, DisplaySlot objectiveSlot, String scoreName, int scoreValue) {
/* 510 */     for (Player player : players) {
/* 511 */       setScoreOnObjective(getObjectiveFromPlayer(player, objectiveSlot), scoreName, scoreValue);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void setScoreOnObjectiveForOnlinePlayers(String objectiveID, String scoreName, int scoreValue) {
/* 516 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 517 */       setScoreOnObjective(getObjectiveFromPlayer(player, objectiveID), scoreName, scoreValue);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setScoreOnObjectiveForOnlinePlayers(DisplaySlot objectiveSlot, String scoreName, int scoreValue) {
/* 523 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 524 */       setScoreOnObjective(getObjectiveFromPlayer(player, objectiveSlot), scoreName, scoreValue);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void addScoreOnObjectiveToPlayer(Player player, Objective objective, String scoreID, int score, String name, String prefix, String suffix) {
/* 530 */     if (objective != null) {
/* 531 */       Team team = createTeamIfNotExistsToPlayer(player, objective.getName() + scoreID, prefix, suffix);
/* 532 */       if (team != null) {
/* 533 */         if (name.length() > 16) {
/* 534 */           name = name.substring(0, 16);
/*     */         }
/* 536 */         setScoreOnObjective(objective, name, score);
/* 537 */         joinTeam(team, name);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void addScoreOnObjectiveToPlayer(Player player, String objectiveID, String scoreID, int score, String name, String prefix, String suffix) {
/* 544 */     addScoreOnObjectiveToPlayer(player, getObjectiveFromPlayer(player, objectiveID), scoreID, score, name, prefix, suffix);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addScoreOnObjectiveToPlayer(Player player, DisplaySlot objectiveSlot, String scoreID, int score, String name, String prefix, String suffix) {
/* 550 */     addScoreOnObjectiveToPlayer(player, getObjectiveFromPlayer(player, objectiveSlot), scoreID, score, name, prefix, suffix);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addScoreOnObjectiveForPlayers(Collection<? extends Player> players, String objectiveID, String scoreID, int score, String name, String prefix, String suffix) {
/* 556 */     for (Player player : players) {
/* 557 */       addScoreOnObjectiveToPlayer(player, objectiveID, scoreID, score, name, prefix, suffix);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void addScoreOnObjectiveForPlayers(Collection<? extends Player> players, DisplaySlot objectiveSlot, String scoreID, int score, String name, String prefix, String suffix) {
/* 563 */     for (Player player : players) {
/* 564 */       addScoreOnObjectiveToPlayer(player, objectiveSlot, scoreID, score, name, prefix, suffix);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void addScoreOnObjectiveForOnlinePlayers(String objectiveID, String scoreID, int score, String name, String prefix, String suffix) {
/* 570 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 571 */       addScoreOnObjectiveToPlayer(player, getObjectiveFromPlayer(player, objectiveID), scoreID, score, name, prefix, suffix);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addScoreOnObjectiveForOnlinePlayers(DisplaySlot objectiveSlot, String scoreID, int score, String name, String prefix, String suffix) {
/* 578 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 579 */       addScoreOnObjectiveToPlayer(player, objectiveSlot, scoreID, score, name, prefix, suffix);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void updateScoreNameOnObjectiveToPlayer(Player player, Objective objective, String name) {
/* 584 */     if (objective != null) {
/* 585 */       Team team = getTeamFromPlayer(player, objective.getName());
/* 586 */       if (team != null) {
/* 587 */         setTeamPrefix(team, name);
/* 588 */         team = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void updateScoreNameOnObjectiveToPlayer(Player player, String objectiveID, String name) {
/* 594 */     updateScoreNameOnObjectiveToPlayer(player, getObjectiveFromPlayer(player, objectiveID), name);
/*     */   }
/*     */   
/*     */   public static void updateScoreNameOnObjectiveToPlayer(Player player, DisplaySlot objectiveSlot, String name) {
/* 598 */     updateScoreNameOnObjectiveToPlayer(player, getObjectiveFromPlayer(player, objectiveSlot), name);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void updateScoreNameOnObjectiveForPlayers(Collection<? extends Player> players, String objectiveID, String name) {
/* 603 */     for (Player player : players) {
/* 604 */       updateScoreNameOnObjectiveToPlayer(player, objectiveID, name);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void updateScoreNameOnObjectiveForPlayers(Collection<? extends Player> players, DisplaySlot objectiveSlot, String name) {
/* 610 */     for (Player player : players) {
/* 611 */       updateScoreNameOnObjectiveToPlayer(player, objectiveSlot, name);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void updateScoreNameOnObjectiveForOnlinePlayers(String objectiveID, String name) {
/* 616 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 617 */       updateScoreNameOnObjectiveToPlayer(player, objectiveID, name);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void updateScoreNameOnObjectiveForOnlinePlayers(DisplaySlot objectiveSlot, String name) {
/* 622 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 623 */       updateScoreNameOnObjectiveToPlayer(player, getObjectiveFromPlayer(player, objectiveSlot), name);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void updateScoreValueOnObjectiveToPlayer(Player player, Objective objective, String scoreID, String value) {
/* 629 */     if (objective != null) {
/* 630 */       Team team = getTeamFromPlayer(player, objective.getName());
/* 631 */       if (team != null) {
/* 632 */         setTeamSuffix(team, value);
/* 633 */         team = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void updateScoreValueOnObjectiveToPlayer(Player player, String objectiveID, String scoreID, String value) {
/* 640 */     updateScoreValueOnObjectiveToPlayer(player, getObjectiveFromPlayer(player, objectiveID), scoreID, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void updateScoreValueOnObjectiveToPlayer(Player player, DisplaySlot objectiveSlot, String scoreID, String value) {
/* 645 */     updateScoreValueOnObjectiveToPlayer(player, getObjectiveFromPlayer(player, objectiveSlot), scoreID, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void updateScoreValueOnObjectiveForPlayers(Collection<? extends Player> players, String objectiveID, String scoreID, String value) {
/* 650 */     for (Player player : players) {
/* 651 */       updateScoreValueOnObjectiveToPlayer(player, objectiveID, scoreID, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void updateScoreValueOnObjectiveForPlayers(Collection<? extends Player> players, DisplaySlot objectiveSlot, String scoreID, String value) {
/* 657 */     for (Player player : players) {
/* 658 */       updateScoreValueOnObjectiveToPlayer(player, objectiveSlot, scoreID, value);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void updateScoreValueOnObjectiveForOnlinePlayers(String objectiveID, String scoreID, String value) {
/* 663 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 664 */       updateScoreValueOnObjectiveToPlayer(player, objectiveID, scoreID, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void updateScoreValueOnObjectiveForOnlinePlayers(DisplaySlot objectiveSlot, String scoreID, String value) {
/* 670 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 671 */       updateScoreValueOnObjectiveToPlayer(player, objectiveSlot, scoreID, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void updateScoreNameAndValueOnObjectiveToPlayer(Player player, Objective objective, String scoreID, String name, String value) {
/* 677 */     if (objective != null) {
/* 678 */       Team team = getTeamFromPlayer(player, objective.getName());
/* 679 */       if (team != null) {
/* 680 */         setTeamPrefix(team, name);
/* 681 */         setTeamSuffix(team, value);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void updateScoreNameAndValueOnObjectiveToPlayer(Player player, String objectiveID, String scoreID, String name, String value) {
/* 688 */     updateScoreNameAndValueOnObjectiveToPlayer(player, getObjectiveFromPlayer(player, objectiveID), scoreID, name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void updateScoreNameAndValueOnObjectiveToPlayer(Player player, DisplaySlot objectiveSlot, String scoreID, String name, String value) {
/* 694 */     updateScoreNameAndValueOnObjectiveToPlayer(player, getObjectiveFromPlayer(player, objectiveSlot), scoreID, name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void updateScoreNameAndValueOnObjectiveForPlayers(Collection<? extends Player> players, String objectiveID, String scoreID, String name, String value) {
/* 700 */     for (Player player : players) {
/* 701 */       updateScoreNameAndValueOnObjectiveToPlayer(player, objectiveID, scoreID, name, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void updateScoreNameAndValueOnObjectiveForPlayers(Collection<? extends Player> players, DisplaySlot objectiveSlot, String scoreID, String name, String value) {
/* 707 */     for (Player player : players) {
/* 708 */       updateScoreNameAndValueOnObjectiveToPlayer(player, objectiveSlot, scoreID, name, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void updateScoreNameAndValueOnObjectiveForOnlinePlayers(String objectiveID, String scoreID, String name, String value) {
/* 714 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 715 */       updateScoreNameAndValueOnObjectiveToPlayer(player, objectiveID, scoreID, name, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void updateScoreNameAndValueOnObjectiveForOnlinePlayers(DisplaySlot objectiveSlot, String scoreID, String name, String value) {
/* 721 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 722 */       updateScoreNameAndValueOnObjectiveToPlayer(player, objectiveSlot, scoreID, name, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void updateScoreOnObjectiveToPlayer(Player player, Objective objective, String scoreID, String name, String value) {
/* 728 */     if (objective != null) {
/* 729 */       Team team = getTeamFromPlayer(player, objective.getName() + scoreID);
/* 730 */       if (team != null) {
/* 731 */         setTeamPrefix(team, name);
/* 732 */         setTeamSuffix(team, value);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void updateScoreOnObjectiveToPlayer(Player player, String objectiveID, String scoreID, String name, String value) {
/* 739 */     updateScoreOnObjectiveToPlayer(player, getObjectiveFromPlayer(player, objectiveID), scoreID, name, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void updateScoreOnObjectiveToPlayer(Player player, DisplaySlot objectiveSlot, String scoreID, String name, String value) {
/* 744 */     updateScoreOnObjectiveToPlayer(player, getObjectiveFromPlayer(player, objectiveSlot), scoreID, name, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void updateScoreOnObjectiveForPlayers(Collection<? extends Player> players, String objectiveID, String scoreID, String name, String value) {
/* 749 */     for (Player player : players) {
/* 750 */       updateScoreOnObjectiveToPlayer(player, objectiveID, scoreID, name, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void updateScoreOnObjectiveForPlayers(Collection<? extends Player> players, DisplaySlot objectiveSlot, String scoreID, String name, String value) {
/* 756 */     for (Player player : players) {
/* 757 */       updateScoreOnObjectiveToPlayer(player, objectiveSlot, scoreID, name, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void updateScoreOnObjectiveForOnlinePlayers(String objectiveID, String scoreID, String name, String value) {
/* 763 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 764 */       updateScoreOnObjectiveToPlayer(player, objectiveID, scoreID, name, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void updateScoreOnObjectiveForOnlinePlayers(DisplaySlot objectiveSlot, String scoreID, String name, String value) {
/* 770 */     for (Player player : Bukkit.getOnlinePlayers())
/* 771 */       updateScoreOnObjectiveToPlayer(player, objectiveSlot, scoreID, name, value); 
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/scoreboard/ScoreboardAPI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */