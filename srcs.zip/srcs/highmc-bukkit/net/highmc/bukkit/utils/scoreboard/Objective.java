/*    */ package net.highmc.bukkit.utils.scoreboard;
/*    */ 
/*    */ import com.google.common.base.Preconditions;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.scoreboard.DisplaySlot;
/*    */ import org.bukkit.scoreboard.Scoreboard;
/*    */ import org.bukkit.scoreboard.Team;
/*    */ 
/*    */ 
/*    */ public abstract class Objective
/*    */ {
/*    */   private org.bukkit.scoreboard.Objective objective;
/*    */   private final Scoreboard scoreboard;
/*    */   
/*    */   public Objective(Scoreboard scoreboard, DisplaySlot slot) {
/* 16 */     this.scoreboard = scoreboard;
/*    */     
/* 18 */     this.objective = scoreboard.getObjective(slot.name().toLowerCase());
/*    */     
/* 20 */     if (this.objective == null) {
/* 21 */       this.objective = scoreboard.registerNewObjective(slot.name().toLowerCase(), "dummy");
/*    */     } else {
/* 23 */       scoreboard.clearSlot(slot);
/*    */       
/* 25 */       for (int index = 15; index > 0; index--) {
/* 26 */         Team team = getScoreboard().getTeam("score-" + index);
/*    */         
/* 28 */         if (team != null) {
/* 29 */           String score = ChatColor.values()[index - 1].toString();
/*    */           
/* 31 */           if (!team.hasEntry(score)) {
/* 32 */             team.addEntry(score);
/*    */           }
/* 34 */           team.unregister();
/* 35 */           getScoreboard().resetScores(score);
/*    */         } 
/*    */       } 
/*    */     } 
/*    */     
/* 40 */     this.objective.setDisplaySlot(slot);
/*    */   }
/*    */   
/*    */   public Scoreboard getScoreboard() {
/* 44 */     return this.scoreboard;
/*    */   }
/*    */   
/*    */   public org.bukkit.scoreboard.Objective getObjective() {
/* 48 */     return this.objective;
/*    */   }
/*    */   
/*    */   public void setDisplayName(String name) {
/* 52 */     Preconditions.checkArgument((name != null), "Parameter 'name' cannot be null");
/* 53 */     this.objective.setDisplayName((name.length() >= 32) ? name.substring(0, 32) : name);
/*    */   }
/*    */   
/*    */   public final void destroy() {
/* 57 */     this.objective.unregister();
/* 58 */     this.objective = null;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/scoreboard/Objective.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */