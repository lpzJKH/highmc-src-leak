/*    */ package net.highmc.bukkit.utils.scoreboard;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class ScoreHelper
/*    */ {
/* 12 */   private static ScoreHelper scoreHelper = new ScoreHelper();
/*    */   
/* 14 */   private Map<UUID, Scoreboard> scoreMap = new HashMap<>();
/*    */   
/*    */   public void setScoreboard(Player player, Scoreboard scoreboard) {
/* 17 */     player.setScoreboard(scoreboard.getScoreboard());
/* 18 */     this.scoreMap.put(player.getUniqueId(), scoreboard);
/*    */   }
/*    */   
/*    */   public void setScoreboardName(Player player, String name) {
/* 22 */     if (this.scoreMap.containsKey(player.getUniqueId()))
/* 23 */       ((Scoreboard)this.scoreMap.get(player.getUniqueId())).setDisplayName(name); 
/*    */   }
/*    */   
/*    */   public void removeScoreboard(int index) {
/* 27 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 28 */       if (this.scoreMap.containsKey(player.getUniqueId()))
/* 29 */         ((Scoreboard)this.scoreMap.get(player.getUniqueId())).remove(index); 
/*    */     } 
/*    */   }
/*    */   public void removeScoreboard(Player player) {
/* 33 */     this.scoreMap.remove(player.getUniqueId());
/*    */   }
/*    */   
/*    */   public void removeScoreboard(Player player, int index) {
/* 37 */     if (this.scoreMap.containsKey(player.getUniqueId()))
/* 38 */       ((Scoreboard)this.scoreMap.get(player.getUniqueId())).remove(index); 
/*    */   }
/*    */   
/*    */   public void addScoreboard(Player player, int index, String value) {
/* 42 */     if (this.scoreMap.containsKey(player.getUniqueId()))
/* 43 */       ((Scoreboard)this.scoreMap.get(player.getUniqueId())).add(index, value); 
/*    */   }
/*    */   
/*    */   public void updateScoreboard(int index, String value) {
/* 47 */     for (Player player : Bukkit.getOnlinePlayers())
/* 48 */       addScoreboard(player, index, value); 
/*    */   }
/*    */   
/*    */   public void updateScoreboard(Player player, int index, String value) {
/* 52 */     addScoreboard(player, index, value);
/*    */   }
/*    */   
/*    */   public static ScoreHelper getInstance() {
/* 56 */     return scoreHelper;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/scoreboard/ScoreHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */