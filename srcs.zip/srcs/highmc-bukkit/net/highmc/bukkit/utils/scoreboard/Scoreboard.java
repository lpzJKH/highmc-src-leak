/*     */ package net.highmc.bukkit.utils.scoreboard;
/*     */ 
/*     */ import net.highmc.bukkit.utils.player.PlayerHelper;
/*     */ import net.highmc.member.Member;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.scoreboard.DisplaySlot;
/*     */ import org.bukkit.scoreboard.Team;
/*     */ 
/*     */ public class Scoreboard extends Objective {
/*     */   private Player player;
/*     */   
/*     */   public Player getPlayer() {
/*  14 */     return this.player;
/*     */   }
/*  16 */   private int index = 15;
/*     */   
/*     */   public Scoreboard(Player player, String title) {
/*  19 */     super(player.getScoreboard(), DisplaySlot.SIDEBAR);
/*  20 */     this.player = player;
/*  21 */     setDisplayName(title);
/*     */   }
/*     */   
/*     */   public void add(String text) {
/*  25 */     add(this.index--, text);
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/*  29 */     String text = "§f§lB §fBranco §c✖";
/*  30 */     String prefix = "", suffix = "";
/*     */     
/*  32 */     if (text.length() <= 16) {
/*  33 */       prefix = text;
/*  34 */       for (int i = prefix.length(); i > 0 && 
/*  35 */         prefix.substring(0, i).endsWith("§"); i--) {
/*  36 */         prefix = prefix.substring(0, i - 1);
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/*  41 */       prefix = text.substring(0, 16);
/*     */       
/*  43 */       for (int i = prefix.length(); i > 0 && 
/*  44 */         prefix.substring(0, i).endsWith("§"); i--) {
/*  45 */         prefix = prefix.substring(0, i - 1);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*  50 */       String color = ChatColor.getLastColors(prefix);
/*     */       
/*  52 */       if (color.startsWith("§f")) {
/*  53 */         color = color.substring(2);
/*     */       }
/*  55 */       suffix = color + text.substring(16);
/*     */       
/*  57 */       if (!suffix.startsWith("§")) {
/*  58 */         ChatColor byChar = ChatColor.getByChar(suffix.charAt(0));
/*     */         
/*  60 */         if (byChar != null) {
/*  61 */           suffix = byChar + suffix.substring(1);
/*     */         }
/*     */       } 
/*     */       
/*  65 */       if (suffix.length() > 16) {
/*  66 */         suffix = suffix.substring(0, 16);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void add(int index, String text) {
/*  72 */     text = PlayerHelper.translate(Member.getLanguage(this.player.getUniqueId()), text);
/*  73 */     Team team = getScoreboard().getTeam("score-" + index);
/*  74 */     String prefix = "", suffix = "";
/*     */     
/*  76 */     if (team == null) {
/*  77 */       team = getScoreboard().registerNewTeam("score-" + index);
/*  78 */       String score = ChatColor.values()[index - 1].toString();
/*  79 */       getObjective().getScore(score).setScore(index);
/*     */       
/*  81 */       if (!team.hasEntry(score)) {
/*  82 */         team.addEntry(score);
/*     */       }
/*     */     } 
/*     */     
/*  86 */     if (text.length() <= 16) {
/*  87 */       prefix = text;
/*  88 */       for (int i = prefix.length(); i > 0 && 
/*  89 */         prefix.substring(0, i).endsWith("§"); i--) {
/*  90 */         prefix = prefix.substring(0, i - 1);
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/*  95 */       prefix = text.substring(0, 16);
/*     */       
/*  97 */       for (int i = prefix.length(); i > 0 && 
/*  98 */         prefix.substring(0, i).endsWith("§"); i--) {
/*  99 */         prefix = prefix.substring(0, i - 1);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 104 */       String color = ChatColor.getLastColors(prefix);
/*     */       
/* 106 */       if (color.startsWith("§f")) {
/* 107 */         color = color.substring(2);
/*     */       }
/* 109 */       suffix = color + text.substring(16);
/*     */       
/* 111 */       if (!suffix.startsWith("§")) {
/* 112 */         ChatColor byChar = ChatColor.getByChar(suffix.charAt(0));
/*     */         
/* 114 */         if (byChar != null) {
/* 115 */           suffix = byChar + suffix.substring(1);
/*     */         }
/*     */       } 
/*     */       
/* 119 */       if (suffix.length() > 16) {
/* 120 */         suffix = suffix.substring(0, 16);
/*     */       }
/*     */     } 
/* 123 */     team.setPrefix(prefix);
/* 124 */     team.setSuffix(suffix);
/*     */   }
/*     */   
/*     */   public void remove(int index) {
/* 128 */     Team team = getScoreboard().getTeam("score-" + index);
/*     */     
/* 130 */     if (team != null) {
/* 131 */       String score = ChatColor.values()[index - 1].toString();
/*     */       
/* 133 */       if (!team.hasEntry(score)) {
/* 134 */         team.addEntry(score);
/*     */       }
/* 136 */       team.unregister();
/* 137 */       getScoreboard().resetScores(score);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/scoreboard/Scoreboard.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */