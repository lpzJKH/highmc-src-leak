package net.highmc.bukkit.utils.menu;

import org.bukkit.entity.Player;

public interface MenuCloseHandler {
  void onClose(Player paramPlayer);
}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/menu/MenuCloseHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */