package net.highmc.bukkit.utils.menu;

import org.bukkit.entity.Player;

public interface MenuUpdateHandler {
  void onUpdate(Player paramPlayer, MenuInventory paramMenuInventory);
}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/menu/MenuUpdateHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */