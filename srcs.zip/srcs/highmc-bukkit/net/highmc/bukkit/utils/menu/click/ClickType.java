/*   */ package net.highmc.bukkit.utils.menu.click;
/*   */ 
/*   */ public enum ClickType {
/* 4 */   LEFT, RIGHT, SHIFT;
/*   */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/menu/click/ClickType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */