package net.highmc.bukkit.utils.menu.click;

import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public interface MenuClickHandler {
  void onClick(Player paramPlayer, Inventory paramInventory, ClickType paramClickType, ItemStack paramItemStack, int paramInt);
}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/menu/click/MenuClickHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */