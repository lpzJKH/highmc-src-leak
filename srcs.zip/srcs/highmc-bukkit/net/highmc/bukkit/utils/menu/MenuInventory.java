/*     */ package net.highmc.bukkit.utils.menu;
/*     */ 
/*     */ import com.comphenix.protocol.PacketType;
/*     */ import com.comphenix.protocol.ProtocolLibrary;
/*     */ import com.comphenix.protocol.events.PacketContainer;
/*     */ import com.comphenix.protocol.utility.MinecraftReflection;
/*     */ import com.comphenix.protocol.wrappers.WrappedChatComponent;
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import net.highmc.bukkit.event.player.PlayerOpenInventoryEvent;
/*     */ import net.highmc.bukkit.utils.menu.click.MenuClickHandler;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.event.inventory.InventoryType;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MenuInventory
/*     */ {
/*     */   private int rows;
/*     */   
/*     */   public int getRows() {
/*  32 */     return this.rows;
/*  33 */   } private InventoryType inventoryType = InventoryType.CHEST; private String title; private Inventory inventory; private boolean onePerPlayer; public InventoryType getInventoryType() { return this.inventoryType; }
/*     */    private Map<Integer, MenuItem> slotItem; private MenuUpdateHandler updateHandler; private MenuCloseHandler closeHandler; public String getTitle() {
/*  35 */     return this.title; }
/*  36 */   public Inventory getInventory() { return this.inventory; } public boolean isOnePerPlayer() {
/*  37 */     return this.onePerPlayer;
/*     */   } public Map<Integer, MenuItem> getSlotItem() {
/*  39 */     return this.slotItem;
/*     */   }
/*  41 */   public void setUpdateHandler(MenuUpdateHandler updateHandler) { this.updateHandler = updateHandler; }
/*  42 */   public MenuUpdateHandler getUpdateHandler() { return this.updateHandler; }
/*  43 */   public void setCloseHandler(MenuCloseHandler closeHandler) { this.closeHandler = closeHandler; } public MenuCloseHandler getCloseHandler() {
/*  44 */     return this.closeHandler;
/*     */   } private boolean reopenInventory = false;
/*  46 */   public boolean isReopenInventory() { return this.reopenInventory; } public void setReopenInventory(boolean reopenInventory) {
/*  47 */     this.reopenInventory = reopenInventory;
/*     */   }
/*     */   
/*  50 */   private static Map<String, Long> openDelay = new HashMap<>();
/*     */   
/*     */   public MenuInventory(String title, int rows) {
/*  53 */     this(title, rows, InventoryType.CHEST, false);
/*     */   }
/*     */   
/*     */   public MenuInventory(String title, InventoryType inventoryType) {
/*  57 */     this(title, 3, inventoryType, false);
/*     */   }
/*     */   
/*     */   public MenuInventory(String title, int rows, InventoryType inventoryType, boolean onePerPlayer) {
/*  61 */     this.rows = rows;
/*  62 */     this.inventoryType = inventoryType;
/*  63 */     this.slotItem = new HashMap<>();
/*  64 */     this.title = title;
/*  65 */     this.onePerPlayer = onePerPlayer;
/*     */     
/*  67 */     if (!onePerPlayer) {
/*  68 */       this.inventory = Bukkit.createInventory(new MenuHolder(this), rows * 9, "");
/*     */     }
/*     */   }
/*     */   
/*     */   public void addItem(MenuItem item) {
/*  73 */     setItem(firstEmpty(), item);
/*     */   }
/*     */   
/*     */   public void addItem(ItemStack item) {
/*  77 */     setItem(firstEmpty(), item);
/*     */   }
/*     */   
/*     */   public void addItem(ItemStack item, MenuClickHandler handler) {
/*  81 */     setItem(firstEmpty(), item, handler);
/*     */   }
/*     */   
/*     */   public void setItem(ItemStack item, int slot) {
/*  85 */     setItem(slot, new MenuItem(item));
/*     */   }
/*     */   
/*     */   public void setItem(int slot, ItemStack item) {
/*  89 */     setItem(slot, new MenuItem(item));
/*     */   }
/*     */   
/*     */   public void setItem(int slot, ItemStack item, MenuClickHandler handler) {
/*  93 */     setItem(slot, new MenuItem(item, handler));
/*     */   }
/*     */   
/*     */   public void setItem(MenuItem item, int slot) {
/*  97 */     setItem(slot, item);
/*     */   }
/*     */   
/*     */   public void removeItem(int slot) {
/* 101 */     this.slotItem.remove(Integer.valueOf(slot));
/*     */     
/* 103 */     if (!this.onePerPlayer) {
/* 104 */       this.inventory.setItem(slot, new ItemStack(Material.AIR));
/*     */     }
/*     */   }
/*     */   
/*     */   public void setItem(int slot, MenuItem item) {
/* 109 */     this.slotItem.put(Integer.valueOf(slot), item);
/*     */     
/* 111 */     if (!this.onePerPlayer) {
/* 112 */       this.inventory.setItem(slot, item.getStack());
/*     */     }
/*     */   }
/*     */   
/*     */   public void setRows(int rows) {
/* 117 */     this.rows = rows;
/*     */     
/* 119 */     if (!this.onePerPlayer) {
/* 120 */       ImmutableList immutableList = ImmutableList.copyOf(this.slotItem.entrySet());
/*     */       
/* 122 */       this.inventory = Bukkit.createInventory(new MenuHolder(this), rows * 9, "");
/* 123 */       this.slotItem.clear();
/* 124 */       for (Map.Entry<Integer, MenuItem> item : (Iterable<Map.Entry<Integer, MenuItem>>)immutableList)
/* 125 */         setItem(((Integer)item.getKey()).intValue(), item.getValue()); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public int firstEmpty() {
/* 130 */     if (!this.onePerPlayer) {
/* 131 */       return this.inventory.firstEmpty();
/*     */     }
/* 133 */     for (int i = 0; i < this.rows * 9; i++) {
/* 134 */       if (!this.slotItem.containsKey(Integer.valueOf(i))) {
/* 135 */         return i;
/*     */       }
/*     */     } 
/* 138 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasItem(int slot) {
/* 143 */     return this.slotItem.containsKey(Integer.valueOf(slot));
/*     */   }
/*     */   
/*     */   public MenuItem getItem(int slot) {
/* 147 */     return this.slotItem.get(Integer.valueOf(slot));
/*     */   }
/*     */   
/*     */   public void clear() {
/* 151 */     this.slotItem.clear();
/* 152 */     if (!this.onePerPlayer) {
/* 153 */       this.inventory.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public void open(Player p) {
/* 158 */     if (isCooldown(p.getName())) {
/*     */       return;
/*     */     }
/* 161 */     if (this.onePerPlayer) {
/* 162 */       if (p.getOpenInventory() == null || p
/* 163 */         .getOpenInventory().getTopInventory().getType() != this.inventoryType || p
/* 164 */         .getOpenInventory().getTopInventory().getSize() != this.rows * 9 || p
/* 165 */         .getOpenInventory().getTopInventory().getHolder() == null || 
/* 166 */         !(p.getOpenInventory().getTopInventory().getHolder() instanceof MenuHolder) || 
/* 167 */         !((MenuHolder)p.getOpenInventory().getTopInventory().getHolder()).isOnePerPlayer()) {
/* 168 */         createAndOpenInventory(p);
/*     */       } else {
/* 170 */         Inventory topInventory = p.getOpenInventory().getTopInventory();
/*     */         
/* 172 */         for (int i = 0; i < this.rows * 9; i++) {
/* 173 */           if (this.slotItem.containsKey(Integer.valueOf(i)))
/* 174 */           { ItemStack oldItem = topInventory.getItem(i);
/* 175 */             ItemStack newItem = ((MenuItem)this.slotItem.get(Integer.valueOf(i))).getStack();
/*     */             
/* 177 */             if (oldItem == null || newItem == null) {
/* 178 */               topInventory.setItem(i, newItem);
/*     */ 
/*     */             
/*     */             }
/* 182 */             else if (oldItem.getType() != newItem.getType() || oldItem
/* 183 */               .getDurability() != newItem.getDurability() || oldItem
/* 184 */               .getAmount() != newItem.getAmount()) {
/* 185 */               topInventory.setItem(i, newItem);
/*     */             }  }
/* 187 */           else { topInventory.setItem(i, null); }
/*     */         
/*     */         } 
/* 190 */         if (!topInventory.getName().equals(getTitle())) {
/* 191 */           updateTitle(p);
/*     */         }
/*     */       } 
/* 194 */       Bukkit.getPluginManager()
/* 195 */         .callEvent((Event)new PlayerOpenInventoryEvent(p, p.getOpenInventory().getTopInventory()));
/* 196 */       ((MenuHolder)p.getOpenInventory().getTopInventory().getHolder()).setMenu(this);
/*     */     } else {
/* 198 */       p.openInventory(this.inventory);
/* 199 */       updateTitle(p);
/* 200 */       Bukkit.getPluginManager().callEvent((Event)new PlayerOpenInventoryEvent(p, this.inventory));
/*     */     } 
/*     */     
/* 203 */     setCooldown(p.getName());
/*     */   }
/*     */   
/*     */   public void updateSlot(Player player, int slot) {
/* 207 */     if (this.slotItem.containsKey(Integer.valueOf(slot))) {
/* 208 */       player.getOpenInventory().getTopInventory().setItem(slot, ((MenuItem)this.slotItem.get(Integer.valueOf(slot))).getStack());
/*     */     } else {
/* 210 */       player.getOpenInventory().getTopInventory().setItem(slot, null);
/*     */     } 
/*     */   }
/*     */   public void setTitle(String title) {
/* 214 */     this.title = title;
/*     */   }
/*     */   
/*     */   public void updateTitle(Player p) {
/*     */     try {
/* 219 */       PacketContainer packet = new PacketContainer(PacketType.Play.Server.OPEN_WINDOW);
/* 220 */       packet.getChatComponents().write(0, WrappedChatComponent.fromText(this.title));
/* 221 */       Method getHandle = MinecraftReflection.getCraftPlayerClass().getMethod("getHandle", new Class[0]);
/* 222 */       Object entityPlayer = getHandle.invoke(p, new Object[0]);
/* 223 */       Field activeContainerField = entityPlayer.getClass().getField("activeContainer");
/* 224 */       Object activeContainer = activeContainerField.get(entityPlayer);
/* 225 */       Field windowIdField = activeContainer.getClass().getField("windowId");
/* 226 */       int id = windowIdField.getInt(activeContainer);
/* 227 */       packet.getStrings().write(0, "minecraft:" + this.inventoryType.name().toLowerCase());
/* 228 */       packet.getIntegers().write(0, Integer.valueOf(id));
/* 229 */       packet.getIntegers().write(1, Integer.valueOf(this.rows * 9));
/*     */       
/* 231 */       ProtocolLibrary.getProtocolManager().sendServerPacket(p, packet);
/* 232 */       p.updateInventory();
/* 233 */     } catch (Exception e) {
/* 234 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void createAndOpenInventory(Player p) {
/* 241 */     Inventory playerInventory = (this.inventoryType == InventoryType.CHEST) ? Bukkit.createInventory(new MenuHolder(this), this.rows * 9, this.title) : Bukkit.createInventory(new MenuHolder(this), this.inventoryType, this.title);
/*     */     
/* 243 */     for (Map.Entry<Integer, MenuItem> entry : this.slotItem.entrySet()) {
/* 244 */       playerInventory.setItem(((Integer)entry.getKey()).intValue(), ((MenuItem)entry.getValue()).getStack());
/*     */     }
/*     */     
/* 247 */     p.openInventory(playerInventory);
/*     */   }
/*     */   
/*     */   public void close(Player p) {
/* 251 */     if (this.onePerPlayer) {
/* 252 */       destroy(p);
/* 253 */       p = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void onClose(Player player) {
/* 258 */     if (this.closeHandler != null)
/* 259 */       this.closeHandler.onClose(player); 
/*     */   }
/*     */   
/*     */   public void destroy(Player p) {
/* 263 */     if (p.getOpenInventory().getTopInventory().getHolder() != null && p
/* 264 */       .getOpenInventory().getTopInventory().getHolder() instanceof MenuHolder) {
/* 265 */       ((MenuHolder)p.getOpenInventory().getTopInventory().getHolder()).destroy();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isCooldown(String playerName) {
/* 270 */     return (openDelay.containsKey(playerName) && ((Long)openDelay.get(playerName)).longValue() > System.currentTimeMillis());
/*     */   }
/*     */   
/*     */   public void setCooldown(String playerName) {
/* 274 */     openDelay.put(playerName, Long.valueOf(System.currentTimeMillis() + 200L));
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/menu/MenuInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */