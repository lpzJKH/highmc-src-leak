/*    */ package net.highmc.bukkit.utils.menu;
/*    */ 
/*    */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*    */ import net.highmc.bukkit.utils.menu.click.MenuClickHandler;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ public class MenuItem
/*    */ {
/*    */   private ItemStack stack;
/*    */   private MenuClickHandler handler;
/*    */   
/*    */   public MenuItem(ItemStack itemstack) {
/* 16 */     this.stack = itemstack;
/* 17 */     this.handler = new MenuClickHandler()
/*    */       {
/*    */         public void onClick(Player p, Inventory inv, ClickType type, ItemStack stack, int slot) {}
/*    */       };
/*    */   }
/*    */ 
/*    */   
/*    */   public MenuItem(ItemStack itemstack, MenuClickHandler clickHandler) {
/* 25 */     this.stack = itemstack;
/* 26 */     this.handler = clickHandler;
/*    */   }
/*    */   
/*    */   public ItemStack getStack() {
/* 30 */     return this.stack;
/*    */   }
/*    */   
/*    */   public MenuClickHandler getHandler() {
/* 34 */     return this.handler;
/*    */   }
/*    */   
/*    */   public void destroy() {
/* 38 */     this.stack = null;
/* 39 */     this.handler = null;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/menu/MenuItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */