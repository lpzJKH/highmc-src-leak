/*    */ package net.highmc.bukkit.utils.menu.confirm;
/*    */ 
/*    */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*    */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*    */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*    */ import net.highmc.bukkit.utils.menu.click.MenuClickHandler;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ public class ConfirmInventory
/*    */ {
/*    */   public ConfirmInventory(Player player, String confirmTitle, final ConfirmHandler handler, final MenuInventory topInventory) {
/* 16 */     final MenuInventory menu = new MenuInventory(confirmTitle, 4);
/*    */     
/* 18 */     MenuClickHandler confirm = new MenuClickHandler()
/*    */       {
/*    */         public void onClick(Player p, Inventory inv, ClickType type, ItemStack stack, int slot)
/*    */         {
/* 22 */           handler.onConfirm(true);
/*    */         }
/*    */       };
/*    */     
/* 26 */     MenuClickHandler noConfirm = new MenuClickHandler()
/*    */       {
/*    */         public void onClick(Player p, Inventory inv, ClickType type, ItemStack stack, int slot)
/*    */         {
/* 30 */           handler.onConfirm(false);
/*    */           
/* 32 */           if (topInventory != null) {
/* 33 */             topInventory.open(p);
/*    */           } else {
/* 35 */             menu.close(p);
/*    */           } 
/*    */         }
/*    */       };
/* 39 */     menu.setItem(10, (new ItemBuilder()).type(Material.STAINED_GLASS_PANE).durability(14).name("§cRejeitar").build(), noConfirm);
/*    */     
/* 41 */     menu.setItem(11, (new ItemBuilder()).type(Material.STAINED_GLASS_PANE).durability(14).name("§cRejeitar").build(), noConfirm);
/*    */     
/* 43 */     menu.setItem(19, (new ItemBuilder()).type(Material.STAINED_GLASS_PANE).durability(14).name("§cRejeitar").build(), noConfirm);
/*    */     
/* 45 */     menu.setItem(20, (new ItemBuilder()).type(Material.STAINED_GLASS_PANE).durability(14).name("§cRejeitar").build(), noConfirm);
/*    */ 
/*    */     
/* 48 */     menu.setItem(15, (new ItemBuilder()).type(Material.STAINED_GLASS_PANE).durability(5).name("§aAceitar").build(), confirm);
/*    */     
/* 50 */     menu.setItem(16, (new ItemBuilder()).type(Material.STAINED_GLASS_PANE).durability(5).name("§aAceitar").build(), confirm);
/*    */     
/* 52 */     menu.setItem(24, (new ItemBuilder()).type(Material.STAINED_GLASS_PANE).durability(5).name("§aAceitar").build(), confirm);
/*    */     
/* 54 */     menu.setItem(25, (new ItemBuilder()).type(Material.STAINED_GLASS_PANE).durability(5).name("§aAceitar").build(), confirm);
/*    */ 
/*    */     
/* 57 */     menu.open(player);
/*    */   }
/*    */   
/*    */   public static interface ConfirmHandler {
/*    */     void onConfirm(boolean param1Boolean);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/menu/confirm/ConfirmInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */