/*    */ package net.highmc.bukkit.utils.menu;
/*    */ 
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ import org.bukkit.inventory.InventoryHolder;
/*    */ 
/*    */ public class MenuHolder
/*    */   implements InventoryHolder {
/*    */   private MenuInventory menu;
/*    */   
/*    */   public MenuHolder(MenuInventory menuInventory) {
/* 12 */     this.menu = menuInventory;
/*    */   }
/*    */   
/*    */   public MenuInventory getMenu() {
/* 16 */     return this.menu;
/*    */   }
/*    */   
/*    */   public void setMenu(MenuInventory menu) {
/* 20 */     this.menu = menu;
/*    */   }
/*    */   
/*    */   public void onClose(Player player) {
/* 24 */     this.menu.onClose(player);
/*    */   }
/*    */   
/*    */   public boolean isOnePerPlayer() {
/* 28 */     return this.menu.isOnePerPlayer();
/*    */   }
/*    */   
/*    */   public void destroy() {
/* 32 */     this.menu = null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Inventory getInventory() {
/* 37 */     if (isOnePerPlayer()) {
/* 38 */       return null;
/*    */     }
/* 40 */     return this.menu.getInventory();
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/menu/MenuHolder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */