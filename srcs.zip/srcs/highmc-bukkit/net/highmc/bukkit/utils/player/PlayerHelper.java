/*     */ package net.highmc.bukkit.utils.player;
/*     */ 
/*     */ import com.comphenix.protocol.PacketType;
/*     */ import com.comphenix.protocol.ProtocolLibrary;
/*     */ import com.comphenix.protocol.events.PacketContainer;
/*     */ import com.comphenix.protocol.wrappers.EnumWrappers;
/*     */ import com.comphenix.protocol.wrappers.WrappedChatComponent;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.utils.PacketBuilder;
/*     */ import net.highmc.bukkit.utils.ProtocolVersion;
/*     */ import net.highmc.bukkit.utils.StringLoreUtils;
/*     */ import net.highmc.language.Language;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlayerHelper
/*     */ {
/*     */   public static void broadcastHeader(String header) {
/*  28 */     broadcastHeaderAndFooter(header, null);
/*     */   }
/*     */   
/*     */   public static void broadcastFooter(String footer) {
/*  32 */     broadcastHeaderAndFooter(null, footer);
/*     */   }
/*     */   
/*     */   public static void broadcastHeaderAndFooter(String header, String footer) {
/*  36 */     for (Player player : Bukkit.getOnlinePlayers())
/*  37 */       setHeaderAndFooter(player, header, footer); 
/*     */   }
/*     */   
/*     */   public static void setHeader(Player p, String header) {
/*  41 */     setHeaderAndFooter(p, header, null);
/*     */   }
/*     */   
/*     */   public static void setFooter(Player p, String footer) {
/*  45 */     setHeaderAndFooter(p, null, footer);
/*     */   }
/*     */   
/*     */   public static void setHeaderAndFooter(Player p, String rawHeader, String rawFooter) {
/*  49 */     PacketContainer packet = new PacketContainer(PacketType.Play.Server.PLAYER_LIST_HEADER_FOOTER);
/*  50 */     packet.getChatComponents().write(0, WrappedChatComponent.fromText(rawHeader));
/*  51 */     packet.getChatComponents().write(1, WrappedChatComponent.fromText(rawFooter));
/*     */     
/*     */     try {
/*  54 */       ProtocolLibrary.getProtocolManager().sendServerPacket(p, packet);
/*  55 */     } catch (InvocationTargetException e) {
/*  56 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void title(Player player, String title, String subTitle) {
/*  61 */     if (ProtocolVersion.getProtocolVersion(player).getId() >= 47) {
/*  62 */       sendPacket(player, (new PacketBuilder(PacketType.Play.Server.TITLE)).writeTitleAction(0, EnumWrappers.TitleAction.TITLE)
/*  63 */           .writeChatComponents(0, WrappedChatComponent.fromText(title)).build());
/*  64 */       sendPacket(player, (new PacketBuilder(PacketType.Play.Server.TITLE)).writeTitleAction(0, EnumWrappers.TitleAction.SUBTITLE)
/*  65 */           .writeChatComponents(0, WrappedChatComponent.fromText(subTitle)).build());
/*  66 */       sendPacket(player, (new PacketBuilder(PacketType.Play.Server.TITLE)).writeTitleAction(0, EnumWrappers.TitleAction.TIMES)
/*  67 */           .writeInteger(0, 10).writeInteger(1, 20).writeInteger(2, 20).build());
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void subtitle(Player player, String subTitle) {
/*  72 */     if (ProtocolVersion.getProtocolVersion(player).getId() >= 47) {
/*  73 */       sendPacket(player, (new PacketBuilder(PacketType.Play.Server.TITLE)).writeTitleAction(0, EnumWrappers.TitleAction.SUBTITLE)
/*  74 */           .writeChatComponents(0, WrappedChatComponent.fromText(subTitle)).build());
/*     */     }
/*     */   }
/*     */   
/*     */   public static void title(Player player, String title, String subTitle, int fadeIn, int stayIn, int fadeOut) {
/*  79 */     if (ProtocolVersion.getProtocolVersion(player).getId() >= 47) {
/*  80 */       sendPacket(player, (new PacketBuilder(PacketType.Play.Server.TITLE)).writeTitleAction(0, EnumWrappers.TitleAction.TITLE)
/*  81 */           .writeChatComponents(0, WrappedChatComponent.fromText(title)).build());
/*  82 */       sendPacket(player, (new PacketBuilder(PacketType.Play.Server.TITLE)).writeTitleAction(0, EnumWrappers.TitleAction.SUBTITLE)
/*  83 */           .writeChatComponents(0, WrappedChatComponent.fromText(subTitle)).build());
/*  84 */       sendPacket(player, (new PacketBuilder(PacketType.Play.Server.TITLE)).writeTitleAction(0, EnumWrappers.TitleAction.TIMES)
/*  85 */           .writeInteger(0, fadeIn).writeInteger(1, stayIn).writeInteger(2, fadeOut).build());
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void actionbar(Player player, String text) {
/*  90 */     PacketContainer packet = new PacketContainer(PacketType.Play.Server.CHAT);
/*  91 */     packet.getChatComponents().write(0, WrappedChatComponent.fromJson("{\"text\":\"" + text + " \"}"));
/*  92 */     packet.getBytes().write(0, Byte.valueOf((byte)2));
/*  93 */     sendPacket(player, packet);
/*     */   }
/*     */   
/*     */   public static void broadcastActionBar(String text) {
/*  97 */     Bukkit.getOnlinePlayers().forEach(player -> actionbar(player, text));
/*     */   }
/*     */   
/*     */   public static void sendPacket(Player player, PacketContainer packet) {
/*     */     try {
/* 102 */       ProtocolLibrary.getProtocolManager().sendServerPacket(player, packet);
/* 103 */     } catch (InvocationTargetException e) {
/* 104 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String translate(Language lang, String string) {
/* 109 */     return CommonPlugin.getInstance().getPluginInfo().findAndTranslate(lang, string);
/*     */   }
/*     */   
/*     */   public static ItemStack translate(Language lang, ItemStack item) {
/* 113 */     if (item != null && item.getType() != Material.AIR && 
/* 114 */       item.hasItemMeta()) {
/* 115 */       ItemMeta meta = item.getItemMeta();
/*     */       
/* 117 */       if (meta.hasDisplayName()) {
/* 118 */         String name = meta.getDisplayName();
/* 119 */         meta.setDisplayName(translate(lang, name));
/*     */       } 
/*     */       
/* 122 */       if (meta.hasLore()) {
/* 123 */         List<String> lore = new ArrayList<>();
/*     */         
/* 125 */         for (String line : meta.getLore()) {
/* 126 */           line = translate(lang, line);
/*     */           
/* 128 */           if (line.contains("\n")) {
/* 129 */             String[] split = line.split("\n");
/*     */             
/* 131 */             for (int i = 0; i < split.length; i++)
/* 132 */               lore.addAll(StringLoreUtils.formatForLore(split[i])); 
/*     */             continue;
/*     */           } 
/* 135 */           lore.addAll(StringLoreUtils.formatForLore(line));
/*     */         } 
/*     */ 
/*     */         
/* 139 */         meta.setLore(lore);
/*     */       } 
/*     */ 
/*     */       
/* 143 */       item.setItemMeta(meta);
/*     */     } 
/*     */ 
/*     */     
/* 147 */     return item;
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/player/PlayerHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */