/*    */ package net.highmc.bukkit.utils.player;
/*    */ 
/*    */ import com.comphenix.protocol.utility.MinecraftReflection;
/*    */ import com.comphenix.protocol.wrappers.WrappedGameProfile;
/*    */ import com.comphenix.protocol.wrappers.WrappedSignedProperty;
/*    */ import com.google.common.cache.CacheBuilder;
/*    */ import com.google.common.cache.CacheLoader;
/*    */ import com.google.common.cache.LoadingCache;
/*    */ import com.mojang.authlib.GameProfile;
/*    */ import com.mojang.authlib.minecraft.MinecraftSessionService;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import net.highmc.CommonPlugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextureFetcher
/*    */ {
/* 22 */   public static final LoadingCache<WrappedGameProfile, WrappedSignedProperty> TEXTURE = CacheBuilder.newBuilder().expireAfterWrite(30L, TimeUnit.MINUTES)
/* 23 */     .build(new CacheLoader<WrappedGameProfile, WrappedSignedProperty>()
/*    */       {
/*    */         public WrappedSignedProperty load(WrappedGameProfile profile) throws Exception
/*    */         {
/*    */           try {
/* 28 */             Object minecraftServer = MinecraftReflection.getMinecraftServerClass().getMethod("getServer", new Class[0]).invoke(null, new Object[0]);
/* 29 */             ((MinecraftSessionService)minecraftServer.getClass().getMethod("aD", new Class[0])
/* 30 */               .invoke(minecraftServer, new Object[0]))
/* 31 */               .fillProfileProperties((GameProfile)profile.getHandle(), true);
/* 32 */           } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException|NoSuchMethodException|SecurityException e) {
/*    */             
/* 34 */             e.printStackTrace();
/*    */           } 
/*    */           
/* 37 */           if (profile.getProperties().containsKey("textures")) {
/* 38 */             return profile.getProperties().get("textures").stream().findFirst().orElse(null);
/*    */           }
/*    */           
/* 41 */           String[] properties = CommonPlugin.getInstance().getSkinData().loadSkinById(profile.getUUID());
/*    */           
/* 43 */           return (properties == null) ? null : new WrappedSignedProperty(profile
/* 44 */               .getName(), properties[0], properties[1]);
/*    */         }
/*    */       });
/*    */ 
/*    */   
/*    */   public static WrappedSignedProperty loadTexture(WrappedGameProfile wrappedGameProfile) {
/* 50 */     return (WrappedSignedProperty)TEXTURE.getUnchecked(wrappedGameProfile);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/player/TextureFetcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */