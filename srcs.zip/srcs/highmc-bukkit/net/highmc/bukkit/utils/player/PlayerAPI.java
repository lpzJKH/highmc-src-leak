/*     */ package net.highmc.bukkit.utils.player;
/*     */ 
/*     */ import com.comphenix.protocol.PacketType;
/*     */ import com.comphenix.protocol.ProtocolLibrary;
/*     */ import com.comphenix.protocol.events.PacketContainer;
/*     */ import com.comphenix.protocol.reflect.FieldAccessException;
/*     */ import com.comphenix.protocol.utility.MinecraftReflection;
/*     */ import com.comphenix.protocol.wrappers.EnumWrappers;
/*     */ import com.comphenix.protocol.wrappers.PlayerInfoData;
/*     */ import com.comphenix.protocol.wrappers.WrappedChatComponent;
/*     */ import com.comphenix.protocol.wrappers.WrappedGameProfile;
/*     */ import com.comphenix.protocol.wrappers.WrappedSignedProperty;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import net.highmc.CommonConst;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.bukkit.BukkitMain;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlayerAPI
/*     */ {
/*     */   public static void changePlayerName(Player player, String name) {
/*  36 */     changePlayerName(player, name, true);
/*     */   }
/*     */   
/*     */   public static void changePlayerName(Player player, String name, boolean respawn) {
/*  40 */     if (respawn) {
/*  41 */       removeFromTab(player);
/*     */     }
/*     */     try {
/*  44 */       Object minecraftServer = MinecraftReflection.getMinecraftServerClass().getMethod("getServer", new Class[0]).invoke(null, new Object[0]);
/*  45 */       Object playerList = minecraftServer.getClass().getMethod("getPlayerList", new Class[0]).invoke(minecraftServer, new Object[0]);
/*  46 */       Field f = playerList.getClass().getSuperclass().getDeclaredField("playersByName");
/*  47 */       f.setAccessible(true);
/*  48 */       Map<String, Object> playersByName = (Map<String, Object>)f.get(playerList);
/*  49 */       playersByName.remove(player.getName());
/*  50 */       WrappedGameProfile profile = WrappedGameProfile.fromPlayer(player);
/*  51 */       Field field = profile.getHandle().getClass().getDeclaredField("name");
/*  52 */       field.setAccessible(true);
/*  53 */       field.set(profile.getHandle(), name);
/*  54 */       field.setAccessible(false);
/*  55 */       playersByName.put(name, MinecraftReflection.getCraftPlayerClass().getMethod("getHandle", new Class[0]).invoke(player, new Object[0]));
/*  56 */       f.setAccessible(false);
/*  57 */     } catch (Exception e) {
/*  58 */       e.printStackTrace();
/*     */     } 
/*     */     
/*  61 */     if (respawn)
/*  62 */       respawnPlayer(player); 
/*     */   }
/*     */   
/*     */   public void addToTab(Player player, Collection<? extends Player> players) {
/*  66 */     PacketContainer packet = new PacketContainer(PacketType.Play.Server.PLAYER_INFO);
/*  67 */     packet.getPlayerInfoAction().write(0, EnumWrappers.PlayerInfoAction.ADD_PLAYER);
/*     */     
/*  69 */     if (player.getGameMode() != null) {
/*     */       try {
/*  71 */         Object entityPlayer = MinecraftReflection.getCraftPlayerClass().getMethod("getHandle", new Class[0]).invoke(player, new Object[0]);
/*     */         
/*  73 */         Object getDisplayName = MinecraftReflection.getEntityPlayerClass().getMethod("getPlayerListName", new Class[0]).invoke(entityPlayer, new Object[0]);
/*  74 */         packet.getPlayerInfoDataLists().write(0, 
/*  75 */             Arrays.asList(new PlayerInfoData[] { new PlayerInfoData(WrappedGameProfile.fromPlayer(player), 0, 
/*  76 */                   EnumWrappers.NativeGameMode.fromBukkit(player.getGameMode()), (getDisplayName != null) ? 
/*  77 */                   WrappedChatComponent.fromHandle(getDisplayName) : null) }));
/*  78 */       } catch (FieldAccessException|IllegalAccessException|IllegalArgumentException|InvocationTargetException|NoSuchMethodException|SecurityException e1) {
/*     */         
/*  80 */         e1.printStackTrace();
/*     */       } 
/*     */     }
/*  83 */     for (Player online : players) {
/*  84 */       if (!online.canSee(player)) {
/*     */         continue;
/*     */       }
/*     */       try {
/*  88 */         ProtocolLibrary.getProtocolManager().sendServerPacket(online, packet);
/*  89 */       } catch (InvocationTargetException e) {
/*  90 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void removeFromTab(Player player) {
/*  96 */     PacketContainer packet = new PacketContainer(PacketType.Play.Server.PLAYER_INFO);
/*  97 */     packet.getPlayerInfoAction().write(0, EnumWrappers.PlayerInfoAction.REMOVE_PLAYER);
/*  98 */     if (player.getGameMode() != null) {
/*     */       try {
/* 100 */         Object entityPlayer = MinecraftReflection.getCraftPlayerClass().getMethod("getHandle", new Class[0]).invoke(player, new Object[0]);
/*     */         
/* 102 */         Object getDisplayName = MinecraftReflection.getEntityPlayerClass().getMethod("getPlayerListName", new Class[0]).invoke(entityPlayer, new Object[0]);
/* 103 */         packet.getPlayerInfoDataLists().write(0, 
/* 104 */             Arrays.asList(new PlayerInfoData[] { new PlayerInfoData(WrappedGameProfile.fromPlayer(player), 0, 
/* 105 */                   EnumWrappers.NativeGameMode.fromBukkit(player.getGameMode()), (getDisplayName != null) ? 
/* 106 */                   WrappedChatComponent.fromHandle(getDisplayName) : null) }));
/* 107 */       } catch (FieldAccessException|IllegalAccessException|IllegalArgumentException|InvocationTargetException|NoSuchMethodException|SecurityException e1) {
/*     */         
/* 109 */         e1.printStackTrace();
/*     */       } 
/*     */     }
/* 112 */     for (Player online : Bukkit.getOnlinePlayers()) {
/* 113 */       if (!online.canSee(player)) {
/*     */         continue;
/*     */       }
/*     */       try {
/* 117 */         ProtocolLibrary.getProtocolManager().sendServerPacket(online, packet);
/* 118 */       } catch (InvocationTargetException e) {
/* 119 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void respawnPlayer(final Player player) {
/* 125 */     respawnSelf(player);
/*     */     
/* 127 */     (new BukkitRunnable()
/*     */       {
/*     */         public void run()
/*     */         {
/* 131 */           Bukkit.getOnlinePlayers().stream().filter(onlinePlayer -> !onlinePlayer.equals(player))
/* 132 */             .filter(onlinePlayer -> onlinePlayer.canSee(player)).forEach(onlinePlayer -> {
/*     */                 onlinePlayer.hidePlayer(player);
/*     */                 onlinePlayer.showPlayer(player);
/*     */               });
/*     */         }
/* 137 */       }).runTaskLater((Plugin)BukkitCommon.getInstance(), 2L);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void respawnSelf(final Player player) {
/* 142 */     List<PlayerInfoData> data = new ArrayList<>();
/*     */     
/* 144 */     if (player.getGameMode() != null) {
/*     */       try {
/* 146 */         Object entityPlayer = MinecraftReflection.getCraftPlayerClass().getMethod("getHandle", new Class[0]).invoke(player, new Object[0]);
/*     */         
/* 148 */         Object getDisplayName = MinecraftReflection.getEntityPlayerClass().getMethod("getPlayerListName", new Class[0]).invoke(entityPlayer, new Object[0]);
/* 149 */         int ping = ((Integer)MinecraftReflection.getEntityPlayerClass().getField("ping").get(entityPlayer)).intValue();
/* 150 */         data.add(new PlayerInfoData(WrappedGameProfile.fromPlayer(player), ping, 
/* 151 */               EnumWrappers.NativeGameMode.fromBukkit(player.getGameMode()), (getDisplayName != null) ? 
/* 152 */               WrappedChatComponent.fromHandle(getDisplayName) : null));
/* 153 */       } catch (FieldAccessException|IllegalAccessException|IllegalArgumentException|InvocationTargetException|NoSuchMethodException|SecurityException|NoSuchFieldException e1) {
/*     */         
/* 155 */         e1.printStackTrace();
/*     */       } 
/*     */     }
/* 158 */     final PacketContainer addPlayerInfo = new PacketContainer(PacketType.Play.Server.PLAYER_INFO);
/* 159 */     addPlayerInfo.getPlayerInfoAction().write(0, EnumWrappers.PlayerInfoAction.ADD_PLAYER);
/* 160 */     addPlayerInfo.getPlayerInfoDataLists().write(0, data);
/*     */     
/* 162 */     final PacketContainer removePlayerInfo = new PacketContainer(PacketType.Play.Server.PLAYER_INFO);
/* 163 */     removePlayerInfo.getPlayerInfoAction().write(0, EnumWrappers.PlayerInfoAction.REMOVE_PLAYER);
/* 164 */     removePlayerInfo.getPlayerInfoDataLists().write(0, data);
/*     */     
/* 166 */     final PacketContainer respawnPlayer = new PacketContainer(PacketType.Play.Server.RESPAWN);
/* 167 */     respawnPlayer.getIntegers().write(0, Integer.valueOf(player.getWorld().getEnvironment().getId()));
/* 168 */     respawnPlayer.getDifficulties().write(0, EnumWrappers.Difficulty.valueOf(player.getWorld().getDifficulty().name()));
/*     */     
/* 170 */     if (player.getGameMode() != null) {
/* 171 */       respawnPlayer.getGameModes().write(0, EnumWrappers.NativeGameMode.fromBukkit(player.getGameMode()));
/*     */     }
/* 173 */     respawnPlayer.getWorldTypeModifier().write(0, player.getWorld().getWorldType());
/* 174 */     final boolean flying = player.isFlying();
/*     */     
/* 176 */     (new BukkitRunnable()
/*     */       {
/*     */         public void run()
/*     */         {
/*     */           try {
/* 181 */             ProtocolLibrary.getProtocolManager().sendServerPacket(player, removePlayerInfo);
/* 182 */             ProtocolLibrary.getProtocolManager().sendServerPacket(player, addPlayerInfo);
/* 183 */             ProtocolLibrary.getProtocolManager().sendServerPacket(player, respawnPlayer);
/* 184 */             player.getInventory().setHeldItemSlot(player.getInventory().getHeldItemSlot());
/* 185 */             player.teleport(player.getLocation());
/* 186 */             player.setFlying(flying);
/* 187 */             player.setWalkSpeed(player.getWalkSpeed());
/* 188 */             player.setMaxHealth(player.getMaxHealth());
/* 189 */             player.setHealthScale(player.getHealthScale());
/* 190 */             player.setExp(player.getExp());
/* 191 */             player.setLevel(player.getLevel());
/* 192 */             player.updateInventory();
/* 193 */           } catch (InvocationTargetException e) {
/* 194 */             e.printStackTrace();
/*     */           } 
/*     */         }
/* 197 */       }).runTask((Plugin)BukkitMain.getInstance());
/*     */   }
/*     */ 
/*     */   
/*     */   public static WrappedSignedProperty changePlayerSkin(Player player, String value, String signature, boolean respawn) {
/* 202 */     return changePlayerSkin(player, new WrappedSignedProperty("textures", value, signature));
/*     */   }
/*     */   
/*     */   public static WrappedSignedProperty changePlayerSkin(Player player, String name, UUID uuid, boolean respawn) {
/* 206 */     WrappedSignedProperty property = null;
/* 207 */     WrappedGameProfile gameProfile = WrappedGameProfile.fromPlayer(player);
/* 208 */     gameProfile.getProperties().clear();
/*     */     
/* 210 */     gameProfile.getProperties().put("textures", 
/* 211 */         property = TextureFetcher.loadTexture(new WrappedGameProfile(uuid, name)));
/*     */     
/* 213 */     if (respawn) {
/* 214 */       respawnPlayer(player);
/*     */     }
/* 216 */     return property;
/*     */   }
/*     */   
/*     */   public static WrappedSignedProperty changePlayerSkin(Player player, WrappedSignedProperty wrappedSignedProperty) {
/* 220 */     WrappedGameProfile gameProfile = WrappedGameProfile.fromPlayer(player);
/*     */     
/* 222 */     gameProfile.getProperties().clear();
/* 223 */     gameProfile.getProperties().put("textures", wrappedSignedProperty);
/*     */     
/* 225 */     respawnPlayer(player);
/*     */     
/* 227 */     return wrappedSignedProperty;
/*     */   }
/*     */   
/*     */   public static void changePlayerSkin(Player player, WrappedSignedProperty property, boolean respawn) {
/* 231 */     WrappedGameProfile gameProfile = WrappedGameProfile.fromPlayer(player);
/* 232 */     gameProfile.getProperties().clear();
/*     */     
/* 234 */     gameProfile.getProperties().put("textures", property);
/*     */     
/* 236 */     if (respawn)
/* 237 */       respawnPlayer(player); 
/*     */   }
/*     */   
/*     */   public static void removePlayerSkin(Player player) {
/* 241 */     removePlayerSkin(player, true);
/*     */   }
/*     */   
/*     */   public static void removePlayerSkin(Player player, boolean respawn) {
/* 245 */     WrappedGameProfile gameProfile = WrappedGameProfile.fromPlayer(player);
/* 246 */     gameProfile.getProperties().clear();
/*     */     
/* 248 */     if (respawn) {
/* 249 */       respawnPlayer(player);
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean validateName(String username) {
/* 254 */     return CommonConst.NAME_PATTERN.matcher(username).matches();
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/player/PlayerAPI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */