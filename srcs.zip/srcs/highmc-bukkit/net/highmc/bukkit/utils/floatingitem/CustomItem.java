package net.highmc.bukkit.utils.floatingitem;

import org.bukkit.Location;
import org.bukkit.inventory.ItemStack;

public interface CustomItem {
  CustomItem spawn();
  
  CustomItem remove();
  
  void teleport(Location paramLocation);
  
  Location getLocation();
  
  ItemStack getItemStack();
}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/floatingitem/CustomItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */