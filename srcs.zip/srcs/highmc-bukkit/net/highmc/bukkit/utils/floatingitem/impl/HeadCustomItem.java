/*    */ package net.highmc.bukkit.utils.floatingitem.impl;
/*    */ 
/*    */ import net.highmc.bukkit.utils.floatingitem.CustomItem;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.entity.ArmorStand;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class HeadCustomItem implements CustomItem {
/*    */   private Location location;
/*    */   private ItemStack itemStack;
/*    */   private ArmorStand armorStand;
/*    */   private boolean alive;
/*    */   
/* 14 */   public Location getLocation() { return this.location; } public ItemStack getItemStack() {
/* 15 */     return this.itemStack;
/*    */   } public ArmorStand getArmorStand() {
/* 17 */     return this.armorStand;
/*    */   } public boolean isAlive() {
/* 19 */     return this.alive;
/*    */   }
/*    */   public HeadCustomItem(Location location, ItemStack itemStack) {
/* 22 */     this.location = location;
/* 23 */     this.itemStack = itemStack;
/*    */   }
/*    */ 
/*    */   
/*    */   public CustomItem spawn() {
/* 28 */     if (this.alive) {
/* 29 */       return this;
/*    */     }
/*    */     
/* 32 */     this.armorStand = (ArmorStand)this.location.getWorld().spawnEntity(this.location, EntityType.ARMOR_STAND);
/*    */     
/* 34 */     this.armorStand.setHelmet(this.itemStack);
/* 35 */     this.armorStand.setCustomNameVisible(false);
/* 36 */     this.armorStand.setGravity(false);
/* 37 */     this.armorStand.setVisible(false);
/* 38 */     this.alive = true;
/* 39 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public CustomItem remove() {
/* 44 */     if (this.alive) {
/* 45 */       this.armorStand.remove();
/* 46 */       this.alive = false;
/* 47 */       return this;
/*    */     } 
/*    */     
/* 50 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void teleport(Location location) {
/* 55 */     this.location = location;
/*    */     
/* 57 */     if (this.alive)
/* 58 */       this.armorStand.teleport(location); 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/floatingitem/impl/HeadCustomItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */