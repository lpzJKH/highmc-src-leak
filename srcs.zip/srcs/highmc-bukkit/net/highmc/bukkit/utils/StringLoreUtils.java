/*    */ package net.highmc.bukkit.utils;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.bukkit.ChatColor;
/*    */ 
/*    */ 
/*    */ public class StringLoreUtils
/*    */ {
/*    */   public static List<String> formatForLore(String text) {
/* 11 */     return getLore(30, text);
/*    */   }
/*    */   
/*    */   public static List<String> getLore(int max, String text) {
/* 15 */     List<String> lore = new ArrayList<>();
/* 16 */     text = ChatColor.translateAlternateColorCodes('&', text);
/* 17 */     String[] split = text.split(" ");
/* 18 */     String color = "";
/* 19 */     text = "";
/*    */     
/* 21 */     for (int i = 0; i < split.length; i++) {
/* 22 */       if (ChatColor.stripColor(text).length() >= max || ChatColor.stripColor(text).endsWith(".") || 
/* 23 */         ChatColor.stripColor(text).endsWith("!")) {
/* 24 */         lore.add(text);
/* 25 */         if (text.endsWith(".") || text.endsWith("!"))
/* 26 */           lore.add(""); 
/* 27 */         text = color;
/*    */       } 
/*    */       
/* 30 */       String toAdd = split[i];
/*    */       
/* 32 */       if (toAdd.contains("§")) {
/* 33 */         color = ChatColor.getLastColors(toAdd.toLowerCase());
/*    */       }
/* 35 */       if (toAdd.contains("\n")) {
/* 36 */         toAdd = toAdd.substring(0, toAdd.indexOf("\n"));
/* 37 */         split[i] = split[i].substring(toAdd.length() + 1);
/* 38 */         lore.add(text + ((text.length() == 0) ? "" : " ") + toAdd);
/* 39 */         text = color;
/* 40 */         i--;
/*    */       } else {
/* 42 */         text = text + ((ChatColor.stripColor(text).length() == 0) ? "" : " ") + toAdd;
/*    */       } 
/*    */     } 
/* 45 */     lore.add(text);
/* 46 */     return lore;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/utils/StringLoreUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */