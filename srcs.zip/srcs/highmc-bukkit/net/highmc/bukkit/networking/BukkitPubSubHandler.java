/*     */ package net.highmc.bukkit.networking;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.reflect.TypeToken;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.UUID;
/*     */ import java.util.logging.Level;
/*     */ import net.highmc.CommonConst;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.backend.data.DataServerMessage;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.bukkit.event.member.PlayerUpdateFieldEvent;
/*     */ import net.highmc.bukkit.event.member.PlayerUpdatedFieldEvent;
/*     */ import net.highmc.bukkit.event.server.ServerEvent;
/*     */ import net.highmc.bukkit.member.BukkitMember;
/*     */ import net.highmc.member.Member;
/*     */ import net.highmc.packet.Packet;
/*     */ import net.highmc.packet.PacketType;
/*     */ import net.highmc.server.ServerType;
/*     */ import net.highmc.server.loadbalancer.server.MinigameServer;
/*     */ import net.highmc.server.loadbalancer.server.ProxiedServer;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.event.Event;
/*     */ 
/*     */ public class BukkitPubSubHandler extends JedisPubSub {
/*     */   public void onMessage(String channel, String message) {
/*     */     try {
/*     */       PacketType packetType;
/*     */       UUID uuid;
/*     */       ServerType sourceType;
/*     */       Packet packet;
/*     */       BukkitMember player;
/*     */       String source;
/*     */       boolean pass;
/*     */       DataServerMessage.Action action;
/*     */       DataServerMessage<DataServerMessage.JoinPayload> dataServerMessage4;
/*     */       DataServerMessage<DataServerMessage.LeavePayload> dataServerMessage3;
/*     */       DataServerMessage<DataServerMessage.JoinEnablePayload> dataServerMessage2;
/*     */       DataServerMessage<DataServerMessage.StartPayload> dataServerMessage1;
/*     */       DataServerMessage<DataServerMessage.StopPayload> dataServerMessage;
/*     */       DataServerMessage<DataServerMessage.UpdatePayload> payload;
/*     */       ProxiedServer server;
/*  43 */       JsonObject jsonObject = (JsonObject)JsonParser.parseString(message);
/*     */       
/*  45 */       if (CommonPlugin.getInstance().getPluginInfo().isRedisDebugEnabled()) {
/*  46 */         CommonPlugin.getInstance().debug("Redis message from channel " + channel + ": " + jsonObject);
/*     */       }
/*  48 */       switch (channel) {
/*     */         case "server_packet":
/*  50 */           packetType = PacketType.valueOf(jsonObject.get("packetType").getAsString());
/*  51 */           packet = (Packet)CommonConst.GSON.fromJson((JsonElement)jsonObject, packetType.getClassType());
/*     */           
/*  53 */           if (!packet.isExclusiveServers() || (packet.isExclusiveServers() && packet
/*  54 */             .getServerList().contains(CommonPlugin.getInstance().getServerId()))) {
/*  55 */             packet.receive();
/*  56 */             Bukkit.getPluginManager().callEvent((Event)new ServerPacketReceiveEvent(packetType, packet));
/*     */           } 
/*     */           break;
/*     */         
/*     */         case "server_members":
/*  61 */           BukkitCommon.getInstance().getServerManager()
/*  62 */             .setTotalMembers(jsonObject.get("totalMembers").getAsInt());
/*  63 */           Bukkit.getPluginManager().callEvent((Event)new PlayerChangeEvent(jsonObject.get("totalMembers").getAsInt()));
/*     */           break;
/*     */         
/*     */         case "member_field":
/*  67 */           if (!jsonObject.has("source") || jsonObject
/*  68 */             .get("source").getAsString().equals(CommonPlugin.getInstance().getServerId())) {
/*     */             break;
/*     */           }
/*  71 */           uuid = UUID.fromString(jsonObject.get("uniqueId").getAsString());
/*  72 */           player = (BukkitMember)CommonPlugin.getInstance().getMemberManager().getMember(uuid, BukkitMember.class);
/*     */           
/*  74 */           pass = false;
/*     */           
/*  76 */           if (player != null) {
/*     */             try {
/*  78 */               Field field = getField(Member.class, jsonObject.get("field").getAsString());
/*  79 */               Object oldObject = field.get(player);
/*  80 */               Object object = CommonConst.GSON.fromJson(jsonObject.get("value"), field.getGenericType());
/*     */               
/*  82 */               PlayerUpdateFieldEvent event = new PlayerUpdateFieldEvent(Bukkit.getServer().getPlayer(uuid), player, field.getName(), oldObject, object);
/*     */               
/*  84 */               Bukkit.getPluginManager().callEvent((Event)event);
/*     */               
/*  86 */               if (!event.isCancelled()) {
/*  87 */                 field.set(player, event.getObject());
/*  88 */                 Bukkit.getPluginManager().callEvent((Event)new PlayerUpdatedFieldEvent(
/*  89 */                       Bukkit.getServer().getPlayer(uuid), player, field.getName(), oldObject, object));
/*  90 */                 pass = true;
/*     */               } 
/*  92 */             } catch (Exception e) {
/*  93 */               e.printStackTrace();
/*     */             } 
/*     */             
/*  96 */             if (pass && jsonObject.get("field").getAsString().toLowerCase().contains("configuration")) {
/*     */               try {
/*  98 */                 Field field = Member.class.getDeclaredField(jsonObject.get("field").getAsString());
/*  99 */                 field.setAccessible(true);
/* 100 */                 Object object = field.get(player);
/*     */                 
/* 102 */                 Field memberField = object.getClass().getDeclaredField("member");
/* 103 */                 memberField.setAccessible(true);
/* 104 */                 memberField.set(field.get(player), player);
/* 105 */               } catch (Exception ex) {
/* 106 */                 ex.printStackTrace();
/*     */               } 
/*     */             }
/*     */           } 
/*     */           break;
/*     */         
/*     */         case "server_info":
/* 113 */           if (!BukkitCommon.getInstance().isServerLog()) {
/*     */             return;
/*     */           }
/* 116 */           sourceType = ServerType.valueOf(jsonObject.get("serverType").getAsString());
/*     */           
/* 118 */           if (sourceType == ServerType.BUNGEECORD) {
/*     */             return;
/*     */           }
/* 121 */           source = jsonObject.get("source").getAsString();
/* 122 */           action = DataServerMessage.Action.valueOf(jsonObject.get("action").getAsString());
/*     */           
/* 124 */           switch (action) {
/*     */             case JOIN:
/* 126 */               dataServerMessage4 = (DataServerMessage<DataServerMessage.JoinPayload>)CommonConst.GSON.fromJson((JsonElement)jsonObject, (new TypeToken<DataServerMessage<DataServerMessage.JoinPayload>>() {
/*     */                   
/* 128 */                   }).getType());
/* 129 */               server = BukkitCommon.getInstance().getServerManager().getServer(source);
/*     */               
/* 131 */               if (server == null) {
/*     */                 return;
/*     */               }
/* 134 */               server.joinPlayer(((DataServerMessage.JoinPayload)dataServerMessage4.getPayload()).getUniqueId());
/* 135 */               Bukkit.getPluginManager().callEvent((Event)new ServerEvent(source, sourceType, server, dataServerMessage4, action));
/*     */               break;
/*     */             
/*     */             case LEAVE:
/* 139 */               dataServerMessage3 = (DataServerMessage<DataServerMessage.LeavePayload>)CommonConst.GSON.fromJson((JsonElement)jsonObject, (new TypeToken<DataServerMessage<DataServerMessage.LeavePayload>>() {
/*     */                   
/* 141 */                   }).getType());
/*     */               
/* 143 */               server = BukkitCommon.getInstance().getServerManager().getServer(source);
/*     */               
/* 145 */               if (server == null) {
/*     */                 return;
/*     */               }
/* 148 */               server.leavePlayer(((DataServerMessage.LeavePayload)dataServerMessage3.getPayload()).getUniqueId());
/* 149 */               Bukkit.getPluginManager().callEvent((Event)new ServerEvent(source, sourceType, server, dataServerMessage3, action));
/*     */               break;
/*     */             
/*     */             case JOIN_ENABLE:
/* 153 */               dataServerMessage2 = (DataServerMessage<DataServerMessage.JoinEnablePayload>)CommonConst.GSON.fromJson((JsonElement)jsonObject, (new TypeToken<DataServerMessage<DataServerMessage.JoinEnablePayload>>() {
/*     */                   
/* 155 */                   }).getType());
/*     */               
/* 157 */               server = BukkitCommon.getInstance().getServerManager().getServer(source);
/*     */               
/* 159 */               if (server == null) {
/*     */                 return;
/*     */               }
/* 162 */               server.setJoinEnabled(((DataServerMessage.JoinEnablePayload)dataServerMessage2.getPayload()).isEnable());
/*     */               break;
/*     */             
/*     */             case START:
/* 166 */               dataServerMessage1 = (DataServerMessage<DataServerMessage.StartPayload>)CommonConst.GSON.fromJson((JsonElement)jsonObject, (new TypeToken<DataServerMessage<DataServerMessage.StartPayload>>() {
/*     */                   
/* 168 */                   }).getType());
/*     */               
/* 170 */               Bukkit.getPluginManager()
/* 171 */                 .callEvent((Event)new ServerEvent(source, sourceType, 
/* 172 */                     BukkitCommon.getInstance().getServerManager().addActiveServer(((DataServerMessage.StartPayload)dataServerMessage1
/* 173 */                       .getPayload()).getServerAddress(), ((DataServerMessage.StartPayload)dataServerMessage1
/* 174 */                       .getPayload()).getServer().getServerId(), sourceType, ((DataServerMessage.StartPayload)dataServerMessage1
/* 175 */                       .getPayload()).getServer().getMaxPlayers(), ((DataServerMessage.StartPayload)dataServerMessage1
/* 176 */                       .getPayload()).getStartTime()), dataServerMessage1, action));
/*     */               break;
/*     */ 
/*     */             
/*     */             case STOP:
/* 181 */               dataServerMessage = (DataServerMessage<DataServerMessage.StopPayload>)CommonConst.GSON.fromJson((JsonElement)jsonObject, (new TypeToken<DataServerMessage<DataServerMessage.StopPayload>>() {
/*     */                   
/* 183 */                   }).getType());
/*     */               
/* 185 */               BukkitCommon.getInstance().getServerManager()
/* 186 */                 .removeActiveServer(((DataServerMessage.StopPayload)dataServerMessage.getPayload()).getServerId());
/* 187 */               Bukkit.getPluginManager().callEvent((Event)new ServerEvent(source, sourceType, null, dataServerMessage, action));
/*     */               break;
/*     */             
/*     */             case UPDATE:
/* 191 */               payload = (DataServerMessage<DataServerMessage.UpdatePayload>)CommonConst.GSON.fromJson((JsonElement)jsonObject, (new TypeToken<DataServerMessage<DataServerMessage.UpdatePayload>>() {
/*     */                   
/* 193 */                   }).getType());
/* 194 */               server = BukkitCommon.getInstance().getServerManager().getServer(source);
/*     */               
/* 196 */               if (server == null) {
/*     */                 return;
/*     */               }
/* 199 */               if (server instanceof MinigameServer) {
/* 200 */                 ((MinigameServer)server).setState(((DataServerMessage.UpdatePayload)payload.getPayload()).getState());
/* 201 */                 ((MinigameServer)server).setTime(((DataServerMessage.UpdatePayload)payload.getPayload()).getTime());
/* 202 */                 ((MinigameServer)server).setMap(((DataServerMessage.UpdatePayload)payload.getPayload()).getMap());
/* 203 */                 Bukkit.getPluginManager()
/* 204 */                   .callEvent((Event)new ServerEvent(source, sourceType, server, payload, action));
/*     */               } 
/*     */               break;
/*     */           } 
/*     */ 
/*     */           
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/* 214 */     } catch (Exception ex) {
/* 215 */       CommonPlugin.getInstance().getLogger().log(Level.WARNING, "An error occured when reading json packet in redis " + channel + "!\n" + message, ex);
/*     */       
/* 217 */       System.out.println(ex.getLocalizedMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   private Field getField(Class<?> clazz, String fieldName) {
/* 222 */     while (clazz != null && clazz != Object.class) {
/*     */       try {
/* 224 */         Field field = clazz.getDeclaredField(fieldName);
/* 225 */         field.setAccessible(true);
/* 226 */         return field;
/* 227 */       } catch (NoSuchFieldException e) {
/* 228 */         clazz = clazz.getSuperclass();
/*     */       } 
/*     */     } 
/* 231 */     return null;
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/networking/BukkitPubSubHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */