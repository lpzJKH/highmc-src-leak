/*    */ package net.highmc;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import net.highmc.bukkit.command.BukkitCommandSender;
/*    */ import net.highmc.command.CommandSender;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ public class BukkitConst
/*    */ {
/* 12 */   public static final List<String> RANDOM = Arrays.asList(new String[] { "BeicolaPvP__", "PernasAbertasPvP", "_InternetPvP_", "_XablauKits_" });
/*    */ 
/*    */   
/* 15 */   public static final List<String> SWEAR_WORDS = Arrays.asList(new String[] { "merda", "loser", "cu", "porra", "buceta", "lixo", "random", "bct", "caralho", "fdp", "vsf", "vsfd", "tnc", "vtnc", "crl", "klux", "arrombado", "krl", "hypemc", "hype", "mushmc", "prismamc", "mush", "prisma", "prismamc.com.br", "hypemc.com.br", "weaven", "weavenmc", "weavenhg", "mc-weaven.com.br", "weaven-network.com.br", "weaven-network", "logicmc.com.br", "empire-network.com.br", "empire", "empiremc", "empire-network", "wayzemc.com.br", "wayze", "wayzemc", "macaco", "macacos", "mushmc.com.br", "seu negro", "seu preto" });
/*    */ 
/*    */   
/*    */   public static final boolean CREATE_MEMBER = false;
/*    */ 
/*    */   
/*    */   public static final double TPS = 20.0D;
/*    */ 
/*    */   
/*    */   public static final int ITEMS_PER_PAGE = 21;
/*    */ 
/*    */   
/* 27 */   public static final CommandSender CONSOLE_SENDER = (CommandSender)new BukkitCommandSender(
/* 28 */       (CommandSender)Bukkit.getConsoleSender());
/*    */   public static final String PERMISION_ADMIN_MODE = "command.admin";
/*    */   public static final String ANTICHEAT_BYPASS = "anticheat.bypass";
/*    */   public static final String PERMISSION_CHAT_DISABLED = "chat.disabled-say";
/*    */   public static final String PERMISSION_CHAT_PAYMENT = "chat.payment-say";
/*    */   public static final String PERMISSION_CHAT_YOUTUBER = "chat.youtuber-say";
/*    */   public static final String ANTICHEAT_IGNORE_METADATA = "anticheat-ignore";
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/BukkitConst.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */