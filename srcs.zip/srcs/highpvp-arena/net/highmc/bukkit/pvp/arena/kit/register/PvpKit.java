/*    */ package net.highmc.bukkit.pvp.arena.kit.register;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import net.highmc.bukkit.pvp.arena.kit.Kit;
/*    */ import org.bukkit.Material;
/*    */ 
/*    */ 
/*    */ public class PvpKit
/*    */   extends Kit
/*    */ {
/*    */   public PvpKit() {
/* 12 */     super("PvP", "Kit padrão sem nenhuma habilidade!", Material.DIAMOND_SWORD, 0, new ArrayList());
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/HighPvP.jar!/net/highmc/bukkit/pvp/arena/kit/register/PvpKit.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */