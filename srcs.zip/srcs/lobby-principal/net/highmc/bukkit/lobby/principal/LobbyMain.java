/*    */ package net.highmc.bukkit.lobby.principal;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import net.highmc.bukkit.lobby.CoreMain;
/*    */ import net.highmc.bukkit.lobby.menu.RankupInventory;
/*    */ import net.highmc.bukkit.lobby.principal.listener.ScoreboardListener;
/*    */ import net.highmc.bukkit.utils.character.handler.ActionHandler;
/*    */ import net.highmc.server.ServerType;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public class LobbyMain
/*    */   extends CoreMain {
/*    */   private static LobbyMain instance;
/*    */   
/*    */   public static LobbyMain getInstance() {
/* 19 */     return instance;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 24 */     instance = this;
/* 25 */     super.onEnable();
/*    */     
/* 27 */     Bukkit.getPluginManager().registerEvents((Listener)new ScoreboardListener(), (Plugin)this);
/*    */     
/* 29 */     createCharacter("npc-hg", "AnjooGaming", new ActionHandler()
/*    */         {
/*    */           public boolean onInteract(Player player, boolean right)
/*    */           {
/* 33 */             LobbyMain.this.sendPlayerToServer(player, new ServerType[] { ServerType.HG_LOBBY });
/* 34 */             return false;
/*    */           }
/* 36 */         }Arrays.asList(new ServerType[] { ServerType.HG, ServerType.HG_LOBBY }, ), new String[] { "§bHG" });
/*    */     
/* 38 */     createCharacter("npc-pvp", "Budokkan", new ActionHandler()
/*    */         {
/*    */           public boolean onInteract(Player player, boolean right)
/*    */           {
/* 42 */             LobbyMain.this.sendPlayerToServer(player, new ServerType[] { ServerType.PVP_LOBBY });
/* 43 */             return false;
/*    */           }
/* 45 */         }Arrays.asList(new ServerType[] { ServerType.PVP_LOBBY, ServerType.ARENA, ServerType.FPS, ServerType.LAVA }, ), new String[] { "§bPvP" });
/*    */     
/* 47 */     createCharacter("npc-duels", "stopeey", new ActionHandler()
/*    */         {
/*    */           public boolean onInteract(Player player, boolean right)
/*    */           {
/* 51 */             LobbyMain.this.sendPlayerToServer(player, new ServerType[] { ServerType.DUELS });
/* 52 */             return false;
/*    */           }
/* 54 */         }Arrays.asList(new ServerType[] { ServerType.DUELS }, ), new String[] { "§bTreino" });
/*    */     
/* 56 */     createCharacter("npc-bedwars", "Abodicom4You", new ActionHandler()
/*    */         {
/*    */           public boolean onInteract(Player player, boolean right)
/*    */           {
/* 60 */             LobbyMain.this.sendPlayerToServer(player, new ServerType[] { ServerType.BW_LOBBY });
/* 61 */             return false;
/*    */           }
/* 63 */         }Arrays.asList(new ServerType[] { ServerType.BW_LOBBY, ServerType.BW_SOLO, ServerType.BW_DUOS, ServerType.BW_TRIO, ServerType.BW_SQUAD, ServerType.BW_1X1, ServerType.BW_2X2 }, ), new String[] { "§bBedwars" });
/*    */ 
/*    */     
/* 66 */     createCharacter("npc-skywars", "Jauaum", new ActionHandler()
/*    */         {
/*    */           public boolean onInteract(Player player, boolean right)
/*    */           {
/* 70 */             LobbyMain.this.sendPlayerToServer(player, new ServerType[] { ServerType.SW_LOBBY });
/* 71 */             return false;
/*    */           }
/* 73 */         }Arrays.asList(new ServerType[] { ServerType.SW_LOBBY, ServerType.SW_SOLO, ServerType.SW_DUOS, ServerType.SW_SQUAD }, ), new String[] { "§bSkywars" });
/*    */ 
/*    */     
/* 76 */     createCharacter("npc-rankup", "LouixZ", new ActionHandler()
/*    */         {
/*    */           public boolean onInteract(Player player, boolean right)
/*    */           {
/* 80 */             new RankupInventory(player);
/* 81 */             return false;
/*    */           }
/* 83 */         },  Arrays.asList(new ServerType[] { ServerType.RANKUP }, ), new String[] { "§bRankup" });
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/Lobby.jar!/net/highmc/bukkit/lobby/principal/LobbyMain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */