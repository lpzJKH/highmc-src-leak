/*    */ package net.highmc.bukkit.lobby.principal.listener;
/*    */ 
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.bukkit.BukkitCommon;
/*    */ import net.highmc.bukkit.event.member.PlayerGroupChangeEvent;
/*    */ import net.highmc.bukkit.event.member.PlayerLanguageChangeEvent;
/*    */ import net.highmc.bukkit.event.server.PlayerChangeEvent;
/*    */ import net.highmc.bukkit.lobby.principal.LobbyMain;
/*    */ import net.highmc.bukkit.utils.scoreboard.ScoreHelper;
/*    */ import net.highmc.bukkit.utils.scoreboard.Scoreboard;
/*    */ import net.highmc.member.Member;
/*    */ import net.highmc.permission.Tag;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerJoinEvent;
/*    */ import org.bukkit.event.player.PlayerQuitEvent;
/*    */ 
/*    */ public class ScoreboardListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler(priority = EventPriority.HIGHEST)
/*    */   public void onPlayerJoin(PlayerJoinEvent event) {
/* 25 */     handleScoreboard(event.getPlayer());
/* 26 */     updateScoreboard(event.getPlayer());
/* 27 */     updatePlayers();
/*    */   }
/*    */   
/*    */   @EventHandler(priority = EventPriority.HIGHEST)
/*    */   public void onPlayerQuit(PlayerQuitEvent event) {
/* 32 */     updatePlayers();
/*    */   }
/*    */   
/*    */   @EventHandler(priority = EventPriority.HIGHEST)
/*    */   public void onPlayerChange(PlayerChangeEvent event) {
/* 37 */     updatePlayers();
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerLanguageChange(PlayerLanguageChangeEvent event) {
/* 42 */     ScoreHelper.getInstance().removeScoreboard(event.getPlayer());
/* 43 */     handleScoreboard(event.getPlayer());
/* 44 */     updateScoreboard(event.getPlayer());
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerGroupChange(PlayerGroupChangeEvent event) {
/* 49 */     updateScoreboard(event.getPlayer());
/*    */   }
/*    */   
/*    */   private void handleScoreboard(Player player) {
/* 53 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId());
/* 54 */     Scoreboard scoreboard = new Scoreboard(player, "§d§lHIGH");
/*    */     
/* 56 */     scoreboard.add(8, "§e");
/* 57 */     scoreboard.add(7, "§f§%scoreboard-group%§: " + 
/* 58 */         CommonPlugin.getInstance().getPluginInfo().getTagByGroup(member.getServerGroup()).getStrippedColor());
/* 59 */     scoreboard.add(5, "");
/* 60 */     scoreboard.add(4, "§fLobby: §7#" + LobbyMain.getInstance().getLobbyId());
/* 61 */     scoreboard.add(3, "§f§%scoreboard-players%§: §a" + 
/* 62 */         BukkitCommon.getInstance().getServerManager().getTotalMembers());
/* 63 */     scoreboard.add(2, "§e");
/* 64 */     scoreboard.add(1, "§ewww." + CommonPlugin.getInstance().getPluginInfo().getWebsite());
/*    */     
/* 66 */     ScoreHelper.getInstance().setScoreboard(player, scoreboard);
/*    */   }
/*    */   
/*    */   private void updateScoreboard(Player player) {
/* 70 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId());
/* 71 */     Tag tag = CommonPlugin.getInstance().getPluginInfo().getTagByGroup(member.getServerGroup());
/* 72 */     ScoreHelper.getInstance().updateScoreboard(player, 7, "§f§%scoreboard-group%§: " + tag.getStrippedColor());
/*    */   }
/*    */   
/*    */   private void updatePlayers() {
/* 76 */     ScoreHelper.getInstance().updateScoreboard(3, "§f§%scoreboard-players%§: §a" + 
/* 77 */         BukkitCommon.getInstance().getServerManager().getTotalMembers());
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/Lobby.jar!/net/highmc/bukkit/lobby/principal/listener/ScoreboardListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */