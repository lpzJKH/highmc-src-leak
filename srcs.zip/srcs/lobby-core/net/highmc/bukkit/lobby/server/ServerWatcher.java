/*    */ package net.highmc.bukkit.lobby.server;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import net.highmc.backend.data.DataServerMessage;
/*    */ import net.highmc.server.ServerType;
/*    */ import net.highmc.server.loadbalancer.server.ProxiedServer;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ServerWatcher
/*    */ {
/*    */   public Set<String> getServerIds() {
/* 14 */     return this.serverIds; } public Set<ServerType> getServerTypes() {
/* 15 */     return this.serverTypes;
/*    */   }
/*    */   
/* 18 */   private Set<String> serverIds = new HashSet<>();
/* 19 */   private Set<ServerType> serverTypes = new HashSet<>();
/*    */ 
/*    */   
/*    */   public ServerWatcher server(ServerType serverType) {
/* 23 */     this.serverTypes.add(serverType);
/* 24 */     return this;
/*    */   }
/*    */   
/*    */   public ServerWatcher server(String serverId) {
/* 28 */     this.serverIds.add(serverId.toLowerCase());
/* 29 */     return this;
/*    */   }
/*    */   
/*    */   public void pulse(ProxiedServer server, DataServerMessage<?> data) {
/* 33 */     if (this.serverIds.contains(data.getSource()) || this.serverTypes.contains(data.getServerType()))
/* 34 */       onServerUpdate(server, data); 
/*    */   }
/*    */   
/*    */   public abstract void onServerUpdate(ProxiedServer paramProxiedServer, DataServerMessage<?> paramDataServerMessage);
/*    */ }


/* Location:              /home/uni/Downloads/aaa/Lobby.jar!/net/highmc/bukkit/lobby/server/ServerWatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */