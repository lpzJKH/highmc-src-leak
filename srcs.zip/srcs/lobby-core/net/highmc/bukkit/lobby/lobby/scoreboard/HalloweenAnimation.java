/*    */ package net.highmc.bukkit.lobby.lobby.scoreboard;
/*    */ 
/*    */ 
/*    */ public class HalloweenAnimation implements ScoreboardAnimation {
/*    */   private String text;
/*    */   private List<String> colorList;
/*    */   private int frame;
/*    */   private int frameLimit;
/*    */   
/* 10 */   public String getText() { return this.text; } public List<String> getColorList() {
/* 11 */     return this.colorList;
/*    */   }
/* 13 */   public int getFrame() { return this.frame; } public int getFrameLimit() {
/* 14 */     return this.frameLimit;
/*    */   }
/*    */   public HalloweenAnimation(String text, List<String> colorList) {
/* 17 */     this.text = text;
/* 18 */     this.colorList = colorList;
/* 19 */     this.frameLimit = colorList.size() - 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public String next() {
/* 24 */     this.frame = (this.frame == this.frameLimit) ? 0 : (this.frame + 1);
/*    */     
/* 26 */     if (this.frame % 2 == 0 && this.frame != 0)
/* 27 */       return (String)this.colorList.get(this.frame) + this.text.substring(0, (this.text.toCharArray()).length / 2) + (String)this.colorList.get(this.frame - 1) + this.text
/* 28 */         .substring(this.text.length() / 2); 
/* 29 */     if (this.frame % 3 == 0 && this.frame != 0) {
/* 30 */       return (String)this.colorList.get(this.frame - 1) + this.text.substring(0, this.text.length() / 2) + (String)this.colorList.get(this.frame) + this.text
/* 31 */         .substring(this.text.length() / 2);
/*    */     }
/* 33 */     return (String)this.colorList.get(this.frame) + this.text;
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/Lobby.jar!/net/highmc/bukkit/lobby/lobby/scoreboard/HalloweenAnimation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */