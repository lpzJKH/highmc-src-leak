/*    */ package net.highmc.bukkit.lobby.lobby.scoreboard;
/*    */ public class ChristmasAnimation implements ScoreboardAnimation {
/*    */   private String text;
/*    */   private int frame;
/*    */   private int frameLimit;
/*    */   
/*    */   public String getText() {
/*  8 */     return this.text;
/*    */   }
/* 10 */   public int getFrame() { return this.frame; } public int getFrameLimit() {
/* 11 */     return this.frameLimit;
/*    */   }
/*    */   public ChristmasAnimation(String text) {
/* 14 */     this.text = text.replace("MC", "");
/* 15 */     this.frameLimit = 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public String next() {
/* 20 */     this.frame = (this.frame == this.frameLimit) ? 0 : (this.frame + 1);
/*    */     
/* 22 */     if (this.frame == 0) {
/* 23 */       return "§f§l" + this.text;
/*    */     }
/* 25 */     return "§c§l" + this.text;
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/Lobby.jar!/net/highmc/bukkit/lobby/lobby/scoreboard/ChristmasAnimation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */