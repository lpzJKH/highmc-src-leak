package net.highmc.bukkit.lobby.lobby.scoreboard;

public interface ScoreboardAnimation {
  String next();
}


/* Location:              /home/uni/Downloads/aaa/Lobby.jar!/net/highmc/bukkit/lobby/lobby/scoreboard/ScoreboardAnimation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */