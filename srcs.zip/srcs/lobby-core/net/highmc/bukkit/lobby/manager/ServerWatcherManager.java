/*    */ package net.highmc.bukkit.lobby.manager;
/*    */ 
/*    */ import com.google.common.collect.ImmutableSet;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import net.highmc.backend.data.DataServerMessage;
/*    */ import net.highmc.bukkit.lobby.server.ServerWatcher;
/*    */ import net.highmc.server.loadbalancer.server.ProxiedServer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServerWatcherManager
/*    */ {
/* 17 */   private Set<ServerWatcher> serverWatcherSet = new HashSet<>();
/*    */ 
/*    */   
/*    */   public void watch(ServerWatcher serverWatcher) {
/* 21 */     this.serverWatcherSet.add(serverWatcher);
/*    */   }
/*    */   
/*    */   public void pulse(ProxiedServer server, DataServerMessage<?> data) {
/* 25 */     ImmutableSet.copyOf(this.serverWatcherSet).forEach(serverWatcher -> serverWatcher.pulse(server, data));
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/Lobby.jar!/net/highmc/bukkit/lobby/manager/ServerWatcherManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */