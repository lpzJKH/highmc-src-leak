/*    */ package net.highmc.bukkit.lobby.manager;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import net.highmc.bukkit.lobby.gamer.Gamer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GamerManager
/*    */ {
/* 15 */   private Map<UUID, Gamer> gamers = new HashMap<>();
/*    */ 
/*    */   
/*    */   public void loadGamer(UUID uuid, Gamer gamer) {
/* 19 */     this.gamers.put(uuid, gamer);
/*    */   }
/*    */   
/*    */   public Gamer getGamer(UUID uuid) {
/* 23 */     return this.gamers.get(uuid);
/*    */   }
/*    */   
/*    */   public Collection<Gamer> getGamers() {
/* 27 */     return this.gamers.values();
/*    */   }
/*    */   
/*    */   public void unloadGamer(UUID uuid) {
/* 31 */     this.gamers.remove(uuid);
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/Lobby.jar!/net/highmc/bukkit/lobby/manager/GamerManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */