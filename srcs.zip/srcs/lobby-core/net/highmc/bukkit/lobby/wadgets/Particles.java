/*    */ package net.highmc.bukkit.lobby.wadgets;
/*    */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*    */ import net.minecraft.server.v1_8_R3.EnumParticle;
/*    */ 
/*    */ public enum Particles {
/*    */   Particles(String name, EnumParticle particle, ItemBuilder item) {
/*    */     this.name = name;
/*    */     this.particle = particle;
/*    */     this.item = item;
/*    */   }
/*    */   
/*    */   private String name;
/*    */   private EnumParticle particle;
/* 14 */   HEART("§6Partículas de Corações", EnumParticle.HEART, (new ItemBuilder())
/* 15 */     .type(Material.INK_SACK).durability(10).name("§6Partículas de Corações")),
/*    */   
/* 17 */   FOGUETE("§6Partículas de Anjo", EnumParticle.FIREWORKS_SPARK, (new ItemBuilder())
/* 18 */     .type(Material.INK_SACK).durability(10).name("§6Partículas de Anjo")),
/* 19 */   FOGO("§6Partículas de Fogo", EnumParticle.FLAME, (new ItemBuilder())
/* 20 */     .type(Material.INK_SACK).durability(10).name("§6Partículas de Fogo")); private ItemBuilder item;
/*    */   public String getName() {
/* 22 */     return this.name; }
/* 23 */   public EnumParticle getParticle() { return this.particle; } public ItemBuilder getItem() {
/* 24 */     return this.item;
/*    */   }
/*    */   public static Particles getParticleByName(String nameOfParticle) {
/* 27 */     for (Particles p : values()) {
/* 28 */       if (p.getName().equalsIgnoreCase(nameOfParticle))
/* 29 */         return p; 
/* 30 */     }  return null;
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/Lobby.jar!/net/highmc/bukkit/lobby/wadgets/Particles.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */