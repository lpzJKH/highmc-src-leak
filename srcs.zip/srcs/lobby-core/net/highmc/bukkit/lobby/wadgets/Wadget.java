/*    */ package net.highmc.bukkit.lobby.wadgets;
/*    */ 
/*    */ import org.bukkit.Material;
/*    */ 
/*    */ public enum Wadget {
/*    */   Wadget(String name, Material type) {
/*    */     this.name = name;
/*    */     this.type = type;
/*    */   }
/*    */   
/*    */   private String name;
/* 12 */   HEADS("Cabeças", Material.GOLD_HELMET), CAPES("Capas", Material.ENCHANTMENT_TABLE),
/* 13 */   PARTICLES("Partículas", Material.NETHER_STAR); private Material type;
/*    */   public String getName() {
/* 15 */     return this.name; } public Material getType() {
/* 16 */     return this.type;
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/Lobby.jar!/net/highmc/bukkit/lobby/wadgets/Wadget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */