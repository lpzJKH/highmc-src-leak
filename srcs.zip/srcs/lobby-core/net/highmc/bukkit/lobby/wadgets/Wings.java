/*    */ package net.highmc.bukkit.lobby.wadgets;
/*    */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*    */ import net.minecraft.server.v1_8_R3.EnumParticle;
/*    */ 
/*    */ public enum Wings {
/*    */   Wings(String name, EnumParticle particle, ItemBuilder item) {
/*    */     this.name = name;
/*    */     this.particle = particle;
/*    */     this.item = item;
/*    */   }
/*    */   
/*    */   private String name;
/*    */   private EnumParticle particle;
/* 14 */   FOGUETE("§6Asas de Anjo", EnumParticle.FIREWORKS_SPARK, (new ItemBuilder())
/* 15 */     .type(Material.FIREWORK).name("§6Asas de Anjo")),
/* 16 */   FOGO("§6Asas de Fogo", EnumParticle.FLAME, (new ItemBuilder()).type(Material.LAVA_BUCKET).name("§6Asas de Fogo")); private ItemBuilder item;
/*    */   public String getName() {
/* 18 */     return this.name; }
/* 19 */   public EnumParticle getParticle() { return this.particle; } public ItemBuilder getItem() {
/* 20 */     return this.item;
/*    */   }
/*    */   public static Wings getWingsByName(String nameOfParticle) {
/* 23 */     for (Wings p : values()) {
/* 24 */       if (p.getName().equalsIgnoreCase(nameOfParticle))
/* 25 */         return p; 
/* 26 */     }  return null;
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/Lobby.jar!/net/highmc/bukkit/lobby/wadgets/Wings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */