/*    */ package net.highmc.bukkit.lobby.wadgets.util;
/*    */ 
/*    */ public class Point3D
/*    */ {
/*    */   public float x;
/*    */   public float y;
/*    */   public float z;
/*    */   
/*    */   public Point3D(float x, float y, float z) {
/* 10 */     this.x = x;
/* 11 */     this.y = y;
/* 12 */     this.z = z;
/*    */   }
/*    */   
/*    */   public Point3D rotate(float rot) {
/* 16 */     double cos = Math.cos(rot);
/* 17 */     double sin = Math.sin(rot);
/*    */     
/* 19 */     return new Point3D((float)(this.x * cos + this.z * sin), this.y, (float)(this.x * -sin + this.z * cos));
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/Lobby.jar!/net/highmc/bukkit/lobby/wadgets/util/Point3D.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */