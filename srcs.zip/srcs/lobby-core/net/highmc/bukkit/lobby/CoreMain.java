/*     */ package net.highmc.bukkit.lobby;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.event.UpdateEvent;
/*     */ import net.highmc.bukkit.lobby.listener.PlayerListener;
/*     */ import net.highmc.bukkit.lobby.listener.ServerListener;
/*     */ import net.highmc.bukkit.lobby.listener.WorldListener;
/*     */ import net.highmc.bukkit.lobby.manager.GamerManager;
/*     */ import net.highmc.bukkit.lobby.manager.ServerWatcherManager;
/*     */ import net.highmc.bukkit.lobby.menu.CosmeticsInventory;
/*     */ import net.highmc.bukkit.lobby.menu.LobbyInventory;
/*     */ import net.highmc.bukkit.lobby.menu.ServerInventory;
/*     */ import net.highmc.bukkit.menu.profile.ProfileInventory;
/*     */ import net.highmc.bukkit.utils.character.Character;
/*     */ import net.highmc.bukkit.utils.character.NPC;
/*     */ import net.highmc.bukkit.utils.character.handler.ActionHandler;
/*     */ import net.highmc.bukkit.utils.helper.HologramHelper;
/*     */ import net.highmc.bukkit.utils.hologram.Hologram;
/*     */ import net.highmc.bukkit.utils.item.ActionItemStack;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.server.ServerType;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public abstract class CoreMain extends BukkitCommon implements Listener {
/*     */   private static CoreMain instance;
/*     */   private GamerManager gamerManager;
/*     */   private ServerWatcherManager serverWatcherManager;
/*     */   private PlayerInventory playerInventory;
/*     */   private ActionItemStack lobbiesItem;
/*     */   private ActionItemStack gamesItem;
/*     */   private ActionItemStack vanishItem;
/*     */   private ActionItemStack wadgetsItem;
/*     */   
/*     */   public static CoreMain getInstance() {
/*  48 */     return instance;
/*     */   }
/*     */   
/*  51 */   public GamerManager getGamerManager() { return this.gamerManager; } public ServerWatcherManager getServerWatcherManager() {
/*  52 */     return this.serverWatcherManager;
/*     */   }
/*  54 */   public void setPlayerInventory(PlayerInventory playerInventory) { this.playerInventory = playerInventory; } public PlayerInventory getPlayerInventory() {
/*  55 */     return this.playerInventory;
/*     */   }
/*  57 */   public ActionItemStack getLobbiesItem() { return this.lobbiesItem; }
/*  58 */   public ActionItemStack getGamesItem() { return this.gamesItem; }
/*  59 */   public ActionItemStack getVanishItem() { return this.vanishItem; } public ActionItemStack getWadgetsItem() {
/*  60 */     return this.wadgetsItem;
/*     */   }
/*  62 */   public List<CharacterInfo> characterInfos = new ArrayList<>(); public List<CharacterInfo> getCharacterInfos() { return this.characterInfos; }
/*     */   
/*  64 */   private int lobbyId = 1; public int getLobbyId() { return this.lobbyId; }
/*     */ 
/*     */   
/*     */   public void onLoad() {
/*  68 */     super.onLoad();
/*  69 */     setServerLog(true);
/*  70 */     instance = this;
/*  71 */     this.serverWatcherManager = new ServerWatcherManager();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  76 */     super.onEnable();
/*     */     
/*  78 */     this.gamerManager = new GamerManager();
/*     */     
/*  80 */     this.lobbyId = getServerId(CommonPlugin.getInstance().getServerId());
/*     */     
/*  82 */     setPlayerInventory(player -> {
/*     */           player.getInventory().setItem(0, this.gamesItem.getItemStack());
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           player.getInventory().setItem(1, ActionItemStack.create((new ItemBuilder()).name("§a§%item.your-profile%§").type(Material.SKULL_ITEM).durability(3).skin(player.getName()).build(), (new ActionItemStack.Interact()
/*     */                 {
/*     */                   public boolean onInteract(Player player, Entity entity, Block block, ItemStack item, ActionItemStack.ActionType action)
/*     */                   {
/*  92 */                     new ProfileInventory(player);
/*  93 */                     return false;
/*     */                   }
/*     */                 }).setInventoryClick(true)).getItemStack());
/*     */           
/*     */           player.getInventory().setItem(4, this.wadgetsItem.getItemStack());
/*     */           
/*     */           player.getInventory().setItem(7, this.vanishItem.getItemStack());
/*     */           
/*     */           player.getInventory().setItem(8, this.lobbiesItem.getItemStack());
/*     */         });
/* 103 */     this.gamesItem = ActionItemStack.create((new ItemBuilder())
/* 104 */         .name("§a§%item.select-server%§").type(Material.COMPASS).build(), (new ActionItemStack.Interact()
/*     */         {
/*     */           
/*     */           public boolean onInteract(Player player, Entity entity, Block block, ItemStack item, ActionItemStack.ActionType action)
/*     */           {
/* 109 */             new ServerInventory(player);
/* 110 */             return true;
/*     */           }
/* 112 */         }).setInventoryClick(true));
/*     */     
/* 114 */     this.wadgetsItem = ActionItemStack.create((new ItemBuilder()).name("§aCosméticos").type(Material.CHEST).build(), (new ActionItemStack.Interact()
/*     */         {
/*     */ 
/*     */           
/*     */           public boolean onInteract(Player player, Entity entity, Block block, ItemStack item, ActionItemStack.ActionType action)
/*     */           {
/* 120 */             new CosmeticsInventory(player);
/* 121 */             return true;
/*     */           }
/* 123 */         }).setInventoryClick(true));
/*     */     
/* 125 */     this.lobbiesItem = ActionItemStack.create((new ItemBuilder())
/* 126 */         .name("§a§%item.select-lobby%§").type(Material.NETHER_STAR).build(), (new ActionItemStack.Interact()
/*     */         {
/*     */           
/*     */           public boolean onInteract(Player player, Entity entity, Block block, ItemStack item, ActionItemStack.ActionType action)
/*     */           {
/* 131 */             new LobbyInventory(player);
/* 132 */             return true;
/*     */           }
/* 134 */         }).setInventoryClick(true));
/*     */     
/* 136 */     this.vanishItem = ActionItemStack.create((new ItemBuilder())
/* 137 */         .name("§fPlayers: §aVisíveis").type(Material.INK_SACK).durability(10).build(), (new ActionItemStack.Interact()
/*     */         {
/*     */ 
/*     */           
/*     */           public boolean onInteract(Player player, Entity entity, Block block, ItemStack item, ActionItemStack.ActionType action)
/*     */           {
/* 143 */             ItemMeta itemMeta = item.getItemMeta();
/*     */             
/* 145 */             boolean visible = itemMeta.getDisplayName().contains("§a");
/*     */             
/* 147 */             item.setDurability(visible ? 8 : 10);
/* 148 */             itemMeta.setDisplayName(visible ? "§fPlayers: §cInvisíveis" : "§fPlayers: §aVisíveis");
/* 149 */             item.setItemMeta(itemMeta);
/*     */             
/* 151 */             if (visible);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 157 */             player.sendMessage(visible ? "§cVocê agora não está mais vendo os jogadores" : "§aVocê agora está vendo os jogadores");
/*     */             
/* 159 */             return true;
/*     */           }
/* 161 */         }).setInventoryClick(true));
/*     */     
/* 163 */     Bukkit.getPluginManager().registerEvents((Listener)new ServerListener(), (Plugin)this);
/* 164 */     Bukkit.getPluginManager().registerEvents((Listener)new PlayerListener(), (Plugin)this);
/* 165 */     Bukkit.getPluginManager().registerEvents((Listener)new WorldListener(), (Plugin)this);
/* 166 */     Bukkit.getPluginManager().registerEvents(this, (Plugin)this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/* 171 */     super.onDisable();
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onUpdate(UpdateEvent event) {
/* 176 */     if (event.getCurrentTick() % 60L == 0L) {
/* 177 */       this.characterInfos.forEach(info -> {
/*     */             Hologram firstLine = info.getHologram().getLines().stream().findFirst().orElse(null);
/*     */             int players = 0;
/*     */             for (ServerType type : info.getTypes()) {
/*     */               players += getServerManager().getBalancer(type).getTotalNumber();
/*     */             }
/*     */             firstLine.setDisplayName("§e" + players + " jogando.");
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int getServerId(String serverId) {
/* 190 */     Pattern pattern = Pattern.compile("^([a-zA-Z]\\d+)\\..*");
/* 191 */     Matcher matcher = pattern.matcher(serverId);
/*     */     
/* 193 */     if (matcher.find()) {
/* 194 */       return Integer.valueOf(matcher.group(1).replaceAll("[^\\d]", "")).intValue();
/*     */     }
/*     */     
/* 197 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public Hologram createCharacter(String location, String playerName, ActionHandler interact, List<ServerType> serverList, String... text) {
/* 202 */     Location loc = getLocationManager().getLocation(location);
/* 203 */     NPC citizen = new NPC(loc, playerName);
/*     */     
/* 205 */     Character character = new Character(citizen, interact);
/*     */     
/* 207 */     Hologram hologram = HologramHelper.createHologram(text[0], loc.add(0.0D, 0.15D, 0.0D));
/*     */     
/* 209 */     int players = 0;
/*     */     
/* 211 */     for (ServerType type : serverList) {
/* 212 */       players += getServerManager().getBalancer(type).getTotalNumber();
/*     */     }
/* 214 */     hologram.line("§e" + players + " jogando.");
/*     */     
/* 216 */     for (int i = 1; i < text.length; i++) {
/* 217 */       hologram.line(text[i]);
/*     */     }
/* 219 */     Bukkit.getOnlinePlayers().forEach(player -> character.show(player));
/* 220 */     this.characterInfos.add(new CharacterInfo(character, hologram, serverList));
/* 221 */     return hologram;
/*     */   }
/*     */   
/*     */   public Hologram createCharacter(String location, String playerName, ActionHandler interact, String... text) {
/* 225 */     return createCharacter(location, playerName, interact, new ArrayList<>(), text);
/*     */   } public class CharacterInfo { private Character character;
/*     */     public CharacterInfo(Character character, Hologram hologram, List<ServerType> types) {
/* 228 */       this.character = character; this.hologram = hologram; this.types = types;
/*     */     }
/*     */     private Hologram hologram; private List<ServerType> types;
/*     */     public Character getCharacter() {
/* 232 */       return this.character;
/* 233 */     } public Hologram getHologram() { return this.hologram; } public List<ServerType> getTypes() {
/* 234 */       return this.types;
/*     */     } }
/*     */ 
/*     */   
/*     */   public static interface PlayerInventory {
/*     */     void handle(Player param1Player);
/*     */   }
/*     */ }


/* Location:              /home/uni/Downloads/aaa/Lobby.jar!/net/highmc/bukkit/lobby/CoreMain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */