/*     */ package net.highmc.bukkit.lobby.menu;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Collectors;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.backend.data.DataServerMessage;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.bukkit.event.server.ServerEvent;
/*     */ import net.highmc.bukkit.lobby.CoreMain;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*     */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*     */ import net.highmc.server.loadbalancer.server.ProxiedServer;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ public class LobbyInventory
/*     */ {
/*  28 */   private static final MenuInventory MENU_INVENTORY = new MenuInventory("§7Lobbys", 3);
/*     */ 
/*     */ 
/*     */   
/*  32 */   private static final Map<String, Integer> SERVER_MAP = new HashMap<>();
/*     */   static {
/*  34 */     Bukkit.getPluginManager().registerEvents(new Listener() { @EventHandler public void onServer(ServerEvent event) { List<ProxiedServer> serverList; int slot;
/*     */             int i;
/*     */             ItemStack itemStack;
/*     */             ItemBuilder itemBuilder;
/*  38 */             if (event.getServerType() != CommonPlugin.getInstance().getServerType()) {
/*     */               return;
/*     */             }
/*  41 */             switch (event.getAction()) {
/*     */               case STOP:
/*     */               case START:
/*  44 */                 LobbyInventory.MENU_INVENTORY.clear();
/*     */ 
/*     */                 
/*  47 */                 serverList = (List<ProxiedServer>)BukkitCommon.getInstance().getServerManager().getBalancer(CommonPlugin.getInstance().getServerType()).getList().stream().sorted((s1, s2) -> s1.getServerId().compareTo(s2.getServerId())).collect(Collectors.toList());
/*     */                 
/*  49 */                 for (i = 0; i < serverList.size(); i++) {
/*  50 */                   ProxiedServer server = serverList.get(i);
/*  51 */                   int j = 11 + i;
/*     */                   
/*  53 */                   LobbyInventory.MENU_INVENTORY.setItem(j, (new ItemBuilder())
/*  54 */                       .name("§aLobby #" + CoreMain.getInstance().getServerId(server.getServerId()))
/*  55 */                       .lore("§7" + server.getOnlinePlayers() + " jogando.")
/*  56 */                       .type(Material.STAINED_GLASS_PANE).durability(5).build(), (player, inventory, clickType, itemStack, index) -> {
/*     */                         if (player.hasPermission("lobby.join")) {
/*     */                           BukkitCommon.getInstance().sendPlayerToServer(player, server.getServerId());
/*     */                         } else {
/*     */                           player.sendMessage("§cSomente jogadores pagantes podem transitar livremente entre os lobbies.");
/*     */                         } 
/*  62 */                       }); LobbyInventory.SERVER_MAP.put(server.getServerId(), Integer.valueOf(j));
/*     */                 } 
/*     */                 break;
/*     */               
/*     */               case JOIN:
/*     */               case LEAVE:
/*  68 */                 slot = ((Integer)LobbyInventory.SERVER_MAP.get(event.getServerId())).intValue();
/*     */                 
/*  70 */                 itemStack = LobbyInventory.MENU_INVENTORY.getInventory().getItem(slot);
/*  71 */                 itemBuilder = ItemBuilder.fromStack(itemStack);
/*     */                 
/*  73 */                 itemStack.setItemMeta(itemBuilder.clearLore()
/*  74 */                     .lore("§7" + event.getProxiedServer().getOnlinePlayers() + " jogando.").build()
/*  75 */                     .getItemMeta());
/*     */                 break;
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */              }
/*     */            }
/*  84 */         (Plugin)BukkitCommon.getInstance());
/*     */ 
/*     */     
/*  87 */     List<ProxiedServer> serverList = BukkitCommon.getInstance().getServerManager().getBalancer(CommonPlugin.getInstance().getServerType()).getList();
/*     */     
/*  89 */     for (int i = 0; i < serverList.size(); i++) {
/*  90 */       ProxiedServer server = serverList.get(i);
/*  91 */       int slot = 11 + i;
/*     */       
/*  93 */       MENU_INVENTORY.setItem(slot, (new ItemBuilder())
/*  94 */           .name("§aLobby #" + (i + 1)).lore("§7" + server.getOnlinePlayers() + " jogando.")
/*  95 */           .type(Material.STAINED_GLASS_PANE).durability(5).build(), (p, inv, type, stack, s) -> BukkitCommon.getInstance().sendPlayerToServer(p, server.getServerId()));
/*     */ 
/*     */ 
/*     */       
/*  99 */       SERVER_MAP.put(server.getServerId(), Integer.valueOf(slot));
/*     */     } 
/*     */   }
/*     */   
/*     */   public LobbyInventory(Player player) {
/* 104 */     MENU_INVENTORY.open(player);
/*     */   }
/*     */ }


/* Location:              /home/uni/Downloads/aaa/Lobby.jar!/net/highmc/bukkit/lobby/menu/LobbyInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */