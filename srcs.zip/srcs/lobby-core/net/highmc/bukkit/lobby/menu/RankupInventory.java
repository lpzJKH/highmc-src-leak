/*     */ package net.highmc.bukkit.lobby.menu;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.backend.data.DataServerMessage;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.bukkit.lobby.CoreMain;
/*     */ import net.highmc.bukkit.lobby.server.ServerWatcher;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*     */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*     */ import net.highmc.server.ServerType;
/*     */ import net.highmc.server.loadbalancer.server.ProxiedServer;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RankupInventory
/*     */ {
/*  24 */   private static final MenuInventory MENU_INVENTORY = new MenuInventory("§7Rankup", 3);
/*     */   
/*     */   static {
/*  27 */     CoreMain.getInstance().getServerWatcherManager().watch((new ServerWatcher()
/*     */         {
/*     */           public void onServerUpdate(ProxiedServer server, DataServerMessage<?> data)
/*     */           {
/*  31 */             String serverId = data.getSource();
/*  32 */             RankupInventory.RankupType rankupType = RankupInventory.RankupType.getByServerId(serverId);
/*     */             
/*  34 */             if (rankupType == null) {
/*  35 */               CommonPlugin.getInstance()
/*  36 */                 .debug("The rankup type " + serverId + " not found " + data.getSource());
/*     */             } else {
/*  38 */               RankupInventory.createRankup(rankupType, server, data.getAction());
/*     */             } 
/*     */           }
/*  41 */         }).server(ServerType.RANKUP));
/*     */     
/*  43 */     for (RankupType rankupType : RankupType.values()) {
/*  44 */       createRankup(rankupType, new ProxiedServer(rankupType
/*     */             
/*  46 */             .name().toLowerCase() + CommonPlugin.getInstance().getPluginInfo().getIp(), ServerType.RANKUP, new HashSet(), 80, false), DataServerMessage.Action.START);
/*     */     }
/*     */ 
/*     */     
/*  50 */     CoreMain.getInstance().getServerManager().getBalancer(ServerType.RANKUP).getList().forEach(server -> {
/*     */           RankupType rankupType = RankupType.getByServerId(server.getServerId());
/*     */           if (rankupType == null) {
/*     */             CommonPlugin.getInstance().debug("The rankup type " + rankupType + " not found");
/*     */           } else {
/*     */             createRankup(rankupType, server, DataServerMessage.Action.START);
/*     */           } 
/*     */         });
/*     */   }
/*     */   
/*     */   public RankupInventory(Player player) {
/*  61 */     MENU_INVENTORY.open(player);
/*     */   }
/*     */   
/*     */   private static void createRankup(RankupType rankupType, ProxiedServer server, DataServerMessage.Action action) {
/*  65 */     int slot = 11 + rankupType.ordinal() * 2;
/*     */     
/*  67 */     ItemBuilder itemBuilder = new ItemBuilder();
/*     */     
/*  69 */     itemBuilder.name("§%server.selector.rankup-server." + rankupType.name().toLowerCase() + "-name%§");
/*  70 */     itemBuilder.type(rankupType.getType());
/*     */     
/*  72 */     itemBuilder.lore(new String[] { "", "§7§%server.selector.rankup-server." + rankupType.name().toLowerCase() + "-description%§", "" });
/*     */ 
/*     */     
/*  75 */     switch (action) {
/*     */       case STOP:
/*  77 */         itemBuilder.lore("§cO servidor está indisponível no momento.");
/*     */         break;
/*     */       
/*     */       case JOIN_ENABLE:
/*  81 */         if (!server.isJoinEnabled()) {
/*  82 */           itemBuilder.lore("§cO servidor está em manutenção.");
/*     */           break;
/*     */         } 
/*     */       
/*     */       default:
/*  87 */         itemBuilder.lore("§7" + server.getOnlinePlayers() + " jogando.");
/*     */         break;
/*     */     } 
/*  90 */     MENU_INVENTORY.setItem(slot, itemBuilder.build(), (p, inv, type, stack, s) -> {
/*     */           if (server == null) {
/*     */             p.sendMessage("§cO servidor não está disponível no momento.");
/*     */             return;
/*     */           } 
/*     */           if (!server.canBeSelected()) {
/*     */             if (server.isFull() && !p.hasPermission("server.full")) {
/*     */               p.sendMessage("§cO servidor está cheio.");
/*     */               return;
/*     */             } 
/*     */             if (!server.isJoinEnabled() && !p.hasPermission("command.admin")) {
/*     */               p.sendMessage("§cO servidor está em manutenção, estamos trabalhando para sua diversão.");
/*     */               return;
/*     */             } 
/*     */           } 
/*     */           BukkitCommon.getInstance().sendPlayerToServer(p, server.getServerId());
/*     */         });
/*     */   }
/*     */   
/*     */   public enum RankupType {
/*     */     private Material type;
/*     */     
/*     */     RankupType(Material type) {
/*     */       this.type = type;
/*     */     }
/*     */     
/* 116 */     MITOLOGIC((String)Material.IRON_PICKAXE), ATLANTIC((String)Material.DIAMOND_PICKAXE), DARKNESS((String)Material.GOLD_PICKAXE);
/*     */     public Material getType() {
/* 118 */       return this.type;
/*     */     }
/*     */     public static RankupType getByServerId(String serverId) {
/* 121 */       for (RankupType type : values()) {
/* 122 */         if (serverId.toLowerCase().contains(type.name().toLowerCase())) {
/* 123 */           return type;
/*     */         }
/*     */       } 
/* 126 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/uni/Downloads/aaa/Lobby.jar!/net/highmc/bukkit/lobby/menu/RankupInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */