/*     */ package net.highmc.bukkit.lobby.menu;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.highmc.bukkit.lobby.CoreMain;
/*     */ import net.highmc.bukkit.lobby.gamer.Gamer;
/*     */ import net.highmc.bukkit.lobby.wadgets.Heads;
/*     */ import net.highmc.bukkit.lobby.wadgets.Particles;
/*     */ import net.highmc.bukkit.lobby.wadgets.Wadget;
/*     */ import net.highmc.bukkit.lobby.wadgets.Wings;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*     */ import net.highmc.bukkit.utils.menu.MenuItem;
/*     */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*     */ import net.md_5.bungee.api.ChatColor;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ public class CosmeticsInventory {
/*  23 */   private int itemsPerPage = 21;
/*     */   
/*     */   public CosmeticsInventory(Player player, Wadget wadget, int page) {
/*  26 */     Gamer gamer = CoreMain.getInstance().getGamerManager().getGamer(player.getUniqueId());
/*  27 */     MenuInventory menuInventory = new MenuInventory("§7Cosméticos", (wadget == null) ? 3 : 6);
/*     */     
/*  29 */     if (wadget == null) {
/*  30 */       for (int i = 0; i < (Wadget.values()).length; i++) {
/*  31 */         Wadget actual = Wadget.values()[i];
/*     */         
/*  33 */         List<Enum<?>> list = Arrays.asList((actual == Wadget.HEADS) ? (Enum<?>[])Heads.values() : ((actual == Wadget.CAPES) ? 
/*  34 */             (Enum<?>[])Wings.values() : (Enum<?>[])Particles.values()));
/*     */ 
/*     */ 
/*     */         
/*  38 */         long totalOwned = list.stream().filter(o -> (player.hasPermission("lobby.wadgets") || player.hasPermission(actual.name().toLowerCase() + "." + o.name().toLowerCase()))).count();
/*     */         
/*  40 */         menuInventory.setItem(11 + i * 2, (new ItemBuilder())
/*  41 */             .name("§a" + actual.getName()).type(actual.getType())
/*  42 */             .lore(new String[] { "", "§7Disponível: §f" + totalOwned + "/" + list.size() }, ).build(), (p, inv, type, stack, slot) -> new CosmeticsInventory(player, actual, 1));
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/*  48 */       List<MenuItem> items = new ArrayList<>();
/*     */       
/*  50 */       switch (wadget) {
/*     */         case HEADS:
/*  52 */           for (Heads heads : Heads.values()) {
/*  53 */             if (player.hasPermission("lobby.cosmetics") || player
/*  54 */               .hasPermission(wadget.name().toLowerCase() + "." + heads.name().toLowerCase())) {
/*  55 */               items.add(new MenuItem((new ItemBuilder()).type(Material.SKULL_ITEM).durability(3)
/*  56 */                     .name("§a" + heads.getHeadName()).lore(new String[] { "", "§eClique aqui para selecionar."
/*  57 */                       }, ).skin(heads.getValue(), "").build(), (p, inv, type, stack, slot) -> {
/*     */                       p.getInventory().setHelmet(stack);
/*     */                       p.closeInventory();
/*     */                       p.sendMessage("§aColetável ativado: Chapéu do " + heads.getHeadName());
/*     */                     }));
/*     */             } else {
/*  63 */               items.add(new MenuItem((new ItemBuilder())
/*  64 */                     .type(Material.INK_SACK).durability(8).name("§a" + heads.getHeadName())
/*  65 */                     .lore(new String[] { "", "§7Exclusivo para §aVIP", "", "§cVocê não possui esse item."
/*  66 */                       }).skin(heads.getValue(), "").build()));
/*     */             } 
/*     */           } 
/*  69 */           menuInventory
/*  70 */             .setItem(new MenuItem((new ItemBuilder()).type(Material.BARRIER).name("§cRemover cabeça").build(), (p, inv, type, stack, s) -> { p.getInventory().setHelmet(null); p.closeInventory(); }), 49);
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case CAPES:
/*  78 */           for (Wings wing : Wings.values()) {
/*  79 */             if (player.hasPermission("lobby.cosmetics") || player
/*  80 */               .hasPermission(wadget.name().toLowerCase() + "." + wing.name().toLowerCase())) {
/*  81 */               items.add(new MenuItem((new ItemBuilder()).type(Material.INK_SACK).durability(10)
/*  82 */                     .name("§a" + wing.getName()).build(), (p, inv, type, stack, slot) -> {
/*     */                       gamer.setUsingParticle(true);
/*     */                       
/*     */                       gamer.setWing(wing);
/*     */                       gamer.setCape(true);
/*     */                       gamer.setParticle(null);
/*     */                       player.closeInventory();
/*     */                       player.sendMessage("§aColetável ativado: " + ChatColor.stripColor(wing.getName()) + "!");
/*     */                     }));
/*     */             } else {
/*  92 */               items.add(new MenuItem(wing.getItem().name(wing.getName()).type(Material.INK_SACK).durability(8)
/*  93 */                     .lore(new String[] { "", "§7Exclusivo para §aVIP", "", "§cVocê não possui esse item." }).build()));
/*     */             } 
/*     */           } 
/*  96 */           menuInventory
/*  97 */             .setItem(new MenuItem((new ItemBuilder()).type(Material.BARRIER).name("§cRemover cabeça").build(), (p, inv, type, stack, s) -> { gamer.setUsingParticle(false); gamer.setCape(false); gamer.setWing(null); gamer.setParticle(null); player.closeInventory(); }), 49);
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case PARTICLES:
/* 108 */           for (Particles particle : Particles.values()) {
/* 109 */             if (player.hasPermission("lobby.cosmetics") || player
/* 110 */               .hasPermission(wadget.name().toLowerCase() + "." + particle.name().toLowerCase())) {
/* 111 */               items.add(new MenuItem((new ItemBuilder()).type(Material.INK_SACK).durability(10)
/* 112 */                     .name("§a" + particle.getName()).build(), (p, inv, type, stack, slot) -> {
/*     */                       gamer.setUsingParticle(true);
/*     */                       
/*     */                       gamer.setCape(false);
/*     */                       gamer.setWing(null);
/*     */                       gamer.setParticle(particle);
/*     */                       player.closeInventory();
/*     */                       player.sendMessage("§aColetável ativado: " + ChatColor.stripColor(particle.getName()) + "!");
/*     */                     }));
/*     */             } else {
/* 122 */               items.add(new MenuItem(particle.getItem().name(particle.getName()).type(Material.INK_SACK)
/* 123 */                     .durability(8).lore(new String[] { "", "§7Exclusivo para §aVIP", "", "§cVocê não possui esse item."
/* 124 */                       }).build()));
/*     */             } 
/*     */           } 
/* 127 */           menuInventory
/* 128 */             .setItem(new MenuItem((new ItemBuilder()).type(Material.BARRIER).name("§cRemover cabeça").build(), (p, inv, type, stack, s) -> { gamer.setUsingParticle(false); gamer.setCape(false); gamer.setParticle(null); player.closeInventory(); }), 49);
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 139 */       int pageStart = 0;
/* 140 */       int pageEnd = this.itemsPerPage;
/*     */       
/* 142 */       if (page > 1) {
/* 143 */         pageStart = (page - 1) * this.itemsPerPage;
/* 144 */         pageEnd = page * this.itemsPerPage;
/*     */       } 
/*     */       
/* 147 */       if (pageEnd > items.size()) {
/* 148 */         pageEnd = items.size();
/*     */       }
/*     */       
/* 151 */       int w = 10;
/*     */       
/* 153 */       for (int i = pageStart; i < pageEnd; i++) {
/* 154 */         MenuItem item = items.get(i);
/* 155 */         menuInventory.setItem(item, w);
/*     */         
/* 157 */         if (w % 9 == 7) {
/* 158 */           w += 3;
/*     */         }
/*     */         else {
/*     */           
/* 162 */           w++;
/*     */         } 
/*     */       } 
/* 165 */       if (page == 1) {
/* 166 */         menuInventory.setItem(47, (new ItemBuilder()).name("§cVoltar").type(Material.ARROW).build(), (p, inv, type, stack, slot) -> new CosmeticsInventory(player, null));
/*     */       } else {
/*     */         
/* 169 */         menuInventory.setItem(new MenuItem((new ItemBuilder())
/* 170 */               .type(Material.ARROW).name("§aPágina " + (page - 1)).build(), (p, inv, type, stack, s) -> new CosmeticsInventory(player, wadget, page - 1)), 47);
/*     */       } 
/*     */ 
/*     */       
/* 174 */       if (Math.ceil((items.size() / this.itemsPerPage)) + 1.0D > page) {
/* 175 */         menuInventory.setItem(new MenuItem((new ItemBuilder())
/* 176 */               .type(Material.ARROW).name("§aPágina " + (page + 1)).build(), (p, inventory, clickType, item, slot) -> new CosmeticsInventory(player, wadget, page + 1)), 51);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 182 */     menuInventory.open(player);
/*     */   }
/*     */   
/*     */   public CosmeticsInventory(Player player, Wadget wadget) {
/* 186 */     this(player, wadget, 1);
/*     */   }
/*     */   
/*     */   public CosmeticsInventory(Player player) {
/* 190 */     this(player, null, 1);
/*     */   }
/*     */ }


/* Location:              /home/uni/Downloads/aaa/Lobby.jar!/net/highmc/bukkit/lobby/menu/CosmeticsInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */