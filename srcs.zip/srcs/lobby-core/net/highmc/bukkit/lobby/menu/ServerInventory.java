/*     */ package net.highmc.bukkit.lobby.menu;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Collectors;
/*     */ import net.highmc.backend.data.DataServerMessage;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.bukkit.event.server.ServerEvent;
/*     */ import net.highmc.bukkit.utils.item.ItemBuilder;
/*     */ import net.highmc.bukkit.utils.menu.MenuInventory;
/*     */ import net.highmc.bukkit.utils.menu.click.ClickType;
/*     */ import net.highmc.server.ServerType;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class ServerInventory {
/*  26 */   private static final MenuInventory MENU_INVENTORY = new MenuInventory("§7§nEscolha um Modo de Jogo", 3);
/*  27 */   private static final Map<String, List<ServerType>> SERVER_MAP = new HashMap<>();
/*     */   
/*     */   static {
/*  30 */     SERVER_MAP.put("bedwars", (List<ServerType>)Arrays.<ServerType>asList(ServerType.values()).stream().filter(type -> type.name().contains("BW"))
/*  31 */         .collect(Collectors.toList()));
/*  32 */     SERVER_MAP.put("skywars", (List<ServerType>)Arrays.<ServerType>asList(ServerType.values()).stream().filter(type -> type.name().contains("SW"))
/*  33 */         .collect(Collectors.toList()));
/*  34 */     SERVER_MAP.put("pvp", Arrays.asList(new ServerType[] { ServerType.ARENA, ServerType.LAVA, ServerType.FPS, ServerType.PVP_LOBBY }));
/*  35 */     SERVER_MAP.put("hardcoregames", Arrays.asList(new ServerType[] { ServerType.HG, ServerType.HG_LOBBY }));
/*  36 */     SERVER_MAP.put("rankup", Arrays.asList(new ServerType[] { ServerType.RANKUP }));
/*     */     
/*  38 */     Bukkit.getPluginManager().registerEvents(new Listener()
/*     */         {
/*     */           @EventHandler
/*     */           public void onServer(ServerEvent event) {
/*  42 */             if (event.getAction() == DataServerMessage.Action.JOIN_ENABLE) {
/*     */               return;
/*     */             }
/*  45 */             ServerType serverType = event.getServerType();
/*     */             
/*  47 */             String name = null;
/*  48 */             List<ServerType> types = new ArrayList<>();
/*     */             
/*  50 */             if (serverType.name().contains("BW")) {
/*  51 */               name = "bedwars";
/*  52 */             } else if (serverType.name().contains("SW")) {
/*  53 */               name = "skywars";
/*  54 */             } else if (serverType.isPvP()) {
/*  55 */               name = "pvp";
/*  56 */             } else if (serverType.isHG()) {
/*  57 */               name = "hardcoregames";
/*  58 */             } else if (serverType == ServerType.RANKUP) {
/*  59 */               name = "rankup";
/*     */             } 
/*  61 */             if (name != null) {
/*  62 */               types.addAll((Collection<? extends ServerType>)ServerInventory.SERVER_MAP.get(name));
/*  63 */               ItemStack itemStack = null;
/*     */               
/*  65 */               for (int i = 11; i < (ServerInventory.MENU_INVENTORY.getInventory().getContents()).length; i++) {
/*  66 */                 ItemStack item = ServerInventory.MENU_INVENTORY.getInventory().getContents()[i];
/*     */                 
/*  68 */                 if (item != null && item.hasItemMeta() && item
/*  69 */                   .getItemMeta().getDisplayName().toLowerCase().contains(name.toLowerCase())) {
/*  70 */                   itemStack = item;
/*     */                   
/*     */                   break;
/*     */                 } 
/*     */               } 
/*  75 */               if (itemStack == null) {
/*     */                 return;
/*     */               }
/*  78 */               ItemBuilder itemBuilder = ItemBuilder.fromStack(itemStack);
/*     */               
/*  80 */               itemStack.setItemMeta(itemBuilder.clearLore().lore("§7" + 
/*  81 */                     BukkitCommon.getInstance().getServerManager().getTotalNumber(types) + " jogando.")
/*  82 */                   .build().getItemMeta());
/*     */             }
/*     */           
/*     */           }
/*  86 */         }(Plugin)BukkitCommon.getInstance());
/*     */     
/*  88 */     MENU_INVENTORY
/*  89 */       .setItem(11, (new ItemBuilder())
/*  90 */         .name("§aPvP").type(Material.IRON_CHESTPLATE)
/*  91 */         .lore("§7" + BukkitCommon.getInstance().getServerManager()
/*  92 */           .getTotalNumber(SERVER_MAP.get("pvp")) + " jogando.")
/*  93 */         .build(), (p, inv, type, stack, slot) -> BukkitCommon.getInstance().sendPlayerToServer(p, new ServerType[] { ServerType.PVP_LOBBY }));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     MENU_INVENTORY.setItem(12, (new ItemBuilder())
/*  99 */         .name("§aHardcoreGames").type(Material.MUSHROOM_SOUP)
/* 100 */         .lore("§7" + BukkitCommon.getInstance().getServerManager()
/* 101 */           .getTotalNumber(SERVER_MAP.get("hardcoregames")) + " jogando.")
/* 102 */         .build(), (p, inv, type, stack, slot) -> {
/*     */           BukkitCommon.getInstance().sendPlayerToServer(p, new ServerType[] { ServerType.HG_LOBBY });
/*     */           
/*     */           p.closeInventory();
/*     */         });
/*     */     
/* 108 */     MENU_INVENTORY.setItem(13, (new ItemBuilder())
/* 109 */         .name("§aSkyWars").type(Material.EYE_OF_ENDER)
/* 110 */         .lore("§7" + BukkitCommon.getInstance().getServerManager()
/* 111 */           .getTotalNumber(SERVER_MAP.get("skywars")) + " jogando.")
/* 112 */         .build(), (p, inv, type, stack, slot) -> {
/*     */           BukkitCommon.getInstance().sendPlayerToServer(p, new ServerType[] { ServerType.SW_LOBBY });
/*     */           
/*     */           p.closeInventory();
/*     */         });
/*     */     
/* 118 */     MENU_INVENTORY.setItem(14, (new ItemBuilder())
/* 119 */         .name("§aBedWars").type(Material.BED)
/* 120 */         .lore("§7" + BukkitCommon.getInstance().getServerManager()
/* 121 */           .getTotalNumber(SERVER_MAP.get("bedwars")) + " jogando.")
/* 122 */         .build(), (p, inv, type, stack, slot) -> {
/*     */           BukkitCommon.getInstance().sendPlayerToServer(p, new ServerType[] { ServerType.BW_LOBBY });
/*     */           
/*     */           p.closeInventory();
/*     */         });
/*     */     
/* 128 */     MENU_INVENTORY
/* 129 */       .setItem(15, (new ItemBuilder())
/* 130 */         .name("§aRankUp").type(Material.DIAMOND_PICKAXE)
/* 131 */         .lore("§7" + BukkitCommon.getInstance().getServerManager()
/* 132 */           .getTotalNumber(SERVER_MAP.get("rankup")) + " jogando.")
/* 133 */         .build(), (p, inv, type, stack, slot) -> new RankupInventory(p));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServerInventory(Player player) {
/* 140 */     MENU_INVENTORY.open(player);
/*     */   }
/*     */ }


/* Location:              /home/uni/Downloads/aaa/Lobby.jar!/net/highmc/bukkit/lobby/menu/ServerInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */