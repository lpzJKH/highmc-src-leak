/*     */ package net.highmc.bukkit.lobby.listener;
/*     */ 
/*     */ import net.highmc.bukkit.event.UpdateEvent;
/*     */ import net.highmc.bukkit.lobby.CoreMain;
/*     */ import net.highmc.bukkit.lobby.gamer.Gamer;
/*     */ import net.highmc.bukkit.lobby.wadgets.util.PointManager;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.block.BlockBreakEvent;
/*     */ import org.bukkit.event.block.BlockBurnEvent;
/*     */ import org.bukkit.event.block.BlockExplodeEvent;
/*     */ import org.bukkit.event.block.BlockIgniteEvent;
/*     */ import org.bukkit.event.block.BlockPhysicsEvent;
/*     */ import org.bukkit.event.block.BlockPlaceEvent;
/*     */ import org.bukkit.event.block.BlockSpreadEvent;
/*     */ import org.bukkit.event.entity.CreatureSpawnEvent;
/*     */ import org.bukkit.event.entity.EntityDamageEvent;
/*     */ import org.bukkit.event.entity.EntityExplodeEvent;
/*     */ import org.bukkit.event.entity.EntityRegainHealthEvent;
/*     */ import org.bukkit.event.entity.FoodLevelChangeEvent;
/*     */ import org.bukkit.event.player.PlayerBucketEmptyEvent;
/*     */ import org.bukkit.event.player.PlayerDropItemEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.event.player.PlayerPickupItemEvent;
/*     */ 
/*     */ public class WorldListener
/*     */   implements Listener
/*     */ {
/*     */   @EventHandler
/*     */   public void onCreatureSpawn(CreatureSpawnEvent event) {
/*  31 */     event.setCancelled((event.getSpawnReason() != CreatureSpawnEvent.SpawnReason.CUSTOM));
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onEntityExplode(EntityExplodeEvent event) {
/*  36 */     event.blockList().clear();
/*  37 */     event.setCancelled(true);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onBlockExplode(BlockExplodeEvent event) {
/*  42 */     event.blockList().clear();
/*  43 */     event.setCancelled(true);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onBlockBurn(BlockBurnEvent event) {
/*  48 */     event.setCancelled(true);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onBlockIgnite(BlockIgniteEvent event) {
/*  53 */     event.setCancelled(true);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onBlockSpread(BlockSpreadEvent event) {
/*  58 */     event.setCancelled(true);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onEntityRegainHealth(EntityRegainHealthEvent event) {
/*  63 */     event.setCancelled(true);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onEntityDamage(EntityDamageEvent event) {
/*  68 */     event.setCancelled(true);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onBlockBreak(BlockBreakEvent event) {
/*  73 */     event.setCancelled(true);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onBlockPlace(BlockPlaceEvent event) {
/*  78 */     event.setCancelled(true);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onBlockPlace(BlockPhysicsEvent event) {
/*  83 */     event.setCancelled(true);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerBucketEmpty(PlayerBucketEmptyEvent event) {
/*  88 */     event.setCancelled(true);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onFoodLevelChange(FoodLevelChangeEvent event) {
/*  93 */     event.setCancelled(true);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerPickupItem(PlayerPickupItemEvent event) {
/*  98 */     event.getItem().remove();
/*  99 */     event.setCancelled(true);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerDropItem(PlayerDropItemEvent event) {
/* 104 */     event.setCancelled(true);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerInteract(PlayerInteractEvent event) {
/* 109 */     event.setCancelled(true);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onUpdate(UpdateEvent event) {
/* 114 */     if (event.getCurrentTick() % 2L == 0L)
/* 115 */       CoreMain.getInstance().getGamerManager().getGamers().stream()
/* 116 */         .filter(gamer -> (gamer.getWing() != null || gamer.getParticle() != null)).forEach(gamer -> {
/*     */             if (gamer.getWing() != null) {
/*     */               PointManager.getInstance().sendPacket(gamer.getPlayer(), gamer.getWing().getParticle());
/*     */             } else {
/*     */               PointManager.getInstance().sendPacket(gamer.getPlayer());
/*     */             } 
/*     */           }); 
/*     */   }
/*     */ }


/* Location:              /home/uni/Downloads/aaa/Lobby.jar!/net/highmc/bukkit/lobby/listener/WorldListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */