/*    */ package net.highmc.bukkit.lobby.listener;
/*    */ 
/*    */ import net.highmc.bukkit.event.server.ServerEvent;
/*    */ import net.highmc.bukkit.lobby.CoreMain;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ 
/*    */ public class ServerListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler
/*    */   public void onServer(ServerEvent event) {
/* 13 */     CoreMain.getInstance().getServerWatcherManager().pulse(event.getProxiedServer(), event.getData());
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/Lobby.jar!/net/highmc/bukkit/lobby/listener/ServerListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */