/*    */ package net.highmc.bukkit.lobby.listener;
/*    */ 
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.bukkit.BukkitCommon;
/*    */ import net.highmc.bukkit.lobby.CoreMain;
/*    */ import net.highmc.bukkit.lobby.LobbyConst;
/*    */ import net.highmc.bukkit.lobby.gamer.Gamer;
/*    */ import net.highmc.bukkit.utils.player.PlayerHelper;
/*    */ import net.highmc.member.Member;
/*    */ import net.highmc.server.ServerType;
/*    */ import org.bukkit.GameMode;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerJoinEvent;
/*    */ import org.bukkit.event.player.PlayerLoginEvent;
/*    */ import org.bukkit.event.player.PlayerMoveEvent;
/*    */ import org.bukkit.event.player.PlayerQuitEvent;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ import org.bukkit.potion.PotionEffectType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlayerListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler(priority = EventPriority.HIGHEST)
/*    */   public void onPlayerLogin(PlayerLoginEvent event) {
/* 32 */     if (event.getResult() != PlayerLoginEvent.Result.ALLOWED) {
/*    */       return;
/*    */     }
/*    */     
/* 36 */     Player player = event.getPlayer();
/* 37 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId());
/*    */     
/* 39 */     if (member == null) {
/* 40 */       event.disallow(PlayerLoginEvent.Result.KICK_OTHER, "§cNão foi possível carregar sua conta, tente novamente.");
/*    */       
/*    */       return;
/*    */     } 
/* 44 */     CoreMain.getInstance().getGamerManager().loadGamer(member.getUniqueId(), new Gamer(member));
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerJoin(PlayerJoinEvent event) {
/* 49 */     Player player = event.getPlayer();
/* 50 */     Member member = CommonPlugin.getInstance().getMemberManager().getMember(player.getUniqueId());
/*    */     
/* 52 */     player.teleport(BukkitCommon.getInstance().getLocationManager().getLocation("spawn"));
/* 53 */     player.setGameMode(GameMode.ADVENTURE);
/*    */     
/* 55 */     if (player.hasPermission("command.fly")) {
/* 56 */       player.setAllowFlight(true);
/* 57 */       player.setFlying(true);
/* 58 */       player.teleport(player.getLocation().add(0.0D, 2.0D, 0.0D));
/*    */     } 
/*    */     
/* 61 */     player.getInventory().clear();
/* 62 */     player.getInventory().setArmorContents(new org.bukkit.inventory.ItemStack[4]);
/*    */     
/* 64 */     player.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, 100, 4));
/* 65 */     player.setHealth(player.getMaxHealth());
/* 66 */     player.setHealthScale(1.0D);
/* 67 */     player.setFoodLevel(20);
/* 68 */     player.setExp(0.0F);
/* 69 */     player.setLevel(0);
/* 70 */     player.setTotalExperience(0);
/*    */     
/* 72 */     CoreMain.getInstance().getPlayerInventory().handle(event.getPlayer());
/*    */     
/* 74 */     if (CommonPlugin.getInstance().getServerType() == ServerType.LOBBY && member.getSessionTime() <= 10000L) {
/* 75 */       PlayerHelper.title(player, "§d§lHIGH", "§eSeja bem-vindo!");
/*    */     }
/* 77 */     PlayerHelper.setHeaderAndFooter(player, "\n§d§lHIGH\n", LobbyConst.TAB_FOOTER);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerQuit(PlayerQuitEvent event) {
/* 82 */     CoreMain.getInstance().getGamerManager().unloadGamer(event.getPlayer().getUniqueId());
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerMove(PlayerMoveEvent event) {
/* 87 */     if (event.getTo().getBlockY() < 1) {
/* 88 */       event.getPlayer().teleport(BukkitCommon.getInstance().getLocationManager().getLocation("spawn"));
/* 89 */     } else if (event.getPlayer().getLocation().subtract(0.0D, 1.0D, 0.0D).getBlock()
/* 90 */       .getType() == Material.SLIME_BLOCK) {
/* 91 */       event.getPlayer().setVelocity(event.getPlayer().getLocation().getDirection().multiply(2).setY(0.6D));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/Lobby.jar!/net/highmc/bukkit/lobby/listener/PlayerListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */