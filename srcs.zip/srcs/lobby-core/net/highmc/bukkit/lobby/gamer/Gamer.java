/*    */ package net.highmc.bukkit.lobby.gamer;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import net.highmc.bukkit.lobby.wadgets.Particles;
/*    */ import net.highmc.bukkit.lobby.wadgets.Wings;
/*    */ import net.highmc.member.Member;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class Gamer
/*    */ {
/*    */   private String name;
/*    */   private UUID uniqueId;
/*    */   
/*    */   public String getName() {
/* 17 */     return this.name; } public UUID getUniqueId() {
/* 18 */     return this.uniqueId;
/*    */   } private boolean flying = false;
/* 20 */   public void setFlying(boolean flying) { this.flying = flying; } private boolean usingParticle = false; private boolean cape = false; public boolean isFlying() {
/* 21 */     return this.flying;
/*    */   } private Particles particle; private Wings wing; public void setUsingParticle(boolean usingParticle) {
/* 23 */     this.usingParticle = usingParticle; } public void setCape(boolean cape) { this.cape = cape; }
/* 24 */   public boolean isUsingParticle() { return this.usingParticle; } public boolean isCape() { return this.cape; }
/* 25 */   public void setParticle(Particles particle) { this.particle = particle; }
/* 26 */   public Particles getParticle() { return this.particle; }
/* 27 */   public void setWing(Wings wing) { this.wing = wing; } public Wings getWing() {
/* 28 */     return this.wing;
/* 29 */   } private double alpha = 0.0D; public void setAlpha(double alpha) { this.alpha = alpha; } public double getAlpha() {
/* 30 */     return this.alpha;
/*    */   }
/*    */   public Gamer(Member member) {
/* 33 */     this.name = member.getName();
/* 34 */     this.uniqueId = member.getUniqueId();
/*    */   }
/*    */   
/*    */   public Player getPlayer() {
/* 38 */     return Bukkit.getPlayer(this.uniqueId);
/*    */   }
/*    */ }


/* Location:              /home/uni/Downloads/aaa/Lobby.jar!/net/highmc/bukkit/lobby/gamer/Gamer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */