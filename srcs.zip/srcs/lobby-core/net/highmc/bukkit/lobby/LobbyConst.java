/*    */ package net.highmc.bukkit.lobby;
/*    */ 
/*    */ import net.highmc.CommonPlugin;
/*    */ 
/*    */ public class LobbyConst
/*    */ {
/*    */   public static final String TITLE_HEADER = "§d§lHIGH";
/*    */   public static final String TITLE_FOOTER = "§eSeja bem-vindo!";
/*    */   public static final String TAB_HEADER = "\n§d§lHIGH\n";
/* 10 */   public static final String TAB_FOOTER = "§f\n§fWebsite: §7" + 
/* 11 */     CommonPlugin.getInstance().getPluginInfo().getWebsite() + "\n§fDiscord: §7" + 
/* 12 */     CommonPlugin.getInstance().getPluginInfo().getDiscord() + "\n§f";
/*    */ }


/* Location:              /home/uni/Downloads/aaa/Lobby.jar!/net/highmc/bukkit/lobby/LobbyConst.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */