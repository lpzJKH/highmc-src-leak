/*    */ package net.highmc.bukkit.gameapi.listener;
/*    */ 
/*    */ import java.util.Optional;
/*    */ import java.util.UUID;
/*    */ import net.highmc.bukkit.gameapi.GameAPI;
/*    */ import net.highmc.bukkit.gameapi.event.GamerLoadEvent;
/*    */ import net.highmc.bukkit.gameapi.gamer.Gamer;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerLoginEvent;
/*    */ import org.bukkit.event.player.PlayerQuitEvent;
/*    */ 
/*    */ 
/*    */ public class GamerListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler(priority = EventPriority.HIGHEST)
/*    */   public void onPlayerLogin(PlayerLoginEvent event) {
/* 23 */     if (event.getResult() == PlayerLoginEvent.Result.ALLOWED) {
/* 24 */       Player player = event.getPlayer();
/* 25 */       Gamer gamer = GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId());
/*    */       
/* 27 */       if (gamer == null) {
/* 28 */         Optional<Gamer> optional = GameAPI.getInstance().getGamerData().loadGamer(player.getUniqueId());
/*    */         
/* 30 */         if (optional.isPresent()) {
/* 31 */           gamer = optional.get();
/*    */         } else {
/*    */           
/*    */           try {
/* 35 */             gamer = GameAPI.getInstance().getGamerClass().getConstructor(new Class[] { String.class, UUID.class }).newInstance(new Object[] { player.getName(), player.getUniqueId() });
/* 36 */             GameAPI.getInstance().getGamerData().createGamer(gamer);
/* 37 */           } catch (InstantiationException|IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException|NoSuchMethodException|SecurityException e) {
/*    */             
/* 39 */             event.setResult(PlayerLoginEvent.Result.KICK_OTHER);
/* 40 */             event.setKickMessage("§c§%gamer-not-loaded%§");
/* 41 */             e.printStackTrace();
/*    */             
/*    */             return;
/*    */           } 
/*    */         } 
/* 46 */         gamer.setPlayer(event.getPlayer());
/* 47 */         gamer.loadGamer();
/*    */         
/* 49 */         GamerLoadEvent gamerLoadEvent = new GamerLoadEvent(player, gamer);
/* 50 */         Bukkit.getPluginManager().callEvent((Event)gamerLoadEvent);
/*    */         
/* 52 */         if (gamerLoadEvent.isCancelled()) {
/* 53 */           event.setResult(PlayerLoginEvent.Result.KICK_OTHER);
/* 54 */           event.setKickMessage(gamerLoadEvent.getReason());
/*    */         } else {
/* 56 */           GameAPI.getInstance().getGamerManager().loadGamer(gamer);
/* 57 */           GameAPI.getInstance()
/* 58 */             .debug("The gamer " + player.getName() + "(" + player.getUniqueId() + ") has been loaded.");
/*    */         } 
/*    */       } else {
/* 61 */         gamer.setPlayer(event.getPlayer());
/* 62 */         GameAPI.getInstance().debug("The gamer " + player
/* 63 */             .getName() + "(" + player.getUniqueId() + ") has already been loaded.");
/*    */       } 
/*    */       
/* 66 */       gamer.setOnline(true);
/*    */     } 
/*    */   }
/*    */   
/*    */   @EventHandler(priority = EventPriority.HIGH)
/*    */   public void onPlayerQuit(PlayerQuitEvent event) {
/* 72 */     Player player = event.getPlayer();
/* 73 */     Gamer gamer = GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId());
/*    */     
/* 75 */     if (gamer == null) {
/*    */       return;
/*    */     }
/* 78 */     gamer.setPlayer(null);
/* 79 */     gamer.setOnline(false);
/*    */     
/* 81 */     if (GameAPI.getInstance().isUnloadGamer()) {
/* 82 */       GameAPI.getInstance().getGamerManager().unloadGamer(gamer.getUniqueId());
/* 83 */       GameAPI.getInstance()
/* 84 */         .debug("The gamer " + player.getName() + "(" + player.getUniqueId() + ") has been unloaded.");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/listener/GamerListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */