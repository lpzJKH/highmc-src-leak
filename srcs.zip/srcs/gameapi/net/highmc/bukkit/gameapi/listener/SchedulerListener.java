/*    */ package net.highmc.bukkit.gameapi.listener;
/*    */ 
/*    */ import net.highmc.bukkit.event.UpdateEvent;
/*    */ import net.highmc.bukkit.gameapi.GameAPI;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ 
/*    */ 
/*    */ public class SchedulerListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler
/*    */   public void update(UpdateEvent event) {
/* 14 */     if (event.getType() == UpdateEvent.UpdateType.SECOND)
/* 15 */       GameAPI.getInstance().getSchedulerManager().pulse(); 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/listener/SchedulerListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */