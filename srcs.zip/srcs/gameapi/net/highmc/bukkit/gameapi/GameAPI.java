/*     */ package net.highmc.bukkit.gameapi;
/*     */ import net.highmc.CommonPlugin;
/*     */ import net.highmc.bukkit.BukkitCommon;
/*     */ import net.highmc.bukkit.gameapi.backend.GamerData;
/*     */ import net.highmc.bukkit.gameapi.backend.impl.GamerDataImpl;
/*     */ import net.highmc.bukkit.gameapi.event.GameStateChangeEvent;
/*     */ import net.highmc.bukkit.gameapi.gamer.Gamer;
/*     */ import net.highmc.bukkit.gameapi.listener.SchedulerListener;
/*     */ import net.highmc.bukkit.gameapi.manager.GamerManager;
/*     */ import net.highmc.bukkit.gameapi.manager.SchedulerManager;
/*     */ import net.highmc.bukkit.gameapi.scheduler.Scheduler;
/*     */ import net.highmc.server.loadbalancer.server.MinigameState;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.event.HandlerList;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public abstract class GameAPI extends BukkitCommon {
/*     */   private static GameAPI instance;
/*     */   private GamerManager gamerManager;
/*     */   private SchedulerManager schedulerManager;
/*     */   
/*     */   public static GameAPI getInstance() {
/*  25 */     return instance;
/*     */   }
/*     */   
/*  28 */   public GamerManager getGamerManager() { return this.gamerManager; } public SchedulerManager getSchedulerManager() {
/*  29 */     return this.schedulerManager;
/*     */   }
/*  31 */   private boolean unloadGamer = true; private Class<? extends Gamer> gamerClass; public void setUnloadGamer(boolean unloadGamer) { this.unloadGamer = unloadGamer; } private String collectionName; private boolean timer; public boolean isUnloadGamer() {
/*  32 */     return this.unloadGamer; }
/*  33 */   public void setGamerClass(Class<? extends Gamer> gamerClass) { this.gamerClass = gamerClass; }
/*  34 */   public Class<? extends Gamer> getGamerClass() { return this.gamerClass; }
/*  35 */   public void setCollectionName(String collectionName) { this.collectionName = collectionName; }
/*  36 */   public String getCollectionName() { return this.collectionName; }
/*  37 */   public void setTimer(boolean timer) { this.timer = timer; }
/*  38 */   public boolean isTimer() { return this.timer; } private boolean consoleControl = true; private GamerData gamerData;
/*  39 */   public void setConsoleControl(boolean consoleControl) { this.consoleControl = consoleControl; } public boolean isConsoleControl() {
/*  40 */     return this.consoleControl;
/*     */   } public GamerData getGamerData() {
/*  42 */     return this.gamerData;
/*     */   }
/*     */   
/*     */   public void onLoad() {
/*  46 */     super.onLoad();
/*  47 */     setServerLog(false);
/*  48 */     setRemovePlayerDat(false);
/*  49 */     instance = this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  54 */     super.onEnable();
/*     */     
/*  56 */     this.gamerManager = new GamerManager();
/*  57 */     this.schedulerManager = new SchedulerManager();
/*     */     
/*  59 */     this.gamerData = (GamerData)new GamerDataImpl();
/*     */     
/*  61 */     Bukkit.getPluginManager().registerEvents((Listener)new GamerListener(), (Plugin)this);
/*  62 */     Bukkit.getPluginManager().registerEvents((Listener)new SchedulerListener(), (Plugin)this);
/*     */   }
/*     */   
/*     */   public void startScheduler(Scheduler scheduler) {
/*  66 */     getSchedulerManager().loadScheduler(scheduler);
/*     */     
/*  68 */     if (Listener.class.isAssignableFrom(scheduler.getClass()))
/*  69 */       Bukkit.getPluginManager().registerEvents((Listener)scheduler, (Plugin)this); 
/*     */   }
/*     */   
/*     */   public void stopScheduler(Scheduler scheduler) {
/*  73 */     getSchedulerManager().unloadScheduler(scheduler);
/*     */     
/*  75 */     if (Listener.class.isAssignableFrom(scheduler.getClass()))
/*  76 */       HandlerList.unregisterAll((Listener)scheduler); 
/*     */   }
/*     */   
/*     */   public void setMap(String mapName) {
/*  80 */     CommonPlugin.getInstance().setMap(mapName);
/*  81 */     CommonPlugin.getInstance().getServerData().updateStatus(getState(), getMapName(), getTime());
/*     */   }
/*     */   
/*     */   public void setTime(int time) {
/*  85 */     CommonPlugin.getInstance().setServerTime(time);
/*  86 */     CommonPlugin.getInstance().getServerData().updateStatus(getState(), getMapName(), getTime());
/*     */   }
/*     */   
/*     */   public void setState(MinigameState state) {
/*  90 */     MinigameState oldState = CommonPlugin.getInstance().getMinigameState();
/*     */     
/*  92 */     if (oldState != state) {
/*  93 */       CommonPlugin.getInstance().setMinigameState(state);
/*  94 */       CommonPlugin.getInstance().getServerData().updateStatus(getState(), getMapName(), getTime());
/*  95 */       System.out.println(oldState + " > " + state);
/*  96 */       Bukkit.getPluginManager().callEvent((Event)new GameStateChangeEvent(oldState, state));
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getMapName() {
/* 101 */     return CommonPlugin.getInstance().getMap();
/*     */   }
/*     */   
/*     */   public int getTime() {
/* 105 */     return CommonPlugin.getInstance().getServerTime();
/*     */   }
/*     */   
/*     */   public MinigameState getState() {
/* 109 */     return CommonPlugin.getInstance().getMinigameState();
/*     */   }
/*     */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/GameAPI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */