/*    */ package net.highmc.bukkit.gameapi.backend.impl;
/*    */ 
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import java.util.Optional;
/*    */ import java.util.UUID;
/*    */ import net.highmc.CommonConst;
/*    */ import net.highmc.CommonPlugin;
/*    */ import net.highmc.backend.mongodb.MongoQuery;
/*    */ import net.highmc.bukkit.gameapi.GameAPI;
/*    */ import net.highmc.bukkit.gameapi.backend.GamerData;
/*    */ import net.highmc.bukkit.gameapi.gamer.Gamer;
/*    */ import net.highmc.utils.json.JsonBuilder;
/*    */ import net.highmc.utils.json.JsonUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GamerDataImpl
/*    */   implements GamerData
/*    */ {
/* 23 */   private MongoQuery query = MongoQuery.createDefault(CommonPlugin.getInstance().getMongoConnection(), 
/* 24 */       GameAPI.getInstance().getCollectionName());
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public <T extends Gamer> Optional<T> loadGamer(UUID uniqueId) {
/* 30 */     JsonElement jsonElement = this.query.findOne("uniqueId", uniqueId.toString());
/* 31 */     return (jsonElement == null) ? Optional.<T>empty() : 
/* 32 */       Optional.<T>of((T)CommonConst.GSON.fromJson(jsonElement, GameAPI.getInstance().getGamerClass()));
/*    */   }
/*    */ 
/*    */   
/*    */   public void createGamer(Gamer gamer) {
/* 37 */     JsonElement jsonElement = this.query.findOne("uniqueId", gamer.getUniqueId().toString());
/*    */     
/* 39 */     if (jsonElement == null) {
/* 40 */       this.query.create(new String[] { CommonConst.GSON.toJson(gamer) });
/*    */     }
/*    */   }
/*    */   
/*    */   public void saveGamer(final Gamer gamer, final String fieldName) {
/* 45 */     CommonPlugin.getInstance().getPluginPlatform().runAsync(new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 49 */             JsonObject tree = JsonUtils.jsonTree(gamer);
/* 50 */             GamerDataImpl.this.query.updateOne("uniqueId", gamer.getUniqueId().toString(), (JsonElement)(new JsonBuilder())
/* 51 */                 .addProperty("fieldName", fieldName).add("value", tree.get(fieldName)).build());
/*    */           }
/*    */         });
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/backend/impl/GamerDataImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */