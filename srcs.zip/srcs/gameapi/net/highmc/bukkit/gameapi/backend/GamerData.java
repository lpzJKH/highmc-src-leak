package net.highmc.bukkit.gameapi.backend;

import java.util.Optional;
import java.util.UUID;
import net.highmc.bukkit.gameapi.gamer.Gamer;

public interface GamerData {
  <T extends Gamer> Optional<T> loadGamer(UUID paramUUID);
  
  void createGamer(Gamer paramGamer);
  
  void saveGamer(Gamer paramGamer, String paramString);
}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/backend/GamerData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */