/*    */ package net.highmc.bukkit.gameapi.gamer;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import java.util.UUID;
/*    */ 
/*    */ public class Team {
/*    */   private int teamId;
/*    */   private int maxPlayers;
/*    */   private Set<UUID> playerSet;
/*    */   
/*    */   public int getTeamId() {
/* 12 */     return this.teamId;
/*    */   }
/* 14 */   public int getMaxPlayers() { return this.maxPlayers; } public Set<UUID> getPlayerSet() {
/* 15 */     return this.playerSet;
/*    */   }
/*    */   public Team(int teamId, int maxPlayers) {
/* 18 */     this.teamId = teamId;
/* 19 */     this.maxPlayers = maxPlayers;
/* 20 */     this.playerSet = new HashSet<>();
/*    */   }
/*    */   
/*    */   public boolean isFull() {
/* 24 */     return (this.playerSet.size() >= this.maxPlayers);
/*    */   }
/*    */   
/*    */   public void team(Gamer gamer) {
/* 28 */     this.playerSet.add(gamer.getUniqueId());
/*    */   }
/*    */   
/*    */   public void unteam(Gamer gamer) {
/* 32 */     this.playerSet.remove(gamer.getUniqueId());
/*    */   }
/*    */   
/*    */   public boolean isTeam(UUID uniqueId) {
/* 36 */     return this.playerSet.contains(uniqueId);
/*    */   }
/*    */   
/*    */   public boolean isTeam(Gamer gamer) {
/* 40 */     return isTeam(gamer.getUniqueId());
/*    */   }
/*    */   
/*    */   public void addPlayer(UUID uniqueId) {
/* 44 */     this.playerSet.add(uniqueId);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/gamer/Team.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */