/*    */ package net.highmc.bukkit.gameapi.gamer;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import net.highmc.bukkit.gameapi.GameAPI;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public abstract class Gamer {
/*    */   private String playerName;
/*    */   private final UUID uniqueId;
/*    */   private transient Player player;
/*    */   private boolean online;
/*    */   
/*    */   public void setPlayerName(String playerName) {
/* 14 */     this.playerName = playerName;
/* 15 */   } public String getPlayerName() { return this.playerName; } public UUID getUniqueId() {
/* 16 */     return this.uniqueId;
/*    */   }
/* 18 */   public Player getPlayer() { return this.player; }
/* 19 */   public void setOnline(boolean online) { this.online = online; } public boolean isOnline() {
/* 20 */     return this.online;
/*    */   }
/*    */   public Gamer(String playerName, UUID uniqueId) {
/* 23 */     this.playerName = playerName;
/* 24 */     this.uniqueId = uniqueId;
/*    */   }
/*    */ 
/*    */   
/*    */   public void loadGamer() {}
/*    */ 
/*    */   
/*    */   public void setPlayer(Player player) {
/* 32 */     this.player = player;
/* 33 */     if (player != null)
/* 34 */       this.playerName = player.getName(); 
/*    */   }
/*    */   
/*    */   public void save(String fieldName) {
/* 38 */     GameAPI.getInstance().getGamerData().saveGamer(this, fieldName);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/gamer/Gamer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */