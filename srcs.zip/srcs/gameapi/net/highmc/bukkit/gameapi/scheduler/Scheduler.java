package net.highmc.bukkit.gameapi.scheduler;

public interface Scheduler {
  void pulse();
}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/scheduler/Scheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */