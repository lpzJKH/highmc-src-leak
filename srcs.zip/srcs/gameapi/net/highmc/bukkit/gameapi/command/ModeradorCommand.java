/*    */ package net.highmc.bukkit.gameapi.command;
/*    */ 
/*    */ import net.highmc.bukkit.gameapi.GameAPI;
/*    */ import net.highmc.command.CommandArgs;
/*    */ import net.highmc.command.CommandClass;
/*    */ import net.highmc.command.CommandFramework.Command;
/*    */ import net.highmc.command.CommandSender;
/*    */ import net.highmc.utils.DateUtils;
/*    */ import net.highmc.utils.string.StringFormat;
/*    */ 
/*    */ public class ModeradorCommand
/*    */   implements CommandClass {
/*    */   @Command(name = "time", aliases = {"tempo"}, permission = "command.time")
/*    */   public void timeCommand(CommandArgs cmdArgs) {
/*    */     long time;
/* 16 */     CommandSender sender = cmdArgs.getSender();
/* 17 */     String[] args = cmdArgs.getArgs();
/*    */     
/* 19 */     if (args.length == 0) {
/* 20 */       sender.sendMessage(sender.getLanguage().t("command-time-usage", new String[] { "%label%", cmdArgs.getLabel() }));
/*    */       
/*    */       return;
/*    */     } 
/* 24 */     if (args[0].equalsIgnoreCase("stop")) {
/* 25 */       GameAPI.getInstance().setTimer(!GameAPI.getInstance().isTimer());
/* 26 */       GameAPI.getInstance().setConsoleControl(false);
/* 27 */       sender.sendMessage("§%command-time-timer-" + (
/* 28 */           GameAPI.getInstance().isTimer() ? "enabled" : "disabled") + "%§");
/*    */ 
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/*    */     try {
/* 35 */       time = DateUtils.parseDateDiff(args[0], true);
/* 36 */     } catch (Exception e) {
/* 37 */       sender.sendMessage(sender.getLanguage().t("number-format-invalid", new String[] { "%number%", args[0] }));
/*    */       
/*    */       return;
/*    */     } 
/* 41 */     int seconds = (int)Math.floor(((time - System.currentTimeMillis()) / 1000L));
/*    */     
/* 43 */     if (seconds >= 7200) {
/* 44 */       seconds = 7200;
/*    */     }
/* 46 */     sender.sendMessage(sender.getLanguage().t("command-time-changed", new String[] { "%time%", 
/* 47 */             StringFormat.formatTime(seconds, StringFormat.TimeFormat.NORMAL) }));
/* 48 */     GameAPI.getInstance().setTime(seconds);
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/command/ModeradorCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */