/*    */ package net.highmc.bukkit.gameapi.event;
/*    */ 
/*    */ import net.highmc.bukkit.event.PlayerCancellableEvent;
/*    */ import net.highmc.bukkit.gameapi.gamer.Gamer;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class GamerLoadEvent extends PlayerCancellableEvent {
/*    */   private Gamer gamer;
/*    */   private String reason;
/*    */   
/* 11 */   public void setGamer(Gamer gamer) { this.gamer = gamer; } public void setReason(String reason) { this.reason = reason; }
/*    */ 
/*    */   
/* 14 */   public Gamer getGamer() { return this.gamer; } public String getReason() {
/* 15 */     return this.reason;
/*    */   }
/*    */   public GamerLoadEvent(Player player, Gamer gamer) {
/* 18 */     super(player);
/* 19 */     this.gamer = gamer;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/event/GamerLoadEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */