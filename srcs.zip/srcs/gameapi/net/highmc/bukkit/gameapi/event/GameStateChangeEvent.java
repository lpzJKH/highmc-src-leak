/*    */ package net.highmc.bukkit.gameapi.event;
/*    */ import net.highmc.server.loadbalancer.server.MinigameState;
/*    */ 
/*    */ public class GameStateChangeEvent extends NormalEvent {
/*    */   private MinigameState oldState;
/*    */   private MinigameState state;
/*    */   
/*    */   public GameStateChangeEvent(MinigameState oldState, MinigameState state) {
/*  9 */     this.oldState = oldState; this.state = state;
/*    */   }
/*    */   
/* 12 */   public MinigameState getOldState() { return this.oldState; } public MinigameState getState() {
/* 13 */     return this.state;
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/event/GameStateChangeEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */