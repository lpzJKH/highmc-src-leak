package net.highmc.bukkit.gameapi.event;

import net.highmc.bukkit.event.NormalEvent;

public class SchedulePulseEvent extends NormalEvent {}


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/event/SchedulePulseEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */