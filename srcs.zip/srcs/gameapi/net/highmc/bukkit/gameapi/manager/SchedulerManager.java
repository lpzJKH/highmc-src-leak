/*    */ package net.highmc.bukkit.gameapi.manager;
/*    */ 
/*    */ import com.google.common.collect.ImmutableList;
/*    */ import com.google.common.collect.ImmutableMap;
/*    */ import com.google.common.collect.UnmodifiableIterator;
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import net.highmc.bukkit.gameapi.GameAPI;
/*    */ import net.highmc.bukkit.gameapi.event.SchedulePulseEvent;
/*    */ import net.highmc.bukkit.gameapi.scheduler.Scheduler;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.event.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SchedulerManager
/*    */ {
/* 24 */   private Map<String, Scheduler> schedulerMap = new HashMap<>();
/*    */ 
/*    */   
/*    */   public void loadScheduler(Scheduler scheduler) {
/* 28 */     this.schedulerMap.put(scheduler.toString().toLowerCase(), scheduler);
/*    */   }
/*    */   
/*    */   public void loadScheduler(String identifier, Scheduler scheduler) {
/* 32 */     this.schedulerMap.put(identifier, scheduler);
/*    */   }
/*    */   
/*    */   public void unloadSchedulers() {
/* 36 */     this.schedulerMap.clear();
/*    */   }
/*    */   
/*    */   public Collection<Scheduler> getSchedulers() {
/* 40 */     return (Collection<Scheduler>)ImmutableList.copyOf(this.schedulerMap.values());
/*    */   }
/*    */   
/*    */   public void unloadScheduler(Scheduler scheduler) {
/* 44 */     String identifier = null;
/*    */     
/* 46 */     for (Map.Entry<String, Scheduler> entry : this.schedulerMap.entrySet()) {
/* 47 */       if (entry.getValue() == scheduler) {
/* 48 */         identifier = entry.getKey();
/*    */         break;
/*    */       } 
/*    */     } 
/* 52 */     if (identifier != null)
/* 53 */       this.schedulerMap.remove(identifier); 
/*    */   }
/*    */   
/*    */   public void unloadScheduler(String identifier) {
/* 57 */     this.schedulerMap.remove(identifier);
/*    */   }
/*    */   
/*    */   public void pulse() {
/* 61 */     boolean pulse = false;
/* 62 */     UnmodifiableIterator<Scheduler> unmodifiableIterator = ImmutableMap.copyOf(this.schedulerMap).values().iterator();
/*    */     
/* 64 */     while (unmodifiableIterator.hasNext()) {
/* 65 */       ((Scheduler)unmodifiableIterator.next()).pulse();
/* 66 */       pulse = true;
/*    */     } 
/*    */     
/* 69 */     if (pulse) {
/* 70 */       Bukkit.getPluginManager().callEvent((Event)new SchedulePulseEvent());
/*    */     }
/* 72 */     if (GameAPI.getInstance().isTimer())
/* 73 */       GameAPI.getInstance().setTime(
/* 74 */           GameAPI.getInstance().getTime() + (GameAPI.getInstance().getState().isDecrementTime() ? -1 : 1)); 
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/manager/SchedulerManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */