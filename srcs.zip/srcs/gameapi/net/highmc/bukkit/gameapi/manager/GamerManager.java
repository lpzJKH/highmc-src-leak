/*    */ package net.highmc.bukkit.gameapi.manager;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Comparator;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import java.util.function.Predicate;
/*    */ import java.util.stream.Collectors;
/*    */ import java.util.stream.Stream;
/*    */ import net.highmc.bukkit.gameapi.gamer.Gamer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GamerManager
/*    */ {
/* 20 */   private Map<UUID, Gamer> gamerMap = new HashMap<>();
/*    */ 
/*    */   
/*    */   public void loadGamer(Gamer gamer) {
/* 24 */     this.gamerMap.put(gamer.getUniqueId(), gamer);
/*    */   }
/*    */   
/*    */   public void unloadGamer(UUID uniqueId) {
/* 28 */     this.gamerMap.remove(uniqueId);
/*    */   }
/*    */   
/*    */   public <T extends Gamer> T getGamer(UUID uniqueId, Class<T> clazz) {
/* 32 */     return this.gamerMap.containsKey(uniqueId) ? clazz.cast(this.gamerMap.get(uniqueId)) : null;
/*    */   }
/*    */   
/*    */   public Gamer getGamer(UUID uniqueId) {
/* 36 */     return this.gamerMap.get(uniqueId);
/*    */   }
/*    */   
/*    */   public boolean hasGamer(UUID uniqueId) {
/* 40 */     return this.gamerMap.containsKey(uniqueId);
/*    */   }
/*    */   
/*    */   public <T extends Gamer> List<T> filter(Predicate<T> filter, Class<T> clazz) {
/* 44 */     return (List<T>)this.gamerMap.values().stream().map(gamer -> (Gamer)clazz.cast(gamer)).filter(filter).collect(Collectors.toList());
/*    */   }
/*    */   
/*    */   public <T extends Gamer> List<T> sort(Comparator<? super T> filter, Class<T> clazz) {
/* 48 */     return (List<T>)this.gamerMap.values().stream().map(gamer -> (Gamer)clazz.cast(gamer)).sorted(filter).collect(Collectors.toList());
/*    */   }
/*    */   
/*    */   public <T extends Gamer> Stream<T> stream(Class<T> clazz) {
/* 52 */     return this.gamerMap.values().stream().map(gamer -> (Gamer)clazz.cast(gamer));
/*    */   }
/*    */   
/*    */   public <T extends Gamer> Collection<T> getGamers(Class<T> clazz) {
/* 56 */     return (Collection<T>)this.gamerMap.values().stream().map(gamer -> (Gamer)clazz.cast(gamer)).collect(Collectors.toList());
/*    */   }
/*    */ }


/* Location:              /home/uni/Área de trabalho/aaa/Bedwars.jar!/net/highmc/bukkit/gameapi/manager/GamerManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */