/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package net.highmc.bukkit.pvp.event;

import net.highmc.bukkit.event.PlayerEvent;
import org.bukkit.entity.Player;

public class PlayerSpawnEvent
extends PlayerEvent {
    public PlayerSpawnEvent(Player player) {
        super(player);
    }
}

