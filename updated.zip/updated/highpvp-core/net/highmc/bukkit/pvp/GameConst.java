/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.bukkit.pvp;

import java.util.Arrays;
import java.util.List;

public class GameConst {
    public static final long COMBATLOG_DELAY = 12000L;
    public static final String COMBATLOG_METADATA = "combatlog";
    public static final List<String> BLOCKED_COMMANDS = Arrays.asList("spawn");
}

