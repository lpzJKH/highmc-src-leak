/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableSet
 */
package net.highmc.bukkit.lobby.manager;

import com.google.common.collect.ImmutableSet;
import java.util.HashSet;
import java.util.Set;
import net.highmc.backend.data.DataServerMessage;
import net.highmc.bukkit.lobby.server.ServerWatcher;
import net.highmc.server.loadbalancer.server.ProxiedServer;

public class ServerWatcherManager {
    private Set<ServerWatcher> serverWatcherSet = new HashSet<ServerWatcher>();

    public void watch(ServerWatcher serverWatcher) {
        this.serverWatcherSet.add(serverWatcher);
    }

    public void pulse(ProxiedServer server, DataServerMessage<?> data) {
        ImmutableSet.copyOf(this.serverWatcherSet).forEach(serverWatcher -> serverWatcher.pulse(server, data));
    }
}

