/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.md_5.bungee.api.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.ItemStack
 */
package net.highmc.bukkit.lobby.menu;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.highmc.bukkit.lobby.CoreMain;
import net.highmc.bukkit.lobby.gamer.Gamer;
import net.highmc.bukkit.lobby.wadgets.Heads;
import net.highmc.bukkit.lobby.wadgets.Particles;
import net.highmc.bukkit.lobby.wadgets.Wadget;
import net.highmc.bukkit.lobby.wadgets.Wings;
import net.highmc.bukkit.utils.item.ItemBuilder;
import net.highmc.bukkit.utils.menu.MenuInventory;
import net.highmc.bukkit.utils.menu.MenuItem;
import net.highmc.bukkit.utils.menu.click.ClickType;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class CosmeticsInventory {
    private int itemsPerPage = 21;

    /*
     * WARNING - void declaration
     */
    public CosmeticsInventory(Player player, Wadget wadget, int page) {
        Gamer gamer = CoreMain.getInstance().getGamerManager().getGamer(player.getUniqueId());
        MenuInventory menuInventory = new MenuInventory("\u00a77Cosm\u00e9ticos", wadget == null ? 3 : 6);
        if (wadget == null) {
            for (int i = 0; i < Wadget.values().length; ++i) {
                Wadget actual = Wadget.values()[i];
                List<Heads> list = Arrays.asList(actual == Wadget.HEADS ? Heads.values() : (actual == Wadget.CAPES ? Wings.values() : Particles.values()));
                long totalOwned = list.stream().filter(o -> player.hasPermission("lobby.wadgets") || player.hasPermission(actual.name().toLowerCase() + "." + o.name().toLowerCase())).count();
                menuInventory.setItem(11 + i * 2, new ItemBuilder().name("\u00a7a" + actual.getName()).type(actual.getType()).lore("", "\u00a77Dispon\u00edvel: \u00a7f" + totalOwned + "/" + list.size()).build(), (p, inv, type, stack, slot) -> new CosmeticsInventory(player, actual, 1));
            }
        } else {
            void var10_20;
            ArrayList<MenuItem> items = new ArrayList<MenuItem>();
            switch (wadget) {
                case HEADS: {
                    for (Enum enum_ : Heads.values()) {
                        if (player.hasPermission("lobby.cosmetics") || player.hasPermission(wadget.name().toLowerCase() + "." + enum_.name().toLowerCase())) {
                            items.add(new MenuItem(new ItemBuilder().type(Material.SKULL_ITEM).durability(3).name("\u00a7a" + ((Heads)enum_).getHeadName()).lore("", "\u00a7eClique aqui para selecionar.").skin(((Heads)enum_).getValue(), "").build(), (arg_0, arg_1, arg_2, arg_3, arg_4) -> CosmeticsInventory.lambda$new$2((Heads)enum_, arg_0, arg_1, arg_2, arg_3, arg_4)));
                            continue;
                        }
                        items.add(new MenuItem(new ItemBuilder().type(Material.INK_SACK).durability(8).name("\u00a7a" + ((Heads)enum_).getHeadName()).lore("", "\u00a77Exclusivo para \u00a7aVIP", "", "\u00a7cVoc\u00ea n\u00e3o possui esse item.").skin(((Heads)enum_).getValue(), "").build()));
                    }
                    menuInventory.setItem(new MenuItem(new ItemBuilder().type(Material.BARRIER).name("\u00a7cRemover cabe\u00e7a").build(), (p, inv, type, stack, s) -> {
                        p.getInventory().setHelmet(null);
                        p.closeInventory();
                    }), 49);
                    break;
                }
                case CAPES: {
                    for (Enum enum_ : Wings.values()) {
                        if (player.hasPermission("lobby.cosmetics") || player.hasPermission(wadget.name().toLowerCase() + "." + enum_.name().toLowerCase())) {
                            items.add(new MenuItem(new ItemBuilder().type(Material.INK_SACK).durability(10).name("\u00a7a" + ((Wings)enum_).getName()).build(), (arg_0, arg_1, arg_2, arg_3, arg_4) -> CosmeticsInventory.lambda$new$4(gamer, (Wings)enum_, player, arg_0, arg_1, arg_2, arg_3, arg_4)));
                            continue;
                        }
                        items.add(new MenuItem(((Wings)enum_).getItem().name(((Wings)enum_).getName()).type(Material.INK_SACK).durability(8).lore("", "\u00a77Exclusivo para \u00a7aVIP", "", "\u00a7cVoc\u00ea n\u00e3o possui esse item.").build()));
                    }
                    menuInventory.setItem(new MenuItem(new ItemBuilder().type(Material.BARRIER).name("\u00a7cRemover cabe\u00e7a").build(), (p, inv, type, stack, s) -> {
                        gamer.setUsingParticle(false);
                        gamer.setCape(false);
                        gamer.setWing(null);
                        gamer.setParticle(null);
                        player.closeInventory();
                    }), 49);
                    break;
                }
                case PARTICLES: {
                    for (Enum enum_ : Particles.values()) {
                        if (player.hasPermission("lobby.cosmetics") || player.hasPermission(wadget.name().toLowerCase() + "." + enum_.name().toLowerCase())) {
                            items.add(new MenuItem(new ItemBuilder().type(Material.INK_SACK).durability(10).name("\u00a7a" + ((Particles)enum_).getName()).build(), (arg_0, arg_1, arg_2, arg_3, arg_4) -> CosmeticsInventory.lambda$new$6(gamer, (Particles)enum_, player, arg_0, arg_1, arg_2, arg_3, arg_4)));
                            continue;
                        }
                        items.add(new MenuItem(((Particles)enum_).getItem().name(((Particles)enum_).getName()).type(Material.INK_SACK).durability(8).lore("", "\u00a77Exclusivo para \u00a7aVIP", "", "\u00a7cVoc\u00ea n\u00e3o possui esse item.").build()));
                    }
                    menuInventory.setItem(new MenuItem(new ItemBuilder().type(Material.BARRIER).name("\u00a7cRemover cabe\u00e7a").build(), (p, inv, type, stack, s) -> {
                        gamer.setUsingParticle(false);
                        gamer.setCape(false);
                        gamer.setParticle(null);
                        player.closeInventory();
                    }), 49);
                }
            }
            int pageStart = 0;
            int pageEnd = this.itemsPerPage;
            if (page > 1) {
                pageStart = (page - 1) * this.itemsPerPage;
                pageEnd = page * this.itemsPerPage;
            }
            if (pageEnd > items.size()) {
                pageEnd = items.size();
            }
            int w = 10;
            int n = pageStart;
            while (var10_20 < pageEnd) {
                MenuItem item2 = (MenuItem)items.get((int)var10_20);
                menuInventory.setItem(item2, w);
                w = w % 9 == 7 ? (w += 3) : ++w;
                ++var10_20;
            }
            if (page == 1) {
                menuInventory.setItem(47, new ItemBuilder().name("\u00a7cVoltar").type(Material.ARROW).build(), (p, inv, type, stack, slot) -> new CosmeticsInventory(player, null));
            } else {
                menuInventory.setItem(new MenuItem(new ItemBuilder().type(Material.ARROW).name("\u00a7aP\u00e1gina " + (page - 1)).build(), (p, inv, type, stack, s) -> new CosmeticsInventory(player, wadget, page - 1)), 47);
            }
            if (Math.ceil(items.size() / this.itemsPerPage) + 1.0 > (double)page) {
                menuInventory.setItem(new MenuItem(new ItemBuilder().type(Material.ARROW).name("\u00a7aP\u00e1gina " + (page + 1)).build(), (p, inventory, clickType, item, slot) -> new CosmeticsInventory(player, wadget, page + 1)), 51);
            }
        }
        menuInventory.open(player);
    }

    public CosmeticsInventory(Player player, Wadget wadget) {
        this(player, wadget, 1);
    }

    public CosmeticsInventory(Player player) {
        this(player, null, 1);
    }

    private static /* synthetic */ void lambda$new$6(Gamer gamer, Particles particle, Player player, Player p, Inventory inv, ClickType type, ItemStack stack, int slot) {
        gamer.setUsingParticle(true);
        gamer.setCape(false);
        gamer.setWing(null);
        gamer.setParticle(particle);
        player.closeInventory();
        player.sendMessage("\u00a7aColet\u00e1vel ativado: " + ChatColor.stripColor((String)particle.getName()) + "!");
    }

    private static /* synthetic */ void lambda$new$4(Gamer gamer, Wings wing, Player player, Player p, Inventory inv, ClickType type, ItemStack stack, int slot) {
        gamer.setUsingParticle(true);
        gamer.setWing(wing);
        gamer.setCape(true);
        gamer.setParticle(null);
        player.closeInventory();
        player.sendMessage("\u00a7aColet\u00e1vel ativado: " + ChatColor.stripColor((String)wing.getName()) + "!");
    }

    private static /* synthetic */ void lambda$new$2(Heads heads, Player p, Inventory inv, ClickType type, ItemStack stack, int slot) {
        p.getInventory().setHelmet(stack);
        p.closeInventory();
        p.sendMessage("\u00a7aColet\u00e1vel ativado: Chap\u00e9u do " + heads.getHeadName());
    }
}

