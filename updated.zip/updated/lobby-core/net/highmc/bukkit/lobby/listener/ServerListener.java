/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 */
package net.highmc.bukkit.lobby.listener;

import net.highmc.bukkit.event.server.ServerEvent;
import net.highmc.bukkit.lobby.CoreMain;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

public class ServerListener
implements Listener {
    @EventHandler
    public void onServer(ServerEvent event) {
        CoreMain.getInstance().getServerWatcherManager().pulse(event.getProxiedServer(), event.getData());
    }
}

