/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.bukkit.lobby.lobby.scoreboard;

public interface ScoreboardAnimation {
    public String next();
}

