/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.bukkit.lobby;

import net.highmc.CommonPlugin;

public class LobbyConst {
    public static final String TITLE_HEADER = "\u00a7d\u00a7lHIGH";
    public static final String TITLE_FOOTER = "\u00a7eSeja bem-vindo!";
    public static final String TAB_HEADER = "\n\u00a7d\u00a7lHIGH\n";
    public static final String TAB_FOOTER = "\u00a7f\n\u00a7fWebsite: \u00a77" + CommonPlugin.getInstance().getPluginInfo().getWebsite() + "\n\u00a7fDiscord: \u00a77" + CommonPlugin.getInstance().getPluginInfo().getDiscord() + "\n\u00a7f";
}

