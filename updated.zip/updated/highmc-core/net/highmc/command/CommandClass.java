/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.command;

import net.highmc.CommonPlugin;
import net.highmc.packet.types.staff.Stafflog;
import net.highmc.server.ServerType;

public interface CommandClass {
    default public void staffLog(String message) {
        CommonPlugin.getInstance().getMemberManager().staffLog(message);
    }

    default public void staffLog(String message, boolean bungeecord) {
        if (bungeecord && CommonPlugin.getInstance().getServerType() != ServerType.BUNGEECORD) {
            CommonPlugin.getInstance().getServerData().sendPacket(new Stafflog("\u00a77[" + message + "\u00a77]"));
        } else {
            CommonPlugin.getInstance().getMemberManager().staffLog(message);
        }
    }
}

