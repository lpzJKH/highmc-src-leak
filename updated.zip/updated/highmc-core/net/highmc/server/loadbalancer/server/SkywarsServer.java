/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.server.loadbalancer.server;

import java.util.Set;
import java.util.UUID;
import net.highmc.server.ServerType;
import net.highmc.server.loadbalancer.server.MinigameServer;
import net.highmc.server.loadbalancer.server.MinigameState;

public class SkywarsServer
extends MinigameServer {
    public SkywarsServer(String serverId, ServerType type, Set<UUID> players, int maxPlayers, boolean joinEnabled) {
        super(serverId, type, players, maxPlayers, joinEnabled);
        this.setState(MinigameState.WAITING);
    }

    @Override
    public boolean canBeSelected() {
        return super.canBeSelected() && !this.isInProgress() && this.getState() == MinigameState.WAITING;
    }

    @Override
    public boolean isInProgress() {
        return this.getState() == MinigameState.PREGAME || this.getState() == MinigameState.GAMETIME || this.getState() == MinigameState.INVINCIBILITY;
    }
}

