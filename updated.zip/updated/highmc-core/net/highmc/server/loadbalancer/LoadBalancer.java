/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.server.loadbalancer;

import net.highmc.server.loadbalancer.element.LoadBalancerObject;

public interface LoadBalancer<T extends LoadBalancerObject> {
    public T next();
}

