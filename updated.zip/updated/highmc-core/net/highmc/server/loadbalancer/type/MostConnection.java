/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.server.loadbalancer.type;

import net.highmc.server.loadbalancer.BaseBalancer;
import net.highmc.server.loadbalancer.element.LoadBalancerObject;
import net.highmc.server.loadbalancer.element.NumberConnection;

public class MostConnection<T extends LoadBalancerObject & NumberConnection>
extends BaseBalancer<T> {
    @Override
    public T next() {
        LoadBalancerObject obj = null;
        if (this.nextObj != null && !this.nextObj.isEmpty()) {
            for (LoadBalancerObject item : this.nextObj) {
                if (!item.canBeSelected()) continue;
                if (obj == null) {
                    obj = item;
                    continue;
                }
                if (((NumberConnection)((Object)obj)).getActualNumber() >= ((NumberConnection)((Object)item)).getActualNumber()) continue;
                obj = item;
            }
        }
        return (T)obj;
    }

    @Override
    public int getTotalNumber() {
        int number = 0;
        for (LoadBalancerObject item : this.nextObj) {
            number += ((NumberConnection)((Object)item)).getActualNumber();
        }
        return number;
    }
}

