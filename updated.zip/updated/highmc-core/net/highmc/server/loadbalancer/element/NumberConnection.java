/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.server.loadbalancer.element;

public interface NumberConnection {
    public int getActualNumber();

    public int getMaxNumber();
}

