/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.server.loadbalancer.element;

public interface Server {
    public boolean isJoinEnabled();
}

