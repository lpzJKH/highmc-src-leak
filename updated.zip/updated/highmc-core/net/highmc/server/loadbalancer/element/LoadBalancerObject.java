/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.server.loadbalancer.element;

public interface LoadBalancerObject {
    public String getServerId();

    public long getStartTime();

    public boolean canBeSelected();
}

