/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Charsets
 *  com.google.gson.stream.JsonReader
 */
package net.highmc;

import com.google.common.base.Charsets;
import com.google.gson.stream.JsonReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.lang.reflect.Field;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Logger;
import net.highmc.CommonConst;
import net.highmc.PluginInfo;
import net.highmc.PluginPlatform;
import net.highmc.backend.data.DiscordData;
import net.highmc.backend.data.MemberData;
import net.highmc.backend.data.PartyData;
import net.highmc.backend.data.ServerData;
import net.highmc.backend.data.SkinData;
import net.highmc.backend.data.impl.DiscordDataImpl;
import net.highmc.backend.data.impl.MemberDataImpl;
import net.highmc.backend.data.impl.PartyDataImpl;
import net.highmc.backend.data.impl.ServerDataImpl;
import net.highmc.backend.data.impl.SkinDataImpl;
import net.highmc.backend.mongodb.MongoConnection;
import net.highmc.backend.redis.RedisConnection;
import net.highmc.manager.ConfigurationManager;
import net.highmc.manager.MemberManager;
import net.highmc.manager.PartyManager;
import net.highmc.manager.ReportManager;
import net.highmc.manager.StatusManager;
import net.highmc.member.party.Party;
import net.highmc.packet.types.configuration.ConfigurationFieldUpdate;
import net.highmc.packet.types.configuration.ConfigurationUpdate;
import net.highmc.permission.Group;
import net.highmc.server.ServerManager;
import net.highmc.server.ServerType;
import net.highmc.server.loadbalancer.BaseBalancer;
import net.highmc.server.loadbalancer.server.MinigameServer;
import net.highmc.server.loadbalancer.server.MinigameState;
import net.highmc.server.loadbalancer.server.ProxiedServer;
import net.highmc.utils.FileCreator;
import net.highmc.utils.configuration.DefaultFileCreator;
import net.highmc.utils.mojang.NameFetcher;
import net.highmc.utils.mojang.UUIDFetcher;

public class CommonPlugin {
    private static CommonPlugin instance;
    private PluginPlatform pluginPlatform;
    private PluginInfo pluginInfo;
    private FileCreator fileCreator;
    private ConfigurationManager configurationManager = new ConfigurationManager();
    private MemberManager memberManager = new MemberManager();
    private PartyManager partyManager = new PartyManager();
    private StatusManager statusManager = new StatusManager();
    private ReportManager reportManager = new ReportManager();
    private DiscordData discordData;
    private MemberData memberData;
    private PartyData partyData;
    private ServerData serverData;
    private SkinData skinData;
    private UUIDFetcher uuidFetcher = new UUIDFetcher();
    private NameFetcher nameFetcher = new NameFetcher();
    private String serverId = "highmc.net";
    private String serverAddress = "0.0.0.0";
    private ServerType serverType = ServerType.BUNGEECORD;
    private boolean joinEnabled = true;
    private String map = "Unknown";
    private MinigameState minigameState = MinigameState.NONE;
    private int serverTime;
    private Class<? extends Party> partyClass;
    private MongoConnection mongoConnection;
    private RedisConnection redisConnection;

    public static void set(Group group, int id) throws Exception {
        Field field = Group.class.getDeclaredField("id");
        field.setAccessible(true);
        field.set(group, id);
    }

    public CommonPlugin(PluginPlatform pluginPlatform) {
        instance = this;
        this.pluginPlatform = pluginPlatform;
        this.fileCreator = new DefaultFileCreator();
        this.loadConfig();
        try {
            this.mongoConnection = new MongoConnection(this.pluginInfo.getMongoCredentials());
            this.redisConnection = new RedisConnection(this.pluginInfo.getRedisCredentials());
            this.mongoConnection.connect();
            this.redisConnection.connect();
            this.setDiscordData(new DiscordDataImpl(this.redisConnection));
            this.setMemberData(new MemberDataImpl(this.mongoConnection, this.redisConnection));
            this.setPartyData(new PartyDataImpl(this.mongoConnection));
            this.setServerData(new ServerDataImpl(this.redisConnection));
            this.setSkinData(new SkinDataImpl(this.redisConnection));
        }
        catch (Exception ex) {
            pluginPlatform.shutdown("The database has not loaded!");
            ex.printStackTrace();
        }
        this.reportManager.loadReports();
    }

    public void loadConfig() {
        try {
            FileInputStream fileInputStream = new FileInputStream(this.fileCreator.createFile("server.json", CommonConst.PRINCIPAL_DIRECTORY));
            InputStreamReader inputStreamReader = new InputStreamReader((InputStream)fileInputStream, "UTF-8");
            JsonReader jsonReader = new JsonReader((Reader)inputStreamReader);
            this.pluginInfo = (PluginInfo)CommonConst.GSON_PRETTY.fromJson(jsonReader, PluginInfo.class);
            jsonReader.close();
            inputStreamReader.close();
            fileInputStream.close();
        }
        catch (Exception ex) {
            ex.printStackTrace();
            this.pluginPlatform.shutdown("The configuration server.json not found!");
        }
    }

    public void saveConfig(String fieldName) {
        try {
            this.pluginInfo.sort();
            String json = CommonConst.GSON_PRETTY.toJson((Object)this.pluginInfo);
            FileOutputStream fileOutputStream = new FileOutputStream(this.fileCreator.createFile("server.json", CommonConst.PRINCIPAL_DIRECTORY));
            OutputStreamWriter outputStreamReader = new OutputStreamWriter((OutputStream)fileOutputStream, "UTF-8");
            BufferedWriter bufferedWriter = new BufferedWriter(outputStreamReader);
            bufferedWriter.write(json);
            bufferedWriter.flush();
            bufferedWriter.close();
            fileOutputStream.close();
            outputStreamReader.close();
        }
        catch (Exception ex) {
            ex.printStackTrace();
            this.pluginPlatform.shutdown("The configuration server.json not found!");
        }
        CommonPlugin.getInstance().getServerData().sendPacket(new ConfigurationFieldUpdate(fieldName));
    }

    public void saveConfig() {
        try {
            this.pluginInfo.sort();
            String json = CommonConst.GSON_PRETTY.toJson((Object)this.pluginInfo);
            FileOutputStream fileOutputStream = new FileOutputStream(this.fileCreator.createFile("server.json", CommonConst.PRINCIPAL_DIRECTORY));
            OutputStreamWriter outputStreamReader = new OutputStreamWriter((OutputStream)fileOutputStream, "UTF-8");
            BufferedWriter bufferedWriter = new BufferedWriter(outputStreamReader);
            bufferedWriter.write(json);
            bufferedWriter.flush();
            bufferedWriter.close();
            fileOutputStream.close();
            outputStreamReader.close();
        }
        catch (Exception ex) {
            ex.printStackTrace();
            this.pluginPlatform.shutdown("The configuration server.json not found!");
        }
        CommonPlugin.getInstance().getServerData().sendPacket(new ConfigurationUpdate());
    }

    public Logger getLogger() {
        return this.pluginPlatform.getLogger();
    }

    public void debug(String message) {
        if (this.pluginInfo.isDebug()) {
            System.out.println("[DEBUG] " + message);
        }
    }

    public void loadServers(ServerManager serverManager) {
        for (Map.Entry<String, Map<String, String>> entry : this.getServerData().loadServers().entrySet()) {
            try {
                if (!entry.getValue().containsKey("type") || !entry.getValue().containsKey("address") || !entry.getValue().containsKey("maxplayers") || ServerType.valueOf(entry.getValue().get("type").toUpperCase()) == ServerType.BUNGEECORD) continue;
                ProxiedServer proxiedServer = serverManager.addActiveServer(entry.getValue().get("address"), entry.getKey(), ServerType.valueOf(entry.getValue().get("type").toUpperCase()), Integer.valueOf(entry.getValue().get("maxplayers")), Long.valueOf(entry.getValue().get("starttime")));
                proxiedServer.setOnlinePlayers(this.getServerData().getPlayers(entry.getKey()));
                proxiedServer.setJoinEnabled(Boolean.valueOf(entry.getValue().get("joinenabled")));
                if (proxiedServer instanceof MinigameServer) {
                    MinigameServer minigameServer = (MinigameServer)proxiedServer;
                    minigameServer.setTime(this.getServerData().getTime(entry.getKey()));
                    minigameServer.setMap(this.getServerData().getMap(entry.getKey()));
                    minigameServer.setState(this.getServerData().getState(entry.getKey()));
                }
                this.debug("The server " + proxiedServer.getServerId() + " (" + (Object)((Object)proxiedServer.getServerType()) + " - " + proxiedServer.getOnlinePlayers() + "/" + proxiedServer.getMaxPlayers() + ") has been loaded!");
            }
            catch (Exception exception) {}
        }
        int players = 0;
        for (BaseBalancer<ProxiedServer> baseBalancer : serverManager.getBalancers().values()) {
            players += baseBalancer.getTotalNumber();
        }
        serverManager.setTotalMembers(players);
    }

    public UUID getUniqueId(String name) {
        return this.getUniqueId(name, true);
    }

    public UUID getUniqueId(String name, boolean cracked) {
        UUID uniqueId = this.getMemberData().getUniqueId(name);
        if (uniqueId != null) {
            return uniqueId;
        }
        uniqueId = this.uuidFetcher.getUUID(name);
        return uniqueId == null && cracked ? UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(Charsets.UTF_8)) : uniqueId;
    }

    public String formatTime(long time) {
        String[] all = CommonConst.FULL_DATE_FORMAT.format(time).split(" ");
        String month = all[2];
        String[] dates = all[0].split("/");
        return dates[0] + " de " + month.toLowerCase() + " de " + dates[2] + " \u00e0s " + all[1];
    }

    public static CommonPlugin createVoid() {
        return new CommonPlugin(new PluginPlatform(){

            @Override
            public void shutdown(String message) {
            }

            @Override
            public void runAsync(Runnable runnable, long delay, long repeat) {
                runnable.run();
            }

            @Override
            public void runAsync(Runnable runnable, long delay) {
                runnable.run();
            }

            @Override
            public void runAsync(Runnable runnable) {
                runnable.run();
            }

            @Override
            public void run(Runnable runnable, long delay, long repeat) {
                runnable.run();
            }

            @Override
            public void run(Runnable runnable, long delay) {
                runnable.run();
            }

            @Override
            public UUID getUniqueId(String playerName) {
                return null;
            }

            @Override
            public Logger getLogger() {
                return Logger.getLogger("premium");
            }

            @Override
            public void dispatchCommand(String command) {
            }

            @Override
            public void broadcast(String string) {
            }

            @Override
            public void broadcast(String string, String permission) {
            }

            @Override
            public String getName(UUID uuid) {
                return null;
            }
        });
    }

    public PluginPlatform getPluginPlatform() {
        return this.pluginPlatform;
    }

    public PluginInfo getPluginInfo() {
        return this.pluginInfo;
    }

    public FileCreator getFileCreator() {
        return this.fileCreator;
    }

    public ConfigurationManager getConfigurationManager() {
        return this.configurationManager;
    }

    public MemberManager getMemberManager() {
        return this.memberManager;
    }

    public PartyManager getPartyManager() {
        return this.partyManager;
    }

    public StatusManager getStatusManager() {
        return this.statusManager;
    }

    public ReportManager getReportManager() {
        return this.reportManager;
    }

    public DiscordData getDiscordData() {
        return this.discordData;
    }

    public MemberData getMemberData() {
        return this.memberData;
    }

    public PartyData getPartyData() {
        return this.partyData;
    }

    public ServerData getServerData() {
        return this.serverData;
    }

    public SkinData getSkinData() {
        return this.skinData;
    }

    public UUIDFetcher getUuidFetcher() {
        return this.uuidFetcher;
    }

    public NameFetcher getNameFetcher() {
        return this.nameFetcher;
    }

    public String getServerId() {
        return this.serverId;
    }

    public String getServerAddress() {
        return this.serverAddress;
    }

    public ServerType getServerType() {
        return this.serverType;
    }

    public boolean isJoinEnabled() {
        return this.joinEnabled;
    }

    public String getMap() {
        return this.map;
    }

    public MinigameState getMinigameState() {
        return this.minigameState;
    }

    public int getServerTime() {
        return this.serverTime;
    }

    public Class<? extends Party> getPartyClass() {
        return this.partyClass;
    }

    public MongoConnection getMongoConnection() {
        return this.mongoConnection;
    }

    public RedisConnection getRedisConnection() {
        return this.redisConnection;
    }

    public static CommonPlugin getInstance() {
        return instance;
    }

    public void setPluginInfo(PluginInfo pluginInfo) {
        this.pluginInfo = pluginInfo;
    }

    public void setConfigurationManager(ConfigurationManager configurationManager) {
        this.configurationManager = configurationManager;
    }

    public void setMemberManager(MemberManager memberManager) {
        this.memberManager = memberManager;
    }

    public void setPartyManager(PartyManager partyManager) {
        this.partyManager = partyManager;
    }

    public void setStatusManager(StatusManager statusManager) {
        this.statusManager = statusManager;
    }

    public void setReportManager(ReportManager reportManager) {
        this.reportManager = reportManager;
    }

    public void setDiscordData(DiscordData discordData) {
        this.discordData = discordData;
    }

    public void setMemberData(MemberData memberData) {
        this.memberData = memberData;
    }

    public void setPartyData(PartyData partyData) {
        this.partyData = partyData;
    }

    public void setServerData(ServerData serverData) {
        this.serverData = serverData;
    }

    public void setSkinData(SkinData skinData) {
        this.skinData = skinData;
    }

    public void setServerId(String serverId) {
        this.serverId = serverId;
    }

    public void setServerAddress(String serverAddress) {
        this.serverAddress = serverAddress;
    }

    public void setServerType(ServerType serverType) {
        this.serverType = serverType;
    }

    public void setJoinEnabled(boolean joinEnabled) {
        this.joinEnabled = joinEnabled;
    }

    public void setMap(String map) {
        this.map = map;
    }

    public void setMinigameState(MinigameState minigameState) {
        this.minigameState = minigameState;
    }

    public void setServerTime(int serverTime) {
        this.serverTime = serverTime;
    }

    public void setPartyClass(Class<? extends Party> partyClass) {
        this.partyClass = partyClass;
    }
}

