/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.manager;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.highmc.CommonPlugin;
import net.highmc.member.status.Status;
import net.highmc.member.status.StatusType;

public class StatusManager {
    private Map<UUID, Map<StatusType, Status>> statusMap = new HashMap<UUID, Map<StatusType, Status>>();

    public Status loadStatus(UUID uniqueId, StatusType statusType) {
        if (this.statusMap.containsKey(uniqueId) && this.statusMap.get(uniqueId).containsKey((Object)statusType)) {
            return this.statusMap.get(uniqueId).get((Object)statusType);
        }
        Status status = CommonPlugin.getInstance().getMemberData().loadStatus(uniqueId, statusType);
        this.statusMap.computeIfAbsent(uniqueId, v -> new HashMap()).put(statusType, status);
        return status;
    }

    public void preloadStatus(UUID uniqueId, StatusType statusType) {
        if (this.statusMap.containsKey(uniqueId) && this.statusMap.get(uniqueId).containsKey((Object)statusType)) {
            return;
        }
        Status status = CommonPlugin.getInstance().getMemberData().loadStatus(uniqueId, statusType);
        this.statusMap.computeIfAbsent(uniqueId, v -> new HashMap()).put(statusType, status);
    }

    public void unloadStatus(UUID uniqueId) {
        this.statusMap.remove(uniqueId);
    }
}

