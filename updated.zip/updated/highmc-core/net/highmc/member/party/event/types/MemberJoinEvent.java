/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.member.party.event.types;

import java.util.UUID;
import net.highmc.member.party.event.PartyEvent;

public class MemberJoinEvent
extends PartyEvent {
    private UUID memberId;

    public UUID getMemberId() {
        return this.memberId;
    }

    public MemberJoinEvent(UUID memberId) {
        this.memberId = memberId;
    }
}

