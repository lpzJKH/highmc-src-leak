/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.member.party.event.types;

import java.util.UUID;
import net.highmc.member.party.event.PartyEvent;

public class MemberLeaveEvent
extends PartyEvent {
    private UUID memberId;

    public UUID getMemberId() {
        return this.memberId;
    }

    public MemberLeaveEvent(UUID memberId) {
        this.memberId = memberId;
    }
}

