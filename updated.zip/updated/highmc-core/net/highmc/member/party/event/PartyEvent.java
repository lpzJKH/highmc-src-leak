/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.member.party.event;

public abstract class PartyEvent {
}

