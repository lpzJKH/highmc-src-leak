/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.member.status;

public enum StatusType {
    HG,
    PVP,
    SKYWARS,
    BEDWARS;

}

