/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.utils.supertype;

public interface FutureCallback<T> {
    public void result(T var1, Throwable var2);
}

