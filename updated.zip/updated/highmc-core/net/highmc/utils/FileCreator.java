/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.utils;

import java.io.File;

public interface FileCreator {
    public File createFile(String var1, String var2) throws Exception;
}

