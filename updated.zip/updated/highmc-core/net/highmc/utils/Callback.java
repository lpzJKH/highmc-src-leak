/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.utils;

public abstract class Callback<T> {
    private T callback;

    public abstract void callback(T var1);

    public T getCallback() {
        return this.callback;
    }
}

