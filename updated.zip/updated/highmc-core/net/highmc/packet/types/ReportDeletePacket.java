/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.packet.types;

import java.util.UUID;
import net.highmc.CommonPlugin;
import net.highmc.packet.Packet;
import net.highmc.packet.PacketType;

public class ReportDeletePacket
extends Packet {
    private UUID reportId;

    public ReportDeletePacket(UUID reportId) {
        super(PacketType.REPORT_DELETE);
        this.reportId = reportId;
    }

    @Override
    public void receive() {
        CommonPlugin.getInstance().getReportManager().deleteReport(this.reportId);
    }
}

