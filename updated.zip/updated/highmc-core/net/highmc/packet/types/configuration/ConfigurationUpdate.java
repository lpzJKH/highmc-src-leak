/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 */
package net.highmc.packet.types.configuration;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.highmc.CommonConst;
import net.highmc.CommonPlugin;
import net.highmc.PluginInfo;
import net.highmc.packet.Packet;
import net.highmc.packet.PacketType;

public class ConfigurationUpdate
extends Packet {
    private JsonObject jsonObject = CommonConst.GSON.toJsonTree((Object)CommonPlugin.getInstance().getPluginInfo()).getAsJsonObject();

    public ConfigurationUpdate() {
        super(PacketType.CONFIGURATION_UPDATE);
    }

    @Override
    public void receive() {
        CommonPlugin.getInstance().setPluginInfo((PluginInfo)CommonConst.GSON.fromJson((JsonElement)this.jsonObject, PluginInfo.class));
    }
}

