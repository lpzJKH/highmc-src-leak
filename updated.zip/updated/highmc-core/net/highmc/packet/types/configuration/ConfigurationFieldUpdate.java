/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package net.highmc.packet.types.configuration;

import com.google.gson.JsonObject;
import java.lang.reflect.Field;
import net.highmc.CommonConst;
import net.highmc.CommonPlugin;
import net.highmc.PluginInfo;
import net.highmc.packet.Packet;
import net.highmc.packet.PacketType;
import net.highmc.utils.json.JsonBuilder;
import net.highmc.utils.json.JsonUtils;
import net.highmc.utils.reflection.Reflection;

public class ConfigurationFieldUpdate
extends Packet {
    private JsonObject jsonObject;

    public ConfigurationFieldUpdate(String fieldName) {
        super(PacketType.CONFIGURATION_FIELD_UPDATE);
        JsonObject tree = JsonUtils.jsonTree(CommonPlugin.getInstance().getPluginInfo());
        this.jsonObject = new JsonBuilder().addProperty("fieldName", fieldName).add("value", tree.get(fieldName)).build();
    }

    @Override
    public void receive() {
        try {
            Field f = Reflection.getField(PluginInfo.class, this.jsonObject.get("fieldName").getAsString());
            Object object = CommonConst.GSON.fromJson(this.jsonObject.get("value"), f.getGenericType());
            f.setAccessible(true);
            f.set(CommonPlugin.getInstance().getPluginInfo(), object);
        }
        catch (IllegalAccessException | IllegalArgumentException | SecurityException e) {
            e.printStackTrace();
        }
    }
}

