/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 */
package net.highmc.packet.types.party;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.highmc.CommonConst;
import net.highmc.CommonPlugin;
import net.highmc.member.party.Party;
import net.highmc.packet.Packet;
import net.highmc.packet.PacketType;

public class PartyCreate
extends Packet {
    private JsonObject jsonObject;

    public PartyCreate(Party party) {
        super(PacketType.PARTY_CREATE);
        this.jsonObject = CommonConst.GSON.toJsonTree((Object)party).getAsJsonObject();
    }

    @Override
    public void receive() {
        Party party = (Party)CommonConst.GSON.fromJson((JsonElement)this.jsonObject, CommonPlugin.getInstance().getPartyClass());
        if (party != null) {
            CommonPlugin.getInstance().getPartyManager().loadParty(party);
            System.out.println("pacote recebido");
        }
    }

    public JsonObject getJsonObject() {
        return this.jsonObject;
    }
}

