/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.packet.types.party;

import java.util.UUID;
import net.highmc.CommonPlugin;
import net.highmc.member.party.Party;
import net.highmc.packet.Packet;
import net.highmc.packet.PacketType;

public class PartyDelete
extends Packet {
    private UUID partyId;

    public PartyDelete(UUID partyId) {
        super(PacketType.PARTY_DELETE);
        this.partyId = partyId;
    }

    @Override
    public void receive() {
        Party party = CommonPlugin.getInstance().getPartyManager().getPartyById(this.partyId);
        if (party != null) {
            CommonPlugin.getInstance().getPartyManager().unloadParty(this.partyId);
        }
    }

    public UUID getPartyId() {
        return this.partyId;
    }
}

