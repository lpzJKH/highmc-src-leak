/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package net.highmc.packet.types;

import com.google.gson.JsonObject;
import java.lang.reflect.Field;
import java.util.UUID;
import net.highmc.CommonConst;
import net.highmc.CommonPlugin;
import net.highmc.packet.Packet;
import net.highmc.packet.PacketType;
import net.highmc.report.Report;
import net.highmc.utils.json.JsonBuilder;
import net.highmc.utils.json.JsonUtils;
import net.highmc.utils.reflection.Reflection;

public class ReportFieldPacket
extends Packet {
    private UUID reportId;
    private JsonObject jsonObject;

    public ReportFieldPacket(Report report, String fieldName) {
        super(PacketType.REPORT_FIELD);
        JsonObject tree = JsonUtils.jsonTree(report);
        this.reportId = report.getReportId();
        this.jsonObject = new JsonBuilder().addProperty("fieldName", fieldName).add("value", tree.get(fieldName)).build();
    }

    @Override
    public void receive() {
        Report report = CommonPlugin.getInstance().getReportManager().getReportById(this.reportId);
        if (report != null) {
            try {
                Field f = Reflection.getField(Report.class, this.jsonObject.get("fieldName").getAsString());
                Object object = CommonConst.GSON.fromJson(this.jsonObject.get("value"), f.getGenericType());
                f.setAccessible(true);
                f.set(report, object);
            }
            catch (IllegalAccessException | IllegalArgumentException | SecurityException e) {
                e.printStackTrace();
            }
        }
    }
}

