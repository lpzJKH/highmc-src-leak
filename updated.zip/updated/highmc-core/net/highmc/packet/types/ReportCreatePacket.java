/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.packet.types;

import net.highmc.CommonPlugin;
import net.highmc.packet.Packet;
import net.highmc.packet.PacketType;
import net.highmc.report.Report;

public class ReportCreatePacket
extends Packet {
    private Report report;

    public ReportCreatePacket(Report report) {
        super(PacketType.REPORT_CREATE);
        this.report = report;
    }

    @Override
    public void receive() {
        CommonPlugin.getInstance().getReportManager().loadReport(this.report);
    }
}

