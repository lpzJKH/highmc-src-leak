/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.md_5.bungee.api.ProxyServer
 *  net.md_5.bungee.api.connection.ProxiedPlayer
 */
package net.highmc.packet.types;

import java.util.UUID;
import net.highmc.CommonPlugin;
import net.highmc.PluginInfo;
import net.highmc.member.Member;
import net.highmc.packet.Packet;
import net.highmc.packet.PacketType;
import net.highmc.punish.Punish;
import net.highmc.punish.PunishType;
import net.highmc.utils.DateUtils;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.connection.ProxiedPlayer;

public class PunishPlayerPacket
extends Packet {
    private UUID playerId;
    private Punish punish;

    public PunishPlayerPacket(UUID playerId, Punish punish) {
        super(PacketType.PUNISH_PLAYER);
        this.bungeecord();
        this.playerId = playerId;
        this.punish = punish;
    }

    @Override
    public void receive() {
        Member member = CommonPlugin.getInstance().getMemberManager().getMember(this.playerId);
        if (member == null && (member = CommonPlugin.getInstance().getMemberData().loadMember(this.playerId)) == null) {
            CommonPlugin.getInstance().debug("Could not find member with UUID " + this.playerId.toString());
            return;
        }
        member.getPunishConfiguration().punish(this.punish);
        member.saveConfig();
        ProxiedPlayer player = ProxyServer.getInstance().getPlayer(this.playerId);
        if (player != null && this.punish.getPunishType() == PunishType.BAN) {
            player.disconnect(PluginInfo.t(member, "ban-" + (this.punish.isPermanent() ? "permanent" : "temporary") + "-kick-message", "%reason%", this.punish.getPunishReason(), "%expireAt%", DateUtils.getTime(member.getLanguage(), this.punish.getExpireAt()), "%punisher%", this.punish.getPunisherName(), "%website%", CommonPlugin.getInstance().getPluginInfo().getWebsite(), "%store%", CommonPlugin.getInstance().getPluginInfo().getStore(), "%discord%", CommonPlugin.getInstance().getPluginInfo().getDiscord()));
        }
    }
}

