/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.packet;

import net.highmc.packet.Packet;
import net.highmc.packet.types.ActionBar;
import net.highmc.packet.types.BroadcastPacket;
import net.highmc.packet.types.PlayerMessagePacket;
import net.highmc.packet.types.PunishPlayerPacket;
import net.highmc.packet.types.ReportCreatePacket;
import net.highmc.packet.types.ReportDeletePacket;
import net.highmc.packet.types.ReportFieldPacket;
import net.highmc.packet.types.StaffchatBungeePacket;
import net.highmc.packet.types.StaffchatDiscordPacket;
import net.highmc.packet.types.configuration.ConfigurationFieldUpdate;
import net.highmc.packet.types.configuration.ConfigurationUpdate;
import net.highmc.packet.types.party.PartyCreate;
import net.highmc.packet.types.party.PartyDelete;
import net.highmc.packet.types.party.PartyField;
import net.highmc.packet.types.skin.SkinChange;
import net.highmc.packet.types.staff.Stafflog;
import net.highmc.packet.types.staff.TeleportToTarget;

public enum PacketType {
    PLAYER_MESSAGE(PlayerMessagePacket.class),
    PUNISH_PLAYER(PunishPlayerPacket.class),
    BROADCAST(BroadcastPacket.class),
    STAFFLOG(Stafflog.class),
    TELEPORT_TO_TARGET(TeleportToTarget.class),
    STAFFCHAT_DISCORD(StaffchatDiscordPacket.class),
    STAFFCHAT_BUNGEE(StaffchatBungeePacket.class),
    REPORT_CREATE(ReportCreatePacket.class),
    REPORT_DELETE(ReportDeletePacket.class),
    REPORT_FIELD(ReportFieldPacket.class),
    ACTION_BAR(ActionBar.class),
    SKIN_CHANGE(SkinChange.class),
    CONFIGURATION_UPDATE(ConfigurationUpdate.class),
    CONFIGURATION_FIELD_UPDATE(ConfigurationFieldUpdate.class),
    PARTY_CREATE(PartyCreate.class),
    PARTY_FIELD(PartyField.class),
    PARTY_DELETE(PartyDelete.class);

    private Class<? extends Packet> classType;

    public Class<? extends Packet> getClassType() {
        return this.classType;
    }

    private PacketType(Class<? extends Packet> classType) {
        this.classType = classType;
    }
}

