/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.backend;

public interface Database {
    public void connect() throws Exception;

    public boolean isConnected();

    public void close();
}

