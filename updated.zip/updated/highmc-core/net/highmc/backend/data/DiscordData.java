/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.backend.data;

public interface DiscordData {
    public String getNameByCode(String var1, boolean var2);

    public String getCodeOrCreate(String var1, String var2);
}

