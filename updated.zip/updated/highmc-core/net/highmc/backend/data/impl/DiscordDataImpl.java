/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  redis.clients.jedis.Jedis
 */
package net.highmc.backend.data.impl;

import java.util.Set;
import net.highmc.backend.data.DiscordData;
import net.highmc.backend.redis.RedisConnection;
import net.highmc.utils.string.CodeCreator;
import redis.clients.jedis.Jedis;

public class DiscordDataImpl
implements DiscordData {
    private RedisConnection redisConnection;

    @Override
    public String getNameByCode(String code, boolean delete) {
        try (Jedis jedis = this.redisConnection.getPool().getResource();){
            Set list = jedis.keys("discord-sync:*");
            for (String possible : list) {
                if (!jedis.get(possible).equals(code)) continue;
                String name = possible.replace("discord-sync:", "");
                if (delete) {
                    jedis.del(possible);
                }
                String string = name;
                return string;
            }
        }
        return null;
    }

    @Override
    public String getCodeOrCreate(String playerName, String code) {
        try (Jedis jedis = this.redisConnection.getPool().getResource();){
            boolean exists;
            boolean bl = exists = jedis.ttl("discord-sync:" + playerName.toLowerCase()) >= 0L;
            if (exists) {
                String string = jedis.get("discord-sync:" + playerName.toLowerCase());
                return string;
            }
            code = CodeCreator.DEFAULT_CREATOR_LETTERS_ONLY.random(6);
            jedis.setex("discord-sync:" + playerName.toLowerCase(), 120, code);
            String string = code;
            return string;
        }
    }

    public DiscordDataImpl(RedisConnection redisConnection) {
        this.redisConnection = redisConnection;
    }
}

