/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.backend.data;

import java.util.UUID;
import net.highmc.backend.data.Data;
import net.highmc.backend.mongodb.MongoQuery;
import net.highmc.member.party.Party;

public interface PartyData
extends Data<MongoQuery> {
    public <T extends Party> T loadParty(UUID var1, Class<T> var2);

    public void createParty(Party var1);

    public void deleteParty(Party var1);

    public void updateParty(Party var1, String var2);

    public UUID getPartyId();
}

