/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 */
package net.highmc.backend.data;

import com.google.gson.JsonElement;
import net.highmc.backend.Query;

public interface Data<T extends Query<JsonElement>> {
    public T getQuery();
}

