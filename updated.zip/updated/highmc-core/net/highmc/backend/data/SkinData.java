/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.backend.data;

import java.util.Optional;
import java.util.UUID;
import net.highmc.utils.skin.Skin;

public interface SkinData {
    public Optional<Skin> loadData(String var1);

    public void save(Skin var1, int var2);

    public String[] loadSkinById(UUID var1);
}

