/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.NonNull
 *  org.apache.commons.pool2.impl.GenericObjectPoolConfig
 *  redis.clients.jedis.Jedis
 *  redis.clients.jedis.JedisPool
 *  redis.clients.jedis.JedisPoolConfig
 *  redis.clients.jedis.JedisPubSub
 */
package net.highmc.backend.redis;

import java.util.logging.Level;
import lombok.NonNull;
import net.highmc.CommonPlugin;
import net.highmc.backend.Credentials;
import net.highmc.backend.Database;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.JedisPubSub;

public class RedisConnection
implements Database {
    @NonNull
    private final String hostname;
    @NonNull
    private final String password;
    private final int port;
    private JedisPool pool;

    public RedisConnection() {
        this("localhost", "", 6379);
    }

    public RedisConnection(Credentials credentials) {
        this(credentials.getHostName(), credentials.getPassWord(), credentials.getPort());
    }

    @Override
    public void connect() {
        JedisPoolConfig config = new JedisPoolConfig();
        config.setMaxTotal(128);
        this.pool = !this.password.isEmpty() ? new JedisPool((GenericObjectPoolConfig)config, this.hostname, this.port, 0, this.password) : new JedisPool((GenericObjectPoolConfig)config, this.hostname, this.port, 0);
    }

    @Override
    public boolean isConnected() {
        return !this.pool.isClosed();
    }

    @Override
    public void close() {
        if (this.pool != null) {
            this.pool.destroy();
        }
    }

    public RedisConnection(@NonNull String hostname, @NonNull String password, int port) {
        if (hostname == null) {
            throw new NullPointerException("hostname is marked non-null but is null");
        }
        if (password == null) {
            throw new NullPointerException("password is marked non-null but is null");
        }
        this.hostname = hostname;
        this.password = password;
        this.port = port;
    }

    public JedisPool getPool() {
        return this.pool;
    }

    public static class PubSubListener
    implements Runnable {
        private RedisConnection redis;
        private JedisPubSub jpsh;
        private final String[] channels;

        public PubSubListener(RedisConnection redis, JedisPubSub s, String ... channels) {
            this.redis = redis;
            this.jpsh = s;
            this.channels = channels;
        }

        @Override
        public void run() {
            CommonPlugin.getInstance().getLogger().log(Level.INFO, "Loading jedis!");
            try (Jedis jedis = this.redis.getPool().getResource();){
                try {
                    jedis.subscribe(this.jpsh, this.channels);
                }
                catch (Exception e) {
                    CommonPlugin.getInstance().getLogger().log(Level.INFO, "PubSub error, attempting to recover.", e);
                    try {
                        this.jpsh.unsubscribe();
                    }
                    catch (Exception exception) {
                        // empty catch block
                    }
                    this.run();
                }
            }
        }

        public void addChannel(String ... channel) {
            this.jpsh.subscribe(channel);
        }

        public void removeChannel(String ... channel) {
            this.jpsh.unsubscribe(channel);
        }

        public void poison() {
            this.jpsh.unsubscribe();
        }
    }
}

