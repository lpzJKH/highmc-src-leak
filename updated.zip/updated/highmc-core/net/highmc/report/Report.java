/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.report;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.highmc.CommonPlugin;
import net.highmc.command.CommandSender;
import net.highmc.member.Member;
import net.highmc.report.ReportInfo;

public class Report {
    private final UUID reportId;
    private String playerName;
    private Map<UUID, ReportInfo> reportMap;
    private UUID lastReport;
    private long createdAt;
    private boolean online;

    public Report(Member reported, CommandSender reporter, String reason, boolean online) {
        this.reportId = reported.getUniqueId();
        this.playerName = reported.getName();
        this.reportMap = new HashMap<UUID, ReportInfo>();
        this.lastReport = reporter.getUniqueId();
        this.createdAt = System.currentTimeMillis();
        this.online = online;
        this.addReport(reporter, reason);
    }

    public void setOnline(boolean online) {
        this.online = online;
        CommonPlugin.getInstance().getMemberData().updateReport(this, "online");
    }

    public void addReport(CommandSender reporter, String reason) {
        this.reportMap.put(reporter.getUniqueId(), new ReportInfo(reporter.getName(), reason));
        this.lastReport = reporter.getUniqueId();
        CommonPlugin.getInstance().getMemberData().updateReport(this, "reportMap");
        CommonPlugin.getInstance().getMemberData().updateReport(this, "lastReport");
    }

    public void deleteReport() {
        CommonPlugin.getInstance().getReportManager().deleteReport(this.reportId);
        CommonPlugin.getInstance().getMemberData().deleteReport(this.reportId);
    }

    public ReportInfo getLastReport() {
        return this.reportMap.get(this.lastReport);
    }

    public long getExpiresAt() {
        return this.getLastReport().getCreatedAt() + 10800000L;
    }

    public boolean hasExpired() {
        return this.getExpiresAt() < System.currentTimeMillis();
    }

    public void notifyPunish() {
        for (Map.Entry<UUID, ReportInfo> entry : this.getReportMap().entrySet()) {
            Member member = CommonPlugin.getInstance().getMemberManager().getMember(entry.getKey());
            if (member == null) continue;
            member.sendMessage("\u00a7aUm jogador que voc\u00ea denunciou recentemente foi banido.");
            member.sendMessage("\u00a7aObrigado por ajudar nossa comunidade!");
        }
        this.deleteReport();
    }

    public UUID getReportId() {
        return this.reportId;
    }

    public String getPlayerName() {
        return this.playerName;
    }

    public Map<UUID, ReportInfo> getReportMap() {
        return this.reportMap;
    }

    public long getCreatedAt() {
        return this.createdAt;
    }

    public boolean isOnline() {
        return this.online;
    }
}

