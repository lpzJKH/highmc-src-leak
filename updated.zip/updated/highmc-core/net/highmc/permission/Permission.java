/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.permission;

public class Permission {
    private String permission;

    public String getPermission() {
        return this.permission;
    }
}

