/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.bukkit.gameapi.bedwars.event.island;

import net.highmc.bukkit.event.NormalEvent;
import net.highmc.bukkit.gameapi.bedwars.island.Island;

public class IslandLoseEvent
extends NormalEvent {
    private Island island;

    public Island getIsland() {
        return this.island;
    }

    public IslandLoseEvent(Island island) {
        this.island = island;
    }
}

