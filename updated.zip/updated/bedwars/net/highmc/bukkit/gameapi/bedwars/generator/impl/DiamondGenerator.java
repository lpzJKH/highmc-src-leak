/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.inventory.ItemStack
 */
package net.highmc.bukkit.gameapi.bedwars.generator.impl;

import net.highmc.bukkit.gameapi.bedwars.generator.Generator;
import net.highmc.bukkit.gameapi.bedwars.generator.GeneratorType;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public class DiamondGenerator
extends Generator {
    public DiamondGenerator(Location location) {
        super(location, GeneratorType.DIAMOND, new ItemStack(Material.DIAMOND));
    }
}

