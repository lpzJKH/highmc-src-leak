/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.bukkit.gameapi.bedwars.event.island;

import net.highmc.bukkit.event.NormalEvent;
import net.highmc.bukkit.gameapi.bedwars.island.Island;
import net.highmc.bukkit.gameapi.bedwars.island.IslandUpgrade;

public class IslandUpgradeEvent
extends NormalEvent {
    private Island island;
    private IslandUpgrade upgrade;
    private int level;

    public Island getIsland() {
        return this.island;
    }

    public IslandUpgrade getUpgrade() {
        return this.upgrade;
    }

    public int getLevel() {
        return this.level;
    }

    public IslandUpgradeEvent(Island island, IslandUpgrade upgrade, int level) {
        this.island = island;
        this.upgrade = upgrade;
        this.level = level;
    }
}

