/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package net.highmc.bukkit.gameapi.bedwars.menu.creator;

import net.highmc.bukkit.utils.menu.MenuInventory;
import org.bukkit.entity.Player;

public class GeneratorCreatorInventory {
    public GeneratorCreatorInventory(Player player) {
        MenuInventory menuInventory = new MenuInventory("\u00a77Criar geradores", 3);
        menuInventory.open(player);
    }
}

