/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.bukkit.gameapi.bedwars.event;

import net.highmc.bukkit.event.NormalEvent;

public class GameStartEvent
extends NormalEvent {
}

