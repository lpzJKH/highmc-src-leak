/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.md_5.bungee.api.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.Sound
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 */
package net.highmc.bukkit.gameapi.bedwars.menu;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.highmc.bukkit.gameapi.GameAPI;
import net.highmc.bukkit.gameapi.bedwars.GameMain;
import net.highmc.bukkit.gameapi.bedwars.gamer.Gamer;
import net.highmc.bukkit.gameapi.bedwars.island.Island;
import net.highmc.bukkit.gameapi.bedwars.menu.FavoriteConfigInventory;
import net.highmc.bukkit.gameapi.bedwars.store.ShopCategory;
import net.highmc.bukkit.gameapi.bedwars.utils.GamerHelper;
import net.highmc.bukkit.utils.item.ItemBuilder;
import net.highmc.bukkit.utils.menu.MenuInventory;
import net.highmc.bukkit.utils.menu.click.ClickType;
import net.highmc.language.Language;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

public class StoreInventory {
    public StoreInventory(Player player) {
        this(player, ShopCategory.FAVORITES);
    }

    /*
     * WARNING - void declaration
     */
    public StoreInventory(final Player player, ShopCategory storeCategory) {
        int i;
        Island island = GameMain.getInstance().getIslandManager().getIsland(player.getUniqueId());
        if (island == null) {
            return;
        }
        Gamer gamer = GameAPI.getInstance().getGamerManager().getGamer(player.getUniqueId(), Gamer.class);
        if (!gamer.isAlive()) {
            return;
        }
        MenuInventory menuInventory = new MenuInventory("\u00a77" + storeCategory.getName(), 6);
        for (i = 0; i < ShopCategory.values().length; ++i) {
            ShopCategory category = ShopCategory.values()[i];
            menuInventory.setItem(i, new ItemBuilder().name("\u00a7a" + category.getName()).type(category.getMaterial()).lore(category == storeCategory ? "" : "\u00a7e\u00a7%click-to-see%\u00a7").build(), (p, inv, type, stack, slot) -> {
                new StoreInventory(player, category);
                player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 1.0f);
            });
        }
        for (i = 0; i < 8; ++i) {
            menuInventory.setItem(9 + i, new ItemBuilder().name(" ").type(Material.STAINED_GLASS_PANE).durability(storeCategory.ordinal() == i ? 5 : 15).build());
        }
        ArrayList<ShopCategory.ShopItem> list = new ArrayList<ShopCategory.ShopItem>(storeCategory.getShopItem());
        switch (storeCategory) {
            case FAVORITES: {
                void var8_13;
                for (Map.Entry entry : gamer.getFavoriteMap().entrySet()) {
                    ShopCategory shopCategory = (ShopCategory)((Object)entry.getKey());
                    List<ShopCategory.ShopItem> shopItems = shopCategory.getShopItem();
                    for (Integer integer : (Set)entry.getValue()) {
                        if (integer < 0 || integer >= shopItems.size()) continue;
                        list.add(shopItems.get(integer));
                    }
                }
                int w = 19;
                boolean bl = false;
                while (storeCategory == ShopCategory.FAVORITES ? var8_13 < 21 : var8_13 < list.size()) {
                    if (var8_13 < list.size()) {
                        ShopCategory.ShopItem item = (ShopCategory.ShopItem)list.get((int)var8_13);
                        if (item.getStack().getType() == Material.GOLD_AXE) {
                            item = gamer.getAxeLevel().getNext().getAsShopItem();
                        } else if (item.getStack().getType() == Material.GOLD_PICKAXE) {
                            item = gamer.getPickaxeLevel().getNext().getAsShopItem();
                        }
                        this.handleItem(menuInventory, gamer, storeCategory, list.indexOf(item), item, w);
                    } else {
                        menuInventory.setItem(w, new ItemBuilder().name(" ").type(Material.STAINED_GLASS_PANE).durability(15).build());
                    }
                    w = w % 9 == 7 ? (w += 3) : ++w;
                    ++var8_13;
                }
                break;
            }
            default: {
                void var8_15;
                int w = 19;
                boolean bl = false;
                while (var8_15 < list.size()) {
                    ShopCategory.ShopItem item = (ShopCategory.ShopItem)list.get((int)var8_15);
                    if (item.getStack().getType() == Material.GOLD_AXE) {
                        item = gamer.getAxeLevel().getNext().getAsShopItem();
                    } else if (item.getStack().getType() == Material.GOLD_PICKAXE) {
                        item = gamer.getPickaxeLevel().getNext().getAsShopItem();
                    }
                    this.handleItem(menuInventory, gamer, storeCategory, list.indexOf(item), item, w);
                    w = w % 9 == 7 ? (w += 3) : ++w;
                    ++var8_15;
                }
                break block0;
            }
        }
        menuInventory.open(player);
        new BukkitRunnable(){

            public void run() {
                player.updateInventory();
            }
        }.runTaskLater((Plugin)GameAPI.getInstance(), 1L);
    }

    public void handleItem(MenuInventory menuInventory, Gamer gamer, ShopCategory storeCategory, int index, ShopCategory.ShopItem shopItem, int slot) {
        menuInventory.setItem(slot, this.createItem(gamer.getPlayer(), shopItem), (p, inv, type, stack, s) -> {
            if (type == ClickType.SHIFT) {
                if (storeCategory == ShopCategory.FAVORITES) {
                    if (gamer.removeFavorite(shopItem)) {
                        p.sendMessage("\u00a7aO item " + ChatColor.stripColor((String)stack.getItemMeta().getDisplayName()) + " foi removido dos favoritos.");
                        new StoreInventory(p, storeCategory);
                    }
                } else {
                    new FavoriteConfigInventory(p, storeCategory, index, shopItem);
                }
            } else {
                this.buy(p, shopItem);
                new StoreInventory(p, storeCategory);
            }
        });
    }

    private ItemStack createItem(Player player, ShopCategory.ShopItem shopItem) {
        Language language = Language.getLanguage(player.getUniqueId());
        ItemBuilder itemBuilder = ItemBuilder.fromStack(shopItem.getStack()).name((player.getInventory().contains(shopItem.getPrice().getMaterial(), shopItem.getPrice().getAmount()) ? "\u00a7a" : "\u00a7c") + (shopItem.getStack().getItemMeta().hasDisplayName() ? shopItem.getStack().getItemMeta().getDisplayName() : language.t(shopItem.getStack().getType().name().toLowerCase().replace("_", "-"), new String[0]))).clearLore().flag(ItemFlag.HIDE_POTION_EFFECTS).lore("\u00a77Pre\u00e7o: \u00a77" + this.getColor(shopItem.getPrice().getMaterial()) + shopItem.getPrice().getAmount() + " " + language.t("bedwars.buy." + shopItem.getPrice().getMaterial().name().toLowerCase().replace("_", "-"), new String[0]));
        if (shopItem.getStack().getItemMeta().getLore() != null && !shopItem.getStack().getItemMeta().getLore().isEmpty()) {
            itemBuilder.lore(shopItem.getStack().getItemMeta().getLore());
        }
        itemBuilder.lore("").lore(language.t("bedwars.store-inventory." + shopItem.getStack().getType().name().toLowerCase().replace("_", "-") + ".description", new String[0]));
        return itemBuilder.build();
    }

    public ChatColor getColor(Material material) {
        return material.name().contains("EMERALD") ? ChatColor.DARK_GREEN : (material.name().contains("GOLD") ? ChatColor.GOLD : (material.name().contains("DIAMOND") ? ChatColor.AQUA : ChatColor.WHITE));
    }

    public void buy(Player player, ShopCategory.ShopItem shopItem) {
        if (player.getInventory().contains(shopItem.getPrice().getMaterial(), shopItem.getPrice().getAmount())) {
            GamerHelper.buyItem(player, shopItem);
        } else {
            player.sendMessage("\u00a7cVoc\u00ea n\u00e3o possui material suficiente.");
            player.playSound(player.getLocation(), Sound.NOTE_BASS, 1.0f, 1.0f);
        }
    }
}

