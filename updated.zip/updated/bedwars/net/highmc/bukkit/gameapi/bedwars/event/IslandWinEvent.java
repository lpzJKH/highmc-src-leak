/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.bukkit.gameapi.bedwars.event;

import net.highmc.bukkit.event.NormalEvent;
import net.highmc.bukkit.gameapi.bedwars.island.Island;

public class IslandWinEvent
extends NormalEvent {
    private Island island;

    public IslandWinEvent(Island island) {
        this.island = island;
    }

    public Island getIsland() {
        return this.island;
    }
}

