/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package net.highmc.bukkit.gameapi.bedwars.event.island;

import net.highmc.bukkit.event.NormalEvent;
import net.highmc.bukkit.gameapi.bedwars.island.Island;
import org.bukkit.entity.Player;

public class IslandBedBreakEvent
extends NormalEvent {
    private Player player;
    private Island island;

    public Player getPlayer() {
        return this.player;
    }

    public Island getIsland() {
        return this.island;
    }

    public IslandBedBreakEvent(Player player, Island island) {
        this.player = player;
        this.island = island;
    }
}

