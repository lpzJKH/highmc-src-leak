/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.md_5.bungee.api.chat.BaseComponent
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package net.highmc.bukkit.gameapi.bedwars.command;

import java.lang.invoke.LambdaMetafactory;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.function.Predicate;
import net.highmc.bukkit.command.BukkitCommandArgs;
import net.highmc.bukkit.gameapi.bedwars.GameMain;
import net.highmc.bukkit.gameapi.bedwars.generator.Generator;
import net.highmc.bukkit.gameapi.bedwars.generator.GeneratorType;
import net.highmc.bukkit.gameapi.bedwars.island.Island;
import net.highmc.bukkit.gameapi.bedwars.island.IslandColor;
import net.highmc.bukkit.gameapi.bedwars.island.IslandUpgrade;
import net.highmc.bukkit.gameapi.bedwars.menu.creator.IslandCreatorInventory;
import net.highmc.bukkit.member.BukkitMember;
import net.highmc.bukkit.utils.Location;
import net.highmc.bukkit.utils.item.ActionItemStack;
import net.highmc.bukkit.utils.item.ItemBuilder;
import net.highmc.command.CommandArgs;
import net.highmc.command.CommandClass;
import net.highmc.command.CommandFramework;
import net.highmc.utils.string.MessageBuilder;
import net.highmc.utils.string.StringFormat;
import net.md_5.bungee.api.chat.BaseComponent;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class ModeratorCommand
implements CommandClass {
    @CommandFramework.Command(name="start", permission="command.start")
    public void startCommand(BukkitCommandArgs cmdArgs) {
        if (GameMain.getInstance().getState().isPregame()) {
            GameMain.getInstance().setTimer(true);
            GameMain.getInstance().startGame();
        } else {
            cmdArgs.getSender().sendMessage("\u00a7cA partida j\u00e1 iniciou.");
        }
    }

    @CommandFramework.Command(name="setprotection", permission="command.island")
    public void setprotectionCommand(CommandArgs cmdArgs) {
        net.highmc.command.CommandSender sender = cmdArgs.getSender();
        String[] args = cmdArgs.getArgs();
        if (args.length == 0) {
            sender.sendMessage(" \u00a7a\u00bb \u00a7fUse \u00a7a/setprotection <double>\u00a7f para mudar a prote\u00e7\u00e3o.");
            return;
        }
        OptionalDouble optionalDouble = StringFormat.parseDouble(args[0]);
        if (!optionalDouble.isPresent()) {
            sender.sendMessage(sender.getLanguage().t("invalid-format-double", "%value%", args[0]));
            return;
        }
        GameMain.getInstance().setMinimunDistanceToPlaceBlocks(optionalDouble.getAsDouble());
        sender.sendMessage("\u00a7aA prote\u00e7\u00e3o de blocos das ilhas foi alterado para " + optionalDouble.getAsDouble() + ".");
    }

    /*
     * Unable to fully structure code
     */
    @CommandFramework.Command(name="island", permission="command.island")
    public void islandCommand(CommandArgs cmdArgs) {
        block36: {
            block35: {
                sender = cmdArgs.getSender();
                player = cmdArgs.getSenderAsMember(BukkitMember.class).getPlayer();
                args = cmdArgs.getArgs();
                if (args.length == 0) {
                    sender.sendMessage("\u00a7%command-island-usage%\u00a7");
                    return;
                }
                islandList = GameMain.getInstance().getConfiguration().getList("islands", Island.class);
                if (args.length != 1) break block35;
                if (args[0].equalsIgnoreCase("list")) {
                    return;
                }
                if (args[0].equalsIgnoreCase("save")) {
                    if (sender.isPlayer()) {
                        player.performCommand("config bedwars save");
                    } else {
                        Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), (String)"config bedwars save");
                    }
                    return;
                }
                iColor = null;
                try {
                    iColor = IslandColor.valueOf(args[0].toUpperCase());
                }
                catch (Exception ex) {
                    sender.sendMessage(sender.getLanguage().t("command-island-color-not-exist", new String[]{"%island%", args[0]}));
                    return;
                }
                islandColor = iColor;
                island = islandList.stream().filter((Predicate<Island>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Z, lambda$islandCommand$0(net.highmc.bukkit.gameapi.bedwars.island.IslandColor net.highmc.bukkit.gameapi.bedwars.island.Island ), (Lnet/highmc/bukkit/gameapi/bedwars/island/Island;)Z)((IslandColor)islandColor)).findFirst().orElse(null);
                if (island == null) {
                    sender.sendMessage(sender.getLanguage().t("command-island-island-not-exist", new String[]{"%island%", StringFormat.formatString(islandColor.name()), "%islandColor%", "\u00a7" + islandColor.getColor().getChar()}));
                    return;
                }
                sender.sendMessage("  \u00a7fIsland " + islandColor.getColor() + "\u00a7%" + islandColor.name().toLowerCase() + "-name%\u00a7");
                for (Field field : Island.class.getDeclaredFields()) {
                    try {
                        field.setAccessible(true);
                        sender.sendMessage("    \u00a7f" + field.getName() + ": " + field.get(island));
                    }
                    catch (IllegalAccessException | IllegalArgumentException e) {
                        e.printStackTrace();
                    }
                }
                break block36;
            }
            iColor = null;
            try {
                iColor = IslandColor.valueOf(args[0].toUpperCase());
            }
            catch (Exception ex) {
                sender.sendMessage(sender.getLanguage().t("command-island-color-not-exist", new String[]{"%island%", args[0]}));
                return;
            }
            islandColor = iColor;
            island = islandList.stream().filter((Predicate<Island>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Z, lambda$islandCommand$1(net.highmc.bukkit.gameapi.bedwars.island.IslandColor net.highmc.bukkit.gameapi.bedwars.island.Island ), (Lnet/highmc/bukkit/gameapi/bedwars/island/Island;)Z)((IslandColor)islandColor)).findFirst().orElse(null);
            if (!args[1].equalsIgnoreCase("create") && island == null) {
                sender.sendMessage("\u00a7%command-island-island-not-exist%\u00a7");
                return;
            }
            var9_15 = args[1].toLowerCase();
            var10_17 = -1;
            switch (var9_15.hashCode()) {
                case -1352294148: {
                    if (!var9_15.equals("create")) break;
                    var10_17 = 0;
                    break;
                }
                case 3108362: {
                    if (!var9_15.equals("edit")) break;
                    var10_17 = 1;
                    break;
                }
                case -469247465: {
                    if (!var9_15.equals("setlocation")) break;
                    var10_17 = 2;
                }
            }
            switch (var10_17) {
                case 0: {
                    if (islandList.stream().filter((Predicate<Island>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Z, lambda$islandCommand$2(net.highmc.bukkit.gameapi.bedwars.island.IslandColor net.highmc.bukkit.gameapi.bedwars.island.Island ), (Lnet/highmc/bukkit/gameapi/bedwars/island/Island;)Z)((IslandColor)islandColor)).findFirst().orElse(null) == null) {
                        islandToCreate = new Island(islandColor, new Location(), new Location(), new Location(), new Location(), new HashMap<Material, List<Location>>(), Island.IslandStatus.ALIVE, new ArrayList<Generator>(), new HashMap<IslandUpgrade, Integer>(), null);
                        islandList.add(islandToCreate);
                        sender.sendMessage(sender.getLanguage().t("command-island-created-success", new String[]{"%island%", StringFormat.formatString(islandToCreate.getIslandColor().name()), "%islandColor%", "\u00a7" + islandToCreate.getIslandColor().getColor().getChar()}));
                        if (sender.isPlayer()) {
                            player.getInventory().addItem(new ItemStack[]{this.createItem(sender, islandToCreate)});
                        }
                        break;
                    }
                    sender.sendMessage("\u00a7%command-island-island-already-exist%\u00a7");
                    break;
                }
                case 1: {
                    if (sender.isPlayer()) {
                        player.getInventory().addItem(new ItemStack[]{this.createItem(sender, island)});
                        break;
                    }
                    sender.sendMessage("\u00a7%command-only-for-player%\u00a7");
                    break;
                }
                case 2: {
                    fieldName = args[2];
                    field = null;
                    for (Field f : Island.class.getDeclaredFields()) {
                        if (!f.getName().equalsIgnoreCase(fieldName)) continue;
                        field = f;
                    }
                    if (field == null) {
                        sender.sendMessage(sender.getLanguage().t("command-island-field-not-exist", new String[]{"%field%", fieldName}));
                        break;
                    }
                    location = null;
                    if (args.length < 6) ** GOTO lbl109
                    optionalX = StringFormat.parseDouble(args[3]);
                    optionalY = StringFormat.parseDouble(args[4]);
                    optionalZ = StringFormat.parseDouble(args[5]);
                    if (optionalX.isPresent() && optionalY.isPresent() && optionalZ.isPresent()) {
                        location = new Location((cmdArgs.isPlayer() != false ? player.getLocation().getWorld() : (World)Bukkit.getWorlds().stream().findFirst().orElse(null)).getName(), optionalX.getAsDouble(), optionalY.getAsDouble(), optionalZ.getAsDouble());
                    } else {
                        sender.sendMessage("\u00a7%number-format%\u00a7");
                        return;
lbl109:
                        // 1 sources

                        if (sender.isPlayer()) {
                            location = Location.fromLocation(player.getLocation());
                        } else {
                            sender.sendMessage("\u00a7%command-only-for-player%\u00a7");
                            return;
                        }
                    }
                    try {
                        field.setAccessible(true);
                        field.set(island, location);
                        sender.sendMessage("\u00a7aLocaliza\u00e7\u00e3o atualizada.");
                    }
                    catch (IllegalAccessException | IllegalArgumentException e) {
                        sender.sendMessage("\u00a7%command-island-not-loaded-location%\u00a7");
                        e.printStackTrace();
                    }
                    break;
                }
            }
        }
    }

    private ItemStack createItem(net.highmc.command.CommandSender sender, final Island islandToCreate) {
        return new ActionItemStack(new ItemBuilder().name(sender.getLanguage().t("bedwars.creator.item-name", "%island%", StringFormat.formatString(islandToCreate.getIslandColor().name()), "%islandColor%", "\u00a7" + islandToCreate.getIslandColor().getColor().getChar())).type(Material.BARRIER).build(), new ActionItemStack.Interact(){

            @Override
            public boolean onInteract(Player player, Entity entity, Block block, ItemStack item, ActionItemStack.ActionType action) {
                new IslandCreatorInventory(player, islandToCreate);
                return true;
            }
        }).getItemStack();
    }

    @CommandFramework.Command(name="generator", permission="command.generator")
    public void generatorCommand(CommandArgs cmdArgs) {
        net.highmc.command.CommandSender sender = cmdArgs.getSender();
        Player player = cmdArgs.getSenderAsMember(BukkitMember.class).getPlayer();
        String[] args = cmdArgs.getArgs();
        if (args.length == 0) {
            this.handleGeneratorUsage(sender);
            return;
        }
        switch (args[0].toLowerCase()) {
            case "list": {
                sender.sendMessage("  \u00a7aLista de Geradores");
                for (GeneratorType generatorType : GeneratorType.values()) {
                    List<Generator> generators = GameMain.getInstance().getGeneratorManager().getGenerators(generatorType);
                    if (generators == null) continue;
                    sender.sendMessage("    \u00a7fGeradores de " + generatorType.getColor() + generatorType.name());
                    for (int index = 0; index < generators.size(); ++index) {
                        Generator generator = generators.get(index);
                        MessageBuilder messageBuilder = new MessageBuilder("      \u00a7fGerador " + (index + 1)).setClickEvent("/" + cmdArgs.getLabel() + " " + generatorType.name() + " " + (index + 1));
                        sender.sendMessage((BaseComponent)messageBuilder.create());
                        sender.sendMessage((BaseComponent)messageBuilder.setMessage("        \u00a7fLocation: \u00a77" + generator.getLocation().getX() + ", " + generator.getLocation().getY() + ", " + generator.getLocation().getZ()).create());
                    }
                }
                break;
            }
            default: {
                GeneratorType generatorType = null;
                try {
                    generatorType = GeneratorType.valueOf(args[0].toUpperCase());
                }
                catch (Exception ex) {
                    sender.sendMessage("\u00a7cO generador n\u00e3o existe.");
                    return;
                }
                if (args.length == 2) {
                    if (args[1].equalsIgnoreCase("create")) {
                        if (sender.isPlayer()) {
                            GameMain.getInstance().getGeneratorManager().createGenerator(generatorType, Location.fromLocation(player.getLocation()), true);
                            sender.sendMessage("\u00a7aO jogador de " + generatorType.name() + " foi criado com sucesso.");
                            break;
                        }
                        sender.sendMessage("\u00a7%command-only-for-player%\u00a7");
                        break;
                    }
                    OptionalInt parseInt = StringFormat.parseInt(args[2]);
                    if (parseInt.isPresent()) {
                        Generator generator = GameMain.getInstance().getGeneratorManager().getGenerator(generatorType, parseInt.getAsInt());
                        if (generator == null) {
                            sender.sendMessage("\u00a7cNenhum gerador encontrado.");
                            break;
                        }
                        sender.sendMessage("  Gerador " + (parseInt.getAsInt() + 1));
                        sender.sendMessage("    Location: \u00a77" + generator.getLocation().getX() + ", " + generator.getLocation().getY() + ", " + generator.getLocation().getZ());
                        sender.sendMessage("    Level: " + generator.getLevel());
                        sender.sendMessage("    Time: " + generator.getGenerateTime() / 1000L);
                        break;
                    }
                    this.handleGeneratorUsage(sender);
                    break;
                }
                if (args.length >= 3) {
                    if (args[1].equalsIgnoreCase("setlocation")) {
                        if (sender.isPlayer()) {
                            OptionalInt parseInt = StringFormat.parseInt(args[2]);
                            if (parseInt.isPresent()) {
                                if (GameMain.getInstance().getGeneratorManager().setLocation(generatorType, parseInt.getAsInt() - 1, Location.fromLocation(player.getLocation()), true)) {
                                    sender.sendMessage("localizacao atulaizada.");
                                    break;
                                }
                                sender.sendMessage("\u00a7cNenhum gerador encontrado.");
                                break;
                            }
                            sender.sendMessage("\u00a7%number-format%\u00a7");
                            break;
                        }
                        sender.sendMessage("\u00a7%command-only-for-player%\u00a7");
                        break;
                    }
                    this.handleGeneratorUsage(sender);
                    break;
                }
                this.handleGeneratorUsage(sender);
                break;
            }
        }
    }

    @CommandFramework.Completer(name="island")
    public List<String> islandCompleter(CommandArgs cmdArgs) {
        ArrayList<String> list;
        block4: {
            String[] args;
            block5: {
                block3: {
                    args = cmdArgs.getArgs();
                    list = new ArrayList<String>();
                    if (args.length != 1) break block3;
                    for (IslandColor color : IslandColor.values()) {
                        if (!color.name().toLowerCase().startsWith(args[0].toLowerCase())) continue;
                        list.add(color.name());
                    }
                    break block4;
                }
                if (args.length != 2) break block5;
                for (String completer : Arrays.asList("create", "edit", "setlocation")) {
                    if (!completer.toLowerCase().startsWith(args[1].toLowerCase())) continue;
                    list.add(completer);
                }
                break block4;
            }
            if (args.length != 3 || !args[1].equalsIgnoreCase("setlocation")) break block4;
            for (Field field : Island.class.getDeclaredFields()) {
                if (!field.getName().toLowerCase().startsWith(args[2].toLowerCase()) || !field.getName().toLowerCase().contains("location")) continue;
                list.add(field.getName());
            }
        }
        return list;
    }

    private void handleGeneratorUsage(net.highmc.command.CommandSender sender) {
        sender.sendMessage("generator list");
        sender.sendMessage("generator <type> create");
        sender.sendMessage("generator <type> setlocation <index>");
    }

    private static /* synthetic */ boolean lambda$islandCommand$2(IslandColor islandColor, Island i) {
        return i.getIslandColor() == islandColor;
    }

    private static /* synthetic */ boolean lambda$islandCommand$1(IslandColor islandColor, Island i) {
        return i.getIslandColor() == islandColor;
    }

    private static /* synthetic */ boolean lambda$islandCommand$0(IslandColor islandColor, Island i) {
        return i.getIslandColor() == islandColor;
    }
}

