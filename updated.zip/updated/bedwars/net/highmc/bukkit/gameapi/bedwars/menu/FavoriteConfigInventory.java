/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package net.highmc.bukkit.gameapi.bedwars.menu;

import net.highmc.bukkit.gameapi.bedwars.store.ShopCategory;
import org.bukkit.entity.Player;

public class FavoriteConfigInventory {
    public FavoriteConfigInventory(Player player, ShopCategory storeCategory, int index, ShopCategory.ShopItem shopItem) {
    }
}

