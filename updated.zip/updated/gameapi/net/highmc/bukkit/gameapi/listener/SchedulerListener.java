/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 */
package net.highmc.bukkit.gameapi.listener;

import net.highmc.bukkit.event.UpdateEvent;
import net.highmc.bukkit.gameapi.GameAPI;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

public class SchedulerListener
implements Listener {
    @EventHandler
    public void update(UpdateEvent event) {
        if (event.getType() == UpdateEvent.UpdateType.SECOND) {
            GameAPI.getInstance().getSchedulerManager().pulse();
        }
    }
}

