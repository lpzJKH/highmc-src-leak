/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.bukkit.gameapi.command;

import net.highmc.bukkit.gameapi.GameAPI;
import net.highmc.command.CommandArgs;
import net.highmc.command.CommandClass;
import net.highmc.command.CommandFramework;
import net.highmc.command.CommandSender;
import net.highmc.utils.DateUtils;
import net.highmc.utils.string.StringFormat;

public class ModeradorCommand
implements CommandClass {
    @CommandFramework.Command(name="time", aliases={"tempo"}, permission="command.time")
    public void timeCommand(CommandArgs cmdArgs) {
        long time;
        CommandSender sender = cmdArgs.getSender();
        String[] args = cmdArgs.getArgs();
        if (args.length == 0) {
            sender.sendMessage(sender.getLanguage().t("command-time-usage", "%label%", cmdArgs.getLabel()));
            return;
        }
        if (args[0].equalsIgnoreCase("stop")) {
            GameAPI.getInstance().setTimer(!GameAPI.getInstance().isTimer());
            GameAPI.getInstance().setConsoleControl(false);
            sender.sendMessage("\u00a7%command-time-timer-" + (GameAPI.getInstance().isTimer() ? "enabled" : "disabled") + "%\u00a7");
            return;
        }
        try {
            time = DateUtils.parseDateDiff(args[0], true);
        }
        catch (Exception e) {
            sender.sendMessage(sender.getLanguage().t("number-format-invalid", "%number%", args[0]));
            return;
        }
        int seconds = (int)Math.floor((time - System.currentTimeMillis()) / 1000L);
        if (seconds >= 7200) {
            seconds = 7200;
        }
        sender.sendMessage(sender.getLanguage().t("command-time-changed", "%time%", StringFormat.formatTime(seconds, StringFormat.TimeFormat.NORMAL)));
        GameAPI.getInstance().setTime(seconds);
    }
}

