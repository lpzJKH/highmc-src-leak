/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.bukkit.gameapi.scheduler;

public interface Scheduler {
    public void pulse();
}

