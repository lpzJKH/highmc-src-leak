/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.bukkit.gameapi.event;

import net.highmc.bukkit.event.NormalEvent;
import net.highmc.server.loadbalancer.server.MinigameState;

public class GameStateChangeEvent
extends NormalEvent {
    private MinigameState oldState;
    private MinigameState state;

    public MinigameState getOldState() {
        return this.oldState;
    }

    public MinigameState getState() {
        return this.state;
    }

    public GameStateChangeEvent(MinigameState oldState, MinigameState state) {
        this.oldState = oldState;
        this.state = state;
    }
}

