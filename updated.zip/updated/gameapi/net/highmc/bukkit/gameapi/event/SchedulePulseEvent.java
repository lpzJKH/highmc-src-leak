/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.bukkit.gameapi.event;

import net.highmc.bukkit.event.NormalEvent;

public class SchedulePulseEvent
extends NormalEvent {
}

