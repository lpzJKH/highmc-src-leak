/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.bukkit.gameapi.backend;

import java.util.Optional;
import java.util.UUID;
import net.highmc.bukkit.gameapi.gamer.Gamer;

public interface GamerData {
    public <T extends Gamer> Optional<T> loadGamer(UUID var1);

    public void createGamer(Gamer var1);

    public void saveGamer(Gamer var1, String var2);
}

