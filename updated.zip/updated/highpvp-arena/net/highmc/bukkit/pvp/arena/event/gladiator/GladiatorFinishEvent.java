/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package net.highmc.bukkit.pvp.arena.event.gladiator;

import net.highmc.bukkit.event.PlayerCancellableEvent;
import org.bukkit.entity.Player;

public class GladiatorFinishEvent
extends PlayerCancellableEvent {
    public GladiatorFinishEvent(Player challenger, Player challenged) {
        super(challenger);
    }
}

