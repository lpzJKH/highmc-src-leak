/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.md_5.bungee.api.plugin.Event
 */
package net.highmc.bungee.event.player;

import net.highmc.command.CommandSender;
import net.highmc.member.Member;
import net.highmc.punish.Punish;
import net.md_5.bungee.api.plugin.Event;

public class PlayerPardonedEvent
extends Event {
    private Member punished;
    private Punish punish;
    private CommandSender sender;

    public Member getPunished() {
        return this.punished;
    }

    public Punish getPunish() {
        return this.punish;
    }

    public CommandSender getSender() {
        return this.sender;
    }

    public PlayerPardonedEvent(Member punished, Punish punish, CommandSender sender) {
        this.punished = punished;
        this.punish = punish;
        this.sender = sender;
    }
}

