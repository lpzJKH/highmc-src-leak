/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.md_5.bungee.api.CommandSender
 *  net.md_5.bungee.api.connection.ProxiedPlayer
 */
package net.highmc.bungee.command;

import net.highmc.CommonPlugin;
import net.highmc.bungee.BungeeConst;
import net.highmc.bungee.member.BungeeMember;
import net.highmc.command.CommandArgs;
import net.highmc.member.Member;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.connection.ProxiedPlayer;

public class BungeeCommandArgs
extends CommandArgs {
    protected BungeeCommandArgs(CommandSender sender, String label, String[] args, int subCommand) {
        super(sender instanceof ProxiedPlayer ? CommonPlugin.getInstance().getMemberManager().getMember(((ProxiedPlayer)sender).getUniqueId()) : BungeeConst.CONSOLE_SENDER, label, args, subCommand);
    }

    @Override
    public boolean isPlayer() {
        return this.getSender() instanceof Member;
    }

    public ProxiedPlayer getPlayer() {
        if (!this.isPlayer()) {
            return null;
        }
        return ((BungeeMember)this.getSender()).getProxiedPlayer();
    }
}

