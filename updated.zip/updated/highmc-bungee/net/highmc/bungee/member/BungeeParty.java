/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.bungee.member;

import java.util.UUID;
import net.highmc.member.Member;
import net.highmc.member.party.Party;

public class BungeeParty
extends Party {
    public BungeeParty(UUID partyId, Member member) {
        super(partyId, member);
    }
}

