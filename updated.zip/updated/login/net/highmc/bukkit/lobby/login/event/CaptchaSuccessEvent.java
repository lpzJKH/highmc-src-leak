/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package net.highmc.bukkit.lobby.login.event;

import net.highmc.bukkit.event.PlayerCancellableEvent;
import org.bukkit.entity.Player;

public class CaptchaSuccessEvent
extends PlayerCancellableEvent {
    public CaptchaSuccessEvent(Player player) {
        super(player);
    }
}

