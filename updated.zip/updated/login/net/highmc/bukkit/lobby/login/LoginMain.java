/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.event.Listener
 *  org.bukkit.plugin.Plugin
 */
package net.highmc.bukkit.lobby.login;

import net.highmc.bukkit.lobby.CoreMain;
import net.highmc.bukkit.lobby.login.listener.PlayerListener;
import net.highmc.bukkit.lobby.login.listener.ScoreboardListener;
import org.bukkit.Bukkit;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;

public class LoginMain
extends CoreMain {
    @Override
    public void onEnable() {
        super.onEnable();
        Bukkit.getPluginManager().registerEvents((Listener)new PlayerListener(), (Plugin)this);
        Bukkit.getPluginManager().registerEvents((Listener)new ScoreboardListener(), (Plugin)this);
        this.setMaxPlayers(6);
        this.setPlayerInventory(player -> {});
    }
}

