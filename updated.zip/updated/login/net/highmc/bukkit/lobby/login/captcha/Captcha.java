/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package net.highmc.bukkit.lobby.login.captcha;

import net.highmc.utils.Callback;
import org.bukkit.entity.Player;

public interface Captcha {
    public void verify(Player var1, Callback<Boolean> var2);
}

