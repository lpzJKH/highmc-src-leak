/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.ItemStack
 */
package net.highmc.bukkit.utils.menu.click;

import net.highmc.bukkit.utils.menu.click.ClickType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public interface MenuClickHandler {
    public void onClick(Player var1, Inventory var2, ClickType var3, ItemStack var4, int var5);
}

