/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.bukkit.utils.menu.click;

public enum ClickType {
    LEFT,
    RIGHT,
    SHIFT;

}

