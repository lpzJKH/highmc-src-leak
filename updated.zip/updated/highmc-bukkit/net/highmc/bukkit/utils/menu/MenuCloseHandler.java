/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package net.highmc.bukkit.utils.menu;

import org.bukkit.entity.Player;

public interface MenuCloseHandler {
    public void onClose(Player var1);
}

