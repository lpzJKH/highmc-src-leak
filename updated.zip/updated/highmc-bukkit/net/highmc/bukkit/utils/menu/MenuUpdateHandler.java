/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package net.highmc.bukkit.utils.menu;

import net.highmc.bukkit.utils.menu.MenuInventory;
import org.bukkit.entity.Player;

public interface MenuUpdateHandler {
    public void onUpdate(Player var1, MenuInventory var2);
}

