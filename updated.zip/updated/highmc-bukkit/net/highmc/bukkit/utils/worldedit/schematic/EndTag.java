/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.bukkit.utils.worldedit.schematic;

import net.highmc.bukkit.utils.worldedit.schematic.Tag;

public final class EndTag
extends Tag {
    public EndTag() {
        super("");
    }

    @Override
    public Object getValue() {
        return null;
    }

    public String toString() {
        return "TAG_End";
    }
}

