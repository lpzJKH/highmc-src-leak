/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.bukkit.utils.worldedit.schematic;

import net.highmc.bukkit.utils.worldedit.schematic.Tag;

public final class LongTag
extends Tag {
    private final long value;

    public LongTag(String name, long value) {
        super(name);
        this.value = value;
    }

    @Override
    public Long getValue() {
        return this.value;
    }

    public String toString() {
        String name = this.getName();
        String append = "";
        if (name != null && !name.equals("")) {
            append = "(\"" + this.getName() + "\")";
        }
        return "TAG_Long" + append + ": " + this.value;
    }
}

