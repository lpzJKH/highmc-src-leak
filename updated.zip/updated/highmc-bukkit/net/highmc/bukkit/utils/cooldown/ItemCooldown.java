/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.inventory.ItemStack
 */
package net.highmc.bukkit.utils.cooldown;

import net.highmc.bukkit.utils.cooldown.Cooldown;
import org.bukkit.inventory.ItemStack;

public class ItemCooldown
extends Cooldown {
    private ItemStack item;
    private boolean selected;

    public ItemCooldown(ItemStack item, String name, Long duration) {
        super(name, duration);
        this.item = item;
    }

    public ItemStack getItem() {
        return this.item;
    }

    public boolean isSelected() {
        return this.selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }
}

