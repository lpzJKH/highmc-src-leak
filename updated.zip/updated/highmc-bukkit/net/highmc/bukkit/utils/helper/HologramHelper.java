/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 */
package net.highmc.bukkit.utils.helper;

import net.highmc.bukkit.BukkitCommon;
import net.highmc.bukkit.utils.hologram.Hologram;
import net.highmc.bukkit.utils.hologram.HologramBuilder;
import net.highmc.bukkit.utils.hologram.impl.SimpleHologram;
import org.bukkit.Location;

public class HologramHelper {
    public static Hologram createHologram(String text, Location location) {
        return BukkitCommon.getInstance().getHologramManager().createHologram(new HologramBuilder().setDisplayName(text).setLocation(location).setHologramClass(SimpleHologram.class));
    }

    public static Hologram createHologram(Hologram hologram) {
        return BukkitCommon.getInstance().getHologramManager().createHologram(hologram);
    }
}

