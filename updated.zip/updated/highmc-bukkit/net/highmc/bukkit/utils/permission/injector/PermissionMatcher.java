/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.bukkit.utils.permission.injector;

public interface PermissionMatcher {
    public boolean isMatches(String var1, String var2);
}

