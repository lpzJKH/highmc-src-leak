/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.bukkit.member.party;

import java.util.UUID;
import net.highmc.member.Member;
import net.highmc.member.party.Party;

public class BukkitParty
extends Party {
    public BukkitParty(UUID partyId, Member member) {
        super(partyId, member);
    }
}

