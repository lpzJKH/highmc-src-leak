/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.bukkit.anticheat.hack;

import net.highmc.bukkit.anticheat.gamer.UserData;
import net.highmc.bukkit.anticheat.hack.HackType;

public class HackData {
    private HackType hackType;
    private long lastNotify;
    private int times;

    public HackData(HackType hackType, UserData userData) {
        this.hackType = hackType;
        this.lastNotify = System.currentTimeMillis();
    }

    public void addTimes() {
        ++this.times;
        this.lastNotify = System.currentTimeMillis();
    }

    public HackType getHackType() {
        return this.hackType;
    }

    public long getLastNotify() {
        return this.lastNotify;
    }

    public int getTimes() {
        return this.times;
    }
}

