/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.bukkit.anticheat.hack.verify;

import net.highmc.bukkit.anticheat.hack.HackType;
import net.highmc.bukkit.anticheat.hack.Verify;

public class KillauraCheck
implements Verify {
    @Override
    public HackType getHackType() {
        return HackType.KILLAURA;
    }
}

