/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package net.highmc.bukkit.command;

import net.highmc.BukkitConst;
import net.highmc.CommonPlugin;
import net.highmc.bukkit.member.BukkitMember;
import net.highmc.command.CommandArgs;
import net.highmc.member.Member;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BukkitCommandArgs
extends CommandArgs {
    protected BukkitCommandArgs(CommandSender sender, String label, String[] args, int subCommand) {
        super(sender instanceof Player ? CommonPlugin.getInstance().getMemberManager().getMember(((Player)sender).getUniqueId()) : BukkitConst.CONSOLE_SENDER, label, args, subCommand);
    }

    @Override
    public boolean isPlayer() {
        return this.getSender() instanceof Member;
    }

    public BukkitMember getSenderAsBukkitMember() {
        return (BukkitMember)BukkitMember.class.cast(this.getSender());
    }

    public Player getPlayer() {
        if (!this.isPlayer()) {
            return null;
        }
        return ((BukkitMember)this.getSender()).getPlayer();
    }
}

