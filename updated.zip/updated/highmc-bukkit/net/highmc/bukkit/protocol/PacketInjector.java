/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.plugin.Plugin
 */
package net.highmc.bukkit.protocol;

import org.bukkit.plugin.Plugin;

public interface PacketInjector {
    public void inject(Plugin var1);
}

