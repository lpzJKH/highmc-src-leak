/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package net.highmc.bukkit.event.player;

import net.highmc.bukkit.event.PlayerCancellableEvent;
import org.bukkit.entity.Player;

public class PlayerDamagePlayerEvent
extends PlayerCancellableEvent {
    private Player damager;
    private double damage;
    private double finalDamage;

    public PlayerDamagePlayerEvent(Player entity, Player damager, boolean cancelled, double damage, double finalDamage) {
        super(entity);
        this.setCancelled(cancelled);
        this.damager = damager;
        this.damage = damage;
        this.finalDamage = finalDamage;
    }

    public void setDamage(double damage) {
        this.damage = damage;
    }

    public Player getDamager() {
        return this.damager;
    }

    public double getDamage() {
        return this.damage;
    }

    public double getFinalDamage() {
        return this.finalDamage;
    }
}

