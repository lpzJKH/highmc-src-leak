/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package net.highmc.bukkit.event.member;

import net.highmc.bukkit.event.PlayerCancellableEvent;
import net.highmc.member.Member;
import net.highmc.permission.Tag;
import org.bukkit.entity.Player;

public class PlayerChangedTagEvent
extends PlayerCancellableEvent {
    private Member member;
    private Tag oldTag;
    private Tag newTag;
    private boolean forced;

    public PlayerChangedTagEvent(Player player, Member member, Tag oldTag, Tag newTag, boolean forced) {
        super(player);
        this.member = member;
        this.oldTag = oldTag;
        this.newTag = newTag;
        this.forced = forced;
    }

    public Member getMember() {
        return this.member;
    }

    public Tag getOldTag() {
        return this.oldTag;
    }

    public Tag getNewTag() {
        return this.newTag;
    }

    public boolean isForced() {
        return this.forced;
    }

    public void setNewTag(Tag newTag) {
        this.newTag = newTag;
    }
}

