/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package net.highmc.bukkit.event.member;

import net.highmc.bukkit.event.PlayerEvent;
import net.highmc.member.Member;
import org.bukkit.entity.Player;

public class PlayerAuthEvent
extends PlayerEvent {
    private Member member;

    public PlayerAuthEvent(Player player, Member member) {
        super(player);
        this.member = member;
    }

    public Member getMember() {
        return this.member;
    }
}

