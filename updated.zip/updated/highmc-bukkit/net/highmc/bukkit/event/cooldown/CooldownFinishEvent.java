/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package net.highmc.bukkit.event.cooldown;

import net.highmc.bukkit.event.cooldown.CooldownStopEvent;
import net.highmc.bukkit.utils.cooldown.Cooldown;
import org.bukkit.entity.Player;

public class CooldownFinishEvent
extends CooldownStopEvent {
    public CooldownFinishEvent(Player player, Cooldown cooldown) {
        super(player, cooldown);
    }
}

