/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package net.highmc.bukkit.event;

import net.highmc.bukkit.event.NormalEvent;
import org.bukkit.entity.Player;

public class PlayerEvent
extends NormalEvent {
    private Player player;

    public PlayerEvent(Player player) {
        this.player = player;
    }

    public Player getPlayer() {
        return this.player;
    }
}

