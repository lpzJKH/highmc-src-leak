/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.bukkit.event.server;

import net.highmc.bukkit.event.NormalEvent;
import net.highmc.packet.Packet;
import net.highmc.packet.PacketType;

public class ServerPacketReceiveEvent
extends NormalEvent {
    private PacketType packetType;
    private Packet packet;

    public ServerPacketReceiveEvent(PacketType packetType, Packet packet) {
        this.packetType = packetType;
        this.packet = packet;
    }

    public PacketType getPacketType() {
        return this.packetType;
    }

    public Packet getPacket() {
        return this.packet;
    }
}

