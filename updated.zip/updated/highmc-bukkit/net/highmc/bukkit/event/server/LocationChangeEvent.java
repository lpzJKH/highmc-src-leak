/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 */
package net.highmc.bukkit.event.server;

import net.highmc.bukkit.event.NormalEvent;
import org.bukkit.Location;

public class LocationChangeEvent
extends NormalEvent {
    private String configName;
    private Location newLocation;
    private Location oldLocation;

    public String getConfigName() {
        return this.configName;
    }

    public Location getNewLocation() {
        return this.newLocation;
    }

    public Location getOldLocation() {
        return this.oldLocation;
    }

    public LocationChangeEvent(String configName, Location newLocation, Location oldLocation) {
        this.configName = configName;
        this.newLocation = newLocation;
        this.oldLocation = oldLocation;
    }
}

