/*
 * Decompiled with CFR 0.152.
 */
package net.highmc.bukkit.event.server;

import net.highmc.bukkit.event.NormalEvent;

public class PlayerChangeEvent
extends NormalEvent {
    private int totalMembers;

    public int getTotalMembers() {
        return this.totalMembers;
    }

    public PlayerChangeEvent(int totalMembers) {
        this.totalMembers = totalMembers;
    }
}

